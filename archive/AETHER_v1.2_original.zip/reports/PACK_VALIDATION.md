# AETHER V1.2 GitHub 生态补充：打包检查与真实限制

**2026-10-15。提供的是设计、对照实验合同和本地规格测试，不是正在运行的 agent 或 80 个仓库的兼容性认证。** 维持 v1.1 全量设计与已通过参考测试。

本次纳入 81 条候选条目（80个独立仓库），文档 `docs/14_ecosystem_audit.md` 将其按 tier 分组；`docs/15_ecosystem_integration.md` 定义插拔接口。追加 10 个 optional 实施任务与 10 个开发场景；含 V1.1 共 73 张票；新增 11 个只验证设计清单/策略的本地测试，合计 84 个参考/策略用例。**所有新增候选 production_enabled=false, dependency_probed=false, immutable_revision=null。**

之前验证的 49 个 V1.1 来源和 23 个主清单条目仍保留；新研究条目见第二清单，不能算作全部通过固定包版本确认。未执行真实 Hindsight/CodeGraph/Crawl4AI/agent-browser/Temporal/OpenHands/Docker/付费模型/benchmark 对照。**不能据此声称超过 Hermes。**

## 实际验证

实际运行：`python -m unittest discover -s tests -v` **84/84 PASS**；`python scripts/verify_pack.py` **PASS（466 项结构检查）**；`python -m compileall -q reference contracts scripts tests` **退出代码 0**。日志保存于 `reports/reference-tests-v1.2.log`、`reports/pack-verification-v1.2.log`，机器摘要在 `reports/pack-validation-v1.2.json`。这些都是本地规格/纯逻辑测试，**不是第三方集成测试**。

> 安全补充：已知有代码仓库使用非商业/AGPL/GPL/ELv2/商业特性许可，真正复制、分发和线上服务之前必须按固定 revision 做合规检查。

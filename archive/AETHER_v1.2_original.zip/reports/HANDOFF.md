# Initial handoff to Codex

Product implementation has not started. This pack contains a complete V1 design, machine contracts, configuration targets, a task queue, public development cases and tested pure reference logic.

Next action: read AGENTS.md and execute M00-01. Install/probe only authorized dependencies; do not assume a source snapshot is a deployable compatibility lock. Build independent code while unavailable Docker/model-key checks are marked blocked.

64 reference unittest methods passed in the preparation environment. No PostgreSQL, Temporal, OpenHands, browser, live-model or Hermes comparison test was executed here. See PACK_VALIDATION.md for the actual check scope.

Update this file with exact commands, test evidence, changed paths, blockers and the next concrete action before every context handoff. Do not replace this task with another architecture discussion.

## 2026-10-15 package revision v1.1 (CodeGraph)
New specification-only work: `docs/13_codegraph.md`, optional runtime feature `config/codegraph.example.yaml`, `contracts/codegraph.schema.json`, repo/tool inventory updates, and M00-06/M05-06/M10-06 tickets. No CodeGraph binary was downloaded, started, installed or connected to Codex. Treat feature as disabled until a pinned revision passes M00. Refer to new structural/unit validation report for this package version. Product implementation remains not started.

## V1.2 生态审计增补（设计，并非已实施）
阅读 `CODEX_ECOSYSTEM_UPDATE.md`。81个候选不自动安装；10个新 optional 任务沿用 M00-M11。新任务最先 M00-07 审选中项目的许可证和 SHA，然后进行独立 eval/redteam 与互斥记忆、采集、浏览器、学习对照。所有新 feature flags disabled；live 上游 probes not_run。

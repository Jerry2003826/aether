"""Offline specification/allowlist checks only. No upstream packages/network/model are exercised."""
import json
from pathlib import Path
import unittest
import yaml

ROOT=Path(__file__).resolve().parents[1]
CAT=yaml.safe_load((ROOT/'config/ecosystem_candidates.yaml').read_text())['candidates']
CONF=yaml.safe_load((ROOT/'config/ecosystem_experiments.example.yaml').read_text())
BACKLOG=yaml.safe_load((ROOT/'tasks/backlog.yaml').read_text())

class EcosystemPolicyTests(unittest.TestCase):
    def test_catalog_coverage(self):
        self.assertEqual(len(CAT),81)
        self.assertEqual(len({x['repo'] for x in CAT}),80)

    def test_all_urls_are_github(self):
        self.assertTrue(all(x['url']=='https://github.com/'+x['repo'] for x in CAT))

    def test_ids_unique(self):
        self.assertEqual(len(CAT),len({x['id'] for x in CAT}))

    def test_all_candidates_off(self):
        self.assertTrue(all(x['production_enabled'] is False and x['dependency_probed'] is False for x in CAT))

    def test_unverified_revision_not_pretended(self):
        self.assertTrue(all(x['immutable_revision'] is None for x in CAT))

    def test_restricted_licenses_not_adopted(self):
        for slug in ('abhigyanpatwari/GitNexus','volcengine/OpenViking','oraios/serena'):
            hit=next(x for x in CAT if x['repo']==slug)
            self.assertIn(hit['tier'],('reference','watch','reject'))
        gitnexus=next(x for x in CAT if x['repo']=='abhigyanpatwari/GitNexus')
        self.assertIn('Noncommercial',gitnexus['license_observed'])

    def test_feature_flags_and_license_rules(self):
        self.assertEqual(CONF['default'],'disabled')
        self.assertTrue(CONF['policy']['license_gate_required'])
        self.assertTrue(CONF['policy']['private_dataset_never_sent_to_vendor'])
        self.assertFalse(CONF['policy']['no_automatic_skill_promotion'] is False)

    def test_no_second_orchestrator(self):
        names=[x['repo'] for x in CAT if x['tier']=='core-existing' and x['category']=='编排与执行']
        self.assertIn('temporalio/temporal',names)
        self.assertNotIn('langchain-ai/deepagents',names)

    def test_new_optional_tasks_linked(self):
        actual={x['id'] for x in BACKLOG['tickets'] if x['id'] in { 'M00-07','M04-06','M05-07','M05-08','M06-06','M08-06','M10-07','M10-08','M10-09','M11-06'}}
        self.assertEqual(len(actual),10)
        for t in BACKLOG['tickets']:
            if t['id'] in actual:self.assertIs(t['mandatory'],False)

    def test_evaluation_scenarios_not_claimed_executed(self):
        cases=[json.loads(l) for l in (ROOT/'evals/ecosystem_public_cases.jsonl').read_text().splitlines()]
        self.assertEqual(len(cases),10)
        self.assertTrue(all(x['status']=='not_run' for x in cases))

    def test_exclusive_memory_engine(self):
        conf=CONF['slots']['memory']
        self.assertEqual(conf['active'],'aether_native')
        self.assertEqual(set(conf['candidates']),{'hindsight','mem0','cognee'})

if __name__=='__main__':unittest.main()

"""Pure specification-policy checks. Does NOT exercise upstream CodeGraph."""
import json
from pathlib import Path, PurePosixPath
import unittest
import jsonschema

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = json.loads((ROOT / 'contracts/codegraph.schema.json').read_text())
FIXTURE = json.loads((ROOT / 'fixtures/codegraph_result.json').read_text())
VALIDATOR = jsonschema.Draft202012Validator({'$defs': SCHEMA['$defs'], '$ref':'#/$defs/CodeContextResult'})

class TestCodeGraphSpecification(unittest.TestCase):
    def test_valid_synthetic_fixture(self):
        VALIDATOR.validate(FIXTURE)

    def test_missing_snapshot_hash_rejected(self):
        broken = dict(FIXTURE); broken.pop('snapshot_sha256')
        self.assertFalse(VALIDATOR.is_valid(broken))

    def test_untrusted_tool_cannot_add_project_path_field(self):
        broken = dict(FIXTURE); broken['projectPath'] = '/home/user/private'
        self.assertFalse(VALIDATOR.is_valid(broken))

    def test_traversal_rejected_in_symbol_path(self):
        broken = json.loads(json.dumps(FIXTURE))
        broken['symbols'][0]['relative_path'] = '../secrets.txt'
        self.assertFalse(VALIDATOR.is_valid(broken))

    def test_absolute_symbol_path_rejected(self):
        broken = json.loads(json.dumps(FIXTURE))
        broken['symbols'][0]['relative_path'] = '/etc/passwd'
        self.assertFalse(VALIDATOR.is_valid(broken))

    def test_affected_results_must_be_advisory(self):
        v=jsonschema.Draft202012Validator({'$defs':SCHEMA['$defs'],'$ref':'#/$defs/CodeAffectedTestsResult'})
        f={k:FIXTURE[k] for k in ('project_id','repository_artifact_id','snapshot_sha256','codegraph_version','index_status')}
        f.update(suggested_relative_test_paths=['tests/test_login.py'], advisory_only=False)
        self.assertFalse(v.is_valid(f))

    def test_windows_traversal_rejected(self):
        broken=json.loads(json.dumps(FIXTURE))
        broken['symbols'][0]['relative_path']='..\\secrets.txt'
        self.assertFalse(VALIDATOR.is_valid(broken))

    def test_request_cannot_supply_host_project_path(self):
        v=jsonschema.Draft202012Validator({'$defs':SCHEMA['$defs'],'$ref':'#/$defs/CodeQueryRequest'})
        request={'repository_artifact_id':FIXTURE['repository_artifact_id'], 'question':'find caller', 'max_context_chars':24000}
        v.validate(request)
        request['projectPath']='/etc'
        self.assertFalse(v.is_valid(request))

    def test_repo_scoping_snapshot_and_freshness_present(self):
        for key in ('project_id','repository_artifact_id','snapshot_sha256','index_status','source_freshness_confirmed'):
            self.assertIn(key, SCHEMA['$defs']['CodeContextResult']['required'])

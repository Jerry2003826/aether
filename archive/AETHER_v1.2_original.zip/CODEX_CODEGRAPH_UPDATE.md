# Codex 增量升级指令：AETHER + CodeGraph (v1.1)

你正在开发 AETHER。2026-10-15 设计规格新增 CodeGraph，但**不能**重新初始化用户的现有工程，也不能覆盖已经完成的工作。

## 如果这是一个新的 AETHER 项目

阅读 `AGENTS.md`、`CODEX_START.md`、`docs/13_codegraph.md`、`config/codegraph.example.yaml` 和 `contracts/codegraph.schema.json`，按照 `tasks/backlog.yaml` 的依赖实施。CodeGraph 是可选能力，初始 `product_enabled: false`。没有验证固定版本和运行能力时不要标记 CodeGraph 工具为“可用”。

## 如果原先的 AETHER 工程已经开始开发

1. 先 `git status` 并保护所有用户现有修改，不覆盖当前 `STATUS.json`、真实 `tasks/backlog.yaml` 状态、现有配置/实际实现/数据库迁移。
2. 把 v1.1 开发包解压到项目旁边的独立目录，而不是原地解压覆盖。比较并**增量合并**：`docs/13_codegraph.md`、`config/codegraph.example.yaml`、`contracts/codegraph.schema.json`、`fixtures/codegraph_result.json` 与 `tests/test_codegraph_spec.py`；按需抽取 AGENTS、SOURCES、DECISIONS、repository_map、execution、security、evaluation 文档新增章节。
3. 将 `config/repositories.yaml` 的 `codegraph` 条目、`config/tools.example.yaml` 的 3 个 `repo.code.*` 工具、`tasks/backlog.yaml` 的 `M00-06/M05-06/M10-06` 三张 **optional** 票据，以及 `evals/dev_cases.jsonl` 中对应三条公开场景分别合并；不要把整个旧 backlog 覆盖到进行中的项目。
4. 如果旧项目已经实现了部分接口，基于已有代码写适配器，保留既有运行/权限模型。任何主架构变更必须经过 ADR，不添加第二套 Agent 调度器。
5. CodeGraph 开发期 Codex 插件与 AETHER 运行时的 CodeGraph 是两个不同集成。不得未经用户批准自动安装工具、运行远端脚本或修改 `~/.codex`。产品运行时只能在隔离 worker 中访问经项目授权的 immutable repo snapshot，默认禁用网络和遥测。
6. `codegraph affected` 仅是相关测试建议，不能取代 verifier registry 的强制测试。即使图谱失效/缺失，OpenHands 编程任务也应继续运行并标记降级。
7. 尝试真实固定版本的 CLI/MCP 探针，验证平台、许可证和行为；无网络/二进制时记录未运行，不得宣布成功。实测 AETHER 有/无图谱的同模型对照，分别计冷索引与热查询成本。
8. 为改动写真实单元、集成、安全测试和日志，持续更新**当前**状态，不清零已完成票据。最终说明哪些是已经写好的代码，哪些只是蓝图或被阻塞。

## 立即行动

现在先审阅当前 repo 和 v1.1 新增文档，给出简短差异清单，然后直接实现第一个未阻塞的 CodeGraph 增量任务；与此同时不影响既有 AETHER 主线。**不要停在重新输出设计稿。**

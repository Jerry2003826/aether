# 03 · 仓库复用地图：明确复用什么，不复用什么

## 总策略

**新建 AETHER 仓库；不 fork Hermes 当应用内核；不把多个完整平台拼起来。** 已经成熟的传输、持久工作流、编码执行器、解析器和检索算子直接用；目标合同、权限、跨任务经验、验收与技能升级由我们实现。

此处的路径是查阅/集成入口，不表示已经把上游源码安装并运行。来源见 `docs/SOURCES.md`；机器清单见 `config/repositories.yaml`。

## A. 执行底座

### A1. NousResearch/hermes-agent —— 独立基线，不是应用内核

仓库：<https://github.com/NousResearch/hermes-agent>

来源快照：`0e427d788d253630d38a3a51cd76849e73cd6925`。重点读 `README.md` 和 `website/docs/user-guide/features/skills.md`，理解其已有记忆、技能学习与写入审批。不要宣称这些功能是 AETHER 独有。

**使用方式**：在独立镜像/进程中跑固定版本，通过 `BaselineRunner` 协议投喂同一任务、模型端点和预算，收集轨迹。M00 实际执行该版本 CLI `--help` 后确定适配命令；本包不捏造稳定的 Hermes Python 内部 API。每个 cold task 使用新 profile；learning 实验使用独立训练 profile，再冻结后评测。

不复制 `run_agent` 内循环、不共用其用户目录、不让 baseline 接触 AETHER 的训练轨迹或隐藏评测答案。

### A2. OpenHands/software-agent-sdk —— 受限编程执行器

仓库：<https://github.com/OpenHands/software-agent-sdk>

来源快照：`0bd5cc2d322d61f785816a29ef1f2e4c86db2460`。该快照 `openhands-sdk/pyproject.toml` 标明 SDK 1.54.0、Python >=3.12；这是读取到的元数据，不是已安装验证。根 workspace 对依赖另有约束，**不得只装一个包就假定四个包兼容**。

实际复用：
- `openhands-sdk`：`LLM`、`Agent`、`Conversation`、`Tool` 与事件/远端 conversation。
- `openhands-tools`：显式启用 `TerminalTool`、`FileEditorTool`，可选 `TaskTrackerTool`；不给它生产连接器。
- `openhands-workspace`：`DockerWorkspace`；研究 `RemoteAPIWorkspace` 以支持将来远程 runner。
- `openhands-agent-server`：私有网络内的会话服务。
- 参考 `examples/02_remote_agent_server/02_convo_with_docker_sandboxed_server.py`：创建 workspace、回调收事件、发送消息、运行、读成本与关闭会话。

**适配位置**：`packages/adapters/aether_adapters/openhands.py`，由 trusted runner-manager 调用。接口是 `start/get/cancel`；创建 job 必须按 intent ID 幂等。具体 SDK 参数以 M00 的最小沙箱测试为准，不编造 `max_iterations` 之类未经核实的构造参数。上游示例使用默认 agent 和浮动 image 只为演示，AETHER 必须改成显式 tool 清单、禁用公共 skill 自动加载、镜像 digest、外部预算/时间守卫。

**输出**：patch、文件 manifest、代码快照哈希、SDK events、用量。`conversation.run()` 结束不代表任务验收通过。最终文件由独立 verifier 重建和检查。

### A3. temporalio/temporal + temporalio/sdk-python —— 唯一持久执行引擎

仓库：<https://github.com/temporalio/temporal>；<https://github.com/temporalio/sdk-python>

用官方服务镜像和 Python SDK，不 fork 服务。复用 workflow/activity/worker/client、持久计时器、signals/updates、child workflows、heartbeat、retry、continue-as-new 与 replay testing。示例仓库 <https://github.com/temporalio/samples-python> 的 `hello/hello_activity.py`、`hello/hello_activity_retry.py` 是入门骨架；不要直接拿例子的无限重试/默认配置上线。

适配位置：`services/worker/aether_worker/workflows/`。所有 LLM、文件和 HTTP 调用放 activity。业务副作用幂等仍由 operation ledger 管理；Temporal 不替外部系统保证 exactly-once。

### A4. BerriAI/litellm —— 模型协议适配，不是第二个 Agent

仓库：<https://github.com/BerriAI/litellm>

在 `services/gateway/` 中复用 SDK `completion/acompletion` 的模型/provider 参数归一、输出和 usage。V1 自建薄层认证与预算逻辑，不依赖其 Enterprise 的治理特性，也不部署第二套自主路由/任务管理平台。

结构化输出先做 provider 能力探针，再做 Pydantic 本地校验；最多两次有限修复，每次计费。价格通过管理员维护并固定版本的价格表，不盲信 model alias 永久价格。runner 环境内 OpenHands 的 LiteLLM 是其内部依赖，但网络只能接 AETHER 网关，不能拿全局 provider key。

## B. 知识、搜索与推荐

### B1. pgvector/pgvector + pgvector/pgvector-python

仓库：<https://github.com/pgvector/pgvector>；<https://github.com/pgvector/pgvector-python>

复用 `vector(1024)`、cosine distance、Python/SQLAlchemy 类型绑定。第一版默认 project-filtered exact search；确认召回/延迟后才启用 HNSW。参考 `examples/hybrid_search/rrf.py` 的融合思想，**不是把 PostgreSQL ts_rank_cd 当 BM25**。索引归属、ACL、删除、证据版本由我们负责。

### B2. xhluca/bm25s + fxsjy/jieba

仓库：<https://github.com/xhluca/bm25s>；<https://github.com/fxsjy/jieba>

BM25S 用 `BM25.index/retrieve/save/load`，以及 `bm25s.tokenization.Tokenizer`。参考 `examples/tokenizer_class.py`。参数 `method=lucene, k1=1.2, b=0.75` 是初始设计值，不声称最优。

中文用 jieba 搜索模式；英文/代码标识符保留完整词并做下划线/camelCase 拆分。冻结 tokenizer 与词典；同一 query/corpus 共享词表与处理版本。所有数据按 project 构建不可变快照、原子切换；BM25S 不替我们实现增量一致性。

### B3. FlagOpen/FlagEmbedding

仓库：<https://github.com/FlagOpen/FlagEmbedding>

复用 `BGEM3FlagModel` 的 `dense_vecs` 作为 1024 维向量；用 `FlagReranker` 的分数进行 cross-encoder 重排。模型固定选择 `BAAI/bge-m3` 和 `BAAI/bge-reranker-v2-m3`，revision 与模型文件哈希由 M00 冻结。参考 `docs/source/bge/bge_m3.rst` 和官方模型卡。

模型运行在独立 ML worker；没有 GPU 时可以 CPU 执行，但不承诺交互延迟。首次下载是安装步骤，离线运行要求预先缓存权重。默认不同时常驻大型生成模型与两个 ML 模型；按队列串行、延迟加载。下载权重许可证独立检查。

### B4. 采集与解析的分工

- <https://github.com/encode/httpx>：trusted gateway HTTP 下载；限大小、超时、重定向并验证网络目标。
- <https://github.com/adbar/trafilatura>：只对已下载 HTML 调用 `extract`；不走其内置下载器。
- <https://github.com/kurtmckee/feedparser>：只解析已下载 RSS/Atom bytes；不是定时器。
- <https://github.com/docling-project/docling>：`DocumentConverter` 与结构化文档/页面定位；从本地文件读取，在资源受限 parser worker 内运行。扫描 OCR 是显式选项，不默认把全部资料 OCR 一遍。
- <https://github.com/microsoft/playwright-python>：只有静态下载无法获取正文时才启动 JS 浏览器；每任务独立 context，无用户现成登录态。不是绕过站点访问控制的工具。

每个 parser 都做 Adapter contract test。源文件路径必须来自我们生成的 artifact ID，不能由页面内容提供主机路径。

### B5. 推荐不再塞入一个完整平台

V1 自己实现基于内容/兴趣/当前目标/新鲜度的排序、MMR 去重、多样性和可关闭探索。没有足够多真实用户行为时，不先装 Gorse/RecBole 冒充有效协同过滤。推荐及反馈协议保持独立，为后续学习排序保留训练样本，但不在 V1 引入另一个数据/权限权威。

## C. 工具、技能与界面

MCP：<https://github.com/modelcontextprotocol/python-sdk>，用 client session 与官方 transport；不照单全收远程工具。上游 SDK major 可能变化，M00 必须固定 major、记录协商协议、验证断线/取消/错误处理。

Skills：<https://github.com/agentskills/agentskills> 与 <https://agentskills.io/specification>，只借标准文件结构。额外安全、评测、部署字段放 `aether.skill.json`，不要篡改标准含义。技能兼容格式不代表脚本安全或功能等价。

UI：<https://github.com/vercel/next.js>、<https://github.com/shadcn-ui/ui>。用 Next.js App Router/TypeScript 与少量受审组件，不搬完整 Agent Canvas，不把 UI 绑定到 OpenHands 内部数据结构。

API：<https://github.com/fastapi/fastapi>。使用 FastAPI/Pydantic 生成真实 OpenAPI；以本包合同做兼容性测试。

观察：<https://github.com/langfuse/langfuse>，仅 optional profile。基本 trace/event/cost 查询先用我们的数据库与 OpenTelemetry。不能让引入 ClickHouse/Redis/对象存储等一组观察依赖成为启动最小系统的前提。

## D. 版本、许可证与供应链门禁

本包没下载完整仓库，也没生成可部署 lock。两条完整 SHA 是当前读取到的来源定位。M00 必须：查固定版本 LICENSE/子目录许可证/权重许可证；选兼容发布；实际安装 smoke；生成 `uv.lock`、前端 lock、镜像 digest 与 `THIRD_PARTY_NOTICES.md`；扫描已知依赖问题并写例外。不得从“仓库开源”推出所有企业目录、模型和社区 skill 可任意使用。

默认依赖库而非复制源码。确需借示例，保留原版权和许可证说明，并记录文件 URL、revision、修改范围。不执行 curl|bash 或任意仓库安装脚本；先审阅再安装。

---
上游依据：S01、S04、S07、S10、S17、S20、S23、S25、S33、S34，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。

## E. 新增 CodeGraph（结构化代码检索）

**选用**：<https://github.com/colbymchenry/codegraph>（MIT，2026-10-15 阅读源码仓库）；入口 CLI `codegraph init/status/explore/callers/callees/impact/affected` 和 MCP server `codegraph serve --mcp`。默认 MCP 仅展示 `codegraph_explore`，其他细分工具需要显式开启。Programmatic `@colbymchenry/codegraph` API 是备选，Node runtime 约束单独校验。

**复用位置**：开发阶段帮助 Codex 理解 AETHER repo；产品阶段在 `packages/adapters/aether_adapters/codegraph.py` 与 `services/runner/repo_intelligence/` 通过隔离子进程或 MCP 做受限代码上下文、调用关系、影响范围和建议测试检索。二者不能共享用户目录和权限。索引是可丢弃的 project + immutable snapshot 缓存，失败回退到授权代码读取。不要让图谱替代 trusted verifier 或 Knowledge Fabric。

**许可证/安装/隐私**：审阅锁定版本与发布证明，`CODEGRAPH_TELEMETRY=0`，沙箱无公网出站，不准自动执行上游 `curl | sh` 或修改宿主 Codex 全局设置。具体协议、任务与评测见 `docs/13_codegraph.md`。来源：S46–S49。

## 2026-10-15 · 扩展 GitHub 生态候选与范围隔离

本文件的 23 个仓库条目仍是 **V1.1 原架构的核心/固定参考范围**；新增候选 **81 条/80 个独立仓库**不自动加入此部署清单，统一在 `config/ecosystem_candidates.yaml` 和 `docs/14_ecosystem_audit.md`。只为已通过 M00-07 审核、实际接入的项目另记 immutable SHA/NOTICE；禁止在 `config/repositories.yaml` 中写进未经实测的伪版本。产品的唯一编排权威仍是 Temporal。

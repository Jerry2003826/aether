# Architecture decision records

| ID | Decision | Rationale / invariant |
|---|---|---|
| ADR-001 | New AETHER core, Hermes isolated baseline | Avoid inheriting a second lifecycle; compare fairly rather than claiming absent features |
| ADR-002 | Temporal owns task execution | Durable execution and replay; DB status is a projection |
| ADR-003 | OpenHands only handles bounded coding jobs | Reuse existing code tools while preserving policy and verification authority |
| ADR-004 | LiteLLM only provider adaptation | No overlapping orchestrator; explicit authorization/cost ledger remains ours |
| ADR-005 | BM25S + pgvector + BGE | Real lexical+dense retrieval without Google dependency or large search platform |
| ADR-006 | Project-scoped immutable indexes | Clear ACL and consistency for personal 50k-chunk scope |
| ADR-007 | Single owner V1, strict project boundaries | Useful scope without pretending enterprise multi-tenancy |
| ADR-008 | Independent verifier, immutable artifacts | Prevent actor self-grading and stale test reuse |
| ADR-009 | Skills are evaluated versioned artifacts | Experience accumulation is not proven learning until tested |
| ADR-010 | No runtime model brand hardcoding | User keys/capabilities vary; live config must be probed, not invented |
| ADR-011 | No guaranteed exactly-once external effects | Use idempotency/reconciliation/manual review for unknown outcomes |
| ADR-012 | Offline scripted mode explicit | Enables development, never masquerades as actual AI performance |
| ADR-013 (2026-10-15) | Adopt `colbymchenry/codegraph` as optional, project-scoped structural code intelligence | Supports Codex authoring + runtime coding jobs via two explicit, separately authenticated integrations; no new scheduler or knowledge authority. Feature flag defaults off until M00 probe. Generated graphs are derived caches and never verification evidence. |

Implementation changes append records with: date, evidence, decision, alternatives, affected contracts, compatibility and tests. Do not delete prior decisions.

## ADR-014 · 2026-10-15: 用可验证试验而不是仓库数量升级 Agent

决定：保留 Temporal-only durable authority、OpenHands bounded executor、PostgreSQL 原始证据，新增 81 条候选资料清单与 10 项**可选**试验/许可任务。优先 Pydantic Evals standalone + Promptfoo developer CI；Hindsight/MemoryEngine、Crawl4AI、agent-browser、Reef/CORAL 先实验，CodeGraph 保持 V1.1 受限位置。不同提供商/记忆系统按相同数据、模型、权限预算互斥对照，不叠加成第二权威。

许可与上游维护风险：GitNexus PolyForm Noncommercial；Serena v2 应用 GPL、SolidLSP MIT；OpenViking 主体 AGPL；Daytona/Roo 归档；Snyk Agent Scan 可能把扫描材料送往供应商 API。所有候选默认 off；实装须再次审核选中固定 revision 的软件包和依赖。原有 M00–M11 必选门禁和验证器约束不变。

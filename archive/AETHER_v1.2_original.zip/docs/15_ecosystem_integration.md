# 15 · Codex 增量实施接口、数据边界与验收清单

本增补不改变 V1.1 主架构。新增适配器只有在 `M00-07` 严格审核之后才能实验；**不把 81 个候选全部安装**。所有候选真实接入之前 `production_enabled=false`。

## 推荐目录（任务交付时创建；规格包本身不包含实现）

```text
packages/adapters/aether_adapters/
  memory_engine.py         # MemoryEngine protocol + AETHER native backend
  hindsight_memory.py      # optional network-local REST client; no global SDK wrapper
  crawl4ai_extractor.py    # bounded approved sources, JS fallback only
  agent_browser.py         # isolated browser CLI, session-scoped
  solidlsp_symbols.py      # optional MIT SolidLSP-only experiments
  codegraph.py             # carried from V1.1
services/experiment_worker/
  recipes/                 # Skill candidate proposals, zero publish permissions
evals/
  adapters/pydantic_evals_adapter.py
  redteam/promptfooconfig.yaml
  datasets/ecosystem_public.jsonl
  reports/                 # actual immutable generated results
config/
  ecosystem_candidates.yaml
  ecosystem_experiments.example.yaml
```

## 数据约定

1. **Adapter 输入**必须由可信网关提供 `tenant/project_id`, `task_id`, `source_hash`, `allowed_capabilities`, `max_cost`、审计事件 `intent_id`；外部 LLM 字符串不能改变这些字段。做权限检查后才可向索引或记忆查询提供项目上下文。
2. **Adapter 输出**必须带 provider、索引/文档版本、耗时、token/CPU 成本、失败分类及 `evidence_ids`，并显式标注 `derived=true`。不能自动将外部记忆内容升级为原始事实。
3. **Memory** 中 Hindsight bank-id 只能由服务端根据已授权项目产生；删除必须覆盖服务端原始记录、图/向量派生索引、备份保留策略及异步任务，最终显示明确删除结果和可能的保留状态。
4. **Browser** 将 `agent-browser` 每个任务运行在固定 SHA/镜像的新 profile 中，禁用导入宿主机个人浏览器状态。截图、download、导航链接带 workspace id/URL 范围；高影响点击需经 Operation Ledger。
5. **Crawler** 只打开白名单 URL，限制大小、深度、并发、重定向和网络目标；解析中保留原始 response hash 及页面时间，不接受网页中的系统指令。
6. **Experiment** 中 Reef/AntOmniEvo 可提案，但 grader/holdout 置于不同身份、容器和网络命名空间；不得受候选代码写入。失败或异常时不会自行 promotion。

## 对应评测任务（可先用离线合成 fixture 编写但不可记为 live 已通过）

| 任务 | 公共开发测试 | 真实集成/安全验收 |
|---|---|---|
| 许可证清单 | 81条均有可访问仓库 URL/许可状态、协议冲突报告 | 所有实际 import/run 的确切子包与 immutable SHA + transitive notice |
| Hindsight/Memory | 同项目/跨项目的 20 个合成时态/冲突/删除用例 | 真实启动记忆服务和 API，删除派生索引，测试拒绝越权 bank id |
| Crawl4AI | 已授权固定网页 HTML/JS/redirect cases | 实际 JS 呈现提取、SSRF/symlink/私网禁止访问验证 |
| Agent Browser | 5 个无账号本地 HTML 页和导航变化用例 | CLI 冷/热启动、会话清理、真实容器网络政策、关键点击审批验证 |
| Code intelligence | CodeGraph/ast-grep/SolidLSP 同 repository snapshot | AST/call impact 与 golden truth 对照，stale index 拒绝、越项目拒绝 |
| Skill Lab | 3 个成功轨迹、3 个回归、3 个注入攻击 | 独立 grader 私有目录，不能偷看 holdout，候选无法发起 promotion |
| Pydantic Evals | 确定性评分和 trace checker 的单测 | 真实 Hermes/AETHER 同设置实验，报告重算完整 |
| Promptfoo | URL/README/MCP/技能四种投毒输入 | 有限红队环境无秘钥外发、审批拒绝、文件越权测试 |

## 关键依赖替换/新增的否决条件

- 任何候选绕过 Temporal 管理操作生命周期、绕过网关审批、或向同一 production job 直接启动第二个 supervisor。
- 候选把私有会话、浏览器 cookies、主机 secret、源码发到非授权云端。
- 引入 GitNexus 违反 PolyForm-Noncommercial，或将 Serena GPL 主体 / OpenViking AGPL 主体直接复制为闭源模块。
- 只有 README 声称性能提升、没有公平实验；显著增加延迟/成本却没有成功率改善。
- 某一可选组件不可用时 AETHER 强依赖它而无法编程、搜索、记忆或执行核心任务。

## 下一步具体实施顺序

M00-07 先审计许可/供应链与环境；随后 M10-07（离线评分）和 M10-08（离线红队）可与主线独立并行；M06-06 先 memory mock，再实际 pilot；M04-06 和 M05-07/08 仍是可选；M08-06 必须在 M08 基础验收器就绪之后才做受控自我进化试验。M10-09 报告必须保留未运行测试的事实。

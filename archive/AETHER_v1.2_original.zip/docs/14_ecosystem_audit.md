# 14 · 2026-10-15 GitHub Agent 开源生态全面审计

> **AETHER V1.2 筛选报告。** 该目录是公开 GitHub 项目及仓库上游文件的研究快照，而不是已安装依赖列表，也不是所有 GitHub 仓库的全集。开源生态持续变化，不能承诺“绝对没有遗漏”。本次按 10 个领域系统筛选 **81 个候选条目 / 80 个独立仓库**（其中 Pydantic AI 分别作为框架和独立 eval 库评估）。库的首页或许可证已经查阅的不代表 API 和所有转移依赖通过了固定版本的实际安装验证。

## 0. 必须保持的架构边界

- **Temporal 唯一持久任务调度权威**。不得再引入可自行恢复、独立重试外部操作的第二套生产工作流。
- **可信工具网关、原始证据存储、独立验证器、权限/费用账本由 AETHER 掌握**；LLM、长期记忆引擎或第三方评测不能修改这些权威记录。
- **OpenHands 仍是第一编码执行器**；其他 Harness 先做同平台公平基线。Codex 是项目开发工具而非生产时隐含的 API 依赖。
- 搜索基础依然是授权站点/RSS/文件采集 + BM25S + pgvector + BGE 重排；新增组件不能偷换成 Google 搜索或强制联网 SaaS。
- 所有**新增依赖都默认关闭**，从独立探索→固定 SHA/许可审查→受控沙箱探针→A/B 性能与安全验证→用户批准后启用。
- 任何网页、MCP、插件说明中的“提权指令”均只是**不可信数据**；扫描器可能有遥测或外发，不能默认为隐私安全。

## 1. 真正值得引入的组合（优先级从高到低）

| 模块 | 首选项目与精确使用面 | 怎么接入 | 何时允许升级 |
|---|---|---|---|
| 真实 Agent 评测（新） | [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) 里的**独立 `pydantic-evals`**：datasets、`Evaluator`、experiment run、工具轨迹指标；不导入 `pydantic-ai` Agent 核心 | `evals/adapters/pydantic_evals_adapter.py`，只读取不可变试验任务/结果事件 | 评测结果能独立复现，LLM judge 不能代替可运行的代码验收 |
| 注入/工具投毒红队（新） | [promptfoo/promptfoo](https://github.com/promptfoo/promptfoo)：CLI、`promptfooconfig.yaml`、回归测试/CI | `evals/redteam/`；离线测试只喂合成材料，不随意上传用户的私有提示词或技能 | 强制覆盖 URL、repo README、搜索摘要、MCP tool description、恶意 SKILL.md 的间接注入 |
| 长期记忆（新，先实验） | [vectorize-io/hindsight](https://github.com/vectorize-io/hindsight) `hindsight-api` / `hindsight-clients`：`retain`/`recall`/`reflect`、`bank_id` | 独立内网服务 `MemoryEngine` adapter；**拒绝未经权限绑定的 bank_id** | 同冻结任务下和原有记忆、Mem0、Cognee 比较正确率、来源/删除/冲突/污染、安全和成本 |
| 采集增强（新，可选） | [unclecode/crawl4ai](https://github.com/unclecode/crawl4ai) 的 `AsyncWebCrawler` + CSS/XPath/JS 页面抽取 | `IngestionExtractor` 接口，在授权站点 JS 页面上作为备选；HTTPX+Trafilatura 保留为默认 | 仅在确实提升 JS 提取覆盖率时启用，采集必须通过 SSRF/域名/机器人规则/安全策略 |
| 代码结构理解（v1.1 已有） | [colbymchenry/codegraph](https://github.com/colbymchenry/codegraph) Rust/CLI/MCP、本地符号关系、影响范围 | `RepositoryIntelligence`，针对**隔离的不可变仓库快照**生成索引 | 图谱新鲜度准确、跨项目不可见、CLI 不联网且降级后编码照常工作 |
| 浏览器低 token 操作（新，可选） | [vercel-labs/agent-browser](https://github.com/vercel-labs/agent-browser)：`snapshot -i`、`--delta`、截图/会话、元素 refs | `BrowserRunner` 的候选后端，默认 Playwright；一个任务一套全新浏览器 profile | 同网站相同权限下，动作准确率提高且不暴露登录 Cookie/环境变量 |
| 自我改进（新，研究） | [Human-Agent-Society/reef](https://github.com/Human-Agent-Society/reef) 的记录、反馈、候选/recipe、evaluation；[CORAL](https://github.com/Human-Agent-Society/CORAL) 的保密评分 | **离线实验服务**产生候选 artifact；AETHER Skill Lab 负责审批和 promotion | 独立封存 holdout 与可信 grader；候选不能读取评测答案或批准自己上线 |
| MCP 检测（新） | [modelcontextprotocol/inspector](https://github.com/modelcontextprotocol/inspector) CLI/Inspector | 开发 CI 里查 tool schemas 和调用兼容性，不能让 inspector 持有线上凭证 | 可审计 schema drift / tool hash / authority 独立执行 |
| 能力对照（新） | [facebookresearch/TUA-Bench](https://github.com/facebookresearch/TUA-Bench)、[harbor-framework/terminal-bench-1](https://github.com/harbor-framework/terminal-bench-1) | 与现有 Hermes 任务保持同模型、权限、基础快照、验收器、预算 | 许可证/数据可信后执行，保存 raw log，未跑记 not_run |

上游首要依据：[Hindsight README](https://github.com/vectorize-io/hindsight)、[Pydantic Evals](https://github.com/pydantic/pydantic-ai/blob/main/docs/evals.md)、[agent-browser README](https://github.com/vercel-labs/agent-browser/blob/main/README.md)、[Crawl4AI README](https://github.com/unclecode/crawl4ai)、[Reef README](https://github.com/Human-Agent-Society/reef)、[CodeGraph README](https://github.com/colbymchenry/codegraph)。上游自述的性能数字不是 AETHER 实测。

## 2. 许可证、安全和已归档项目——不能忽略

| 项目 | 已核对的关键限制 | AETHER 处理方式 |
|---|---|---|
| [GitNexus](https://github.com/abhigyanpatwari/GitNexus/blob/main/LICENSE) | **PolyForm Noncommercial 1.0.0**；源码公开≠允许商业复用 | 可以在许可允许的非商业研究中做只读对照；不能作为潜在商业产品默认依赖，也不能照搬其代码 |
| [Serena v2](https://github.com/oraios/serena/blob/main/docs/01-about/060_license.md) | **2026-10-13 v2.0.0**：应用 `src/serena` 等 GPL-3.0-or-later，`src/solidlsp` MIT | 可独立研究/复用 MIT SolidLSP；任何 Serena 应用再分发先审 GPL 条款和边界 |
| [OpenViking](https://github.com/volcengine/OpenViking) | 主体 **AGPL-3.0**，`crates/ov_cli` Apache-2.0、部分 examples Apache/MIT | 只研究 `viking://` / L0-L2 渐进式上下文的设计；要运行主服务先审 AGPL 网络提供义务 |
| [SearXNG](https://github.com/searxng/searxng) | **AGPL-3.0**；默认聚合外部搜索引擎，并非自建全网索引 | 只有用户明确想用外部元搜索时作为 sidecar；禁用 Google 引擎，不称其为完全自主索引 |
| [Firecrawl](https://github.com/firecrawl/firecrawl) | 服务端 **AGPL-3.0**，SDK 与云功能授权不同 | HTTPX、Trafilatura、Crawl4AI 优先；研究 Firecrawl 时审部署与许可证 |
| [Langfuse](https://github.com/langfuse/langfuse/blob/main/LICENSE) | 核心 **MIT**；`ee/` 等目录独立商业许可证 | 已是可选观测方案；不能默认启用付费/企业特性。还要检查默认遥测开关 |
| [Phoenix](https://github.com/Arize-ai/phoenix) | **Elastic License 2.0**：source-available 但不是 OSI 通常认定的开源许可 | 参考 OTel 接口，默认不嵌入 |
| [Mastra](https://github.com/mastra-ai/mastra) | 核心 Apache-2.0，`ee/` 为商业许可证 | 仅参考核心设计；排除 ee |
| [Activepieces](https://github.com/activepieces/activepieces) | 社区核心 MIT，`packages/ee` 等商业特性 | 借鉴 connector OAuth/审批；不导入重型工作流平台 |
| [Daytona](https://github.com/daytonaio/daytona) | GitHub 开源仓库已在 **2026-10-03 归档**；此前核心转为私有仓库 | **不作为** AETHER 新的可维护自托管沙箱根基 |
| [Roo Code](https://github.com/RooCodeInc/Roo-Code) | **2026-05-15 归档** | 作为历史/对照，不做生产依赖 |
| [Snyk Agent Scan](https://github.com/snyk/agent-scan/blob/main/docs/scanning.md) | 公开文档明确说明 MCP 配置签名和技能文件可能发送 Snyk API 分析 | **禁用自动联网扫描**；只有用户同意且对数据外发做过单独风险评估才用 |
| [Composio](https://github.com/ComposioHQ/composio) | SDK MIT，但常见工具会话/认证/执行依赖 Composio API Key 和托管平台 | 可选连接器，明确标注外部服务依赖；不能违反“不依赖 Google/第三方云作必需条件” |

> 许可证不是简单的“AGPL 绝对不能商业使用”：AGPL 允许商业使用，但有网络访问等条件；是否影响你的部署和分发需按实际组合与法律意见核对。Noncommercial 则有明确目的限制。以上是技术选型风险提示，不构成法律意见。任何项目的**精确发布版本及其子目录、transitive dependencies**都必须在 M00 固定审核。

## 3. 功能归属和优先替代顺序

### 3.1 MemoryEngine 协议（只有一个项目级权威引擎）

```python
class MemoryEngine(Protocol):
    async def retain(self, project_id: str, source_event_id: str, source_hash: str,
                     content: str, policy: MemoryPolicy) -> MemoryReceipt: ...
    async def recall(self, project_id: str, query: str, limit: int,
                     as_of: datetime | None = None) -> list[MemoryHit]: ...
    async def delete_source(self, project_id: str, source_event_id: str) -> DeleteReceipt: ...
    async def health(self) -> MemoryHealth: ...
```

`project_id` 来自 AETHER 身份上下文，永远不能用 Agent 从自然语言填的字符串替代。AETHER Evidence Ledger 是权威记录；下游 Hindsight/Mem0/Cognee 只是**派生检索索引**。即使外部存储不可用，证据/权限/删除请求记录也必须保留并能重试索引修复。`reflect` 生成内容不能自动升格为事实。

**实验矩阵：** `AETHER native`, `Hindsight`, `Mem0`, `Cognee`；同一份匿名化合成语料、相同模型条件、相同token/cost计量；考察来源命中率、时态事实修改、冲突说明、tenant泄漏率、数据删除闭环、工具注入抵抗、P95查询延迟。**只有一个方案可以正式投产**；代码先写统一接口，不要全安装。

### 3.2 BrowserRunner 协议

```python
class BrowserRunner(Protocol):
    async def open(self, actor_context: TrustedContext, url: str) -> PageReceipt: ...
    async def snapshot(self, session_id: str, mode: Literal['interactive','full','delta']) -> Snapshot: ...
    async def act(self, approved_intent: OperationIntent, action: BrowserAction) -> ActionReceipt: ...
    async def close(self, session_id: str) -> None: ...
```

`agent-browser snapshot -i` / `--delta` 减少 DOM 噪声，但元素 `@eN` 只是**临时页面会话引用**，不能当跨导航永久定位符。需要单独容器+临时用户目录、站点白名单、DNS/IP/跳转审计、可疑下载封锁、外部副作用统一审批。不要把宿主 Chrome 登录态或个人 Cookie 挂进去。

### 3.3 IngestionExtractor 协议

`HTTPX + Trafilatura` 为轻量默认；只有 HTML 正文不足或 JS 客户端渲染的**授权站点**调用 `Crawl4AI AsyncWebCrawler`。解析结果需要记录 `url + fetched_at + sha256 + parser_version + canonical_url + source_rights`；测试正文结构准确率、抓取吞吐、CPU/内存、SSRF 防护与 robots/ToS 政策，不复用真实浏览器登录态。

### 3.4 SkillLab 实验层

借鉴 Reef 的 record→recipe→evaluation→artifact 和 CORAL 的受保护 grader 设计，不让实验引擎拥有 production 凭据、holdout 答案或 publish 权限。Skill 候选必须不可变，满足：真实任务回放+清洁 holdout+置信区间/预算+人工批准+分阶段灰度+回滚。失败原因可进经验库，但**不能把失败后的模型自我解释当作事实**。

## 4. 按功能完整候选目录（机器清单见 config/ecosystem_candidates.yaml）

以下为候选库全量索引：**已查看首页**表示核对过概念或能力；**license_checked**表示检索确认了该项许可描述；**verify_at_pin**表示未对固定版本完成完整许可审查。**tier=pilot/adopt-dev 不等于已经安装。**

### 编排与执行（20 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [NousResearch/hermes-agent](https://github.com/NousResearch/hermes-agent) | `reference` | `verify\_at\_pin` | **skills, memory, subagents, skill learning**：独立锁定基线，执行公平对照；不得用其执行循环做自身实现 |
| [temporalio/temporal](https://github.com/temporalio/temporal) | `core-existing` | `verify\_at\_pin` | **server / persistence / workflow durability**：唯一持久执行引擎，拒绝第二状态权威 |
| [temporalio/sdk-python](https://github.com/temporalio/sdk-python) | `core-existing` | `verify\_at\_pin` | **Client, Worker, Workflow, Activity, Replay**：编排事务与恢复，只在 Activity 调工具 |
| [OpenHands/software-agent-sdk](https://github.com/OpenHands/software-agent-sdk) | `core-existing` | `verify\_at\_pin` | **openhands-sdk; tools; workspace; agent-server**：限定编码工作子任务的沙箱执行器 |
| [deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness) | `reference` | `MIT` | **Cordis / plugin harness / TypeScript tool runtime**：借鉴紧凑 Harness 和动态能力；developer preview 不做生产编排 |
| [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) | `pilot` | `MIT` | **pydantic_evals; durable_execution/temporal; capabilities**：只优先引入 pydantic-evals 评测包；主 agent/Temporal 编排不迁移 |
| [langchain-ai/deepagents](https://github.com/langchain-ai/deepagents) | `reference` | `verify\_at\_pin` | **agent planning, context, files, subagents**：对照研究；与自有循环重复，不引入生产 |
| [bytedance/deer-flow](https://github.com/bytedance/deer-flow) | `reference` | `verify\_at\_pin` | **superagent orchestration, context, browser, research**：参考长期任务 UX 与研究工具；不导入 LangGraph 第二编排 |
| [openclaw/openclaw](https://github.com/openclaw/openclaw) | `reference` | `verify\_at\_pin` | **multi-channel assistant runtime**：研究跨终端接入，非 AETHER 的底层编排器 |
| [paperclipai/paperclip](https://github.com/paperclipai/paperclip) | `reference` | `MIT` | **agent organization, goals, cost, governance UI**：借鉴代理组织治理和人类审批设计 |
| [mvschwarz/openrig](https://github.com/mvschwarz/openrig) | `reference` | `Apache-2.0` | **Codex/Claude/Pi multi-agent sessions**：研究团队协作协议，暂不运行第二 supervisor |
| [october-dev/october-harness](https://github.com/october-dev/october-harness) | `watch` | `MIT` | **CLI/RPC/SDK, durable messaging via October Bus**：2026 新兴 Pi fork；多 Agent 总线值得学习，早期项目仅实验 |
| [earendil-works/pi](https://github.com/earendil-works/pi) | `reference` | `verify\_at\_pin` | **minimal coding agent core / sessions / RPC**：研究薄 Harness 和上下文压缩，不替换 OpenHands |
| [anomalyco/opencode](https://github.com/anomalyco/opencode) | `reference` | `verify\_at\_pin` | **terminal coding harness / tools**：编码基线对照，不作为并行任务权威 |
| [openai/codex](https://github.com/openai/codex) | `reference` | `verify\_at\_pin` | **coding CLI / sandbox / ACP when available**：Codex 用于构建 AETHER，不等于嵌入生产核心 |
| [microsoft/agent-framework](https://github.com/microsoft/agent-framework) | `watch` | `verify\_at\_pin` | **multi-agent patterns, graph workflows**：仅研究组织协作，避免第二工作流 |
| [google/adk-python](https://github.com/google/adk-python) | `reference` | `verify\_at\_pin` | **agent SDK and session semantics**：研究接口设计，不能让 Google 成为必需依赖 |
| [agentscope-ai/agentscope](https://github.com/agentscope-ai/agentscope) | `watch` | `verify\_at\_pin` | **multi-agent, tracing, orchestration**：备用评测对象，不引入新主循环 |
| [mastra-ai/mastra](https://github.com/mastra-ai/mastra) | `reference` | `Apache-2.0\_core; proprietary\_ee` | **TS workflow, agent and UI integration**：仅阅读 Apache 核心；ee/ 商业许可不混入 |
| [activepieces/activepieces](https://github.com/activepieces/activepieces) | `reference` | `MIT\_core; commercial\_ee` | **connector workflows / pieces / MCP**：参考第三方应用连接器，不增加第二自动化系统 |

### 记忆与上下文（9 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [vectorize-io/hindsight](https://github.com/vectorize-io/hindsight) | `pilot` | `MIT` | **hindsight-api, hindsight-clients; retain/recall/reflect; banks**：优先记忆引擎对照实验；AETHER 保存原始证据和删除权 |
| [mem0ai/mem0](https://github.com/mem0ai/mem0) | `pilot` | `Apache-2.0` | **mem0; memory CRUD and vector recall**：记忆替代组对照，按项目隔离测 Recall、冲突、删除 |
| [topoteretes/cognee](https://github.com/topoteretes/cognee) | `pilot` | `verify\_at\_pin` | **remember/recall/improve/forget, graph/vector/code context**：与 Hindsight/Mem0 比较；不得同时写三套生产权威记忆 |
| [volcengine/OpenViking](https://github.com/volcengine/OpenViking) | `reference` | `AGPL-3.0\_main; Apache-2.0\_cli` | **context file tree; viking://; progressive L0/L1/L2**：研究上下文分层；AGPL 主体不默认为可嵌入闭源核心 |
| [getzep/graphiti](https://github.com/getzep/graphiti) | `pilot` | `Apache-2.0` | **graphiti_core; time-aware knowledge graph**：可选时间知识图实验；Neo4j/FalkorDB 等依赖增加运维 |
| [HKUDS/LightRAG](https://github.com/HKUDS/LightRAG) | `reference` | `MIT` | **graph RAG extraction + indexing**：研究实体关系召回，暂不替代现有 BM25S+pgvector |
| [letta-ai/letta](https://github.com/letta-ai/letta) | `reference` | `verify\_at\_pin` | **persistent agent memory/state**：只参考分层状态管理，避免完整 runtime 叠加 |
| [thedotmack/claude-mem](https://github.com/thedotmack/claude-mem) | `watch` | `verify\_at\_pin` | **coding-agent session memory**：研究进程间会话总结，可不依赖完整插件 |
| [JordyZomer/Lemmalog](https://github.com/JordyZomer/Lemmalog) | `watch` | `verify\_at\_pin` | **Datalog / provenance memory**：早期研究候选，不做默认服务 |

### 代码智能（7 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [colbymchenry/codegraph](https://github.com/colbymchenry/codegraph) | `pilot` | `MIT` | **Rust kernel; local index; codegraph CLI/MCP; impact queries**：沿用 V1.1 可选方案，隔离快照+白名单+新鲜度 |
| [abhigyanpatwari/GitNexus](https://github.com/abhigyanpatwari/GitNexus) | `reference` | `PolyForm-Noncommercial-1.0.0` | **MCP query/context/impact/trace/api_impact; readonly/allowlist**：仅符合许可的本地非商业研究，不纳入商用构建和依赖 |
| [oraios/serena](https://github.com/oraios/serena) | `reference` | `GPL-3.0-or-later\_app; MIT\_solidlsp` | **src/solidlsp symbol/LSP; Serena v2 REPL**：优先独立研究 MIT SolidLSP，避免把 GPL 应用代码复制到核心 |
| [ast-grep/ast-grep](https://github.com/ast-grep/ast-grep) | `pilot` | `verify\_at\_pin` | **structural search/rewrite CLI, rule patterns**：独立静态代码修改/安全检查；不是调用图数据库替代 |
| [tree-sitter/tree-sitter](https://github.com/tree-sitter/tree-sitter) | `reference` | `verify\_at\_pin` | **AST parsing grammar ecosystem**：仅在必要时直接用解析接口；优先复用 CodeGraph 解析 |
| [astral-sh/ruff](https://github.com/astral-sh/ruff) | `core-existing` | `verify\_at\_pin` | **lint and formatter**：编码质量关卡；不负责 agent 规划 |
| [astral-sh/ty](https://github.com/astral-sh/ty) | `watch` | `MIT` | **Python type checking**：新型类型检查候选；与 Pyright/mypy 基线比误报和性能 |

### 浏览器与采集（12 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [microsoft/playwright-python](https://github.com/microsoft/playwright-python) | `core-existing` | `verify\_at\_pin` | **BrowserContext, locators, screenshots**：可信隔离浏览器原语；明确网络/站点和认证边界 |
| [vercel-labs/agent-browser](https://github.com/vercel-labs/agent-browser) | `pilot` | `Apache-2.0` | **CLI session, snapshot -i/-delta, refs, screenshots**：与纯 Playwright 比 token/成功率；只用干净浏览器 profile |
| [browser-use/browser-use](https://github.com/browser-use/browser-use) | `pilot` | `verify\_at\_pin` | **browser agent actions/DOM extraction**：备选受控浏览器执行器；严格副作用批准 |
| [browserbase/stagehand](https://github.com/browserbase/stagehand) | `pilot` | `verify\_at\_pin` | **act/extract/observe browser automation**：交互抽取对照；检查是否依赖云服务或私有 provider |
| [microsoft/playwright-mcp](https://github.com/microsoft/playwright-mcp) | `reference` | `verify\_at\_pin` | **MCP browser snapshot/tools**：适配模型工具协议时比较，需控制会话和 egress |
| [Tencent/BrowserSkill](https://github.com/Tencent/BrowserSkill) | `reference` | `MIT` | **existing logged-in browser automation**：真实浏览器登录态风险高；默认禁用，不继承本机 Cookie |
| [unclecode/crawl4ai](https://github.com/unclecode/crawl4ai) | `pilot` | `Apache-2.0` | **AsyncWebCrawler; CSS/XPath extraction; Markdown; JS**：作为 JS 页面和复杂 HTML 解析的可选 ingestion adapter |
| [firecrawl/firecrawl](https://github.com/firecrawl/firecrawl) | `reference` | `AGPL-3.0\_server; SDK varies` | **crawl/search/extract APIs**：只做比较；自托管/云功能不完全一致；许可需隔离 |
| [searxng/searxng](https://github.com/searxng/searxng) | `pilot` | `AGPL-3.0` | **metasearch optional sidecar**：外网发现的可选独立服务；默认禁用 Google 上游 |
| [infiniflow/ragflow](https://github.com/infiniflow/ragflow) | `reference` | `Apache-2.0` | **document parser, RAG pipeline**：研究复杂 PDF 和表格解析，不引入重型并行检索系统 |
| [assafelovic/gpt-researcher](https://github.com/assafelovic/gpt-researcher) | `reference` | `verify\_at\_pin` | **source gathering, citations and research report**：比较研究任务策略与来源去重 |
| [onyx-dot-app/onyx](https://github.com/onyx-dot-app/onyx) | `reference` | `verify\_at\_pin` | **enterprise search connectors/security patterns**：研究企业资料采集授权，不复制全套平台 |

### 工具与授权（5 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [modelcontextprotocol/python-sdk](https://github.com/modelcontextprotocol/python-sdk) | `core-existing` | `verify\_at\_pin` | **MCP client transport and schema**：受审网关唯一出口，工具清单需版本固定 |
| [modelcontextprotocol/inspector](https://github.com/modelcontextprotocol/inspector) | `adopt-dev` | `verify\_at\_pin` | **MCP Inspector debug & schema probes**：开发期探针，不将 inspector 端口暴露公网 |
| [ComposioHQ/composio](https://github.com/ComposioHQ/composio) | `watch` | `MIT\_SDK; hosted\_API\_key\_required` | **python/ SDK; ts/packages/core tool search/execute**：连接器生态有价值，但托管 OAuth/云服务不是无第三方依赖核心 |
| [ArcadeAI/arcade-mcp](https://github.com/ArcadeAI/arcade-mcp) | `watch` | `verify\_at\_pin` | **MCPApp, auth-scoped tool decorators**：研究 OAuth/token 隔离设计；云托管可选非核心 |
| [snyk/agent-scan](https://github.com/snyk/agent-scan) | `reference` | `verify\_at\_pin` | **MCP/skill risk scanner CLI**：默认不连接云 API；该扫描器会向 Snyk API 提交配置/技能信息 |

### 持久化与沙箱（6 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [google/ax](https://github.com/google/ax) | `watch` | `Apache-2.0` | **Kubernetes agent sandbox control plane**：面向规模化多节点，当前单机 V1 不引入 K8s |
| [daytonaio/daytona](https://github.com/daytonaio/daytona) | `reject` | `verify\_archived` | **formerly open sandbox implementation**：上游 2026-10-03 归档；核心此前私有化，不作为自托管主依赖 |
| [e2b-dev/E2B](https://github.com/e2b-dev/E2B) | `watch` | `verify\_at\_pin` | **code sandbox execution**：谨慎查自托管和计费依赖，V1 优先 OpenHands Docker |
| [cloudflare/sandbox-sdk](https://github.com/cloudflare/sandbox-sdk) | `watch` | `verify\_at\_pin` | **vendor-specific remote sandboxes**：仅多云环境可选，不能成为离线必需条件 |
| [dbos-inc/dbos-transact-py](https://github.com/dbos-inc/dbos-transact-py) | `reference` | `MIT` | **durable functions**：Temporal 的直接替代路线，保持唯一引擎不共用 |
| [restatedev/sdk-python](https://github.com/restatedev/sdk-python) | `reference` | `verify\_at\_pin` | **durable execution workflows**：只做概念对比，不能并行持久化业务循环 |

### 持续学习（4 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [Human-Agent-Society/reef](https://github.com/Human-Agent-Society/reef) | `pilot` | `Apache-2.0` | **service, storage/records, recipe, train, evaluation**：离线实验外置；仅输出候选 artifact，部署由 AETHER 授权 |
| [Human-Agent-Society/CORAL](https://github.com/Human-Agent-Society/CORAL) | `reference` | `Apache-2.0` | **autonomous code experiments / protected grader**：参考评测环境与判卷隐私隔离，防止 agent 改评分 |
| [ant-research/AntOmniEvo](https://github.com/ant-research/AntOmniEvo) | `pilot` | `Apache-2.0` | **ArtifactSchema, System, Evaluator, proposals**：与 Reef 做实验性能力比较，不能双重上线 |
| [microsoft/agent-lightning](https://github.com/microsoft/agent-lightning) | `reference` | `MIT` | **agent training / RL trajectory optimization**：未来权重更新，V1 不依赖训练集群/GPU |

### 评测与观测（10 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) | `adopt-dev` | `MIT` | **pydantic_evals datasets, evaluators, trajectories**：使用独立 pydantic-evals 包，确定性验收仍自有 |
| [promptfoo/promptfoo](https://github.com/promptfoo/promptfoo) | `adopt-dev` | `MIT` | **eval/redteam CLI and CI config**：开发期注入/工具投毒对照；不得联网泄漏机密数据 |
| [UKGovernmentBEIS/inspect_ai](https://github.com/UKGovernmentBEIS/inspect_ai) | `pilot` | `verify\_at\_pin` | **eval tasks, scorer, dataset, agent models**：与 Pydantic Evals 试对照，择一为主，不套叠 |
| [langfuse/langfuse](https://github.com/langfuse/langfuse) | `core-existing` | `MIT\_core; commercial\_ee` | **tracing, sessions, prompts, datasets**：可选观测，核心 MIT，ee 单独许可证；配置去标识与禁遥测 |
| [Arize-ai/phoenix](https://github.com/Arize-ai/phoenix) | `reference` | `Elastic-License-2.0` | **OpenTelemetry traces, experiment UI**：源代码可见但不是 OSI 开源许可；不默认引入 |
| [facebookresearch/TUA-Bench](https://github.com/facebookresearch/TUA-Bench) | `pilot` | `verify\_at\_pin` | **terminal benchmark tasks and grading**：加入新终端真实任务对照，先审查数据许可证和资源成本 |
| [harbor-framework/terminal-bench-1](https://github.com/harbor-framework/terminal-bench-1) | `pilot` | `verify\_at\_pin` | **terminal task benchmark**：同模型同预算含 TUA、内部验收对照 |
| [SWE-bench/SWE-bench](https://github.com/SWE-bench/SWE-bench) | `pilot` | `verify\_at\_pin` | **real repository patch benchmarks**：编码成功率对照和金标准验收 |
| [sierra-research/tau2-bench](https://github.com/sierra-research/tau2-bench) | `pilot` | `verify\_at\_pin` | **tool use benchmark with user simulation**：工具行为序列与副作用正确性 |
| [xlang-ai/OSWorld](https://github.com/xlang-ai/OSWorld) | `reference` | `verify\_at\_pin` | **desktop GUI agent benchmark**：V1 GUI 控制非目标，后续电脑 Agent 用 |

### 本地推理与检索（8 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [BerriAI/litellm](https://github.com/BerriAI/litellm) | `core-existing` | `verify\_at\_pin` | **completion / acompletion and accounting**：可信模型网关 adapter；不运行自治编排器 |
| [ollama/ollama](https://github.com/ollama/ollama) | `pilot` | `verify\_at\_pin` | **local model server and model registry**：供 16GB 显存小模型探索；无需默认云服务 |
| [ggml-org/llama.cpp](https://github.com/ggml-org/llama.cpp) | `pilot` | `verify\_at\_pin` | **GGUF runtime, llama-server**：本地低显存推理候选；与 Ollama 二选一部署 |
| [vllm-project/vllm](https://github.com/vllm-project/vllm) | `watch` | `verify\_at\_pin` | **high throughput batching and serving**：服务规模化场景；单机 V1 不必部署 |
| [sgl-project/sglang](https://github.com/sgl-project/sglang) | `watch` | `verify\_at\_pin` | **efficient generation engine**：规模化推理/训练备用，不与 vLLM 同时成为必选 |
| [FlagOpen/FlagEmbedding](https://github.com/FlagOpen/FlagEmbedding) | `core-existing` | `verify\_at\_pin` | **BGE-M3 and reranker models**：已有 embedding/rerank；必须验证具体模型维数 |
| [pgvector/pgvector](https://github.com/pgvector/pgvector) | `core-existing` | `verify\_at\_pin` | **PostgreSQL vector index**：已有向量召回模块 |
| [xhluca/bm25s](https://github.com/xhluca/bm25s) | `core-existing` | `verify\_at\_pin` | **BM25 lexical retrieval**：已有词法检索，不误写成 PG ts_rank BM25 |

## 5. 对照实验与录用规则

- **公共基线**：Hermes 最新冻结 SHA、AETHER 无候选版、AETHER 开启候选版；同一可运行模型、工具权限、token/cost 上限、仓库快照、隐藏测试和网络政策。所有使用外部服务的数据必须单独标记，不把数据未锁定的结果作公平比较。
- **指标**：`task_success`、`false_completion`、`security_violation`、`cost_per_success`、`tool_calls`、`tokens`、`context_resident_tokens`、`P50/P95`、`failure_recovery`、`rollback_correctness`。Crawl4AI 额外有页面解析质量；Memory 有污染/删除和时态事实；图谱有冷/热索引与无效图缓存检测。
- **避免评测作弊**：独立的高可信工具按事先签名的任务和工件校验；模型不能接触保密 verifier、通过评测结果反向编辑任务，也不能自动改门槛。
- **录用政策**：任一安全或项目隔离测试失败→不启用；结果波动不显著→继续保留默认方案；重依赖若收益不足→不安装。记录`not_run`与缺失资源；不能把项目方 README benchmark 当我们的结果。
- **当前硬件**：本地小模型路线由 Ollama 或 llama.cpp 二选一，云端模型可替换；不强行安装 vLLM+SGLang 双服务器，不假设显存可以装下任意量化模型。

## 6. 来源验证层级

`review_status=license_checked` 表示已通过 GitHub 官方仓库许可证或 README 明确宣称核对许可类别，但**未**完成第三方依赖许可证审计、法律审查和固定代码提交哈希。`review_status=needs_license_check` 是尚未核对。`production_enabled=false` 和 `dependency_probed=false` 如实代表**未集成、未验收**。

特别留意 2026 年 10 月新的变化：Serena v2 更新 2026-10-13；Crawl4AI v0.9.5 2026-10-14；Daytona 开源仓库归档 2026-10-03。后续所有日期/版本都需要 Codex 再去对应 release/tag/commit 复核。

## 7. 结论

**这次真正该落地的是 5 个工作面：独立 eval + Promptfoo 红队、可切换 MemoryEngine、CodeGraph 仓库智能、浏览器/爬虫可选适配、隔离的 Skill 自我进化实验。** 原来 Temporal 和 OpenHands 的基本职责不变。不要为收集 80 个仓库而增加 80 个依赖。

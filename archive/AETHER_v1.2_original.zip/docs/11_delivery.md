# 11 · Codex 实施、验收与交付定义

## 开发方式

先测试包合同，再锁定真实依赖，然后先做薄的完整链路，不先堆所有表单。每milestone产出一个可执行增量；普通任务连续推进。上下文不够时写HANDOFF再继续，而不是重新解释架构。不得把缺密钥作为不做存储/工作流/UI的理由。

## M00—M11阶段门

| 阶段 | 交付 | 必须看到的证据 |
|---|---|---|
| M00 | 依赖/API/平台/licensing spike、lock与doctor | 原始安装/import/最小sandbox命令；失败明确列出 |
| M01 | 数据库、身份、project隔离、契约 | 真Postgres迁移与runtime角色RLS测试 |
| M02 | Temporal task纵向链路 | 提交→工具→验证→事件；重启worker能继续 |
| M03 | gateway预算/权限/operation ledger | 并发reservation、审批重放、unknown对账测试 |
| M04 | 采集、BM25、向量、重排、证据 | 真模型向量+中英夹具排序；删除立即不再返回 |
| M05 | OpenHands编码执行与独立测试 | 真实隔离job、patch、trusted tests、相同digest证据 |
| M06 | 记忆、MCP、审批全闭环 | 冲突/更正、schema漂移与scope回归 |
| M07 | 推荐、反馈、定时跟踪 | 幂等profile、可关闭探索、无变化不总结 |
| M08 | 技能候选、独立评测、deploy/rollback | 失败候选不晋级，样本不足不宣传有效 |
| M09 | 完整UI和端到端场景 | Playwright连接真实API，不仅组件mock |
| M10 | Hermes基线与学习比较工具 | 实际runner smoke；四组实验manifest、费用与split审计 |
| M11 | 系统故障、安全、live演示与发布包 | 重启/断网/重复命令/恢复；生成完整验收报告 |

详细tickets在`tasks/backlog.yaml`。所有mandatory gate必须运行；不能只满足happy path。真实模型与最终独立数据集缺失时，分开标blocked和not_evaluated。

## 必须做出的三段演示

**研究**：导入一组中英本地/授权网页资料，提出比较目标；真实搜索与引用，显示没有证据的项，不用LLM编造来源。

**编码**：把一个有故障的小仓库快照交给OpenHands；输出patch，在独立trusted tests中验证；worker中途中断后任务恢复，不能生成重复job。

**学习**：从合格的训练trace生成候选；一个坏skill被拒绝，一个符合门槛的候选以真实evaluator结果进入试运行；回滚恢复旧版。合成reference分数只用于控制逻辑测试，不当真实学习收益展示。

## 测试分层

- Unit：纯函数/合同/排序/预算/状态和错误处理，不需要网络。
- Integration：真实PostgreSQL/Temporal/文件存储/本地HTTP与MCPfixture，依赖被替换的部分明确标记。
- Security：真实进程/容器网络、权限、secret、SSRF、scope与注入场景。
- E2E：UI到真实API和workflow；scripted模型可用于确定性链路，但不能替代live验收。
- Live：用户配置的真实模型，研究与编码各至少一次，记录成本与产物hash。不自动产生真实外部写操作。
- Evaluation：dev/validation/release dataset角色明确；没有独立release dataset，不报告对Hermes优越性。

每个测试log包含命令、cwd、commit、python/node/image refs、开始结束、exit code、summary、artifacts。`make acceptance-report`由实际JUnit/JSON结果生成，不能手填全绿。

## 完成/阻塞规则

状态：not_started/in_progress/blocked/done。done要求相关tests执行且通过；blocked必须有可复现错误和最小外部依赖说明。缺少一个必需环境不能把所有独立ticket都标blocked。

产品“V1完成”需要M00-M11工程mandatory与live gate通过；“优于Hermes”是独立结论。没有live配置时可以交付可运行工程版，但最终summary必须说live gate未运行。

## 最终交付清单

可运行前后端、数据库迁移、锁定依赖/镜像、.env.example无secret、真实make命令、种子夹具、runtime auth与隔离、独立验证器、技能注册/评测/回滚、baseline runner、测试日志与report、故障恢复说明、备份恢复操作和限制。补`THIRD_PARTY_NOTICES.md`与实际运行的资源/平台矩阵。

必须保留本规格版本。任何架构变更写DECISIONS，说明触发证据、替代方案、迁移影响和新增测试。不因偏好换栈，不把新依赖数量当成果。

---
上游依据：S43、S44，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。

## CodeGraph 附加验收（可选 feature，但评测不得省略）

AETHER without CodeGraph 必须仍能完成编码功能。启用时，单独验收索引/查询权限、版本失效/恢复、candidate hash 变化后的 stale 行为、进程退出/清缓存及无公网遥测；Graph 推荐的测试只能增加而不能替代可信 suite。通过 M00-06/M05-06 的验证后，M10-06 记录有/无图谱成本收益。Codex 不可将外部组件尚未安装当作系统功能已完成。

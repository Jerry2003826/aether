# Specification boundary

This is a complete implementable V1 design in the sense of fixed scope, component choices, data/API contracts, explicit unknown integration gates and sequenced acceptance tasks. It is not a claim that every upstream integration has already been executed or that all production code is included.

Architecture changes require evidence. M00 is a required compatibility investigation, not an invitation to redesign the product. Only replace an incompatible adapter in its stated boundary; keep the single workflow authority and all security/evaluation invariants.

The optional services and deferred features are intentional, not hidden placeholders. V1 is for one owner and multiple isolated projects, technical research/coding/search/recommendation/authorized watches; it is not a public hostile multi-tenant cloud, a global web index or an AGI training project.

The provided SQL is a concrete baseline rather than a production migration; runtime roles, immutable write controls, CAS transactions, service auth and database integration tests remain implementation tasks. OpenAPI describes endpoints rather than implementing them. Public acceptance scenario specifications are not executable test results. See reports/PACK_VALIDATION.md.

# 13 · CodeGraph 接入规格：代码知识图谱（2026-10-15 增补）

## 0. 确认选择与边界

**选用**：<https://github.com/colbymchenry/codegraph>，MIT license；2026-10-15 查阅官方 README、CLI/MCP、Library API、遥测和供应链描述（来源 S46–S49）。**不**默认安装其他同名 CodeGraph (`codegraph-ai/CodeGraph`, `Lordymine/codegraph`, `GitNexus`)；`CodeGraph` 不是唯一产品名，若用户指另一款必须重新比较。

这是 `Coding Intelligence` / `Repository Intelligence` 层，不是整个 AETHER 的 Knowledge Fabric（普通文章、网页、PDF 等依旧 BM25S + pgvector + BGE），不代替 Temporal、OpenHands、独立 verifier，也不引入 Neo4j。

在产品边界上，CodeGraph 主要提供 `symbol -> file -> caller/callee -> dependency -> possible impact/test hint` 的查询路径。由 AETHER 负责数据授权、不可变版本、工具调用预算、评测和最终报告。

**两个完全独立的使用场景**：

1. **开发 AETHER 的 Codex（宿主工具）**：在开发机上启用 CodeGraph MCP/CLI 以理解 AETHER 源码，可在 M00 的安装/安全审查通过后初始化；并非 AETHER 产品的一项实际已实现能力。
2. **AETHER 内运行的 Agent（产品功能）**：只可经 `RepositoryIntelligence` 内部适配器，在指定项目、指定不可变仓库快照的受限 worker/沙箱内访问 Graph。Agent 不直接运行 host Codex 的 MCP，不共享开发机的全局用户目录或凭证。

## 1. 复用上游哪个模块

优先通过稳定 CLI + MCP 协议接入，隔离于 Python 控制平面：

- CLI：`codegraph init [path]`、`codegraph status [path]`、`codegraph explore <query>`、`codegraph callers/callees/impact <symbol>`、`codegraph affected [files...]`，**具体输出结构需 M00 固定发布后实测**。
- MCP：启动方式 `codegraph serve --mcp`；官方默认只暴露 `codegraph_explore`，而 `node/search/callers/callees/impact/files/status` 需按文档额外启用。不能假定默认就有全部工具。
- 备选 SDK：npm 包 `@colbymchenry/codegraph` 导出 `CodeGraph.init/open/indexAll/searchNodes/getCallers/buildContext/getImpactRadius`。如果 CLI/MCP 无法满足 token budget/JSON 数据需求，单独 Node 子进程可使用 SDK（要求 Node >=22.5 for built-in sqlite），在 M00 验证实际签名与卸载行为后才切换；**不把 Node SDK embed 进 Python 进程**。
- 内部数据：`*.codegraph` graph cache 为派生数据；不复制上游索引引擎/源码。SQLite `.codegraph/` 和 watcher 生命周期必须与某一个单独 snapshot worker 生命周期一致。

默认使用 CLI 的 `--json`（仅在该命令经 `help` 确认支持时）或 MCP 结构化响应；`codegraph_explore` 的自由文本输出若未明确带稳定 field metadata，需用 AETHER 自己的 source snapshot resolver 二次绑定 `file:line` 和 hash，**禁止解析自然语言后虚构精准图谱边**。

## 2. AETHER 内部 API（全部自有，并非上游）

`RepositoryIntelligence`：

```python
index(snapshot: AuthorizedRepositorySnapshot, options: IndexOptions) -> IndexManifest
query(scope: ProjectScope, snapshot_id: UUID, question: str, max_tokens: int) -> CodeContextResult
impact(scope: ProjectScope, snapshot_id: UUID, symbol_ref: str, max_depth: int) -> CodeImpactResult
affected_tests(scope: ProjectScope, snapshot_id: UUID, changed_files: list[str]) -> AffectedTestsResult
invalidate(project_id: UUID, snapshot_id: UUID) -> None
```

`project_id` 与 `snapshot_id` 从 server-authenticated task context / immutable artifact ledger 绑定；LLM **不能**传一个绝对 `projectPath`、仓库 URL、host 路径、worker 环境变量或进程命令来选择查询作用域。`query` 只接受约束长度的自然语言问题；symbol/path/changed_files 做白名单字段验证。用于执行的 SDK/CLI 命令由 adapter 生成固定 argv，无 shell 插值。

MCP 原始工具是外部供应商实现，接入走审阅过的 ToolGateway capability；不要直接把整个 `codegraph_*` 工具集给 actor。工具白名单详见 `config/tools.example.yaml` 的 `repo.code.*`。实际授权由 AETHER 服务端复查，不能信 MCP tools 的描述。

**索引身份**：`(project_id, repository_artifact_id, snapshot_sha256, codegraph_version, extraction_options_hash)`。`IndexManifest` 包含它们及 index ready/stale/failed 状态、建立时间、上游工具版本、已索引文件计数和审计 ref。`run_id` 仅归属操作，不成为新索引身份。每个不可变 repo snapshot 的索引都是派生缓存；修改后产生 candidate snapshot/new index，不把新文件覆盖到先前验收使用的索引。

**响应约束**：`CodeContextResult` 中每个事实性 symbol/location 都有 `relative_path`、行范围、`file_sha256`、`snapshot_sha256`、`graph_version` 以及 freshness；未知边/不支持语言用 `unknown`，不能造边。

## 3. 真实编程任务流程

```text
Coding intent (owner-approved immutable repository snapshot)
   ↓ verify project/capability and snapshot digest
RunnerManager → isolated workspace (NO host git mount, NO global home)
   ↓ optional CodeGraph index (bounded CPU/RAM/timeout)
Repo intelligence → relevant symbols / imports / impact / candidate test hints
   ↓ untrusted-data channel with source paths + digest, token budget
OpenHands Executor → patch → immutable candidate artifact
   ↓ new candidate snapshot + independent graph freshness check
Impacted test suggestions (ADVISORY only)
   ↓ independent Verifier's trusted suite ALWAYS executes
Result: pass/fail + artifact hash + graph version + costs/latency
```

**两个故障场景**：

- Graph 缺少 caller edge（动态调用、Python monkey-patching、反射等）→ 回答降级为 `partial/unknown` 并提供原始 AST/静态结果；Actor 可以再读取已授权真实源码。绝不把“未列出调用者”解释为无调用者。
- Graph 因文件变动/自动 watcher debounce 变旧 → `stale` 标记，指定文件重新读取/重建索引；禁止在最终验收时当作当前 patch 的真实结构图。

`codegraph affected` 可帮助确定**额外**可能需要跑的测试，但不能缩小 AETHER 的强制 trusted test suite，也不能阻止全套安全/回归测试。影响范围只是静态近似，不能是“安全证明”。

## 4. 安全与隐私

- 只有已登记仓库快照：拒绝符号链接逃逸、zip-slip、绝对路径、`..`、hardlink/export 篡改。路径词法验证不够：读取源码还要在受限 worker 内做 realpath/openat 类安全校验。
- 默认 `CODEGRAPH_TELEMETRY=0` 且 worker 默认无公网出站。官方说明本地索引与匿名遥测是两个不同事实，不能混淆“本地解析”和“绝对零外传”。
- `.codegraph/` 放在沙箱/专用索引 volume，严格按 project+snapshot 分区，设置大小、CPU、内存、文件数与运行时限。不得索引 host `~` 或文件系统根；`.gitignore` + 额外 denylist 排除 `.env`、credentials、私钥、tokens、数据库 dumps、其他项目的 workspace。
- 未授权 `projectPath` 必须无法绕过：进程只看见**单个**仓库的只读副本。MCP server 不加载任何用户目录可用的其他项目索引。
- 源码中的注释、README、字符串、自动生成文档和工具返回内容均视为**不可信数据**，不得转化成系统指令/权限/用户要求。上下文裁剪和脱敏后才给模型，跨服务传输避免携带 secrets。
- 禁止 `curl | sh` 自动安装，也不能让 agent 自动运行 `codegraph install` 修改用户的 `~/.codex/config.toml` / root `AGENTS.md`。M00 先审安装包、许可证、镜像/可执行文件哈希与发布证明；仅用户同意后进行开发机全局配置。产品生产运行用**锁定版本**、单独 worker 镜像。
- CLI/MCP 失败应显式降级到授权的 filename search/read/grep；不得把纯 grep 结果冒充图谱结构结论。

## 5. 配置与接入顺序

- `config/codegraph.example.yaml` 是计划配置；`enabled: false` 是默认。管理员安装并通过探针后才打开产品 feature flag。
- **M00-06**：审 repo、锁定发布、CLI/MCP probe、macOS arm64 和 Linux runner 平台矩阵、telemetry-off/权限边界、产生 `reports/codegraph-probe.json`，不自动改 Codex 全局配置。
- **M05-06**：实现 project/snapshot-scoped adapter + cache manifest + read-only tool whitelist + stale/symlink/deleted-project tests。任何不可用情况不得阻塞主 OpenHands 编码任务，可诚实降级。
- **M10-06**：对同一公开任务集运行 `AETHER+CodeGraph` vs `AETHER without CodeGraph`，同时测**正确率、文件打开数、模型 token、耗时、总成本、漏召/错误影响范围**。比较两组使用相同模型、相同 source snapshot、相同预算。Graph 预索引耗时计入总成本且区分 cold/warm。

以上 3 个是额外开发任务，不改动原 60 个主体任务的完成标准；在未完成产品时不宣称 CodeGraph 提升。供应商官方 benchmark 是自报结果，**不当作 AETHER 的结果**。其 README 还说明长会话结束时图谱检索残留的上下文可能反而更多；因此要求报告 `residual context tokens` 与 truncation/memory pressure。

## 6. 给 Codex 的开发指导

先阅读 `docs/13_codegraph.md`、`config/codegraph.example.yaml`、`contracts/codegraph.schema.json` 和新票据。**不要**将 CodeGraph 的 install 脚本作为项目 bootstrap 自动执行。

完成 M00-06 后可以在受审开发机上用以下**参考命令**手动接入 Codex：

```sh
# 确认具体版本并检查其 npm 脚本/许可证后，替换 VERSION（不得使用 latest 作为 lock）
npm view @colbymchenry/codegraph versions --json
npm install -g @colbymchenry/codegraph@VERSION
CODEGRAPH_TELEMETRY=0 codegraph install --print-config codex  # 仅读取建议配置
cd /path/to/aether                 # 必须是已审阅的具体项目目录
CODEGRAPH_TELEMETRY=0 codegraph init
CODEGRAPH_TELEMETRY=0 codegraph status
# 用户同意后再按打印片段注册 Codex MCP/AGENTS.md；不自动修改全局配置。
```

MCP 工具配置由用户显式同意；为了调试也可以使用 `CODEGRAPH_TELEMETRY=0 codegraph explore "where is the coding executor boundary"`。这是静态代码理解，不是对 OpenHands 任务结果的验证。

## 7. 验收标准

- 未安装 CodeGraph：正常编码流可运行，返回 `degraded: missing_codegraph`，不伪装已经做结构检索。
- 未授权 project/snapshot、跨项目路径、不可变版本失配、`..` / symlink 逃逸一律拒绝。
- 当前候选变动后，陈旧图谱不能被当作当前候选已验证的结构。
- graph-only 指向测试文件只能**增加**检查，不能取代 trusted suite。
- 实际 CLI 或 MCP query 出现退出失败/超时/协议错误时，错误被记录，失败不摧毁编程任务。
- 评测报告记录冷启动索引耗时 + warm 查询成本；有 CodeGraph/无 CodeGraph 共享同一个模型与固定版本，未运行不能声称收益。

来源：S46–S49；实现方案、合同/限制及默认值是 AETHER 自定，非上游保证。

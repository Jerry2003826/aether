# 来源与核实边界

设计核实日期：2026-10-14。下列是实际查阅的上游仓库、官方文档或官方模型卡。具体库/API事实由这些来源支持；AETHER架构、默认阈值、接口、验收规则和排期分解属于本设计，并非上游保证。

两条Git SHA来自该日期实际读取的branch metadata，仅冻结来源定位。除这两条外没有伪造commit、lock、镜像digest或已完成的兼容性测试。可变分支/文档需M00复核到最终锁定版本。未做完整依赖安全/许可证审计，亦未下载完整上游代码。

仓库复用以依赖安装和薄adapter为主；本包未粘贴上游大段代码。源码或社区skills复制时必须保留对应版权与许可证。所有来源只作本设计依据，不自动授权连接用户账户或产生副作用。

| ID | 来源 | 设计中支持的内容 / 核实限制 |
|---|---|---|
| S01 | [Hermes官方仓库；现有Agent功能和基线入口](https://github.com/NousResearch/hermes-agent) | 读取README/功能；baseline snapshot见repositories.yaml。 |
| S02 | [Hermes Skills文档](https://github.com/NousResearch/hermes-agent/blob/main/website/docs/user-guide/features/skills.md) | 已有技能写入审批；不宣称AETHER独有。 |
| S03 | [Hermes来源commit](https://github.com/NousResearch/hermes-agent/commit/0e427d788d253630d38a3a51cd76849e73cd6925) | 2026-10-14读取branch main，来源定位，不是已运行基线。 |
| S04 | [OpenHands Software Agent SDK](https://github.com/OpenHands/software-agent-sdk) | 复用SDK/tools/workspace/agent-server，而不是整套应用。 |
| S05 | [OpenHands固定SDK metadata](https://github.com/OpenHands/software-agent-sdk/blob/0bd5cc2d322d61f785816a29ef1f2e4c86db2460/openhands-sdk/pyproject.toml) | 读取version1.54.0和Python>=3.12；未安装。 |
| S06 | [OpenHands workspace约束](https://github.com/OpenHands/software-agent-sdk/blob/0bd5cc2d322d61f785816a29ef1f2e4c86db2460/pyproject.toml) | 四包workspace与依赖约束；M00实际解决。 |
| S07 | [OpenHands远端Docker会话示例](https://github.com/OpenHands/software-agent-sdk/blob/0bd5cc2d322d61f785816a29ef1f2e4c86db2460/examples/02_remote_agent_server/02_convo_with_docker_sandboxed_server.py) | 读取DockerWorkspace/Conversation/events/cost/close；默认preset/latest不可照搬。 |
| S08 | [OpenHands Agent Server架构](https://docs.openhands.dev/sdk/arch/agent-server) | 远端编程执行器的边界。 |
| S09 | [OpenHands Workspace架构](https://docs.openhands.dev/sdk/arch/workspace) | 本地/远端workspace；具体参数在锁定版复核。 |
| S10 | [Temporal Python SDK](https://github.com/temporalio/sdk-python) | workflow/activity/worker/client。 |
| S11 | [Temporal Python文档](https://docs.temporal.io/develop/python) | 持久工作流开发入口。 |
| S12 | [Temporal messages](https://docs.temporal.io/develop/python/workflows/message-passing) | signal/update/query语义。 |
| S13 | [Temporal testing](https://docs.temporal.io/develop/python/best-practices/testing-suite) | 工作流测试与回放。 |
| S14 | [Temporal activity定义](https://docs.temporal.io/activity-definition) | 活动幂等性；不保证任意外部副作用exactly-once。 |
| S15 | [Temporal官方样例](https://github.com/temporalio/samples-python) | hello/hello_activity.py与hello_activity_retry.py。 |
| S16 | [Temporal服务](https://github.com/temporalio/temporal) | 选择持久服务，不fork服务。 |
| S17 | [LiteLLM SDK](https://github.com/BerriAI/litellm) | provider适配；不是AETHER权限权威。 |
| S18 | [LiteLLM completion](https://docs.litellm.ai/docs/completion) | completion/acompletion接口入口。 |
| S19 | [LiteLLM structured output](https://docs.litellm.ai/docs/completion/json_mode) | provider能力存在差异，须本地schema校验。 |
| S20 | [pgvector](https://github.com/pgvector/pgvector) | vector类型、cosine、exact/HNSW。 |
| S21 | [pgvector Python binding](https://github.com/pgvector/pgvector-python) | Python/SQLAlchemy适配。 |
| S22 | [pgvector RRF样例](https://github.com/pgvector/pgvector-python/blob/master/examples/hybrid_search/rrf.py) | 参考融合方法；并非说明PostgreSQL FTS是BM25。 |
| S23 | [BM25S](https://github.com/xhluca/bm25s) | BM25/Tokenizer/index/retrieve/save/load；不可变索引生命周期由AETHER实现。 |
| S24 | [jieba](https://github.com/fxsjy/jieba) | 中文搜索分词。 |
| S25 | [FlagEmbedding](https://github.com/FlagOpen/FlagEmbedding) | BGEM3FlagModel/FlagReranker。 |
| S26 | [BGE-M3官方模型卡](https://huggingface.co/BAAI/bge-m3) | 选用dense 1024维；revision和权重license须固定。 |
| S27 | [BGE reranker官方模型卡](https://huggingface.co/BAAI/bge-reranker-v2-m3) | 选定重排器；未测目标机器延迟。 |
| S28 | [HTTPX](https://github.com/encode/httpx) | 可信HTTP下载基础；SSRF策略并非该库自动提供。 |
| S29 | [Trafilatura](https://github.com/adbar/trafilatura) | extract解析已下载HTML。 |
| S30 | [feedparser](https://github.com/kurtmckee/feedparser) | RSS/Atom bytes解析。 |
| S31 | [Docling](https://github.com/docling-project/docling) | 本地文档转换；OCR不是默认全部执行。 |
| S32 | [Playwright Python](https://github.com/microsoft/playwright-python) | 有需要才调用JS浏览器。 |
| S33 | [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk) | client/transport；固定major与protocol。 |
| S34 | [Agent Skills规格](https://agentskills.io/specification) | SKILL.md标准；安全/评测sidecar是本设计。 |
| S35 | [Agent Skills仓库](https://github.com/agentskills/agentskills) | 兼容格式参考，不等于可信技能市场。 |
| S36 | [FastAPI](https://github.com/fastapi/fastapi) | API基础；不复制完整平台。 |
| S37 | [Next.js](https://github.com/vercel/next.js) | App Router/TypeScript UI。 |
| S38 | [shadcn/ui](https://github.com/shadcn-ui/ui) | 少量审阅组件，不引入第二个Agent UI数据模型。 |
| S39 | [Langfuse](https://github.com/langfuse/langfuse) | 仅可选观察profile。 |
| S40 | [PostgreSQL17 RLS](https://www.postgresql.org/docs/17/ddl-rowsecurity.html) | owner/superuser/BYPASSRLS边界，真实非superuser角色必须测试。 |
| S41 | [Docker rootless安全文档](https://docs.docker.com/engine/security/rootless/) | 风险缓解，不宣称容器绝对安全或公开多租户隔离。 |
| S42 | [Pydantic models文档](https://docs.pydantic.dev/latest/concepts/models/) | shape validation与frozen不是权限/深冻结。 |
| S43 | [OpenAI Codex AGENTS.md](https://developers.openai.com/codex/agent-configuration/agents-md) | 根目录AGENTS.md与渐进读取；产品进度另外持久记录。 |
| S44 | [OpenAI Codex实践](https://developers.openai.com/codex/learn/best-practices) | 明确任务/上下文/验证要求；不是一次prompt完成的保证。 |
| S45 | [OpenAI Codex CLI](https://developers.openai.com/codex/cli) | 在项目目录使用Codex的官方入口；不假设订阅是产品API key。 |
| S46 | [CodeGraph 官方仓库](https://github.com/colbymchenry/codegraph) | 2026-10-15 读取：MIT、CodeGraph CLI + MCP (`codegraph_explore` 默认)、`codegraph affected`、SQLite `.codegraph`、监控增量更新，支持 Codex；M00 仍必须锁定发布及安装校验。 |
| S47 | [CodeGraph 源码内嵌 Library Usage](https://github.com/colbymchenry/codegraph#library-usage) | `CodeGraph.init/open`、`indexAll`、`buildContext`、`getImpactRadius` 等为可选 JS API；包内 Node 22.5+ 的约束不同于自带运行时的 CLI。 |
| S48 | [CodeGraph 遥测与供应链说明](https://github.com/colbymchenry/codegraph#telemetry) | 官方描述匿名遥测、`CODEGRAPH_TELEMETRY=0` 关闭，发布签名/attestation 验证流程；AETHER 在本地 worker 里默认禁用外联。 |
| S49 | [CodeGraph CLI 与 MCP tool 描述](https://github.com/colbymchenry/codegraph#mcp-tools) | 默认 MCP 工具为 `codegraph_explore`，其他结构查询可经 CLI/配置开启；工具默认返回的 context 含源码，必须设上下文和数据出站限制。 |

# 把下面整段发给 Codex

你现在位于 AETHER 项目根目录。这里已经有完整的产品规格、仓库复用映射、机器可读契约、参考代码和开发验收任务。你的任务是按这些文件把 AETHER V1 实现出来，不是再给我一个设计方案。

先读 AGENTS.md、README.md、MASTER_SPEC.md、STATUS.json 和 tasks/backlog.yaml，再按当前阶段读取对应文档。先检查现有文件和 Git 状态，不覆盖用户已有代码。从第一个未完成且未被阻塞的任务开始；默认依次完成 M00–M11。技术选型和边界按规格执行，不要另起一套 Agent 框架。

M00 必须实际核实上游 API、Python/Node/镜像兼容性、许可证范围和依赖锁；config/repositories.yaml 中的 SHA 只是来源快照，不能冒充已经验证的运行环境。然后先交付可运行的完整纵向链路：提交目标 → Temporal 执行 → 真实工具 → 独立验证 → 证据与事件展示；随后补齐研究检索、编程执行、权限审批、持久记忆、推荐、定时追踪和技能评测升级。

没有 API key 时使用明确标记的 scripted 模型完成真实系统的离线端到端开发，不允许伪造模型输出冒充 live 结果。没有 Docker 或网络时，如实记录阻塞，但继续实现可以本地完成的契约、核心逻辑、UI、数据库迁移和测试。不得把没执行的测试写成通过，不得因为测试失败而删除测试、降低阈值或篡改预期结果。

每个任务必须有实际代码、测试和运行证据。及时更新 STATUS.json、tasks/backlog.yaml、reports/Mxx.md 和 reports/HANDOFF.md。普通本地开发不要反复问我要不要继续；不要只做 M00 或只做漂亮页面就结束。持续完成所有可以完成的任务。遇到真实环境限制时列明具体阻塞和未完成项，不要宣布整个系统完成。

最终交付应包含可运行前后端、锁定依赖、Docker Compose 开发环境、数据库迁移、种子数据、make 命令、独立验收与安全测试、真实 live 演示记录（有密钥时）、Hermes 对照评测入口以及清晰的启动说明。未经我明确授权，不得向外部仓库 push、发布服务、购买资源或执行真实高影响外部操作。

现在开始检查仓库并直接实施第一个可执行任务。

## 2026-10-15 CodeGraph 增补指令

补充阅读 `docs/13_codegraph.md`、`config/codegraph.example.yaml`、`contracts/codegraph.schema.json`，按 `M00-06/M05-06/M10-06` 实施。不自动安装 CodeGraph 或修改全局 Codex 设置；M00 先审固定版本、CLI/MCP行为和遥测。可选功能缺失时正常编码流程要降级可用，独立测试绝不能被 CodeGraph affected-test 建议替代。

## V1.2 GitHub ecosystem gate
Before choosing new optional components, read `CODEX_ECOSYSTEM_UPDATE.md`, `docs/14_ecosystem_audit.md`, `docs/15_ecosystem_integration.md`, `config/ecosystem_candidates.yaml` and `config/ecosystem_experiments.example.yaml`. Do not bulk-install the catalog. See M00-07 and other optional tickets in backlog; existing Temporal/OpenHands core stays unchanged.

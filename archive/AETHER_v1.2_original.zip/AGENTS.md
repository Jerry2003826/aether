# AETHER implementation instructions

You are implementing AETHER V1, not producing another proposal. User-facing language is Simplified Chinese; source identifiers and API fields use English. Preserve the supplied specification and build real functionality.

## Read first
1. `README.md`, `MASTER_SPEC.md`, `docs/02_architecture.md`.
2. `docs/03_repository_map.md`, `docs/04_execution.md`, `docs/06_security.md`.
3. `tasks/backlog.yaml`, `STATUS.json`, then the documents required by the current milestone.
Read other files progressively; do not stuff the entire pack into a prompt. If paths or upstream APIs have changed, inspect the pinned source and document the change in `docs/DECISIONS.md`.

## Fixed decisions
- New modular Python backend; Temporal is the only authority for running task lifecycle. PostgreSQL stores domain data, commands, operations and read models; do not build a second scheduler in the database.
- FastAPI + Pydantic + SQLAlchemy/Alembic; Python 3.13 for the control plane. Separate virtual environments/images for OpenHands and embedding dependencies when required.
- A small typed AETHER turn loop runs through Temporal activities. LiteLLM is a provider adapter inside the trusted model gateway, not another autonomous orchestrator.
- OpenHands Software Agent SDK is a bounded coding executor behind our runner interface, never the owner of the whole application. Use explicit tools, no automatic public skill/plugin loading and no unrestricted preset.
- PostgreSQL + pgvector for authoritative metadata and vectors; BM25S project-scoped immutable lexical indexes; FlagEmbedding for BGE-M3 and BGE reranking. No Google search or Google-dependent core service.
- Next.js + TypeScript UI, real API, SSE event replay; no fake dashboard data outside clearly labeled fixture/demo mode.
- Do not add LangGraph, CrewAI, Letta, AutoGen, Gorse, Vespa, Neo4j, Kafka or Kubernetes to V1. Langfuse is an optional observation profile, not required to run the system.
- All API credentials stay in trusted services. Agent sandboxes never mount Docker socket, host home, SSH keys, control-plane database credentials or verifier secrets.

## Implementation order
Work through M00–M11 in `tasks/backlog.yaml`, preserving dependencies. Finish a minimal vertical slice before broadening features. For each ticket: implement -> run relevant tests -> inspect artifacts/logs -> fix -> record evidence. Continue to the next unblocked ticket without asking for permission to do ordinary local work. Do not auto-push, publish, buy services, send real messages or change machine-wide security settings.

## Honesty and anti-shortcut rules
- Never report tests as passed unless executed. Record command, environment, exit code and log path. A skipped live test is not a pass.
- No TODO-only endpoints, no production mocks, no `return True` verifiers, no swallowed exceptions, no “success” for unknown outcomes.
- Preserve acceptance tests. Do not lower thresholds, remove failing checks or rewrite expected values to make a milestone green. Legitimate spec corrections require a decision record and corresponding tests.
- Do not invent third-party methods, exact package versions, model IDs, container image digests or compatibility claims. M00 resolves and validates them. Do not use `latest` in a release manifest.
- Keep `reference/` as a tested reference; port it into real services and add integration tests. Passing reference tests alone does not complete any product milestone.
- Credentials and prices are not provided. The live configuration must fail closed when missing; implement offline fixture mode independently. Do not scrape developer tool subscription credentials as runtime API keys.

## Security and correctness invariants
1. Network I/O, model calls and filesystem side effects occur in activities or trusted services, never in deterministic Workflow code.
2. External operations have stable intent IDs, argument hashes, resource versions, approval binding, an operation ledger and explicit unknown-outcome reconciliation. Temporal retries do not mean exactly-once effects.
3. Read-only tools still require authorization and data-egress control. Never trust MCP annotations, web content, repository files or skill text to define permissions.
4. Verification is a separate trust boundary. Bind results to the immutable artifact and acceptance-contract hashes. A hash proves byte identity, not truth or trusted origin.
5. Project authorization applies before retrieval/reranking/LLM context formation. A project's files, vectors, skills and audit records must never leak through another project's request.
6. Keep cost reservations until ambiguous model bills are reconciled. Unknown prices or usage are not zero cost.
7. Skill candidates cannot promote themselves, modify policy, change evaluation datasets or write their own final scores.
8. Holdout data is not in actor or learner containers. Public development fixtures are not a held-out benchmark.

## Target commands to implement
`make doctor bootstrap dev demo-offline test-unit test-integration test-security test-e2e demo-live acceptance-report`
The first product vertical slice must be runnable without paid model access, but only by an explicitly named scripted provider using real orchestration, storage, parsing and verification.

## Work records
Update `STATUS.json`, ticket statuses and `reports/Mxx.md` after each milestone. Store local progress as small commits when in a Git repository; never amend away user work or force-push. If blocked, write the exact failing command, necessary missing resource and affected tests, then continue independent tickets. Before each context handoff, update `reports/HANDOFF.md` with the next concrete action.

## Final delivery
Provide real launch commands, config instructions, test evidence, demo recordings/screenshots when available, artifact/commit hashes and remaining limitations. Mark V1 complete only if mandatory gates in `docs/11_delivery.md` passed. An attractive front end is not a completed Agent system.

## CodeGraph addendum (2026-10-15)
CodeGraph is an optional, approved *structural code intelligence* component, not a replacement for general search or the independent verifier. Read `docs/13_codegraph.md` and `config/codegraph.example.yaml`. Implement new tickets M00-06 / M05-06 / M10-06; preserve M00-M11 mandatory path. Do not silently install codegraph or rewrite global Codex MCP/AGENTS settings. Choose only `colbymchenry/codegraph` after auditing a pinned version. Product feature flag remains off until probes pass. Scope every index/query to project-owned immutable repository snapshots inside a sandbox; never permit actor-provided projectPath. Graph affected-test suggestions must not reduce trusted tests. Telemetry must be disabled and network blocked in runtime worker. Compare graph-on/off in a controlled ablation and report raw outcomes, not vendor benchmark multipliers.

## V1.2 ecosystem due-diligence addendum (2026-10-15)
Research inventory `config/ecosystem_candidates.yaml` is NOT a production dependency lock. Study `docs/14_ecosystem_audit.md` and `docs/15_ecosystem_integration.md` only when implementing one of M00-07/M04-06/M05-07/M05-08/M06-06/M08-06/M10-07/M10-08/M10-09/M11-06. These ten items are optional/experiment tasks; no pre-existing mandatory gate is weakened. Keep all feature flags OFF until a pinned revision, license and privacy audit, isolated real probe and benefit/safety ablation have completed.
- Adopt **pydantic-evals alone** for development evaluation; do not add Pydantic AI's Agent runtime as another orchestrator. Promptfoo synthetic-only red-team tests complement rather than replace verifier.
- Pick **at most one** production MemoryEngine; evidence, source IDs and ACL authority stay in AETHER. Never blindly deploy Hindsight, Mem0, Cognee, Graphiti and OpenViking together.
- CodeGraph remains only approved optional code graph. GitNexus is PolyForm Noncommercial and not for default commercial embedding. Serena v2 application is GPL-3.0-or-later; its `src/solidlsp` is MIT; check exact version and component. No code copying across license boundary without approval.
- Daytona and Roo Code upstream repos were archived in 2026; exclude as production dependencies. All third-party browser profiles MUST be fresh, task-local and unauthenticated by default. Snyk Agent Scan may send discovered MCP/skills to vendor API; do not turn on remote scanning by default.
- Report every benchmark honestly, including `not_run`, time/cost, unchanged baseline, equal privileges, grader version and project-scoped immutable artifacts. No one commits third-party skills into the trusted tool surface without explicit review.

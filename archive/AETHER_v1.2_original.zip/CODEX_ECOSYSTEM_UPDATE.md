# 给正在开发 AETHER V1.1 的 Codex：增量升级指令（V1.2）

你当前负责实施 AETHER；用户额外要求把 2026-10-15 GitHub 新开源生态调研中的高价值能力系统性纳入设计。**只做增量合并，保留已有用户工作/commit，不回滚 V1.1 的 CodeGraph 计划，尤其不能用新框架替换 Temporal 的唯一权威。**

完整新增文件：`docs/14_ecosystem_audit.md`, `docs/15_ecosystem_integration.md`, `config/ecosystem_candidates.yaml`, `config/ecosystem_experiments.example.yaml`；阅读 `tasks/backlog.yaml` 的新任务和 `AGENTS.md` 新约束。

实施顺序：
1. 先运行 `git status`，备份和查看现有更改，不要强制覆盖。
2. 执行 M00-07：为实际准备集成的候选核对官方 tag/immutable commit/软件包名、根/子目录许可证、transitive 依赖、平台支持、数据遥测/联网隐私、维护状态。**不要把 81 个仓库批量 pip/npm install**。
3. 按主线推进原有 M00-M11；工具选择只采用**统一 Adapter 接口**，每个功能槽只有一个生产实现。
4. 第一批新试验：`pydantic-evals` (独立 eval，不需要 pydantic-ai Agent)、promptfoo 合成数据红队、Hindsight vs AETHER-native vs Mem0/Cognee、Crawl4AI（授权 JS 页面备选）、agent-browser（空白隔离 profile）、CodeGraph 与 MIT SolidLSP 对比。
5. 自我进化参考 Reef+CORAL 独立 grader 实验；只接离线 evaluator，不把训练/实验框架放到生产调度路径。
6. 基于 raw evidence 做 Hermes / AETHER on/off 公平对照。未执行的真实平台和付费模型测试必须标 `not_run`，禁止将 mock 通过写成 live 功能完成。

默认不引入：GitNexus（PolyForm-Noncommercial，除符合条件的独立非商业对照外）；Serena v2 GPL 主体（可用 MIT `src/solidlsp`）；OpenViking AGPL 主体、SearXNG AGPL、Firecrawl AGPL（如需部署须另审）；归档 Daytona/Roo；会向 Snyk API 发送工具/技能数据的自动 agent-scan；Composio 托管服务（不能成为强制依赖）。

运行规格包结构验证：`python scripts/verify_pack.py`; 运行参考测试：`python -m unittest discover -s tests -v`。这些不是任何线上依赖的验收。读 `STATUS.json` 查看设计状态。

不要询问用户是否允许普通本地实现；如需付费服务/发布/发邮件/把用户私有数据送入第三方/改全局 Codex 设置则等待审批。任务完成要附**真实命令、exit code、日志与 artifact hash**，继续跟进未完成任务。

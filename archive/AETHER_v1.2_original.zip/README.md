# AETHER — Codex 开发交付包

**规格版本：1.2 · 设计日期：2026-10-15 · 状态：设计 + 可测试领域参考实现，不是已完成的产品。**

AETHER 是一个自托管、以可验证执行和受控经验学习为核心的个人 Agent 系统。第一版面向技术研究、代码修改、资料搜索、个性化推荐和持续跟踪。基础模型可替换；核心检索不依赖 Google；模型权重不需要训练。

本包的目的不是让 Codex 再写方案，而是让它按确定的架构交付完整 V1。`reference/` 是已经编写的契约与纯逻辑参考，不是 Temporal、OpenHands、浏览器或数据库的真实集成。

## 交给 Codex

1. 把本 ZIP 解压到一个新建 Git 项目的根目录，确保根目录能看到 `AGENTS.md`。不要覆盖已有项目文件。若在既有仓库中使用，先建独立分支，保留原文件，并让 Codex 做冲突检查。
2. 在 Codex 中打开这个根目录，粘贴 `CODEX_START.md` 中的提示词。
3. Codex 应从 M00 开始连续实现，并把每个阶段的真实命令、退出码和结果写到 `reports/`。缺少网络、Docker 或 API 密钥时，应继续做不依赖它们的工作，并如实标记被阻塞的验收，而不是伪造通过。

**这不是声称一次提示就能保证整个产品完成。** 规格按长任务、上下文切换和多次会话设计；中断后用同一提示继续，先读 `STATUS.json` 和 `tasks/backlog.yaml`。不要因为产品很大而退回继续讨论架构。

## 阅读顺序

- `AGENTS.md`：Codex 的执行约束与完成定义。
- `MASTER_SPEC.md`：一份串联全部设计的总规格。
- `docs/03_repository_map.md`：哪个仓库、哪些模块、怎么接、哪些不能复用。
- `tasks/backlog.yaml`：有依赖关系、产物和测试要求的开发任务。
- `contracts/`、`reference/`、`fixtures/`：机器可读接口和示例。
- `docs/11_delivery.md`：构建、测试、演示、发布与恢复要求。
- `reports/PACK_VALIDATION.md`：本次交付包实际做过的检查与没做过的检查。

## 产品建成后的操作目标（下列是 Codex 必须实现的命令，目前不是已有程序）

```sh
make doctor                 # 查依赖、端口、Docker、模型配置；不泄露密钥
make bootstrap              # 安装锁定依赖、迁移、准备本地配置
make dev                    # 启动开发栈
make demo-offline           # 真实数据库/工作流/工具，使用明确标记的脚本化模型
make test-unit
make test-integration
make test-security
make test-e2e
make demo-live              # 真实模型，显式提供密钥与预算；不静默启用
make acceptance-report      # 汇总真正运行的测试，未运行项目必须单独列出
```

现在可执行的包自检：

```sh
python scripts/verify_pack.py
python -m unittest discover -s tests -v
```

自检使用 Python 3.12+、Pydantic 2、PyYAML、jsonschema；环境缺包时只报告缺失。锁定产品依赖是 M00 的工作，不能把本包的参考环境冒充产品 lockfile。

## 三条不可退让的完成条件

**执行完成不等于模型说完成。** 必须有绑定产物哈希的独立验收结果。

**会写记忆不等于会学习。** 技能更新必须经过独立评测、版本切换和回滚。

**架构先进不等于已经超过 Hermes。** 只有在公开记录的同模型、同预算实验里胜出，才能提出限定范围的比较结论。

## 本包不包含

未授权的账号凭证、云账单额度、真正封存的最终测试集、已安装的第三方仓库、完整应用、产品依赖锁文件或“优于 Hermes”的实测结果。`config/repositories.yaml` 中的 snapshot SHA 是来源定位，不是兼容性或安全认证。

## v1.1 增补：CodeGraph

加入可选项目级代码知识图谱。**已写入设计、机读合同、仓库清单、配置、实施任务和公开验收场景；并没有安装/运行 CodeGraph 本体。** 开发期 Codex MCP 与产品内运行时是不同的权限环境。参考 `docs/13_codegraph.md`，CodeGraph 默认关闭，M00 验证后才能启用。普通文档与网页检索仍由 BM25S/pgvector/BGE 负责。

## v1.2 增补：GitHub 生态选型、候选适配和许可审计

2026-10-15 增加 81 条候选条目（80 个独立 GitHub 仓库）、10 项可选实施/对照任务、10 份纯开发期公共用例、11 项**纯本地规格策略测试**。新增后总任务 **73**，原 63 项含 CodeGraph 的任务完整保留。**仅两项开发评测工具（Pydantic Evals 和 Promptfoo）建议优先引入开发环境，其余都是试验或参考，绝不批量安装。**

- 详见 `docs/14_ecosystem_audit.md`、`docs/15_ecosystem_integration.md`、`config/ecosystem_candidates.yaml`。
- 新项目请使用 `CODEX_START.md`，现有正在实施的 AETHER 项目使用 `CODEX_ECOSYSTEM_UPDATE.md` 增量合并。
- 须先锁真实版本与许可证再运行任何上游组件；此次新增部分**未**运行真实第三方库、Docker、模型或外部 benchmark。

# AETHER · 完整系统设计与 Codex 开发规格

**V1.2 · 2026-10-15 · 中文交付版（GitHub 生态审计 + CodeGraph 增补）**

定位：自托管、以可验证执行和受控经验学习为核心的个人 Agent 系统，集成技术研究、编程、证据记忆、自主检索、个性化推荐与持续跟踪。

交付的是设计、接口、任务队列、配置模板、开发夹具与可执行领域参考逻辑，不是已完成的应用。尚无“优于Hermes”的实测结论。Codex应解压完整开发包并从AGENTS.md与M00开始，不只读取这份总文档。

## 目录

1. `00_SCOPE_AND_LIMITATIONS.md` — Specification boundary
2. `01_product.md` — 01 · 产品范围与成功定义
3. `02_architecture.md` — 02 · 架构与唯一权威
4. `03_repository_map.md` — 03 · 仓库复用地图：明确复用什么，不复用什么
5. `04_execution.md` — 04 · 目标合同、执行循环与故障恢复
6. `05_knowledge.md` — 05 · Knowledge Fabric、搜索、记忆与推荐
7. `06_security.md` — 06 · 权限、隔离与提示词注入防线
8. `07_learning_evaluation.md` — 07 · Skill Evolution Lab 与可信评测
9. `08_api_ui.md` — 08 · API、控制台与用户交互
10. `09_data.md` — 09 · 数据模型、事务与保留
11. `10_operations.md` — 10 · 运行栈、模型、成本与发布
12. `11_delivery.md` — 11 · Codex 实施、验收与交付定义
13. `12_integration_details.md` — 12 · 集成细节、认证与初始参数
14. `DECISIONS.md` — Architecture decision records
15. `SOURCES.md` — 来源与核实边界
16. `13_codegraph.md` — 结构化代码图谱 CodeGraph 增补
17. `14_ecosystem_audit.md` — 2026 GitHub 开源生态全面审计
18. `15_ecosystem_integration.md` — 新候选适配和验收门禁


---

<!-- canonical source: docs/00_SCOPE_AND_LIMITATIONS.md -->

# Specification boundary

This is a complete implementable V1 design in the sense of fixed scope, component choices, data/API contracts, explicit unknown integration gates and sequenced acceptance tasks. It is not a claim that every upstream integration has already been executed or that all production code is included.

Architecture changes require evidence. M00 is a required compatibility investigation, not an invitation to redesign the product. Only replace an incompatible adapter in its stated boundary; keep the single workflow authority and all security/evaluation invariants.

The optional services and deferred features are intentional, not hidden placeholders. V1 is for one owner and multiple isolated projects, technical research/coding/search/recommendation/authorized watches; it is not a public hostile multi-tenant cloud, a global web index or an AGI training project.

The provided SQL is a concrete baseline rather than a production migration; runtime roles, immutable write controls, CAS transactions, service auth and database integration tests remain implementation tasks. OpenAPI describes endpoints rather than implementing them. Public acceptance scenario specifications are not executable test results. See reports/PACK_VALIDATION.md.


---

<!-- canonical source: docs/01_product.md -->

# 01 · 产品范围与成功定义

## 1. 产品定位

AETHER 是个人使用、可扩展到小团队的自托管 Agent 工作台。V1 的初始发布是**单账户、多项目**；不同项目仍必须强隔离。研究资料、搜索索引、偏好和执行记录均由自己控制。它以 ResearchOS 式技术资料研究为主要知识场景，并可在隔离环境执行代码任务。

“先进”定义为可以测量的结果，而不是 Agent 数量：任务结果真实可验、失败后可恢复、同等结果成本更低、经验在未见任务上有用。是否超过 Hermes 留给对照实验，不预先宣称。

## 2. V1 必须完整实现的用户故事

| 编号 | 用户故事 | 最终可见结果 |
|---|---|---|
| U01 | 提交自然语言目标，检查系统理解与验收条件 | 可编辑草案、批准后的不可变合同、预算 |
| U02 | 调研某技术并比较多个方案 | 可追溯来源的报告、搜索过程、局限说明 |
| U03 | 在指定仓库快照中实现一个功能 | 独立 patch、测试日志、差异预览；不自动改主分支 |
| U04 | 中断程序/重启机器后继续任务 | 恢复记录；不重复不可逆操作 |
| U05 | 审批需要外部副作用的动作 | 具体目标、参数、影响、有效期；拒绝后不执行 |
| U06 | 纠正记忆、查来源、删除某项目资料 | 冲突解释、历史版本、删除与索引失效可验证 |
| U07 | 搜索自己的技术资料并获得推荐 | 混合搜索、重排、推荐理由与反馈入口 |
| U08 | 订阅授权来源的变化 | 定时增量采集、差异摘要、站内通知 |
| U09 | 看见系统从任务中提议新技能 | 候选 diff、独立评测、批准/回滚 |
| U10 | 看清模型成本和所有执行证据 | 单次请求到任务汇总；未知成本明确显示 |
| U11 | 在无外网和无付费模型时体验演示 | 基于本地夹具与 scripted provider 的真实系统链路 |
| U12 | 接入一个经管理员审核的 MCP 服务 | 受限工具列表，schema 固定，权限与审批不旁路 |

## 3. 不纳入 V1，但要保留清晰接口

不做企业计费、组织 SSO、完整办公 IM 网关、公开互联网全量搜索引擎、社交协同过滤平台、手机/桌面全 GUI 控制、基础模型微调、自动修改自身控制代码、生产集群调度。不是以未来模块替代当期功能：V1 仍要完成上表全部核心闭环。

核心不依赖 Google 的含义：不使用 Google 搜索/API/身份服务/云服务作为必要条件；资料可来自授权站点、RSS、arXiv API、GitHub API及本地文件。公开网页发现范围受已配置来源限制，不把有限语料库称为全球互联网索引。云模型也是可替换依赖；离线模式不承诺达到云模型质量。

## 4. 初始容量边界（设计预算，不是实测）

每项目上限 50,000 chunks；默认最多 2 个活跃工具节点、1 个编码沙箱；单账户；Linux amd64 为完整编码沙箱验收平台，macOS arm64 为控制台/研究链路验收平台。CUDA 仅是 embedding/reranker 的可选加速；控制服务不依赖 GPU。运行资源须由 M00/M11 实测，不给出未经测试的内存或吞吐保证。

## 5. 三种完成状态

- **工程可用**：功能、故障、安全与本地演示验收通过。
- **真实模型可用**：真实模型完成研究任务与代码任务，所有账单和工具调用可追踪。
- **有比较优势**：冻结实验中，在明确任务分布、模型和成本口径下优于基线。

前两项不自动推出第三项。没有真实模型凭证时只能交付“工程验收完成、live 验收被阻塞”，不能标全量 V1 完成。

---
上游依据：S01、S02，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。


---

<!-- canonical source: docs/02_architecture.md -->

# 02 · 架构与唯一权威

## 1. 逻辑分层

```text
Next.js Workbench
       │ HTTPS / REST / SSE
FastAPI API ── PostgreSQL(domain, commands, operations, projections)
       │ durable command outbox
Temporal Server ── TaskWorkflow / ResearchWorkflow / WatchWorkflow / SkillEvaluationWorkflow
       │ activities (all non-deterministic I/O)
AETHER Worker
  ├─ Goal compiler / bounded typed turn loop / DAG scheduler
  ├─ Knowledge & search adapter ── BM25S snapshots + pgvector
  ├─ Trusted Gateway ── model calls / approved tool dispatch / cost & capability checks
  ├─ Runner Manager ── isolated OpenHands coding jobs
  │     └─ Optional CodeGraph repo intelligence ── scoped source graph cache
  └─ Independent Verifier ── clean test job / evidence validation / human acceptance

Ingestion & ML worker ── HTTPX + Trafilatura + feedparser + Docling + FlagEmbedding
Artifact store ── project-scoped content-addressed files
Optional observability ── OpenTelemetry / Langfuse
```

这是逻辑图，不要求每一项成为微服务。API、领域模块、worker 共用一个 Python monorepo。网关、runner-manager、verifier 分开进程/凭证，原因是权限隔离，不是追求微服务数量。ML 和 OpenHands 分环境以控制依赖冲突。

## 2. 权威归属

| 状态 | 权威 | 其他模块怎么读取 |
|---|---|---|
| 执行进度、DAG、等待/取消、重试计划 | Temporal Workflow history | Query/update 与 PostgreSQL 可重建投影 |
| 用户目标、合同、权限、审批、成本账本、知识版本 | PostgreSQL | API/activities；workflow 只引用版本与 ID |
| 某次外部操作实际是否发生 | 外部系统 + operation ledger 的对账证据 | gateway reconcile，不能只看 workflow 状态 |
| 字节产物 | ArtifactStore 的不可变对象 | ID+SHA256，读取时鉴权 |
| 编码会话内的临时执行 | OpenHands job/conversation | 有界执行器，不调度应用级任务 |
| 技能当前启用版本 | PostgreSQL skill deployment record | 固定版本注入；会话中途不悄悄切换 |

PostgreSQL 的 task.status 是投影，不是另一套调度器。禁止 API 直接写 SUCCEEDED。调度器崩溃恢复依赖 Temporal，不从 UI 状态猜测下一步。

## 3. 模块/目录目标

```text
apps/web/                          # Next.js TypeScript
services/api/aether_api/            # auth, REST, SSE, commands
services/worker/aether_worker/      # Temporal workflows/activities
services/gateway/aether_gateway/    # model & tool execution admission
services/runner/aether_runner/      # trusted Docker/remote job lifecycle
services/verifier/aether_verifier/  # deterministic/human evidence checks
services/ml/aether_ml/              # embedding, reranker, parsing
packages/domain/aether_domain/      # typed contracts, no network I/O
packages/knowledge/aether_knowledge/
packages/skills/aether_skills/
packages/evaluation/aether_evaluation/
packages/adapters/aether_adapters/  # only sanctioned third-party boundaries
migrations/                        # Alembic, derived from schema contract
infra/                             # compose, locked image refs, healthchecks
examples/                          # real runnable user demos
```

`reference/` 和 `contracts/` 为规格基准，生产包不得通过修改它们来躲过验收。可以把参考逻辑提取到 domain 包，再让同一组测试同时验证生产实现。

## 4. 核心接口

`RepositoryIntelligence.query/impact/affected_tests(snapshot,scope)` (optional; see `docs/13_codegraph.md`); `ModelGateway.generate(request) -> ModelResult`；`ToolGateway.execute(intent) -> OperationResult`；`CodingExecutor.start/get/cancel(job)`；`Verifier.verify(request) -> VerificationResult`；`Knowledge.search(request) -> SearchResult`；`SkillRegistry.resolve(scope,task_type,version)`；`ArtifactStore.put/get/delete`。

接口详见 `contracts/interfaces.py` 和 `contracts/domain.schema.json`。这些是 AETHER 自己的接口，不是声称上游仓库存在同名方法。

## 5. 调度方式

默认一个 planning actor；任务节点按角色使用 research、coding 或 extraction 执行器。并行最多两个读节点，写同一资源严格串行；编码节点默认一个。验证器只检查结果，不参与规划。禁止 agent-to-agent 无界群聊。

Planner 产生 DAG 时校验节点唯一、依赖存在、无环、并发/预算和深度上限。只有全部依赖已验证通过的节点能被调度。失败重规划不能删除原始合同中的验收条件。

## 6. 禁止隐式控制路径

UI 不直接访问 OpenHands Agent Server、Temporal 管理接口或 LiteLLM。插件不能直连数据库。Actor 不能写技能生产目录。LLM 不能通过工具结果重定义权限。对所有下游 executor 做资源限额与端到端截止时间检查，而不是仅在提示词里写“不要超时”。

---
上游依据：S04、S10、S14，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。


---

<!-- canonical source: docs/03_repository_map.md -->

# 03 · 仓库复用地图：明确复用什么，不复用什么

## 总策略

**新建 AETHER 仓库；不 fork Hermes 当应用内核；不把多个完整平台拼起来。** 已经成熟的传输、持久工作流、编码执行器、解析器和检索算子直接用；目标合同、权限、跨任务经验、验收与技能升级由我们实现。

此处的路径是查阅/集成入口，不表示已经把上游源码安装并运行。来源见 `docs/SOURCES.md`；机器清单见 `config/repositories.yaml`。

## A. 执行底座

### A1. NousResearch/hermes-agent —— 独立基线，不是应用内核

仓库：<https://github.com/NousResearch/hermes-agent>

来源快照：`0e427d788d253630d38a3a51cd76849e73cd6925`。重点读 `README.md` 和 `website/docs/user-guide/features/skills.md`，理解其已有记忆、技能学习与写入审批。不要宣称这些功能是 AETHER 独有。

**使用方式**：在独立镜像/进程中跑固定版本，通过 `BaselineRunner` 协议投喂同一任务、模型端点和预算，收集轨迹。M00 实际执行该版本 CLI `--help` 后确定适配命令；本包不捏造稳定的 Hermes Python 内部 API。每个 cold task 使用新 profile；learning 实验使用独立训练 profile，再冻结后评测。

不复制 `run_agent` 内循环、不共用其用户目录、不让 baseline 接触 AETHER 的训练轨迹或隐藏评测答案。

### A2. OpenHands/software-agent-sdk —— 受限编程执行器

仓库：<https://github.com/OpenHands/software-agent-sdk>

来源快照：`0bd5cc2d322d61f785816a29ef1f2e4c86db2460`。该快照 `openhands-sdk/pyproject.toml` 标明 SDK 1.54.0、Python >=3.12；这是读取到的元数据，不是已安装验证。根 workspace 对依赖另有约束，**不得只装一个包就假定四个包兼容**。

实际复用：
- `openhands-sdk`：`LLM`、`Agent`、`Conversation`、`Tool` 与事件/远端 conversation。
- `openhands-tools`：显式启用 `TerminalTool`、`FileEditorTool`，可选 `TaskTrackerTool`；不给它生产连接器。
- `openhands-workspace`：`DockerWorkspace`；研究 `RemoteAPIWorkspace` 以支持将来远程 runner。
- `openhands-agent-server`：私有网络内的会话服务。
- 参考 `examples/02_remote_agent_server/02_convo_with_docker_sandboxed_server.py`：创建 workspace、回调收事件、发送消息、运行、读成本与关闭会话。

**适配位置**：`packages/adapters/aether_adapters/openhands.py`，由 trusted runner-manager 调用。接口是 `start/get/cancel`；创建 job 必须按 intent ID 幂等。具体 SDK 参数以 M00 的最小沙箱测试为准，不编造 `max_iterations` 之类未经核实的构造参数。上游示例使用默认 agent 和浮动 image 只为演示，AETHER 必须改成显式 tool 清单、禁用公共 skill 自动加载、镜像 digest、外部预算/时间守卫。

**输出**：patch、文件 manifest、代码快照哈希、SDK events、用量。`conversation.run()` 结束不代表任务验收通过。最终文件由独立 verifier 重建和检查。

### A3. temporalio/temporal + temporalio/sdk-python —— 唯一持久执行引擎

仓库：<https://github.com/temporalio/temporal>；<https://github.com/temporalio/sdk-python>

用官方服务镜像和 Python SDK，不 fork 服务。复用 workflow/activity/worker/client、持久计时器、signals/updates、child workflows、heartbeat、retry、continue-as-new 与 replay testing。示例仓库 <https://github.com/temporalio/samples-python> 的 `hello/hello_activity.py`、`hello/hello_activity_retry.py` 是入门骨架；不要直接拿例子的无限重试/默认配置上线。

适配位置：`services/worker/aether_worker/workflows/`。所有 LLM、文件和 HTTP 调用放 activity。业务副作用幂等仍由 operation ledger 管理；Temporal 不替外部系统保证 exactly-once。

### A4. BerriAI/litellm —— 模型协议适配，不是第二个 Agent

仓库：<https://github.com/BerriAI/litellm>

在 `services/gateway/` 中复用 SDK `completion/acompletion` 的模型/provider 参数归一、输出和 usage。V1 自建薄层认证与预算逻辑，不依赖其 Enterprise 的治理特性，也不部署第二套自主路由/任务管理平台。

结构化输出先做 provider 能力探针，再做 Pydantic 本地校验；最多两次有限修复，每次计费。价格通过管理员维护并固定版本的价格表，不盲信 model alias 永久价格。runner 环境内 OpenHands 的 LiteLLM 是其内部依赖，但网络只能接 AETHER 网关，不能拿全局 provider key。

## B. 知识、搜索与推荐

### B1. pgvector/pgvector + pgvector/pgvector-python

仓库：<https://github.com/pgvector/pgvector>；<https://github.com/pgvector/pgvector-python>

复用 `vector(1024)`、cosine distance、Python/SQLAlchemy 类型绑定。第一版默认 project-filtered exact search；确认召回/延迟后才启用 HNSW。参考 `examples/hybrid_search/rrf.py` 的融合思想，**不是把 PostgreSQL ts_rank_cd 当 BM25**。索引归属、ACL、删除、证据版本由我们负责。

### B2. xhluca/bm25s + fxsjy/jieba

仓库：<https://github.com/xhluca/bm25s>；<https://github.com/fxsjy/jieba>

BM25S 用 `BM25.index/retrieve/save/load`，以及 `bm25s.tokenization.Tokenizer`。参考 `examples/tokenizer_class.py`。参数 `method=lucene, k1=1.2, b=0.75` 是初始设计值，不声称最优。

中文用 jieba 搜索模式；英文/代码标识符保留完整词并做下划线/camelCase 拆分。冻结 tokenizer 与词典；同一 query/corpus 共享词表与处理版本。所有数据按 project 构建不可变快照、原子切换；BM25S 不替我们实现增量一致性。

### B3. FlagOpen/FlagEmbedding

仓库：<https://github.com/FlagOpen/FlagEmbedding>

复用 `BGEM3FlagModel` 的 `dense_vecs` 作为 1024 维向量；用 `FlagReranker` 的分数进行 cross-encoder 重排。模型固定选择 `BAAI/bge-m3` 和 `BAAI/bge-reranker-v2-m3`，revision 与模型文件哈希由 M00 冻结。参考 `docs/source/bge/bge_m3.rst` 和官方模型卡。

模型运行在独立 ML worker；没有 GPU 时可以 CPU 执行，但不承诺交互延迟。首次下载是安装步骤，离线运行要求预先缓存权重。默认不同时常驻大型生成模型与两个 ML 模型；按队列串行、延迟加载。下载权重许可证独立检查。

### B4. 采集与解析的分工

- <https://github.com/encode/httpx>：trusted gateway HTTP 下载；限大小、超时、重定向并验证网络目标。
- <https://github.com/adbar/trafilatura>：只对已下载 HTML 调用 `extract`；不走其内置下载器。
- <https://github.com/kurtmckee/feedparser>：只解析已下载 RSS/Atom bytes；不是定时器。
- <https://github.com/docling-project/docling>：`DocumentConverter` 与结构化文档/页面定位；从本地文件读取，在资源受限 parser worker 内运行。扫描 OCR 是显式选项，不默认把全部资料 OCR 一遍。
- <https://github.com/microsoft/playwright-python>：只有静态下载无法获取正文时才启动 JS 浏览器；每任务独立 context，无用户现成登录态。不是绕过站点访问控制的工具。

每个 parser 都做 Adapter contract test。源文件路径必须来自我们生成的 artifact ID，不能由页面内容提供主机路径。

### B5. 推荐不再塞入一个完整平台

V1 自己实现基于内容/兴趣/当前目标/新鲜度的排序、MMR 去重、多样性和可关闭探索。没有足够多真实用户行为时，不先装 Gorse/RecBole 冒充有效协同过滤。推荐及反馈协议保持独立，为后续学习排序保留训练样本，但不在 V1 引入另一个数据/权限权威。

## C. 工具、技能与界面

MCP：<https://github.com/modelcontextprotocol/python-sdk>，用 client session 与官方 transport；不照单全收远程工具。上游 SDK major 可能变化，M00 必须固定 major、记录协商协议、验证断线/取消/错误处理。

Skills：<https://github.com/agentskills/agentskills> 与 <https://agentskills.io/specification>，只借标准文件结构。额外安全、评测、部署字段放 `aether.skill.json`，不要篡改标准含义。技能兼容格式不代表脚本安全或功能等价。

UI：<https://github.com/vercel/next.js>、<https://github.com/shadcn-ui/ui>。用 Next.js App Router/TypeScript 与少量受审组件，不搬完整 Agent Canvas，不把 UI 绑定到 OpenHands 内部数据结构。

API：<https://github.com/fastapi/fastapi>。使用 FastAPI/Pydantic 生成真实 OpenAPI；以本包合同做兼容性测试。

观察：<https://github.com/langfuse/langfuse>，仅 optional profile。基本 trace/event/cost 查询先用我们的数据库与 OpenTelemetry。不能让引入 ClickHouse/Redis/对象存储等一组观察依赖成为启动最小系统的前提。

## D. 版本、许可证与供应链门禁

本包没下载完整仓库，也没生成可部署 lock。两条完整 SHA 是当前读取到的来源定位。M00 必须：查固定版本 LICENSE/子目录许可证/权重许可证；选兼容发布；实际安装 smoke；生成 `uv.lock`、前端 lock、镜像 digest 与 `THIRD_PARTY_NOTICES.md`；扫描已知依赖问题并写例外。不得从“仓库开源”推出所有企业目录、模型和社区 skill 可任意使用。

默认依赖库而非复制源码。确需借示例，保留原版权和许可证说明，并记录文件 URL、revision、修改范围。不执行 curl|bash 或任意仓库安装脚本；先审阅再安装。

---
上游依据：S01、S04、S07、S10、S17、S20、S23、S25、S33、S34，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。

## E. 新增 CodeGraph（结构化代码检索）

**选用**：<https://github.com/colbymchenry/codegraph>（MIT，2026-10-15 阅读源码仓库）；入口 CLI `codegraph init/status/explore/callers/callees/impact/affected` 和 MCP server `codegraph serve --mcp`。默认 MCP 仅展示 `codegraph_explore`，其他细分工具需要显式开启。Programmatic `@colbymchenry/codegraph` API 是备选，Node runtime 约束单独校验。

**复用位置**：开发阶段帮助 Codex 理解 AETHER repo；产品阶段在 `packages/adapters/aether_adapters/codegraph.py` 与 `services/runner/repo_intelligence/` 通过隔离子进程或 MCP 做受限代码上下文、调用关系、影响范围和建议测试检索。二者不能共享用户目录和权限。索引是可丢弃的 project + immutable snapshot 缓存，失败回退到授权代码读取。不要让图谱替代 trusted verifier 或 Knowledge Fabric。

**许可证/安装/隐私**：审阅锁定版本与发布证明，`CODEGRAPH_TELEMETRY=0`，沙箱无公网出站，不准自动执行上游 `curl | sh` 或修改宿主 Codex 全局设置。具体协议、任务与评测见 `docs/13_codegraph.md`。来源：S46–S49。


---

<!-- canonical source: docs/04_execution.md -->

# 04 · 目标合同、执行循环与故障恢复

## 1. Goal compiler

输入：用户原始目标、项目范围、可用工具、预算、允许数据出口。输出 `GoalContract`：可读目标、假设、产物、验收条款、停止条件和权限请求。所有模型草案做 schema 校验；无法确定的内容保留为显式假设，不能虚构用户同意。

只允许注册过的验收模板：`artifact_exists`、`json_schema`、`trusted_test_suite`、`citation_integrity`、`source_coverage`、`human_review`。模板参数有自己的 schema。不能把模型生成的任意 shell 当可信检查器。用户可选择现有测试 suite；suite 定义/命令由 trusted registry 维护，记录 hash。

目标提交后是 DRAFT。低风险且完全套用用户预批准模板的目标可自动批准；否则展示合同供用户批准。批准生成不可变 contract hash。重规划不能减弱合同；需要变更就生成新版本并重新批准。审批权限只能由 owner 操作。

## 2. Task 状态机

`DRAFT -> QUEUED -> RUNNING -> VERIFYING -> SUCCEEDED`

可分支：`RUNNING/VERIFYING -> WAITING_APPROVAL / PAUSED / NEEDS_REVIEW / FAILED / CANCELLED`。`WAITING_APPROVAL -> RUNNING/VERIFYING` 使用记录的 resume_state。`VERIFYING -> RUNNING` 仅用于有限重做；`NEEDS_REVIEW` 必须人工解决后回原阶段。终态不可直接复活；重跑创建新 task/run lineage。`UNKNOWN` 是 operation 状态（错误类别为 `UNKNOWN_OUTCOME`），并使相关 task 进入 NEEDS_REVIEW，不是 success 或普通 retry。

暂停是在安全边界不发出新操作；已经发往外部的操作可能仍完成。取消调用 runner cancellation、停止新模型调用、撤销 capability，随后对在途副作用做对账。UI 明确区别“已请求取消”和“取消已完成”。

## 3. Typed turn loop

```text
load immutable contract + budget snapshot
compile bounded DAG (<=32 nodes; depth<=3)
while unfinished:
  apply authorized control commands
  get dependency-ready nodes
  reserve budget/verification headroom
  select approved skills at fixed versions
  build context from authorized evidence
  call model -> validate Decision (no arbitrary code deserialization)
  for each proposed tool call:
    normalize args -> check capabilities/data egress/resource locks
    get approval when needed -> persist operation intent
    execute/reconcile through gateway -> persist evidence
  schedule independent verification of candidate artifacts
  success only if every mandatory criterion passes for current artifact hash
  else bounded repair/replan; stop at budget/deadline or unresolved outcome
```

Actor 的可选决定是 `call_tools`、`submit_candidate`、`request_clarification`、`stop_blocked`。不能返回 `mark_success` 或 `promote_skill`。工具结果是数据，不追加系统指令。

默认：最多 64 个 turn、48 次模型请求（子执行器也算）、2 次 replan、节点并行 2、编码沙箱 1；这些是配置上限不是承诺使用次数。模型格式修复和 verifier 模型评审同样占预算。等待审批最长 72h，等待不消耗 active execution budget。

## 4. Temporal 具体规则

- Workflow 仅用确定性逻辑和 SDK 的时间/UUID等确定性接口；所有网络、数据库、随机外部源和文件 I/O 在 Activity。
- 短读 Activity：有限指数退避、总超时。写 Activity：不可盲重试，先读 operation ledger。长编码：`start_job` 快速返回稳定 job ID，循环 `get_job` + durable timer；也可长轮询 heartbeat，但不得每次 Activity retry 新建 job。
- Update/Signal 命令携带 `command_id`，去重后再改变状态。Query 只读。API 先把命令写 DB outbox，dispatcher 可重试投递。
- API 提交：同一 transaction 写 task+start command；Workflow ID 使用稳定 task_id；“已存在”视为重复提交而不是再启动一个任务。
- 每个事件有稳定逻辑 event_id；重放或 Activity retry 不能生成重复 UI 事件。投影可从事件/历史重建，UI 展示 `projection_updated_at`。
- 历史过长时 continue-as-new 携带压缩后的 DAG/合同/游标，外部保存大产物。不要把整份 PDF、embedding 或完整源码塞入 history。
- Workflow 代码改版必须通过旧 history replay，并制定版本迁移；不能用“重建数据库”回避升级测试。

## 5. Operation ledger

每次**逻辑意图**分配 intent_id，重试沿用；重复执行同样参数但用户新意图必须有新 ID。记录 `(project_id, task_id, intent_id)` 唯一，`args_hash`、resource_version、capability ID、approval ID、idempotency class、provider ID、状态与证据。

状态：`PREPARED -> DISPATCHED -> CONFIRMED`；异常可 `FAILED` 或 `UNKNOWN`。在网络请求前 durable write DISPATCHED。网络请求返回之前 worker 崩溃时，不能假定没发生。

| 类别 | 崩溃/超时后的处理 |
|---|---|
| read_only | 可有限重试；每次模型/付费读取另记账 |
| idempotent_write | 使用同一 provider idempotency key；先查询现有结果 |
| reconcilable_write | 用远程对象 ID/marker/diff 与预期状态对账；确认未发生后才能重试 |
| non_idempotent | UNKNOWN 后停止，人工处理；禁止自动重发 |

租约到期不等于上一个外部请求停止。采用 fencing token、稳定 job ID、禁止并发 owner；外部不支持 fence 时依靠 UNKNOWN+对账。数据库 exactly-once 插入不等于网络副作用 exactly-once。

## 6. OpenHands job 生命周期

`QUEUED -> STARTING -> ACTIVE -> EXPORTING -> FINISHED`，失败/取消分支。每 job 一个隔离仓库副本与工作目录；使用已批准的 base_commit 导出，不把 host git worktree 的 `.git` 指针和主机仓库挂入沙箱。

模型走 job-scoped gateway token；任务自身只能在这个预算里调用指定模型。token 即使被该 job 的 shell 看到也不能调用管理/审批/其他项目接口。SDK 内部事件不直接作为 trusted evidence。

终止时停止进程树，收集 stdout/stderr 限长、退出状态、文件 manifest、patch hash。删除工作空间前先保存结果；崩溃后 start(intent_id) 返回既有 job，不再建第二个。TTL reaper 与恢复有 lease 协议，不能删掉仍活跃的 job。

## 7. Independent verifier

输入：不可变合同、candidate manifest hash、base_commit、trusted suite hash。新建干净验证工作区，按受限流程应用 patch，使用独立只读测试定义；不继承 actor 的解释/总结。运行代码仍是执行不可信代码，必须隔离网络与凭证。

验证集不让 actor 修改；拒绝被改写的 test runner、跳过全部测试、空结果、退出码被吞、测试采集数异常。Verifier 自己按可信 API生成证据记录，不接受 actor 自签结果。代码变动之后必须重新验收，不能沿用旧 commit 的绿灯。

研究任务：先查引用 source/version/hash/span 存在且可访问，再按合同检查覆盖率；“引用存在”不等于内容支持结论，语义支持必须独立 LLM/人工判断，并展示不确定项。主观目标可诚实停在 WAITING_APPROVAL（等待人工验收），不能用全自动 PASS 冒充成熟判断。

## 8. 关键崩溃点验收

必须注入：task DB提交后但 workflow未启动；外部服务已处理但HTTP响应丢失；artifact落盘后但ledger未提交；worker在审批等待时重启；重复审批命令；kill编码runner；verifier在生成报告前崩溃；workflow代码升级；budget reservation后网络超时。每个场景验证结果和操作次数，不只看进程是否重新启动。

---
上游依据：S07、S11、S12、S13、S14，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。

## 9. 增补：CodeGraph 编程上下文（可选）

CodingExecutor 只能在获准的 immutable repository snapshot 上让受限 RepoIntelligence worker 构建/查询代码图谱；返回 source digest + graph version + freshness，调用信息只作为 actor 的未可信上下文。已改动源码必须创建新 candidate snapshot。Graph 的 `affected` 提供测试建议，**不能减少 trusted verifier suite**。默认不开启，无 graph 时继续既有编码链路。详见 `docs/13_codegraph.md`。


---

<!-- canonical source: docs/05_knowledge.md -->

# 05 · Knowledge Fabric、搜索、记忆与推荐

## 1. 知识对象与来源

每份资料分成 `Source -> SourceVersion -> Chunk`。Source 是稳定入口，SourceVersion 保存抓取时间、内容时间（未知则 null）、原始/规范化内容 hash、语言、解析器版本、可见项目；Chunk 保存 canonical text 的 code-point offset、页号/段落标识和向量模型版本。摘要不能替代原文证据。

每条记忆是 `MemoryRecord`：kind（semantic/episodic/procedural）、category（fact/preference/procedure/episode/project_decision）、claim、epistemic_status（proposed/source_claim/user_confirmed/observed_test/inference/superseded）、来源证据、scope、valid_from/valid_to、recorded_at、置信等级及其产生方式。冲突由conflict_group标记，删除由deleted_at表示，不把来源可信度和生命周期混成一个字段。置信等级是启发式，不假装经统计校准的事实概率。

用户明确陈述、网站声称、Agent 推断、实际测试结果分开。冲突不覆写：产生 conflict group，保留双方证据与时间，让用户或任务消解。重要项目决策优先显式确认；敏感个人信息不自动跨项目共享。

## 2. 采集链路

```text
approved SourceConfig
  -> quota / robots / source permission / HTTP safety checks
  -> conditional GET (ETag / Last-Modified when available)
  -> immutable raw artifact + metadata
  -> isolated parser -> canonical text + locator map
  -> exact hash dedupe / near duplicate grouping
  -> versioned chunking
  -> embedding job
  -> PostgreSQL commit + index update outbox
  -> BM25S generation build + atomic pointer swap
```

默认输入：授权 URL、RSS/Atom、GitHub public API、arXiv API、上传 Markdown/纯文本/文本PDF、WebVTT字幕。私有 GitHub 连接是管理员配置的受限 connector，凭证不传 actor；不在 V1 假装支持所有私人平台。

网络每来源并发1、请求间隔初始1秒、HTML/RSS/VTT body默认10MiB、HTTP总硬上限20MiB、本地PDF上传默认25MiB；遇429服从 Retry-After，拒绝未经授权的登录/付费墙绕过。限值是设计初值。重复源 canonical URL 和内容hash去重，历史版本仍可引用。压缩文件默认不展开；未来展开必须有zip-slip、symlink和解压比/总大小限制。

解析失败保存 error、原始hash、失败阶段，可重试；不要悄悄存空正文。Docling/HTML parser 都按cpu/time/memory上限运行；OCR只给明确扫描件任务，记录费用/耗时，不代替文本解析。

## 3. Chunking

按标题/段落/代码块优先切分，初始目标 embedding-token 512、overlap64、单chunk最多1024tokens。不要将巨大代码块硬塞进一个向量；保留 parent section link。引用 offset 总是针对规范化文本，而不是后续分词文本。对中文、emoji、合成字符、CRLF、HTML实体做 offset 测试。

生产chunk_id使用UUIDv5，由project namespace与source_version_id/chunking_version/span确定性生成；原始摘要单独作为内容hash，不把64位hex塞进UUID字段。重切分产生新版本，不复用旧 chunk_id 指向新内容。embedding 维数、模型revision、归一化方式和 tokenizer version 一并存储；禁止不同embedding模型的数据混用。

## 4. 词法索引

BM25S `method=lucene,k1=1.2,b=0.75`。`Tokenizer` 采用冻结中文jieba词典+英文/代码分词；query词表禁止自增长破坏索引。停用词不要删除有意义的代码符号或否定词。未知词得到空或低召回，不导致异常。

每项目一个不可变generation。构建worker从固定数据库快照导出有序chunk IDs与文本，保存BM25矩阵/词表、映射、source watermark和manifest hash；写临时目录后校验，原子切换active generation。查询拿到generation句柄后整个请求使用同一版本，引用计数结束才GC旧目录。进程并发构建通过数据库advisory lock/lease避免覆盖。

明确限制：BM25S不是我们的事务型增量索引；批量重建默认debounce30秒。UI展示index_lag。新资料只有当chunk/vector/lexical符合最低合同才显示ready；向量失败可显式lexical_only，不假装完整hybrid。

删除/撤权立即进入tombstone，所有搜索结果在返回、重排、组装LLM上下文之前再次查权限/有效性；随后重建index并清理磁盘。在V1项目内权限一致，不承诺细粒度每段ACL；跨项目索引绝不合并再先检索后过滤。

## 5. Hybrid retrieval

查询输入先鉴权。原query必保留；可最多产生2个受预算限制的改写，不让改写替换用户真实意图。默认每路top50：BM25与dense cosine。融合用 RRF：`sum(1/(60+rank))`，rank从1开始、同一路重复ID只计一次。初版固定权重相等；不把不同数值尺度的BM25和cosine直接相加。

RRF top30交 `BAAI/bge-reranker-v2-m3`，返回top8；每份文档最多2段，再按上下文预算裁剪。知识工具结果带所有 source_version/hash/span，不只返回自然语言摘要。重排失败允许标记degraded并退回RRF，不改变证据ID。

本地小语料默认精确向量查询。HNSW是后续同一接口下的优化，须验证project过滤后Recall@k；不能为了速度过滤掉正确答案却不报告。分别测BM25-only/dense-only/RRF/rerank的Recall@10、MRR@10、nDCG@10和p95，不先宣布hybrid必然更好。

## 6. Evidence graph

不引入Neo4j。PostgreSQL `evidence_links` 表存 `supports/contradicts/derived_from/supersedes/tested_by` 边。边的端点统一为immutable artifact：source version的canonical text、memory claim snapshot或验证报告。边有来源和创建方法，LLM声称的supports不等于已验证支持。材料来源变更时，旧版本引用仍可查；失效/删除则输出明确撤回状态，而不是偷偷改引用文本。

报告中的每个重要外部事实绑定一个或多个Citation，核实source hash/offset与claim。LLM评审仅检查语义相关性，独立于最终发布判定。无法证实的结论写“不确定”，不要引用不相关来源凑数量。

## 7. 长短期记忆策略

工作记忆：当前目标、已完成节点、重要失败、工具结果索引；大内容存artifact，不把整个历史拼回prompt。项目记忆：稳定决策/术语/约束，需有来源。个人偏好：默认只在项目内生效，owner可显式设为global。

写入流程 `observation -> proposed -> dedupe/conflict check -> policy -> source_claim / inference / observed_test / user_confirmed`（根据真实来源分类，只有明确用户确认才是user_confirmed）。对于高影响偏好、事实冲突和跨项目共享请求需要确认；网页和仓库不能把“用户允许发送密钥”写入记忆。读取先scope过滤，再检索；高重要度/新鲜度帮助排序，不提升未经验证的可信等级。

删除必须涵盖chunk/vector/BM25快照、推荐特征、派生摘要缓存和可选trace数据。Temporal history尽量只存不敏感ID；已写入历史的敏感payload必须按加密/保留策略处理。删除状态与备份到期时间告知用户，不能声称已从不可改写备份即时物理清除。

## 8. 推荐闭环（完整V1，但不冒充协同过滤）

候选：项目知识库内容相似top100、已批准来源的新资料top50、当前goal相关top50。排除hidden/已删除/跨项目内容；document级去重。

初始score各特征归一到[0,1]：`0.35长期兴趣+0.15短期兴趣+0.20当前目标+0.10新鲜度+0.10来源可信等级+0.10未读新颖性`。缺失特征对剩余权重重新归一。公式和版本写入每次推荐事件，不称最优算法。用MMR λ=0.8选10项，单来源最多2项，所有非随机推荐可解释为实际特征贡献。

反馈：bookmark+3、helpful+2、click+0.2、有效停留+0.3、hide-3，仅作初始规则。停留只接受窗口在前台且有效曝光的范围；click不直接等于学习收益。事件带event_id去重，记录impression_id、候选集合hash、rank、policy_version、exposure_time。

探索默认关闭。开启后仅在最后一个slot执行ε=0.05的均匀随机探索；记录候选N和实际选择概率，不能把ε直接当propensity。最优item被选择的概率为(1-ε)+ε/N，其余为ε/N；候选改变需新hash。安全/隐私过滤发生在探索前。用户可关闭画像与探索，或清空兴趣。

主动跟踪使用Temporal schedules；只跟踪预批准来源和明确目标，默认生成站内通知/研究草稿，不自动向他人发消息。每次扫描有独立预算和增量水位，无变化则不调用总结模型。

---
上游依据：S20、S21、S23、S24、S25、S26、S27、S29、S30、S31，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。

## 9. 代码图谱与 Knowledge Fabric 的区分

通用网页/文档/RSS 仍采用本章 BM25S + pgvector + BGE；CodeGraph 仅处理代码仓库的 symbols/imports/calls/impact，不替代个人项目记忆、事实证据图或验收。代码图谱索引是版本化的派生缓存，受 project ACL/仓库快照限制。详见 `docs/13_codegraph.md`。


---

<!-- canonical source: docs/06_security.md -->

# 06 · 权限、隔离与提示词注入防线

## 1. 威胁模型

把网页、RSS、PDF、代码仓库、MCP响应、第三方skill和LLM输出全部视为不可信。攻击可能诱导泄露API key、读取其他项目、修改验收/日志、扩大权限、反复花钱、运行恶意依赖或伪造完成报告。提示词过滤只能辅助，不是边界；隔离容器也不是无条件安全承诺。

可信域：owner身份系统、policy/tool registry、gateway、runner-manager、verifier控制进程、release evaluator。应用开发者能修改这些代码，因此自我进化只允许改skill/受限workflow DSL，不允许Agent自动替换可信控制代码。

## 2. 网络和凭证分区

control网络：API/DB/Temporal/worker/gateway的受认证通信。runner-admin接口只允许trusted worker调用。每个编码job使用单独sandbox网络，默认无互联网，只能访问其job-scoped model gateway端点。沙箱不能访问control网段、其他job、云metadata、宿主机管理端口、Docker socket或DNS外传通道。HTTP工具由网关代表调用。

runner-manager是高权限基础设施。Docker socket仅它可持有，而且使用专用rootless daemon/专用runner VM；不能挂给API或Agent容器。不得声称只加`read_only`就防止越权。对恶意不受信任仓库的公开多租户部署，容器边界不够，V1明确不支持；应在后续使用更强隔离并重新威胁评审。

数据库key、provider key、GitHub token、审批签名key和verifier身份分别分发；任何一个actor不能获得全局credential。job-scoped token限制模型、project、task、预算、期限、调用次数，只能访问特定endpoint。不要把provider原始key透传给OpenHands。

## 3. 工具分类与能力授权

工具的分类、参数schema与影响由本地管理员维护的registry决定，**不信任MCP annotations**。类别：

- R0：授权项目内读取、搜索、无需外部变更的分析。仍要检查数据出口。
- R1：隔离工作空间文件改写/代码执行；无宿主机和外部写权限。
- R2：外部可撤销写操作，例如新建草稿PR；逐次绑定审批或明确限域预授权。
- R3：付款、正式发送、删除外部资源、部署、权限变更。V1默认disabled；只有管理员显式启用已实现且有对账策略的connector后逐次审批。没有实现的工具不能变成一个万能HTTP接口。

`CapabilityGrant`包含owner/project/task、tool、allowed_resources、args hash或限域规则、max_uses、expiry、data_class、egress destinations。Actor只能提出request，不能签发grant。流程为normalize -> resolve target -> check policy -> approval -> reserve -> commit intent -> dispatch。

## 4. 审批绑定与TOCTOU

Approval显示真实收件人/仓库/分支/域名、规范化参数、payload/patch hash、资源版本、费用上限、有效期和可逆性。批准后的参数、文件内容、base_commit、目标变化必须重新审批。不要使用“允许Agent干任何事”复选框。

审批token服务端签名、单用途、短TTL；数据库CAS消耗；重复点击不能重复动作。签名比较恒时；签名key不在sandbox。服务端确认owner身份，不接受请求体里自报的approver_id。审核事件单独记录。过期与撤回都阻止新的dispatch，但不假装撤销已经发生的外部操作。

## 5. SSRF与网页安全

下载只接受http/https、默认80/443，无URL userinfo、无file/gopher/unix等scheme。解析并规范化IDN/IPv4/IPv6；禁止loopback、private/link-local/metadata、reserved等非公开目标（本地fixture通过单独测试配置定点允许）。每次redirect重新检查，限制跳数、请求时长、解压后body大小和content type。

DNS检查必须与实际连接目标绑定并配合网络出口规则；“先查一次IP，再让库任意重解析”不能过安全验收。防DNS rebinding、IPv4-mapped IPv6、重定向到metadata、代理环境变量绕过、服务名称解析逃逸。HTTPX本身不提供这些授权语义；网络策略在真实容器内做探针验证。实现不了就禁用对应live网页功能，不降低测试。

JS浏览器与parser都不能在control网络。浏览器下载/弹窗/第三方请求受限，禁用复用用户cookie、自动扩展和未批准写请求。网页HTML在UI中作为清洗后的内容展示，禁止原样innerHTML；Markdown renderer禁止任意script/危险URL。提示词注入样本展示为引用数据而非执行指令。

## 6. 文件、代码和依赖

只挂载显式工作卷，non-root、drop capabilities、no-new-privileges、资源限额、默认只读rootfs、限制pids、独立tmp。真实可用字段以runner镜像smoke验证。tar/patch/file操作拒绝绝对路径、`..`、symlink/hardlink逃逸、设备文件和过大产物。

代码提交使用base snapshot与patch，不直接挂主机源码根、home或`.ssh`。安装依赖属于代码执行风险：默认镜像预装工具；临时新增包需批准的registry出口/锁定hash，不能让网页给出任意curl|bash后直接跑。Git hooks和仓库自带启动脚本不视为可信。

trusted test suite只读且独立；actor无法写测试定义、评测标签或verifier结果表。只读测试文件也不能解决被测代码运行时攻击，所以测试sandbox仍无密钥与网络。

## 7. MCP接入

只有管理员添加transport和server executable/URL，禁止模型动态安装MCP server。首次拉取schema保存hash并审核；server升级或工具schema变更进入quarantine，暂停旧授权。stdio使用固定argv而非shell拼接；远程服务固定TLS和允许域名。读超时、body限制、cancel和重连必须测试。

每个MCP tool映射到AETHER tool ID、风险/幂等分类与JSONschema。任何未分类工具默认deny。远程返回的instructions或“这是只读操作”不能修改分类。OAuth token仅gateway存储，按最小scope申请；未实现OAuth的provider只提供管理员配置token方式，UI如实标明。

## 8. 身份、审计与删除

V1单owner启动：仅loopback绑定，通过本机一次性enrollment建立登录；无默认公开密码。使用HttpOnly+SameSite cookie，state-changing请求检查CSRF/Origin；不在URL/localStorage存长期admin token。非loopback发布需要TLS和正式密钥配置，缺失则拒绝启动。

服务身份与用户会话分离。所有project请求服务端查访问权限，不能信header里的project_id。对所有list/detail/SSE/artifact/search/feedback/skill入口做越权测试。

审计默认存摘要、hash、工具参数的脱敏版本；避免原始秘密。hash chain可发现部分修改，但不对有DB管理员权限的人提供不可篡改保证。真正防篡改需外部只追加存储，V1不虚假宣传。审计保留期限可配置，敏感payload独立加密并支持删除。

## 9. 强制安全回归

至少包含prompt注入、跨项目检索、审批重放/参数漂移/过期、SSRF与DNSrebinding、路径逃逸、伪造工具分类、unknown effect、预算竞态、secret输出脱敏、恶意测试修改、公共skill自动加载、MCP schema漂移和sandbox网络连通探针。安全失败阻止发布和技能promotion；不能通过给提示词加一句“请安全”来代替修复。

---
上游依据：S33、S40、S41，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。

## 增补：CodeGraph MCP/CLI 不能获得主机级权限

CodeGraph 有机会读取整个仓库源码并把源码返回给模型，因此它是有真实数据泄露风险的**只读工具**。工作进程必须仅挂载获准 snapshot，不挂宿主 home、其他项目仓库、credentials 或 Docker socket；关闭遥测/默认网络；LLM 不能传递任意 projectPath。源码注释/README/工具响应全部视作不可信。图谱影响分析和相关测试列表不构成可信安全验收。完整规则见 `docs/13_codegraph.md`。


---

<!-- canonical source: docs/07_learning_evaluation.md -->

# 07 · Skill Evolution Lab 与可信评测

## 1. 学什么，不学什么

V1不更新基础模型权重，不自修改control plane。学习对象是有适用范围的操作技能、检索策略配置和可解释的工具workflow；不接受任意代码自动进入高权限路径。用户反馈帮助发现候选，但最终是否更好由独立任务结果决定。

可学习的例子：某类依赖升级先检查lockfile；针对某类检索任务保留原query再改写；某类失败需要运行一个已批准的诊断工具。不可学习的例子：绕过审批、放宽验收、删除失败日志、把测试答案抄进skill。

## 2. Skill bundle

```text
skill-name/
  SKILL.md              # standard YAML frontmatter + human-readable procedure
  aether.skill.json     # scope, version, required capabilities, hashes, eval metadata
  references/           # reviewed supporting material
  scripts/              # optional; disabled until explicitly reviewed and hash-approved
```

按标准name/description规范校验。manifest记录parent version、training trace IDs、compatibility、tool schema hashes、test family、allowed scopes、max_step/tool budget、risk class和bundle hash。manifest里的权限是**请求**，不是自动授权。外部skill导入一律quarantine。

## 3. 候选生成和去污

只读取已授权、已脱敏、验收有结论的trace。成功例和失败例均保留原因；agent自述成功不算成功轨迹。训练数据和测试数据按任务来源/模板family/时间切分，避免同一仓库补丁变体同时在训练和验证里。

学习器输出CandidateSkill+具体假设+预计适用域+反例。进行secret检查、许可证来源检查、重复/冲突检查、过宽权限检查、拒绝包含答案/用户私人原文片段的skill。每批最多3个候选、学习预算独立受限；没有足够证据则什么都不更新。

## 4. Promotion 状态机

`DRAFT -> QUARANTINED -> STATIC_PASSED -> EVALUATING -> ELIGIBLE -> CANARY -> ACTIVE`

失败状态 `REJECTED`；已部署可 `ROLLED_BACK`。STATIC_PASSED不意味着效果更好。ELIGIBLE需要独立evaluator产物；CANARY默认需要owner确认。在线任务运行固定skill版本，部署切换只影响新run；旧版始终可回滚。

## 5. 评测门槛（初始研发策略，不是已取得结果）

候选必须先过全部安全/契约回归，然后在至少30个独立task family代表任务上与父版本配对比较。每个任务同model/config/toolset、重置环境、相同预算。对family做配对bootstrap置信区间；多个seed是同一任务的重复测量，不能冒充更多独立样本。

初始自动eligibility：成功率提升>=5个百分点、paired95%CI下界>0、成本比<=1.10、无新的安全失败、mandatory任务无回归。样本不足/CI跨0则INSUFFICIENT_EVIDENCE，不用“多数票”硬升。阈值版本化，改阈值不得重用同一holdout挑结果。人可选择试验性canary，但UI显示未证实提升，不能标“已学会”。

对于零成本scripted测试，成本比没有商业意义，只验证管线。离线重放是测试策略或解析的一种方法，不能替代真实执行的skill有效性比较。

## 6. Canary 与回滚

只在预批准的低风险新任务上启用5%（可设0）的canary。风险类不匹配不分流。保存task到version的分配、时间、selector policy和结果。发现任一安全失败立即停用；连续功能退化或成本越界按预先写入的窗口规则暂停并回滚。历史ACTIVE指针与bundle hash可原子切回，已运行任务保持原版本或显式取消。

不要把不断窥视线上小样本当严格统计显著。门槛用于工程保护，发布优越性需要另行冻结实验。

## 7. Hermes 对照实验设计

四组：Hermes cold、Hermes learned/frozen、AETHER cold、AETHER learned/frozen。每组使用独立home/workspace、同一基础模型及provider revision、相同数据/工具能力和输出token/成本限制；记录任何无法匹配的差异。基线也有机会使用自身学习功能，不能只让AETHER见训练样本。

模型路由先关闭，防止用更贵更强模型冒充架构优势。然后可以另做cost-aware router实验，明确是另一个比较。训练阶段预算同时报告；技能推理token也算成本。衡量：objective task success、false completion、恢复正确性、unsafe attempts blocked、实际unsafe effects、p50/p95时延、总token/费用、每成功任务成本。

学习消融：关memory、关skills、关verification辅助、无rerank、无经验选择器。消融不能关闭基础安全权限；安全不是可牺牲的实验变量。

## 8. 数据集隔离

本包 `evals/dev_cases.jsonl` 是**公开开发验收场景**，Codex可以看，不能叫heldout。产品提供独立evaluator加载release dataset的接口，但真实最终集应由owner或独立流程在冻结release后提供/封存，存在代码/actor容器之外。训练/学习器不给它文件系统访问权。

合成隐藏标签若生成器/seed/答案已让开发Agent看到，不等于真正未知任务。发布报告记录dataset hash、family split、版本、评测次数、是否窥视；同一holdout用作选型后就不再是最终holdout。

没有最终集时只生成实验工具和开发验收报告，不捏造“提升20%”。上一轮提到的成功率/成本目标是愿望，不是对本项目的先验事实。

## 9. 统计与结果格式

报告包含每任务结果、实际验证证据、失败类型、费用known/unknown、模型请求数、wall time、approval wait time、timeout和abstention。abstention不算成功但不等于false completion。false completion分母写清：所有声称完成的任务或全部任务，两个口径都可给但不能混用。

至少同时给raw counts与CI。0次失败不证明失败率为0；小样本不能保证1%以下。比较优越性只对测试分布成立。失败任务和unknown账单不可以从均值中偷偷删掉。

---
上游依据：S01、S02、S34，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。

## 10. CodeGraph 消融实验（新增）

在同模型、同代码快照、同预算与验收集下做 CodeGraph On/Off 消融，比较客观任务完成率、token、成本、时延、文件读取数量与遗漏关键调用路径。冷启动索引工作单独计入成本，warm 查询重复测；失败/timeout照计。项目官网的节省比例仅作为假设，不能直接复制进 AETHER 的结果。额外记录 residual context tokens：CodeGraph 官方自测提醒长会话残留上下文可能更多。见 `M10-06`。


---

<!-- canonical source: docs/08_api_ui.md -->

# 08 · API、控制台与用户交互

## 1. 通用协议

API前缀`/v1`，JSON字段snake_case，时间UTC RFC3339；UI按Australia/Melbourne展示并标注时区。ID使用UUID，示例/reference中允许可读测试ID，生产层统一转换。分页使用opaque cursor和limit<=100，不用无界列表。

对创建task、发布skill和外部操作请求使用`Idempotency-Key`，作用域是owner+project+route+key，保存规范化payload hash；同key不同body返回409。更新资源使用If-Match版本控制；审批重新绑定具体artifact/intent，不依赖UI缓存。

错误统一`{code,message,request_id,retryable,details}`。401未登录、403越权、404不可见或不存在、409版本/幂等冲突、422不合法合同、429限流/预算、503依赖不可用。不把异常包装成200+success:false。健康检查`/health/live`与`/health/ready`分开。

## 2. 资源与路由

| 路由 | 方法 | 契约/行为 |
|---|---|---|
| /v1/projects | GET/POST | owner项目列表/创建；不暴露其他项目 |
| /v1/projects/{project_id}/tasks | GET/POST | 分页任务；POST输入原始目标+预算/资料范围，202返回task_id |
| /v1/projects/{project_id}/tasks/{task_id} | GET | 状态投影、合同版本、budget known/held/unknown、产物 |
| /v1/projects/{project_id}/tasks/{task_id}/contract | GET/PUT | 草案合同；已批准合同变更新建version，旧版只读 |
| /v1/projects/{project_id}/tasks/{task_id}/commands | POST | approve_goal/pause/resume/cancel；command_id去重，202异步接收 |
| /v1/projects/{project_id}/tasks/{task_id}/events | GET SSE | event_id游标重放，不丢断线期间事件 |
| /v1/projects/{project_id}/approvals | GET | 待处理审批列表 |
| /v1/projects/{project_id}/approvals/{approval_id}/decision | POST | approve/reject；body含expected_intent_hash，server查owner |
| /v1/projects/{project_id}/artifacts | POST multipart | owner上传受限文件，返回ArtifactRef，默认25MiB |
| /v1/projects/{project_id}/artifacts/{artifact_id} | GET/DELETE | 鉴权后读取/删除；download不接受任意path |
| /v1/projects/{project_id}/sources | GET/POST | source config，域名/权限/抓取间隔明确 |
| /v1/projects/{project_id}/sources/{source_id} | GET/PATCH/DELETE | 版本控制；删除立即tombstone |
| /v1/projects/{project_id}/ingestions | POST/GET | ingest command与状态，内容未索引完明确显示 |
| /v1/projects/{project_id}/search | POST | query、filters、mode；返回hits/来源/索引版本/degraded |
| /v1/projects/{project_id}/memories | GET/POST | 搜索或用户明确添加记忆；proposed不能自动confirmed |
| /v1/projects/{project_id}/memories/{memory_id} | PATCH/DELETE | 用户纠正/删除；生成新revision或tombstone |
| /v1/projects/{project_id}/recommendations | GET | 推荐列表、impression_id、真实特征解释 |
| /v1/projects/{project_id}/feedback | POST | idempotent event；user不在body中自报 |
| /v1/projects/{project_id}/skills | GET/POST | 列表/导入quarantine；脚本不自动运行 |
| /v1/projects/{project_id}/skills/{skill_id}/evaluate | POST | 独立evaluator job；actor不能指定最终分数 |
| /v1/projects/{project_id}/skills/{skill_id}/deployments | POST | promote/rollback，要求eligible eval hash+审批 |
| /v1/projects/{project_id}/watches | GET/POST | 授权来源跟踪、schedule、预算 |
| /v1/projects/{project_id}/watches/{watch_id} | PATCH/DELETE | 暂停/更新/删除schedule |
| /v1/projects/{project_id}/evaluations | GET/POST | 明确dev/validation/release类别与dataset hash |
| /v1/projects/{project_id}/costs | GET | 时间范围与任务账本；未知成本单独字段 |
| /v1/admin/connectors | GET/POST | owner-only registry和连接器配置；密钥仅写不可回显 |
| /v1/admin/connectors/{connector_id}/probe | POST | 非副作用能力测试，不能自动扩大scope |
| /v1/admin/models/probe | POST | model/tool/structured output能力与价格配置检查 |

`contracts/openapi.yaml`提供上述资源与认证路由的设计合同；实现时由真实FastAPI生成OpenAPI并做契约差异测试。不得只实现少数示例就宣布API完成。`apps/web`通过生成的typed client调用真实API。

## 3. SSE

EventEnvelope包含event_id、task_id、project_id、sequence、type、time、payload、schema_version。持久event序号在每task单调增加，不用时间戳替代唯一ID。客户端`Last-Event-ID`重连，从数据库读遗漏事件后再进入live tail；心跳与数据事件区分。

events必须脱敏。不同task的event ID不能拿来绕过项目权限。历史已清理时返回明确cursor_expired和重新拉取snapshot方法，不静默从现在开始。UI不能因最后一个LLM token写“完成”就把task标成success。

## 4. 控制台页面

**Overview**：项目切换、活跃任务、待审批、最近失败、今日成本（unknown单列）。没有数据时显示空态与新建任务，不用假曲线填满页面。

**Task workspace**：左栏DAG/步骤列表，中间目标合同与运行事件，右栏预算/权限/技能版本；底部Artifacts与Verification。暂停/取消有请求中状态；显示恢复次数和为什么blocked。有限长度执行理由即可，不要求记录模型隐藏chain of thought。

**Approval inbox**：目标、规范化参数/patch、影响、费用、expiry、资源版本、来源与变更diff。高影响动作不能默认checked；不提供误导性的“永久允许所有”。

**Knowledge**：来源状态、索引延迟、版本、删除；Search结果可展开命中段落与source。Memory页面显示谁说的/何时/冲突/有效范围，支持纠正与forget。

**Discover**：推荐卡片、真实推荐理由、bookmark/helpful/hide；探索状态可见、可关闭，禁止用伪随机结果冒充学习模型。

**Skills lab**：候选和parent diff、训练来源数量、验证集类别、raw结果/CI/费用、部署与回滚。没有足够样本明确“证据不足”，不显示虚假的能力增长百分比。

**Evaluations & settings**：四组baseline实验配置与报告；模型alias、key状态、预算、connector权限、隐私/保留设置。

## 5. UI验收

支持中文长文本、键盘操作、明确label、焦点管理、可读对比度。至少测试窄屏和桌面；错误、loading、offline、empty、stale projection、approval expired都要可视化。禁止暴露原始HTML/密钥。Playwright测试使用真实API与fixture provider；mock-only组件测试不能代替端到端。

---
上游依据：S36、S37、S38，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。


---

<!-- canonical source: docs/09_data.md -->

# 09 · 数据模型、事务与保留

`contracts/schema.sql`是数据库初始结构合同，不是声称已经在PostgreSQL运行过的迁移。Codex将它转为Alembic并执行clean upgrade / rollback / upgrade / data-preserving upgrade测试。

另有auth_sessions、node_dependencies、ingestion_jobs、coding_jobs和connector_configs辅助表；身份表为全局，业务实体均有project_id。evidence_links以不可变artifact为边的端点，verification结果可附在tested_by边上。

## 实体组

| 组 | 表 | 关键约束 |
|---|---|---|
| 身份/项目 | owners, projects | V1单owner；project域是所有业务的隔离边界 |
| 目标与运行 | tasks, goal_contracts, task_nodes, command_outbox, task_events | contract版本不可覆盖；event/command去重；status为投影 |
| 权限与操作 | capability_grants, approvals, operations | 同intent唯一；approval绑定hash；未知结果保留 |
| 证据 | artifacts, verification_results, evidence_links | immutable hash；验证关联contract/产物/验证器 |
| 成本 | budget_accounts, model_requests | 整数microUSD；reservation与actual分开；unknown不是0 |
| 知识 | sources, source_versions, chunks, index_generations, memories | 来源版本、offset、scope、向量revision一致 |
| 学习 | skills, skill_versions, skill_deployments, evaluation_runs | 同scope活动版本原子切换；候选无自升权限 |
| 个性化 | feedback_events, profile_snapshots, recommendation_impressions | 幂等反馈；policy/propensity版本；能删除与重算 |
| 自动化 | watches, notifications | schedule ID稳定、站内通知默认无外部副作用 |
| 审计 | audit_events | 只追加应用权限；不声称可抵抗数据库管理员 |

## Scope与数据库权限

所有业务表含project_id，引用采用(project_id,id)复合FK，避免把其他项目的对象挂进来。应用层鉴权+数据库RLS双层；DB会话每transaction设置授权后的project上下文，连接池复用不得遗留scope。只给服务所需权限；API账号不能写verification结果、skill评测成绩和最终task成功状态；actor无数据库账号。

`schema.sql`中的RLS是project predicate基准，实际迁移必须加入角色权限与项目列表访问策略。不能因为表owner通常绕过RLS而在集成测试中只用superuser；必须用真实runtime角色验证。项目创建等全局操作走专用已认证路径。

## 四个关键事务

1. **提交**：task+contract draft+command_outbox原子提交；Temporal dispatcher用固定workflow ID，失败可重投。
2. **审批与动作**：锁定approval和operation，核对intent hash/version/expiry，消耗一次性授权、写PREPARED/DISPATCHED；远程网络调用不在长数据库transaction内。
3. **预算**：锁budget account，验证spent+held+new<=limit与verification headroom，插入唯一request reservation；结算actual时保留超支事实，不能拒绝记账以伪装没超额。
4. **技能切换**：校验独立eval evidence与expected previous version，更新active deployment，append audit；写入版本不修改已运行任务。

## 大对象

数据库保存metadata/ref，内容在ArtifactStore。路径只能服务端生成`project_id/sha256-prefix/sha256`，不得接受用户相对路径作为最终存储路径。先临时写入+fsync+hash验证，再rename；DB记录引用，后台GC回收无引用对象。下载必须经过鉴权，public URL不默认开放。支持将来S3兼容adapter，但V1默认本地volume不依赖第三方对象存储。

## 数据一致性

index、profile、UI projection都是可重建派生数据；每次查询记录水位/版本。缓存key至少含project_id+权限版本+source/embedding/tokenizer版本+query。删除和撤权增加visibility epoch，旧缓存立即失效。RRF与reranker不能绕过tombstone检查。

## 保留与备份

默认原始模型prompt不落日志；可配置脱敏trace保留30天、task metadata90天、artifact30天、知识资料直到owner删除。所有默认值在配置可见，不是法律要求。backup单独加密，记录保留与删除到期；测试pg dump/restore及artifact hash核对。恢复后先停外部dispatch，对UNKNOWN和未完成操作对账，不能一恢复就重放全部写操作。

---
上游依据：S20、S40，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。


---

<!-- canonical source: docs/10_operations.md -->

# 10 · 运行栈、模型、成本与发布

## 1. 运行模式

**reference-only**：本包的schema/纯函数自检，不能证明产品能运行。

**offline demo**：完整API、PostgreSQL、Temporal、真实本地文件/HTML工具、独立verifier、真实UI；只有模型换成显式ScriptedProvider。本地fixture站点在专用测试网络定点允许。ML权重不存在时可以测试lexical-only，完整hybrid gate仍标blocked，不能用随机向量冒充真实embedding。

**live local**：owner配置模型key和price table后启用真实推理；编码使用隔离runner，研究来源通过白名单。默认不开公网、不自动收费、不发送真实外部消息。

**release**：镜像与依赖均固定、启用认证/TLS、runtime用户非superuser、完成备份恢复/网络隔离/真实模型测试。个人部署，不声明公开多租户安全。

## 2. 基础技术版本策略

control plane Python3.13；Node24用于前端；PostgreSQL17 major+pgvector；Temporal选择与Python SDK兼容的稳定release。OpenHands四个包保持一个已验证release/revision集合。ML可独立Python环境，如3.13无所需wheel则固定3.12并记录，而不是降全项目或随意升级所有包。

M00输出`uv.lock`（各独立workspace如有）、`pnpm-lock.yaml`、`infra/images.lock.json`、`config/upstream.lock.json`、`config/models.lock.json`。此处没有猜测具体未验证的package patch版本或image digest。确认license/security后才拉取/构建镜像；仓库main/head只用作来源观察，不当生产浮动依赖。

## 3. Compose目标

必要服务：postgres、temporal-server、api、worker、gateway、web；编码功能再启动runner-manager与按job创建的沙箱；ML worker通过profile启用真实检索。Temporal UI为开发工具，可选且不对公网开放。基本event/cost可视化直接来自AETHER API，不依赖Langfuse。

PostgreSQL为AETHER与Temporal使用独立数据库/用户，持久volume。Temporal开发模式可以使用独立测试服务，但release必须使用持久服务配置，不能把start-dev的临时状态冒充生产恢复能力。Compose健康检查等待真实ready；迁移作为显式job；命令不能默认删除volume。

全栈镜像digest/arm64支持由实际拉取验证。macOS arm64可以跑控制/研究链路；完整Linux sandbox安全与故障验收在Linux amd64环境执行。Windows通过WSL2/远端Linux控制，不假设原生Docker安全行为完全相同。

## 4. 模型路由

逻辑alias固定：`planner`、`actor`、`coder`、`judge`、`extractor`。初期planner/actor/coder可共享同一个用户提供的强工具调用模型；judge尽量不看actor总结，评审以确定性测试优先。更换模型厂商不是架构创新。

生成模型不写死商业型号或假设免费额度；`config/models.example.yaml`要求管理员提供真实provider/model_id/api_key_env/base_url（如需）和价格。缺值时live启动失败，offline仍可用。不得提取Codex/Cursor登录凭据给产品当API key。

每个alias能力探针：基本生成、JSON schema校验、tool call、usage字段、超时/取消、并发上限、长上下文边界、错误归一。用户配置模型不能自动获得更高权限。未知模型价格和usage标unknown并停止进一步自动花费，不能按0计。

M00不需要购买任何新模型。优化router在完成同模型baseline后启用：先rule-based按任务复杂度路由，记录route reason；能耗/延迟/费用以实测选型，不因为“小模型”就假定更省。

## 5. 预算账本

货币单位整数microUSD，1美元=1,000,000microUSD；若展示AUD需要显式配置汇率时间和来源，不随意用固定汇率。本包不提供实时价格。

默认单task上限2,000,000microUSD、100,000tokens、48model requests、active执行1800秒；20%费用和token预算保留给verification/收尾。用户批准合同后才可提高。学习批次单独budget，不偷偷从任务剩余额度无限学习。

每请求先按输入token上界+max_output与已批准价格版本reserve；结果按actual usage结算，cache tokens/reasoning tokens按该provider计费规则记录。estimate与actual分列。超时且可能已计费时保留reservation为unknown，人工/provider对账后结算；强行释放会导致重复花费。

预算是尽力约束，若provider返回超过估算的实际费用必须真实记账、阻断后续请求、告警。不能承诺分布式外部账单永远绝对不超出估计，但本地并发reservation决策必须原子且无竞争漏洞。

## 6. 观察与日志

每任务trace_id；每模型请求、工具operation、runner job、verification都有关联ID。基本日志JSON格式、默认脱敏；记录错误类别、耗时、token、成本known/unknown。不要存隐藏chain-of-thought；保存简明决策理由、输入/输出hash与工具证据即可。

指标：queue depth、active jobs、workflow retry、unknown operations、approval age、budget held/actual、parser errors、index lag、retrieval latency、verification failure、skill rollback。为每个故障提供UI和诊断命令，不能只有日志里一个traceback。

## 7. 禁止默认危险的运维行为

不使用`docker compose down -v`作为普通重启/升级；不自动清空DB；不把任何admin端口映射0.0.0.0；不在前端bundle注入provider key。备份恢复、数据导出、真实PR发布需要显式命令和授权。安装脚本不改机器范围防火墙/安全设置；需要这些权限的部署步骤先生成配置供owner执行/批准，并把相关验收标清。

---
上游依据：S05、S06、S17、S26、S27、S41，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。


---

<!-- canonical source: docs/11_delivery.md -->

# 11 · Codex 实施、验收与交付定义

## 开发方式

先测试包合同，再锁定真实依赖，然后先做薄的完整链路，不先堆所有表单。每milestone产出一个可执行增量；普通任务连续推进。上下文不够时写HANDOFF再继续，而不是重新解释架构。不得把缺密钥作为不做存储/工作流/UI的理由。

## M00—M11阶段门

| 阶段 | 交付 | 必须看到的证据 |
|---|---|---|
| M00 | 依赖/API/平台/licensing spike、lock与doctor | 原始安装/import/最小sandbox命令；失败明确列出 |
| M01 | 数据库、身份、project隔离、契约 | 真Postgres迁移与runtime角色RLS测试 |
| M02 | Temporal task纵向链路 | 提交→工具→验证→事件；重启worker能继续 |
| M03 | gateway预算/权限/operation ledger | 并发reservation、审批重放、unknown对账测试 |
| M04 | 采集、BM25、向量、重排、证据 | 真模型向量+中英夹具排序；删除立即不再返回 |
| M05 | OpenHands编码执行与独立测试 | 真实隔离job、patch、trusted tests、相同digest证据 |
| M06 | 记忆、MCP、审批全闭环 | 冲突/更正、schema漂移与scope回归 |
| M07 | 推荐、反馈、定时跟踪 | 幂等profile、可关闭探索、无变化不总结 |
| M08 | 技能候选、独立评测、deploy/rollback | 失败候选不晋级，样本不足不宣传有效 |
| M09 | 完整UI和端到端场景 | Playwright连接真实API，不仅组件mock |
| M10 | Hermes基线与学习比较工具 | 实际runner smoke；四组实验manifest、费用与split审计 |
| M11 | 系统故障、安全、live演示与发布包 | 重启/断网/重复命令/恢复；生成完整验收报告 |

详细tickets在`tasks/backlog.yaml`。所有mandatory gate必须运行；不能只满足happy path。真实模型与最终独立数据集缺失时，分开标blocked和not_evaluated。

## 必须做出的三段演示

**研究**：导入一组中英本地/授权网页资料，提出比较目标；真实搜索与引用，显示没有证据的项，不用LLM编造来源。

**编码**：把一个有故障的小仓库快照交给OpenHands；输出patch，在独立trusted tests中验证；worker中途中断后任务恢复，不能生成重复job。

**学习**：从合格的训练trace生成候选；一个坏skill被拒绝，一个符合门槛的候选以真实evaluator结果进入试运行；回滚恢复旧版。合成reference分数只用于控制逻辑测试，不当真实学习收益展示。

## 测试分层

- Unit：纯函数/合同/排序/预算/状态和错误处理，不需要网络。
- Integration：真实PostgreSQL/Temporal/文件存储/本地HTTP与MCPfixture，依赖被替换的部分明确标记。
- Security：真实进程/容器网络、权限、secret、SSRF、scope与注入场景。
- E2E：UI到真实API和workflow；scripted模型可用于确定性链路，但不能替代live验收。
- Live：用户配置的真实模型，研究与编码各至少一次，记录成本与产物hash。不自动产生真实外部写操作。
- Evaluation：dev/validation/release dataset角色明确；没有独立release dataset，不报告对Hermes优越性。

每个测试log包含命令、cwd、commit、python/node/image refs、开始结束、exit code、summary、artifacts。`make acceptance-report`由实际JUnit/JSON结果生成，不能手填全绿。

## 完成/阻塞规则

状态：not_started/in_progress/blocked/done。done要求相关tests执行且通过；blocked必须有可复现错误和最小外部依赖说明。缺少一个必需环境不能把所有独立ticket都标blocked。

产品“V1完成”需要M00-M11工程mandatory与live gate通过；“优于Hermes”是独立结论。没有live配置时可以交付可运行工程版，但最终summary必须说live gate未运行。

## 最终交付清单

可运行前后端、数据库迁移、锁定依赖/镜像、.env.example无secret、真实make命令、种子夹具、runtime auth与隔离、独立验证器、技能注册/评测/回滚、baseline runner、测试日志与report、故障恢复说明、备份恢复操作和限制。补`THIRD_PARTY_NOTICES.md`与实际运行的资源/平台矩阵。

必须保留本规格版本。任何架构变更写DECISIONS，说明触发证据、替代方案、迁移影响和新增测试。不因偏好换栈，不把新依赖数量当成果。

---
上游依据：S43、S44，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。

## CodeGraph 附加验收（可选 feature，但评测不得省略）

AETHER without CodeGraph 必须仍能完成编码功能。启用时，单独验收索引/查询权限、版本失效/恢复、candidate hash 变化后的 stale 行为、进程退出/清缓存及无公网遥测；Graph 推荐的测试只能增加而不能替代可信 suite。通过 M00-06/M05-06 的验证后，M10-06 记录有/无图谱成本收益。Codex 不可将外部组件尚未安装当作系统功能已完成。


---

<!-- canonical source: docs/12_integration_details.md -->

# 12 · 集成细节、认证与初始参数

## 服务间协议

所有内部调用仍做服务身份认证，不因为处于Compose网络就信任请求。V1使用安装时随机生成、按服务分开的凭据与明确scope；不写进仓库或传给actor。非本机跨主机连接要求TLS。生产轮换和撤销记录在audit。

**runner → model gateway**：为OpenHands提供经过能力探针确认的OpenAI-compatible chat-completions端点；若所选模型不支持该协议则由LiteLLM适配。job token仅能访问推理端点，服务器从token查project/task/job，不接受body改变scope。请求中model只能是授权alias，max_tokens受服务端限额；每次流式请求同样先reserve，流关闭后处理usage/unknown；不能用流提前终止绕过账单。

**worker → runner**：使用contracts/interfaces.py定义的start/get/cancel。start以(project,task,intent)唯一，返回job_id；get返回真实状态/最后心跳/产物引用；cancel返回accepted而非“外部动作已停止”。API/actor不直接得到容器地址。runner把upstream事件转换为脱敏AETHER event，不接受上游直接修改应用状态。

**worker → verifier**：发送immutable input manifest、contract hash、registry中trusted suite ID/hash，独立worker检查；只允许verifier凭据创建最终evidence，API/runner/actor均不能仿造。验收schema来自本包contracts/acceptance.schema.json，不是自由的shell字符串。

**worker → knowledge/ML**：文本先在受限parser转canonical text再进入embedding/rerank。首版内网HTTP或同进程协议均可，但返回embedding revision、维数、输入hash；一次batch内部不能混模型revision。状态不可用明确degraded/blocked，不能返回随机向量。

## 单owner认证流程

安装命令生成随机一次性bootstrap secret，终端只显示一次，禁止日志。`POST /v1/auth/bootstrap`只允许loopback、无既有owner、有效secret，创建owner并设置持久登录口令（服务端Argon2id哈希）；立刻作废bootstrap secret。公网不能开放bootstrap。

`POST /v1/auth/session`用口令登录，限流，返回HttpOnly/SameSite会话cookie；cookie为随机不透明值，数据库仅保存其哈希。`GET /v1/auth/session`返回身份/CSRF token；`DELETE`注销并撤销服务端session。状态变更要求CSRF token+Origin检查；跨站CORS默认关闭。release cookie Secure，localhost开发例外显式配置。

服务端从session取owner，不相信body中的owner字段。session表有expiry/last_seen/revoked，默认12小时绝对有效期、30分钟idle，可配置。恢复口令只能走本机显式CLI，撤销所有session。此方案不等于企业SSO。

## 具体时间/重试边界（初始值）

| 操作 | 默认值 | 处理原则 |
|---|---|---|
| HTTP静态抓取 | connect5s、read20s、total30s，最多3次重定向、HTTP硬上限20MiB（HTML/RSS默认10MiB） | redirect/每次真实连接重做目标策略；非幂等写不套此重试 |
| 读Activity | 单次30s、总90s、最多3次、backoff1/2/4s | 只有允许幂等重试的读操作 |
| LLM请求 | total120s，stream idle30s | 超时可能计费；unknown保留reservation，不能无条件重发 |
| 模型结构修复 | 最多2次 | 占同一task预算和总请求上限 |
| 代码job | 默认15分钟且不超过task剩余active budget | 以job状态/实际开始时间计，poll5s；取消grace10s后隔离进程树终止 |
| 文档parser | 每文件120s、默认内存1GiB | kill并报告parser_timeout；大文档可显式扩额，不默默跳页 |
| 审批 | 72小时 | expired后PAUSED，不继续执行旧授权；新的审批需新grant |
| SSE | 15秒heartbeat | DB为游标恢复来源，不能只依赖内存广播 |
| BM25 generation | 30秒debounce，单builder租约 | 查询可使用明确标记的旧generation；删除立即过滤 |

资源值是设计起点，M00在目标机器测量后写platform report，可按证据调整；不是性能承诺。OpenHands官方SDK是否有同名参数须实测，本表由外围服务执行，不据此虚构上游参数。

## 工作流拓扑细化

`TaskWorkflow`为用户task的唯一parent，保存contract版本、node cursor、pending command ID和剩余预算摘要。Research/Code/Extraction节点可用受限child workflow；Verification用独立task queue。`WatchWorkflow`只比较源变化并在预算内提交普通research task；`SkillEvaluationWorkflow`只运行受控评测，不是递归创建无界agent。

workflow history软上限5000 events时在安全边界continue-as-new；有未决update handler/child结果时先完成或明确转交，保持task的logical ID。外部UI event序列不随run ID重置。Activity读取DB合同后返回版本和hash，workflow固定使用该版本，不能每次重放重新读“最新”。

暂停/取消命令可随时接收，但应用在安全边界，预算不得因重启/continue-as-new重置。active elapsed应持久计算，排队/审批等待不扣active budget，已启动的远程job即使worker离线也继续计时。48次模型请求上限同时覆盖OpenHands内部调用和judge；验证预留按共享账本原子检查。

## 参考代码边界

Pydantic frozen仅阻止字段重新赋值，不深冻结list/dict。真正不可变合同需：规范化序列化、hash、只追加DB版本、写权限和每次使用校验，不能靠frozen=True实现安全边界。reference BudgetLedger是单进程算法参考；生产必须用事务。validate_relative_export_path仅做词法校验，不解决symlink、hardlink、mount或TOCTOU。SHA只能证明字节一致，不能证明来源可信。

参考Identifier允许可读fixture值，生产所有实体ID统一UUID；example中sha256用于合成内容身份，不是声称真实线上来源。schema文档的ID限制不能代替鉴权。

## 本地文件与仓库输入

UI使用`POST /v1/projects/{project_id}/artifacts`上传本地文件，默认25MiB，先写受限临时目录后校验hash和类型；Source.kind=local_document时locator只能是本项目artifact ID，不能是服务器路径。编码仓库由owner显式导出/上传快照或受限Git connector按批准revision取得；压缩包导入必须检查zip-slip/symlink/hardlink/文件数量/解压总大小，且在隔离worker中处理，不通用展开用户任意附件。

技能评测/部署等非聊天控制操作使用有类型的control task关联审批和审计；不能伪造任意既有task作为approval scope。若无需外部动作，control task仅使用其审批能力，不获取执行器权限。

---
上游依据：S07、S18、S19、S42，详见 `docs/SOURCES.md`。本章的AETHER设计决策与默认参数不是上游性能保证。

## CodeGraph 运行时协议（新增）

受信 RepoIntelligence adapter 在 isolated runner 的专用工作进程中执行固定 CLI/MCP；可按 immutable snapshot manifest 缓存 index。只暴露 `repo.code.explore`, `repo.code.impact`, `repo.code.affected_tests` 经受信 gateway 过滤的结果；前后端/actor 不能调用全局 MCP server 或选择路径。版本与 status/freshness 写入 artifact metadata；取消任务时停止 watcher/daemon、关闭本次 graph 句柄。默认禁用，降级需显式记录。详见 `docs/13_codegraph.md`。


---

<!-- canonical source: docs/13_codegraph.md -->

# 13 · CodeGraph 接入规格：代码知识图谱（2026-10-15 增补）

## 0. 确认选择与边界

**选用**：<https://github.com/colbymchenry/codegraph>，MIT license；2026-10-15 查阅官方 README、CLI/MCP、Library API、遥测和供应链描述（来源 S46–S49）。**不**默认安装其他同名 CodeGraph (`codegraph-ai/CodeGraph`, `Lordymine/codegraph`, `GitNexus`)；`CodeGraph` 不是唯一产品名，若用户指另一款必须重新比较。

这是 `Coding Intelligence` / `Repository Intelligence` 层，不是整个 AETHER 的 Knowledge Fabric（普通文章、网页、PDF 等依旧 BM25S + pgvector + BGE），不代替 Temporal、OpenHands、独立 verifier，也不引入 Neo4j。

在产品边界上，CodeGraph 主要提供 `symbol -> file -> caller/callee -> dependency -> possible impact/test hint` 的查询路径。由 AETHER 负责数据授权、不可变版本、工具调用预算、评测和最终报告。

**两个完全独立的使用场景**：

1. **开发 AETHER 的 Codex（宿主工具）**：在开发机上启用 CodeGraph MCP/CLI 以理解 AETHER 源码，可在 M00 的安装/安全审查通过后初始化；并非 AETHER 产品的一项实际已实现能力。
2. **AETHER 内运行的 Agent（产品功能）**：只可经 `RepositoryIntelligence` 内部适配器，在指定项目、指定不可变仓库快照的受限 worker/沙箱内访问 Graph。Agent 不直接运行 host Codex 的 MCP，不共享开发机的全局用户目录或凭证。

## 1. 复用上游哪个模块

优先通过稳定 CLI + MCP 协议接入，隔离于 Python 控制平面：

- CLI：`codegraph init [path]`、`codegraph status [path]`、`codegraph explore <query>`、`codegraph callers/callees/impact <symbol>`、`codegraph affected [files...]`，**具体输出结构需 M00 固定发布后实测**。
- MCP：启动方式 `codegraph serve --mcp`；官方默认只暴露 `codegraph_explore`，而 `node/search/callers/callees/impact/files/status` 需按文档额外启用。不能假定默认就有全部工具。
- 备选 SDK：npm 包 `@colbymchenry/codegraph` 导出 `CodeGraph.init/open/indexAll/searchNodes/getCallers/buildContext/getImpactRadius`。如果 CLI/MCP 无法满足 token budget/JSON 数据需求，单独 Node 子进程可使用 SDK（要求 Node >=22.5 for built-in sqlite），在 M00 验证实际签名与卸载行为后才切换；**不把 Node SDK embed 进 Python 进程**。
- 内部数据：`*.codegraph` graph cache 为派生数据；不复制上游索引引擎/源码。SQLite `.codegraph/` 和 watcher 生命周期必须与某一个单独 snapshot worker 生命周期一致。

默认使用 CLI 的 `--json`（仅在该命令经 `help` 确认支持时）或 MCP 结构化响应；`codegraph_explore` 的自由文本输出若未明确带稳定 field metadata，需用 AETHER 自己的 source snapshot resolver 二次绑定 `file:line` 和 hash，**禁止解析自然语言后虚构精准图谱边**。

## 2. AETHER 内部 API（全部自有，并非上游）

`RepositoryIntelligence`：

```python
index(snapshot: AuthorizedRepositorySnapshot, options: IndexOptions) -> IndexManifest
query(scope: ProjectScope, snapshot_id: UUID, question: str, max_tokens: int) -> CodeContextResult
impact(scope: ProjectScope, snapshot_id: UUID, symbol_ref: str, max_depth: int) -> CodeImpactResult
affected_tests(scope: ProjectScope, snapshot_id: UUID, changed_files: list[str]) -> AffectedTestsResult
invalidate(project_id: UUID, snapshot_id: UUID) -> None
```

`project_id` 与 `snapshot_id` 从 server-authenticated task context / immutable artifact ledger 绑定；LLM **不能**传一个绝对 `projectPath`、仓库 URL、host 路径、worker 环境变量或进程命令来选择查询作用域。`query` 只接受约束长度的自然语言问题；symbol/path/changed_files 做白名单字段验证。用于执行的 SDK/CLI 命令由 adapter 生成固定 argv，无 shell 插值。

MCP 原始工具是外部供应商实现，接入走审阅过的 ToolGateway capability；不要直接把整个 `codegraph_*` 工具集给 actor。工具白名单详见 `config/tools.example.yaml` 的 `repo.code.*`。实际授权由 AETHER 服务端复查，不能信 MCP tools 的描述。

**索引身份**：`(project_id, repository_artifact_id, snapshot_sha256, codegraph_version, extraction_options_hash)`。`IndexManifest` 包含它们及 index ready/stale/failed 状态、建立时间、上游工具版本、已索引文件计数和审计 ref。`run_id` 仅归属操作，不成为新索引身份。每个不可变 repo snapshot 的索引都是派生缓存；修改后产生 candidate snapshot/new index，不把新文件覆盖到先前验收使用的索引。

**响应约束**：`CodeContextResult` 中每个事实性 symbol/location 都有 `relative_path`、行范围、`file_sha256`、`snapshot_sha256`、`graph_version` 以及 freshness；未知边/不支持语言用 `unknown`，不能造边。

## 3. 真实编程任务流程

```text
Coding intent (owner-approved immutable repository snapshot)
   ↓ verify project/capability and snapshot digest
RunnerManager → isolated workspace (NO host git mount, NO global home)
   ↓ optional CodeGraph index (bounded CPU/RAM/timeout)
Repo intelligence → relevant symbols / imports / impact / candidate test hints
   ↓ untrusted-data channel with source paths + digest, token budget
OpenHands Executor → patch → immutable candidate artifact
   ↓ new candidate snapshot + independent graph freshness check
Impacted test suggestions (ADVISORY only)
   ↓ independent Verifier's trusted suite ALWAYS executes
Result: pass/fail + artifact hash + graph version + costs/latency
```

**两个故障场景**：

- Graph 缺少 caller edge（动态调用、Python monkey-patching、反射等）→ 回答降级为 `partial/unknown` 并提供原始 AST/静态结果；Actor 可以再读取已授权真实源码。绝不把“未列出调用者”解释为无调用者。
- Graph 因文件变动/自动 watcher debounce 变旧 → `stale` 标记，指定文件重新读取/重建索引；禁止在最终验收时当作当前 patch 的真实结构图。

`codegraph affected` 可帮助确定**额外**可能需要跑的测试，但不能缩小 AETHER 的强制 trusted test suite，也不能阻止全套安全/回归测试。影响范围只是静态近似，不能是“安全证明”。

## 4. 安全与隐私

- 只有已登记仓库快照：拒绝符号链接逃逸、zip-slip、绝对路径、`..`、hardlink/export 篡改。路径词法验证不够：读取源码还要在受限 worker 内做 realpath/openat 类安全校验。
- 默认 `CODEGRAPH_TELEMETRY=0` 且 worker 默认无公网出站。官方说明本地索引与匿名遥测是两个不同事实，不能混淆“本地解析”和“绝对零外传”。
- `.codegraph/` 放在沙箱/专用索引 volume，严格按 project+snapshot 分区，设置大小、CPU、内存、文件数与运行时限。不得索引 host `~` 或文件系统根；`.gitignore` + 额外 denylist 排除 `.env`、credentials、私钥、tokens、数据库 dumps、其他项目的 workspace。
- 未授权 `projectPath` 必须无法绕过：进程只看见**单个**仓库的只读副本。MCP server 不加载任何用户目录可用的其他项目索引。
- 源码中的注释、README、字符串、自动生成文档和工具返回内容均视为**不可信数据**，不得转化成系统指令/权限/用户要求。上下文裁剪和脱敏后才给模型，跨服务传输避免携带 secrets。
- 禁止 `curl | sh` 自动安装，也不能让 agent 自动运行 `codegraph install` 修改用户的 `~/.codex/config.toml` / root `AGENTS.md`。M00 先审安装包、许可证、镜像/可执行文件哈希与发布证明；仅用户同意后进行开发机全局配置。产品生产运行用**锁定版本**、单独 worker 镜像。
- CLI/MCP 失败应显式降级到授权的 filename search/read/grep；不得把纯 grep 结果冒充图谱结构结论。

## 5. 配置与接入顺序

- `config/codegraph.example.yaml` 是计划配置；`enabled: false` 是默认。管理员安装并通过探针后才打开产品 feature flag。
- **M00-06**：审 repo、锁定发布、CLI/MCP probe、macOS arm64 和 Linux runner 平台矩阵、telemetry-off/权限边界、产生 `reports/codegraph-probe.json`，不自动改 Codex 全局配置。
- **M05-06**：实现 project/snapshot-scoped adapter + cache manifest + read-only tool whitelist + stale/symlink/deleted-project tests。任何不可用情况不得阻塞主 OpenHands 编码任务，可诚实降级。
- **M10-06**：对同一公开任务集运行 `AETHER+CodeGraph` vs `AETHER without CodeGraph`，同时测**正确率、文件打开数、模型 token、耗时、总成本、漏召/错误影响范围**。比较两组使用相同模型、相同 source snapshot、相同预算。Graph 预索引耗时计入总成本且区分 cold/warm。

以上 3 个是额外开发任务，不改动原 60 个主体任务的完成标准；在未完成产品时不宣称 CodeGraph 提升。供应商官方 benchmark 是自报结果，**不当作 AETHER 的结果**。其 README 还说明长会话结束时图谱检索残留的上下文可能反而更多；因此要求报告 `residual context tokens` 与 truncation/memory pressure。

## 6. 给 Codex 的开发指导

先阅读 `docs/13_codegraph.md`、`config/codegraph.example.yaml`、`contracts/codegraph.schema.json` 和新票据。**不要**将 CodeGraph 的 install 脚本作为项目 bootstrap 自动执行。

完成 M00-06 后可以在受审开发机上用以下**参考命令**手动接入 Codex：

```sh
# 确认具体版本并检查其 npm 脚本/许可证后，替换 VERSION（不得使用 latest 作为 lock）
npm view @colbymchenry/codegraph versions --json
npm install -g @colbymchenry/codegraph@VERSION
CODEGRAPH_TELEMETRY=0 codegraph install --print-config codex  # 仅读取建议配置
cd /path/to/aether                 # 必须是已审阅的具体项目目录
CODEGRAPH_TELEMETRY=0 codegraph init
CODEGRAPH_TELEMETRY=0 codegraph status
# 用户同意后再按打印片段注册 Codex MCP/AGENTS.md；不自动修改全局配置。
```

MCP 工具配置由用户显式同意；为了调试也可以使用 `CODEGRAPH_TELEMETRY=0 codegraph explore "where is the coding executor boundary"`。这是静态代码理解，不是对 OpenHands 任务结果的验证。

## 7. 验收标准

- 未安装 CodeGraph：正常编码流可运行，返回 `degraded: missing_codegraph`，不伪装已经做结构检索。
- 未授权 project/snapshot、跨项目路径、不可变版本失配、`..` / symlink 逃逸一律拒绝。
- 当前候选变动后，陈旧图谱不能被当作当前候选已验证的结构。
- graph-only 指向测试文件只能**增加**检查，不能取代 trusted suite。
- 实际 CLI 或 MCP query 出现退出失败/超时/协议错误时，错误被记录，失败不摧毁编程任务。
- 评测报告记录冷启动索引耗时 + warm 查询成本；有 CodeGraph/无 CodeGraph 共享同一个模型与固定版本，未运行不能声称收益。

来源：S46–S49；实现方案、合同/限制及默认值是 AETHER 自定，非上游保证。


---

<!-- canonical source: docs/DECISIONS.md -->

# Architecture decision records

| ID | Decision | Rationale / invariant |
|---|---|---|
| ADR-001 | New AETHER core, Hermes isolated baseline | Avoid inheriting a second lifecycle; compare fairly rather than claiming absent features |
| ADR-002 | Temporal owns task execution | Durable execution and replay; DB status is a projection |
| ADR-003 | OpenHands only handles bounded coding jobs | Reuse existing code tools while preserving policy and verification authority |
| ADR-004 | LiteLLM only provider adaptation | No overlapping orchestrator; explicit authorization/cost ledger remains ours |
| ADR-005 | BM25S + pgvector + BGE | Real lexical+dense retrieval without Google dependency or large search platform |
| ADR-006 | Project-scoped immutable indexes | Clear ACL and consistency for personal 50k-chunk scope |
| ADR-007 | Single owner V1, strict project boundaries | Useful scope without pretending enterprise multi-tenancy |
| ADR-008 | Independent verifier, immutable artifacts | Prevent actor self-grading and stale test reuse |
| ADR-009 | Skills are evaluated versioned artifacts | Experience accumulation is not proven learning until tested |
| ADR-010 | No runtime model brand hardcoding | User keys/capabilities vary; live config must be probed, not invented |
| ADR-011 | No guaranteed exactly-once external effects | Use idempotency/reconciliation/manual review for unknown outcomes |
| ADR-012 | Offline scripted mode explicit | Enables development, never masquerades as actual AI performance |
| ADR-013 (2026-10-15) | Adopt `colbymchenry/codegraph` as optional, project-scoped structural code intelligence | Supports Codex authoring + runtime coding jobs via two explicit, separately authenticated integrations; no new scheduler or knowledge authority. Feature flag defaults off until M00 probe. Generated graphs are derived caches and never verification evidence. |

Implementation changes append records with: date, evidence, decision, alternatives, affected contracts, compatibility and tests. Do not delete prior decisions.


---

<!-- canonical source: docs/SOURCES.md -->

# 来源与核实边界

设计核实日期：2026-10-14。下列是实际查阅的上游仓库、官方文档或官方模型卡。具体库/API事实由这些来源支持；AETHER架构、默认阈值、接口、验收规则和排期分解属于本设计，并非上游保证。

两条Git SHA来自该日期实际读取的branch metadata，仅冻结来源定位。除这两条外没有伪造commit、lock、镜像digest或已完成的兼容性测试。可变分支/文档需M00复核到最终锁定版本。未做完整依赖安全/许可证审计，亦未下载完整上游代码。

仓库复用以依赖安装和薄adapter为主；本包未粘贴上游大段代码。源码或社区skills复制时必须保留对应版权与许可证。所有来源只作本设计依据，不自动授权连接用户账户或产生副作用。

| ID | 来源 | 设计中支持的内容 / 核实限制 |
|---|---|---|
| S01 | [Hermes官方仓库；现有Agent功能和基线入口](https://github.com/NousResearch/hermes-agent) | 读取README/功能；baseline snapshot见repositories.yaml。 |
| S02 | [Hermes Skills文档](https://github.com/NousResearch/hermes-agent/blob/main/website/docs/user-guide/features/skills.md) | 已有技能写入审批；不宣称AETHER独有。 |
| S03 | [Hermes来源commit](https://github.com/NousResearch/hermes-agent/commit/0e427d788d253630d38a3a51cd76849e73cd6925) | 2026-10-14读取branch main，来源定位，不是已运行基线。 |
| S04 | [OpenHands Software Agent SDK](https://github.com/OpenHands/software-agent-sdk) | 复用SDK/tools/workspace/agent-server，而不是整套应用。 |
| S05 | [OpenHands固定SDK metadata](https://github.com/OpenHands/software-agent-sdk/blob/0bd5cc2d322d61f785816a29ef1f2e4c86db2460/openhands-sdk/pyproject.toml) | 读取version1.54.0和Python>=3.12；未安装。 |
| S06 | [OpenHands workspace约束](https://github.com/OpenHands/software-agent-sdk/blob/0bd5cc2d322d61f785816a29ef1f2e4c86db2460/pyproject.toml) | 四包workspace与依赖约束；M00实际解决。 |
| S07 | [OpenHands远端Docker会话示例](https://github.com/OpenHands/software-agent-sdk/blob/0bd5cc2d322d61f785816a29ef1f2e4c86db2460/examples/02_remote_agent_server/02_convo_with_docker_sandboxed_server.py) | 读取DockerWorkspace/Conversation/events/cost/close；默认preset/latest不可照搬。 |
| S08 | [OpenHands Agent Server架构](https://docs.openhands.dev/sdk/arch/agent-server) | 远端编程执行器的边界。 |
| S09 | [OpenHands Workspace架构](https://docs.openhands.dev/sdk/arch/workspace) | 本地/远端workspace；具体参数在锁定版复核。 |
| S10 | [Temporal Python SDK](https://github.com/temporalio/sdk-python) | workflow/activity/worker/client。 |
| S11 | [Temporal Python文档](https://docs.temporal.io/develop/python) | 持久工作流开发入口。 |
| S12 | [Temporal messages](https://docs.temporal.io/develop/python/workflows/message-passing) | signal/update/query语义。 |
| S13 | [Temporal testing](https://docs.temporal.io/develop/python/best-practices/testing-suite) | 工作流测试与回放。 |
| S14 | [Temporal activity定义](https://docs.temporal.io/activity-definition) | 活动幂等性；不保证任意外部副作用exactly-once。 |
| S15 | [Temporal官方样例](https://github.com/temporalio/samples-python) | hello/hello_activity.py与hello_activity_retry.py。 |
| S16 | [Temporal服务](https://github.com/temporalio/temporal) | 选择持久服务，不fork服务。 |
| S17 | [LiteLLM SDK](https://github.com/BerriAI/litellm) | provider适配；不是AETHER权限权威。 |
| S18 | [LiteLLM completion](https://docs.litellm.ai/docs/completion) | completion/acompletion接口入口。 |
| S19 | [LiteLLM structured output](https://docs.litellm.ai/docs/completion/json_mode) | provider能力存在差异，须本地schema校验。 |
| S20 | [pgvector](https://github.com/pgvector/pgvector) | vector类型、cosine、exact/HNSW。 |
| S21 | [pgvector Python binding](https://github.com/pgvector/pgvector-python) | Python/SQLAlchemy适配。 |
| S22 | [pgvector RRF样例](https://github.com/pgvector/pgvector-python/blob/master/examples/hybrid_search/rrf.py) | 参考融合方法；并非说明PostgreSQL FTS是BM25。 |
| S23 | [BM25S](https://github.com/xhluca/bm25s) | BM25/Tokenizer/index/retrieve/save/load；不可变索引生命周期由AETHER实现。 |
| S24 | [jieba](https://github.com/fxsjy/jieba) | 中文搜索分词。 |
| S25 | [FlagEmbedding](https://github.com/FlagOpen/FlagEmbedding) | BGEM3FlagModel/FlagReranker。 |
| S26 | [BGE-M3官方模型卡](https://huggingface.co/BAAI/bge-m3) | 选用dense 1024维；revision和权重license须固定。 |
| S27 | [BGE reranker官方模型卡](https://huggingface.co/BAAI/bge-reranker-v2-m3) | 选定重排器；未测目标机器延迟。 |
| S28 | [HTTPX](https://github.com/encode/httpx) | 可信HTTP下载基础；SSRF策略并非该库自动提供。 |
| S29 | [Trafilatura](https://github.com/adbar/trafilatura) | extract解析已下载HTML。 |
| S30 | [feedparser](https://github.com/kurtmckee/feedparser) | RSS/Atom bytes解析。 |
| S31 | [Docling](https://github.com/docling-project/docling) | 本地文档转换；OCR不是默认全部执行。 |
| S32 | [Playwright Python](https://github.com/microsoft/playwright-python) | 有需要才调用JS浏览器。 |
| S33 | [MCP Python SDK](https://github.com/modelcontextprotocol/python-sdk) | client/transport；固定major与protocol。 |
| S34 | [Agent Skills规格](https://agentskills.io/specification) | SKILL.md标准；安全/评测sidecar是本设计。 |
| S35 | [Agent Skills仓库](https://github.com/agentskills/agentskills) | 兼容格式参考，不等于可信技能市场。 |
| S36 | [FastAPI](https://github.com/fastapi/fastapi) | API基础；不复制完整平台。 |
| S37 | [Next.js](https://github.com/vercel/next.js) | App Router/TypeScript UI。 |
| S38 | [shadcn/ui](https://github.com/shadcn-ui/ui) | 少量审阅组件，不引入第二个Agent UI数据模型。 |
| S39 | [Langfuse](https://github.com/langfuse/langfuse) | 仅可选观察profile。 |
| S40 | [PostgreSQL17 RLS](https://www.postgresql.org/docs/17/ddl-rowsecurity.html) | owner/superuser/BYPASSRLS边界，真实非superuser角色必须测试。 |
| S41 | [Docker rootless安全文档](https://docs.docker.com/engine/security/rootless/) | 风险缓解，不宣称容器绝对安全或公开多租户隔离。 |
| S42 | [Pydantic models文档](https://docs.pydantic.dev/latest/concepts/models/) | shape validation与frozen不是权限/深冻结。 |
| S43 | [OpenAI Codex AGENTS.md](https://developers.openai.com/codex/agent-configuration/agents-md) | 根目录AGENTS.md与渐进读取；产品进度另外持久记录。 |
| S44 | [OpenAI Codex实践](https://developers.openai.com/codex/learn/best-practices) | 明确任务/上下文/验证要求；不是一次prompt完成的保证。 |
| S45 | [OpenAI Codex CLI](https://developers.openai.com/codex/cli) | 在项目目录使用Codex的官方入口；不假设订阅是产品API key。 |
| S46 | [CodeGraph 官方仓库](https://github.com/colbymchenry/codegraph) | 2026-10-15 读取：MIT、CodeGraph CLI + MCP (`codegraph_explore` 默认)、`codegraph affected`、SQLite `.codegraph`、监控增量更新，支持 Codex；M00 仍必须锁定发布及安装校验。 |
| S47 | [CodeGraph 源码内嵌 Library Usage](https://github.com/colbymchenry/codegraph#library-usage) | `CodeGraph.init/open`、`indexAll`、`buildContext`、`getImpactRadius` 等为可选 JS API；包内 Node 22.5+ 的约束不同于自带运行时的 CLI。 |
| S48 | [CodeGraph 遥测与供应链说明](https://github.com/colbymchenry/codegraph#telemetry) | 官方描述匿名遥测、`CODEGRAPH_TELEMETRY=0` 关闭，发布签名/attestation 验证流程；AETHER 在本地 worker 里默认禁用外联。 |
| S49 | [CodeGraph CLI 与 MCP tool 描述](https://github.com/colbymchenry/codegraph#mcp-tools) | 默认 MCP 工具为 `codegraph_explore`，其他结构查询可经 CLI/配置开启；工具默认返回的 context 含源码，必须设上下文和数据出站限制。 |



---

<!-- canonical source: docs/14_ecosystem_audit.md -->

# 14 · 2026-10-15 GitHub Agent 开源生态全面审计

> **AETHER V1.2 筛选报告。** 该目录是公开 GitHub 项目及仓库上游文件的研究快照，而不是已安装依赖列表，也不是所有 GitHub 仓库的全集。开源生态持续变化，不能承诺“绝对没有遗漏”。本次按 10 个领域系统筛选 **81 个候选条目 / 80 个独立仓库**（其中 Pydantic AI 分别作为框架和独立 eval 库评估）。库的首页或许可证已经查阅的不代表 API 和所有转移依赖通过了固定版本的实际安装验证。

## 0. 必须保持的架构边界

- **Temporal 唯一持久任务调度权威**。不得再引入可自行恢复、独立重试外部操作的第二套生产工作流。
- **可信工具网关、原始证据存储、独立验证器、权限/费用账本由 AETHER 掌握**；LLM、长期记忆引擎或第三方评测不能修改这些权威记录。
- **OpenHands 仍是第一编码执行器**；其他 Harness 先做同平台公平基线。Codex 是项目开发工具而非生产时隐含的 API 依赖。
- 搜索基础依然是授权站点/RSS/文件采集 + BM25S + pgvector + BGE 重排；新增组件不能偷换成 Google 搜索或强制联网 SaaS。
- 所有**新增依赖都默认关闭**，从独立探索→固定 SHA/许可审查→受控沙箱探针→A/B 性能与安全验证→用户批准后启用。
- 任何网页、MCP、插件说明中的“提权指令”均只是**不可信数据**；扫描器可能有遥测或外发，不能默认为隐私安全。

## 1. 真正值得引入的组合（优先级从高到低）

| 模块 | 首选项目与精确使用面 | 怎么接入 | 何时允许升级 |
|---|---|---|---|
| 真实 Agent 评测（新） | [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) 里的**独立 `pydantic-evals`**：datasets、`Evaluator`、experiment run、工具轨迹指标；不导入 `pydantic-ai` Agent 核心 | `evals/adapters/pydantic_evals_adapter.py`，只读取不可变试验任务/结果事件 | 评测结果能独立复现，LLM judge 不能代替可运行的代码验收 |
| 注入/工具投毒红队（新） | [promptfoo/promptfoo](https://github.com/promptfoo/promptfoo)：CLI、`promptfooconfig.yaml`、回归测试/CI | `evals/redteam/`；离线测试只喂合成材料，不随意上传用户的私有提示词或技能 | 强制覆盖 URL、repo README、搜索摘要、MCP tool description、恶意 SKILL.md 的间接注入 |
| 长期记忆（新，先实验） | [vectorize-io/hindsight](https://github.com/vectorize-io/hindsight) `hindsight-api` / `hindsight-clients`：`retain`/`recall`/`reflect`、`bank_id` | 独立内网服务 `MemoryEngine` adapter；**拒绝未经权限绑定的 bank_id** | 同冻结任务下和原有记忆、Mem0、Cognee 比较正确率、来源/删除/冲突/污染、安全和成本 |
| 采集增强（新，可选） | [unclecode/crawl4ai](https://github.com/unclecode/crawl4ai) 的 `AsyncWebCrawler` + CSS/XPath/JS 页面抽取 | `IngestionExtractor` 接口，在授权站点 JS 页面上作为备选；HTTPX+Trafilatura 保留为默认 | 仅在确实提升 JS 提取覆盖率时启用，采集必须通过 SSRF/域名/机器人规则/安全策略 |
| 代码结构理解（v1.1 已有） | [colbymchenry/codegraph](https://github.com/colbymchenry/codegraph) Rust/CLI/MCP、本地符号关系、影响范围 | `RepositoryIntelligence`，针对**隔离的不可变仓库快照**生成索引 | 图谱新鲜度准确、跨项目不可见、CLI 不联网且降级后编码照常工作 |
| 浏览器低 token 操作（新，可选） | [vercel-labs/agent-browser](https://github.com/vercel-labs/agent-browser)：`snapshot -i`、`--delta`、截图/会话、元素 refs | `BrowserRunner` 的候选后端，默认 Playwright；一个任务一套全新浏览器 profile | 同网站相同权限下，动作准确率提高且不暴露登录 Cookie/环境变量 |
| 自我改进（新，研究） | [Human-Agent-Society/reef](https://github.com/Human-Agent-Society/reef) 的记录、反馈、候选/recipe、evaluation；[CORAL](https://github.com/Human-Agent-Society/CORAL) 的保密评分 | **离线实验服务**产生候选 artifact；AETHER Skill Lab 负责审批和 promotion | 独立封存 holdout 与可信 grader；候选不能读取评测答案或批准自己上线 |
| MCP 检测（新） | [modelcontextprotocol/inspector](https://github.com/modelcontextprotocol/inspector) CLI/Inspector | 开发 CI 里查 tool schemas 和调用兼容性，不能让 inspector 持有线上凭证 | 可审计 schema drift / tool hash / authority 独立执行 |
| 能力对照（新） | [facebookresearch/TUA-Bench](https://github.com/facebookresearch/TUA-Bench)、[harbor-framework/terminal-bench-1](https://github.com/harbor-framework/terminal-bench-1) | 与现有 Hermes 任务保持同模型、权限、基础快照、验收器、预算 | 许可证/数据可信后执行，保存 raw log，未跑记 not_run |

上游首要依据：[Hindsight README](https://github.com/vectorize-io/hindsight)、[Pydantic Evals](https://github.com/pydantic/pydantic-ai/blob/main/docs/evals.md)、[agent-browser README](https://github.com/vercel-labs/agent-browser/blob/main/README.md)、[Crawl4AI README](https://github.com/unclecode/crawl4ai)、[Reef README](https://github.com/Human-Agent-Society/reef)、[CodeGraph README](https://github.com/colbymchenry/codegraph)。上游自述的性能数字不是 AETHER 实测。

## 2. 许可证、安全和已归档项目——不能忽略

| 项目 | 已核对的关键限制 | AETHER 处理方式 |
|---|---|---|
| [GitNexus](https://github.com/abhigyanpatwari/GitNexus/blob/main/LICENSE) | **PolyForm Noncommercial 1.0.0**；源码公开≠允许商业复用 | 可以在许可允许的非商业研究中做只读对照；不能作为潜在商业产品默认依赖，也不能照搬其代码 |
| [Serena v2](https://github.com/oraios/serena/blob/main/docs/01-about/060_license.md) | **2026-10-13 v2.0.0**：应用 `src/serena` 等 GPL-3.0-or-later，`src/solidlsp` MIT | 可独立研究/复用 MIT SolidLSP；任何 Serena 应用再分发先审 GPL 条款和边界 |
| [OpenViking](https://github.com/volcengine/OpenViking) | 主体 **AGPL-3.0**，`crates/ov_cli` Apache-2.0、部分 examples Apache/MIT | 只研究 `viking://` / L0-L2 渐进式上下文的设计；要运行主服务先审 AGPL 网络提供义务 |
| [SearXNG](https://github.com/searxng/searxng) | **AGPL-3.0**；默认聚合外部搜索引擎，并非自建全网索引 | 只有用户明确想用外部元搜索时作为 sidecar；禁用 Google 引擎，不称其为完全自主索引 |
| [Firecrawl](https://github.com/firecrawl/firecrawl) | 服务端 **AGPL-3.0**，SDK 与云功能授权不同 | HTTPX、Trafilatura、Crawl4AI 优先；研究 Firecrawl 时审部署与许可证 |
| [Langfuse](https://github.com/langfuse/langfuse/blob/main/LICENSE) | 核心 **MIT**；`ee/` 等目录独立商业许可证 | 已是可选观测方案；不能默认启用付费/企业特性。还要检查默认遥测开关 |
| [Phoenix](https://github.com/Arize-ai/phoenix) | **Elastic License 2.0**：source-available 但不是 OSI 通常认定的开源许可 | 参考 OTel 接口，默认不嵌入 |
| [Mastra](https://github.com/mastra-ai/mastra) | 核心 Apache-2.0，`ee/` 为商业许可证 | 仅参考核心设计；排除 ee |
| [Activepieces](https://github.com/activepieces/activepieces) | 社区核心 MIT，`packages/ee` 等商业特性 | 借鉴 connector OAuth/审批；不导入重型工作流平台 |
| [Daytona](https://github.com/daytonaio/daytona) | GitHub 开源仓库已在 **2026-10-03 归档**；此前核心转为私有仓库 | **不作为** AETHER 新的可维护自托管沙箱根基 |
| [Roo Code](https://github.com/RooCodeInc/Roo-Code) | **2026-05-15 归档** | 作为历史/对照，不做生产依赖 |
| [Snyk Agent Scan](https://github.com/snyk/agent-scan/blob/main/docs/scanning.md) | 公开文档明确说明 MCP 配置签名和技能文件可能发送 Snyk API 分析 | **禁用自动联网扫描**；只有用户同意且对数据外发做过单独风险评估才用 |
| [Composio](https://github.com/ComposioHQ/composio) | SDK MIT，但常见工具会话/认证/执行依赖 Composio API Key 和托管平台 | 可选连接器，明确标注外部服务依赖；不能违反“不依赖 Google/第三方云作必需条件” |

> 许可证不是简单的“AGPL 绝对不能商业使用”：AGPL 允许商业使用，但有网络访问等条件；是否影响你的部署和分发需按实际组合与法律意见核对。Noncommercial 则有明确目的限制。以上是技术选型风险提示，不构成法律意见。任何项目的**精确发布版本及其子目录、transitive dependencies**都必须在 M00 固定审核。

## 3. 功能归属和优先替代顺序

### 3.1 MemoryEngine 协议（只有一个项目级权威引擎）

```python
class MemoryEngine(Protocol):
    async def retain(self, project_id: str, source_event_id: str, source_hash: str,
                     content: str, policy: MemoryPolicy) -> MemoryReceipt: ...
    async def recall(self, project_id: str, query: str, limit: int,
                     as_of: datetime | None = None) -> list[MemoryHit]: ...
    async def delete_source(self, project_id: str, source_event_id: str) -> DeleteReceipt: ...
    async def health(self) -> MemoryHealth: ...
```

`project_id` 来自 AETHER 身份上下文，永远不能用 Agent 从自然语言填的字符串替代。AETHER Evidence Ledger 是权威记录；下游 Hindsight/Mem0/Cognee 只是**派生检索索引**。即使外部存储不可用，证据/权限/删除请求记录也必须保留并能重试索引修复。`reflect` 生成内容不能自动升格为事实。

**实验矩阵：** `AETHER native`, `Hindsight`, `Mem0`, `Cognee`；同一份匿名化合成语料、相同模型条件、相同token/cost计量；考察来源命中率、时态事实修改、冲突说明、tenant泄漏率、数据删除闭环、工具注入抵抗、P95查询延迟。**只有一个方案可以正式投产**；代码先写统一接口，不要全安装。

### 3.2 BrowserRunner 协议

```python
class BrowserRunner(Protocol):
    async def open(self, actor_context: TrustedContext, url: str) -> PageReceipt: ...
    async def snapshot(self, session_id: str, mode: Literal['interactive','full','delta']) -> Snapshot: ...
    async def act(self, approved_intent: OperationIntent, action: BrowserAction) -> ActionReceipt: ...
    async def close(self, session_id: str) -> None: ...
```

`agent-browser snapshot -i` / `--delta` 减少 DOM 噪声，但元素 `@eN` 只是**临时页面会话引用**，不能当跨导航永久定位符。需要单独容器+临时用户目录、站点白名单、DNS/IP/跳转审计、可疑下载封锁、外部副作用统一审批。不要把宿主 Chrome 登录态或个人 Cookie 挂进去。

### 3.3 IngestionExtractor 协议

`HTTPX + Trafilatura` 为轻量默认；只有 HTML 正文不足或 JS 客户端渲染的**授权站点**调用 `Crawl4AI AsyncWebCrawler`。解析结果需要记录 `url + fetched_at + sha256 + parser_version + canonical_url + source_rights`；测试正文结构准确率、抓取吞吐、CPU/内存、SSRF 防护与 robots/ToS 政策，不复用真实浏览器登录态。

### 3.4 SkillLab 实验层

借鉴 Reef 的 record→recipe→evaluation→artifact 和 CORAL 的受保护 grader 设计，不让实验引擎拥有 production 凭据、holdout 答案或 publish 权限。Skill 候选必须不可变，满足：真实任务回放+清洁 holdout+置信区间/预算+人工批准+分阶段灰度+回滚。失败原因可进经验库，但**不能把失败后的模型自我解释当作事实**。

## 4. 按功能完整候选目录（机器清单见 config/ecosystem_candidates.yaml）

以下为候选库全量索引：**已查看首页**表示核对过概念或能力；**license_checked**表示检索确认了该项许可描述；**verify_at_pin**表示未对固定版本完成完整许可审查。**tier=pilot/adopt-dev 不等于已经安装。**

### 编排与执行（20 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [NousResearch/hermes-agent](https://github.com/NousResearch/hermes-agent) | `reference` | `verify\_at\_pin` | **skills, memory, subagents, skill learning**：独立锁定基线，执行公平对照；不得用其执行循环做自身实现 |
| [temporalio/temporal](https://github.com/temporalio/temporal) | `core-existing` | `verify\_at\_pin` | **server / persistence / workflow durability**：唯一持久执行引擎，拒绝第二状态权威 |
| [temporalio/sdk-python](https://github.com/temporalio/sdk-python) | `core-existing` | `verify\_at\_pin` | **Client, Worker, Workflow, Activity, Replay**：编排事务与恢复，只在 Activity 调工具 |
| [OpenHands/software-agent-sdk](https://github.com/OpenHands/software-agent-sdk) | `core-existing` | `verify\_at\_pin` | **openhands-sdk; tools; workspace; agent-server**：限定编码工作子任务的沙箱执行器 |
| [deepseek-ai/deepseek-harness](https://github.com/deepseek-ai/deepseek-harness) | `reference` | `MIT` | **Cordis / plugin harness / TypeScript tool runtime**：借鉴紧凑 Harness 和动态能力；developer preview 不做生产编排 |
| [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) | `pilot` | `MIT` | **pydantic_evals; durable_execution/temporal; capabilities**：只优先引入 pydantic-evals 评测包；主 agent/Temporal 编排不迁移 |
| [langchain-ai/deepagents](https://github.com/langchain-ai/deepagents) | `reference` | `verify\_at\_pin` | **agent planning, context, files, subagents**：对照研究；与自有循环重复，不引入生产 |
| [bytedance/deer-flow](https://github.com/bytedance/deer-flow) | `reference` | `verify\_at\_pin` | **superagent orchestration, context, browser, research**：参考长期任务 UX 与研究工具；不导入 LangGraph 第二编排 |
| [openclaw/openclaw](https://github.com/openclaw/openclaw) | `reference` | `verify\_at\_pin` | **multi-channel assistant runtime**：研究跨终端接入，非 AETHER 的底层编排器 |
| [paperclipai/paperclip](https://github.com/paperclipai/paperclip) | `reference` | `MIT` | **agent organization, goals, cost, governance UI**：借鉴代理组织治理和人类审批设计 |
| [mvschwarz/openrig](https://github.com/mvschwarz/openrig) | `reference` | `Apache-2.0` | **Codex/Claude/Pi multi-agent sessions**：研究团队协作协议，暂不运行第二 supervisor |
| [october-dev/october-harness](https://github.com/october-dev/october-harness) | `watch` | `MIT` | **CLI/RPC/SDK, durable messaging via October Bus**：2026 新兴 Pi fork；多 Agent 总线值得学习，早期项目仅实验 |
| [earendil-works/pi](https://github.com/earendil-works/pi) | `reference` | `verify\_at\_pin` | **minimal coding agent core / sessions / RPC**：研究薄 Harness 和上下文压缩，不替换 OpenHands |
| [anomalyco/opencode](https://github.com/anomalyco/opencode) | `reference` | `verify\_at\_pin` | **terminal coding harness / tools**：编码基线对照，不作为并行任务权威 |
| [openai/codex](https://github.com/openai/codex) | `reference` | `verify\_at\_pin` | **coding CLI / sandbox / ACP when available**：Codex 用于构建 AETHER，不等于嵌入生产核心 |
| [microsoft/agent-framework](https://github.com/microsoft/agent-framework) | `watch` | `verify\_at\_pin` | **multi-agent patterns, graph workflows**：仅研究组织协作，避免第二工作流 |
| [google/adk-python](https://github.com/google/adk-python) | `reference` | `verify\_at\_pin` | **agent SDK and session semantics**：研究接口设计，不能让 Google 成为必需依赖 |
| [agentscope-ai/agentscope](https://github.com/agentscope-ai/agentscope) | `watch` | `verify\_at\_pin` | **multi-agent, tracing, orchestration**：备用评测对象，不引入新主循环 |
| [mastra-ai/mastra](https://github.com/mastra-ai/mastra) | `reference` | `Apache-2.0\_core; proprietary\_ee` | **TS workflow, agent and UI integration**：仅阅读 Apache 核心；ee/ 商业许可不混入 |
| [activepieces/activepieces](https://github.com/activepieces/activepieces) | `reference` | `MIT\_core; commercial\_ee` | **connector workflows / pieces / MCP**：参考第三方应用连接器，不增加第二自动化系统 |

### 记忆与上下文（9 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [vectorize-io/hindsight](https://github.com/vectorize-io/hindsight) | `pilot` | `MIT` | **hindsight-api, hindsight-clients; retain/recall/reflect; banks**：优先记忆引擎对照实验；AETHER 保存原始证据和删除权 |
| [mem0ai/mem0](https://github.com/mem0ai/mem0) | `pilot` | `Apache-2.0` | **mem0; memory CRUD and vector recall**：记忆替代组对照，按项目隔离测 Recall、冲突、删除 |
| [topoteretes/cognee](https://github.com/topoteretes/cognee) | `pilot` | `verify\_at\_pin` | **remember/recall/improve/forget, graph/vector/code context**：与 Hindsight/Mem0 比较；不得同时写三套生产权威记忆 |
| [volcengine/OpenViking](https://github.com/volcengine/OpenViking) | `reference` | `AGPL-3.0\_main; Apache-2.0\_cli` | **context file tree; viking://; progressive L0/L1/L2**：研究上下文分层；AGPL 主体不默认为可嵌入闭源核心 |
| [getzep/graphiti](https://github.com/getzep/graphiti) | `pilot` | `Apache-2.0` | **graphiti_core; time-aware knowledge graph**：可选时间知识图实验；Neo4j/FalkorDB 等依赖增加运维 |
| [HKUDS/LightRAG](https://github.com/HKUDS/LightRAG) | `reference` | `MIT` | **graph RAG extraction + indexing**：研究实体关系召回，暂不替代现有 BM25S+pgvector |
| [letta-ai/letta](https://github.com/letta-ai/letta) | `reference` | `verify\_at\_pin` | **persistent agent memory/state**：只参考分层状态管理，避免完整 runtime 叠加 |
| [thedotmack/claude-mem](https://github.com/thedotmack/claude-mem) | `watch` | `verify\_at\_pin` | **coding-agent session memory**：研究进程间会话总结，可不依赖完整插件 |
| [JordyZomer/Lemmalog](https://github.com/JordyZomer/Lemmalog) | `watch` | `verify\_at\_pin` | **Datalog / provenance memory**：早期研究候选，不做默认服务 |

### 代码智能（7 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [colbymchenry/codegraph](https://github.com/colbymchenry/codegraph) | `pilot` | `MIT` | **Rust kernel; local index; codegraph CLI/MCP; impact queries**：沿用 V1.1 可选方案，隔离快照+白名单+新鲜度 |
| [abhigyanpatwari/GitNexus](https://github.com/abhigyanpatwari/GitNexus) | `reference` | `PolyForm-Noncommercial-1.0.0` | **MCP query/context/impact/trace/api_impact; readonly/allowlist**：仅符合许可的本地非商业研究，不纳入商用构建和依赖 |
| [oraios/serena](https://github.com/oraios/serena) | `reference` | `GPL-3.0-or-later\_app; MIT\_solidlsp` | **src/solidlsp symbol/LSP; Serena v2 REPL**：优先独立研究 MIT SolidLSP，避免把 GPL 应用代码复制到核心 |
| [ast-grep/ast-grep](https://github.com/ast-grep/ast-grep) | `pilot` | `verify\_at\_pin` | **structural search/rewrite CLI, rule patterns**：独立静态代码修改/安全检查；不是调用图数据库替代 |
| [tree-sitter/tree-sitter](https://github.com/tree-sitter/tree-sitter) | `reference` | `verify\_at\_pin` | **AST parsing grammar ecosystem**：仅在必要时直接用解析接口；优先复用 CodeGraph 解析 |
| [astral-sh/ruff](https://github.com/astral-sh/ruff) | `core-existing` | `verify\_at\_pin` | **lint and formatter**：编码质量关卡；不负责 agent 规划 |
| [astral-sh/ty](https://github.com/astral-sh/ty) | `watch` | `MIT` | **Python type checking**：新型类型检查候选；与 Pyright/mypy 基线比误报和性能 |

### 浏览器与采集（12 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [microsoft/playwright-python](https://github.com/microsoft/playwright-python) | `core-existing` | `verify\_at\_pin` | **BrowserContext, locators, screenshots**：可信隔离浏览器原语；明确网络/站点和认证边界 |
| [vercel-labs/agent-browser](https://github.com/vercel-labs/agent-browser) | `pilot` | `Apache-2.0` | **CLI session, snapshot -i/-delta, refs, screenshots**：与纯 Playwright 比 token/成功率；只用干净浏览器 profile |
| [browser-use/browser-use](https://github.com/browser-use/browser-use) | `pilot` | `verify\_at\_pin` | **browser agent actions/DOM extraction**：备选受控浏览器执行器；严格副作用批准 |
| [browserbase/stagehand](https://github.com/browserbase/stagehand) | `pilot` | `verify\_at\_pin` | **act/extract/observe browser automation**：交互抽取对照；检查是否依赖云服务或私有 provider |
| [microsoft/playwright-mcp](https://github.com/microsoft/playwright-mcp) | `reference` | `verify\_at\_pin` | **MCP browser snapshot/tools**：适配模型工具协议时比较，需控制会话和 egress |
| [Tencent/BrowserSkill](https://github.com/Tencent/BrowserSkill) | `reference` | `MIT` | **existing logged-in browser automation**：真实浏览器登录态风险高；默认禁用，不继承本机 Cookie |
| [unclecode/crawl4ai](https://github.com/unclecode/crawl4ai) | `pilot` | `Apache-2.0` | **AsyncWebCrawler; CSS/XPath extraction; Markdown; JS**：作为 JS 页面和复杂 HTML 解析的可选 ingestion adapter |
| [firecrawl/firecrawl](https://github.com/firecrawl/firecrawl) | `reference` | `AGPL-3.0\_server; SDK varies` | **crawl/search/extract APIs**：只做比较；自托管/云功能不完全一致；许可需隔离 |
| [searxng/searxng](https://github.com/searxng/searxng) | `pilot` | `AGPL-3.0` | **metasearch optional sidecar**：外网发现的可选独立服务；默认禁用 Google 上游 |
| [infiniflow/ragflow](https://github.com/infiniflow/ragflow) | `reference` | `Apache-2.0` | **document parser, RAG pipeline**：研究复杂 PDF 和表格解析，不引入重型并行检索系统 |
| [assafelovic/gpt-researcher](https://github.com/assafelovic/gpt-researcher) | `reference` | `verify\_at\_pin` | **source gathering, citations and research report**：比较研究任务策略与来源去重 |
| [onyx-dot-app/onyx](https://github.com/onyx-dot-app/onyx) | `reference` | `verify\_at\_pin` | **enterprise search connectors/security patterns**：研究企业资料采集授权，不复制全套平台 |

### 工具与授权（5 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [modelcontextprotocol/python-sdk](https://github.com/modelcontextprotocol/python-sdk) | `core-existing` | `verify\_at\_pin` | **MCP client transport and schema**：受审网关唯一出口，工具清单需版本固定 |
| [modelcontextprotocol/inspector](https://github.com/modelcontextprotocol/inspector) | `adopt-dev` | `verify\_at\_pin` | **MCP Inspector debug & schema probes**：开发期探针，不将 inspector 端口暴露公网 |
| [ComposioHQ/composio](https://github.com/ComposioHQ/composio) | `watch` | `MIT\_SDK; hosted\_API\_key\_required` | **python/ SDK; ts/packages/core tool search/execute**：连接器生态有价值，但托管 OAuth/云服务不是无第三方依赖核心 |
| [ArcadeAI/arcade-mcp](https://github.com/ArcadeAI/arcade-mcp) | `watch` | `verify\_at\_pin` | **MCPApp, auth-scoped tool decorators**：研究 OAuth/token 隔离设计；云托管可选非核心 |
| [snyk/agent-scan](https://github.com/snyk/agent-scan) | `reference` | `verify\_at\_pin` | **MCP/skill risk scanner CLI**：默认不连接云 API；该扫描器会向 Snyk API 提交配置/技能信息 |

### 持久化与沙箱（6 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [google/ax](https://github.com/google/ax) | `watch` | `Apache-2.0` | **Kubernetes agent sandbox control plane**：面向规模化多节点，当前单机 V1 不引入 K8s |
| [daytonaio/daytona](https://github.com/daytonaio/daytona) | `reject` | `verify\_archived` | **formerly open sandbox implementation**：上游 2026-10-03 归档；核心此前私有化，不作为自托管主依赖 |
| [e2b-dev/E2B](https://github.com/e2b-dev/E2B) | `watch` | `verify\_at\_pin` | **code sandbox execution**：谨慎查自托管和计费依赖，V1 优先 OpenHands Docker |
| [cloudflare/sandbox-sdk](https://github.com/cloudflare/sandbox-sdk) | `watch` | `verify\_at\_pin` | **vendor-specific remote sandboxes**：仅多云环境可选，不能成为离线必需条件 |
| [dbos-inc/dbos-transact-py](https://github.com/dbos-inc/dbos-transact-py) | `reference` | `MIT` | **durable functions**：Temporal 的直接替代路线，保持唯一引擎不共用 |
| [restatedev/sdk-python](https://github.com/restatedev/sdk-python) | `reference` | `verify\_at\_pin` | **durable execution workflows**：只做概念对比，不能并行持久化业务循环 |

### 持续学习（4 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [Human-Agent-Society/reef](https://github.com/Human-Agent-Society/reef) | `pilot` | `Apache-2.0` | **service, storage/records, recipe, train, evaluation**：离线实验外置；仅输出候选 artifact，部署由 AETHER 授权 |
| [Human-Agent-Society/CORAL](https://github.com/Human-Agent-Society/CORAL) | `reference` | `Apache-2.0` | **autonomous code experiments / protected grader**：参考评测环境与判卷隐私隔离，防止 agent 改评分 |
| [ant-research/AntOmniEvo](https://github.com/ant-research/AntOmniEvo) | `pilot` | `Apache-2.0` | **ArtifactSchema, System, Evaluator, proposals**：与 Reef 做实验性能力比较，不能双重上线 |
| [microsoft/agent-lightning](https://github.com/microsoft/agent-lightning) | `reference` | `MIT` | **agent training / RL trajectory optimization**：未来权重更新，V1 不依赖训练集群/GPU |

### 评测与观测（10 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai) | `adopt-dev` | `MIT` | **pydantic_evals datasets, evaluators, trajectories**：使用独立 pydantic-evals 包，确定性验收仍自有 |
| [promptfoo/promptfoo](https://github.com/promptfoo/promptfoo) | `adopt-dev` | `MIT` | **eval/redteam CLI and CI config**：开发期注入/工具投毒对照；不得联网泄漏机密数据 |
| [UKGovernmentBEIS/inspect_ai](https://github.com/UKGovernmentBEIS/inspect_ai) | `pilot` | `verify\_at\_pin` | **eval tasks, scorer, dataset, agent models**：与 Pydantic Evals 试对照，择一为主，不套叠 |
| [langfuse/langfuse](https://github.com/langfuse/langfuse) | `core-existing` | `MIT\_core; commercial\_ee` | **tracing, sessions, prompts, datasets**：可选观测，核心 MIT，ee 单独许可证；配置去标识与禁遥测 |
| [Arize-ai/phoenix](https://github.com/Arize-ai/phoenix) | `reference` | `Elastic-License-2.0` | **OpenTelemetry traces, experiment UI**：源代码可见但不是 OSI 开源许可；不默认引入 |
| [facebookresearch/TUA-Bench](https://github.com/facebookresearch/TUA-Bench) | `pilot` | `verify\_at\_pin` | **terminal benchmark tasks and grading**：加入新终端真实任务对照，先审查数据许可证和资源成本 |
| [harbor-framework/terminal-bench-1](https://github.com/harbor-framework/terminal-bench-1) | `pilot` | `verify\_at\_pin` | **terminal task benchmark**：同模型同预算含 TUA、内部验收对照 |
| [SWE-bench/SWE-bench](https://github.com/SWE-bench/SWE-bench) | `pilot` | `verify\_at\_pin` | **real repository patch benchmarks**：编码成功率对照和金标准验收 |
| [sierra-research/tau2-bench](https://github.com/sierra-research/tau2-bench) | `pilot` | `verify\_at\_pin` | **tool use benchmark with user simulation**：工具行为序列与副作用正确性 |
| [xlang-ai/OSWorld](https://github.com/xlang-ai/OSWorld) | `reference` | `verify\_at\_pin` | **desktop GUI agent benchmark**：V1 GUI 控制非目标，后续电脑 Agent 用 |

### 本地推理与检索（8 项）

| 项目 | 决策 | 已观察许可 | 精确复用面/理由 |
|---|---|---|---|
| [BerriAI/litellm](https://github.com/BerriAI/litellm) | `core-existing` | `verify\_at\_pin` | **completion / acompletion and accounting**：可信模型网关 adapter；不运行自治编排器 |
| [ollama/ollama](https://github.com/ollama/ollama) | `pilot` | `verify\_at\_pin` | **local model server and model registry**：供 16GB 显存小模型探索；无需默认云服务 |
| [ggml-org/llama.cpp](https://github.com/ggml-org/llama.cpp) | `pilot` | `verify\_at\_pin` | **GGUF runtime, llama-server**：本地低显存推理候选；与 Ollama 二选一部署 |
| [vllm-project/vllm](https://github.com/vllm-project/vllm) | `watch` | `verify\_at\_pin` | **high throughput batching and serving**：服务规模化场景；单机 V1 不必部署 |
| [sgl-project/sglang](https://github.com/sgl-project/sglang) | `watch` | `verify\_at\_pin` | **efficient generation engine**：规模化推理/训练备用，不与 vLLM 同时成为必选 |
| [FlagOpen/FlagEmbedding](https://github.com/FlagOpen/FlagEmbedding) | `core-existing` | `verify\_at\_pin` | **BGE-M3 and reranker models**：已有 embedding/rerank；必须验证具体模型维数 |
| [pgvector/pgvector](https://github.com/pgvector/pgvector) | `core-existing` | `verify\_at\_pin` | **PostgreSQL vector index**：已有向量召回模块 |
| [xhluca/bm25s](https://github.com/xhluca/bm25s) | `core-existing` | `verify\_at\_pin` | **BM25 lexical retrieval**：已有词法检索，不误写成 PG ts_rank BM25 |

## 5. 对照实验与录用规则

- **公共基线**：Hermes 最新冻结 SHA、AETHER 无候选版、AETHER 开启候选版；同一可运行模型、工具权限、token/cost 上限、仓库快照、隐藏测试和网络政策。所有使用外部服务的数据必须单独标记，不把数据未锁定的结果作公平比较。
- **指标**：`task_success`、`false_completion`、`security_violation`、`cost_per_success`、`tool_calls`、`tokens`、`context_resident_tokens`、`P50/P95`、`failure_recovery`、`rollback_correctness`。Crawl4AI 额外有页面解析质量；Memory 有污染/删除和时态事实；图谱有冷/热索引与无效图缓存检测。
- **避免评测作弊**：独立的高可信工具按事先签名的任务和工件校验；模型不能接触保密 verifier、通过评测结果反向编辑任务，也不能自动改门槛。
- **录用政策**：任一安全或项目隔离测试失败→不启用；结果波动不显著→继续保留默认方案；重依赖若收益不足→不安装。记录`not_run`与缺失资源；不能把项目方 README benchmark 当我们的结果。
- **当前硬件**：本地小模型路线由 Ollama 或 llama.cpp 二选一，云端模型可替换；不强行安装 vLLM+SGLang 双服务器，不假设显存可以装下任意量化模型。

## 6. 来源验证层级

`review_status=license_checked` 表示已通过 GitHub 官方仓库许可证或 README 明确宣称核对许可类别，但**未**完成第三方依赖许可证审计、法律审查和固定代码提交哈希。`review_status=needs_license_check` 是尚未核对。`production_enabled=false` 和 `dependency_probed=false` 如实代表**未集成、未验收**。

特别留意 2026 年 10 月新的变化：Serena v2 更新 2026-10-13；Crawl4AI v0.9.5 2026-10-14；Daytona 开源仓库归档 2026-10-03。后续所有日期/版本都需要 Codex 再去对应 release/tag/commit 复核。

## 7. 结论

**这次真正该落地的是 5 个工作面：独立 eval + Promptfoo 红队、可切换 MemoryEngine、CodeGraph 仓库智能、浏览器/爬虫可选适配、隔离的 Skill 自我进化实验。** 原来 Temporal 和 OpenHands 的基本职责不变。不要为收集 80 个仓库而增加 80 个依赖。


---

<!-- canonical source: docs/15_ecosystem_integration.md -->

# 15 · Codex 增量实施接口、数据边界与验收清单

本增补不改变 V1.1 主架构。新增适配器只有在 `M00-07` 严格审核之后才能实验；**不把 81 个候选全部安装**。所有候选真实接入之前 `production_enabled=false`。

## 推荐目录（任务交付时创建；规格包本身不包含实现）

```text
packages/adapters/aether_adapters/
  memory_engine.py         # MemoryEngine protocol + AETHER native backend
  hindsight_memory.py      # optional network-local REST client; no global SDK wrapper
  crawl4ai_extractor.py    # bounded approved sources, JS fallback only
  agent_browser.py         # isolated browser CLI, session-scoped
  solidlsp_symbols.py      # optional MIT SolidLSP-only experiments
  codegraph.py             # carried from V1.1
services/experiment_worker/
  recipes/                 # Skill candidate proposals, zero publish permissions
evals/
  adapters/pydantic_evals_adapter.py
  redteam/promptfooconfig.yaml
  datasets/ecosystem_public.jsonl
  reports/                 # actual immutable generated results
config/
  ecosystem_candidates.yaml
  ecosystem_experiments.example.yaml
```

## 数据约定

1. **Adapter 输入**必须由可信网关提供 `tenant/project_id`, `task_id`, `source_hash`, `allowed_capabilities`, `max_cost`、审计事件 `intent_id`；外部 LLM 字符串不能改变这些字段。做权限检查后才可向索引或记忆查询提供项目上下文。
2. **Adapter 输出**必须带 provider、索引/文档版本、耗时、token/CPU 成本、失败分类及 `evidence_ids`，并显式标注 `derived=true`。不能自动将外部记忆内容升级为原始事实。
3. **Memory** 中 Hindsight bank-id 只能由服务端根据已授权项目产生；删除必须覆盖服务端原始记录、图/向量派生索引、备份保留策略及异步任务，最终显示明确删除结果和可能的保留状态。
4. **Browser** 将 `agent-browser` 每个任务运行在固定 SHA/镜像的新 profile 中，禁用导入宿主机个人浏览器状态。截图、download、导航链接带 workspace id/URL 范围；高影响点击需经 Operation Ledger。
5. **Crawler** 只打开白名单 URL，限制大小、深度、并发、重定向和网络目标；解析中保留原始 response hash 及页面时间，不接受网页中的系统指令。
6. **Experiment** 中 Reef/AntOmniEvo 可提案，但 grader/holdout 置于不同身份、容器和网络命名空间；不得受候选代码写入。失败或异常时不会自行 promotion。

## 对应评测任务（可先用离线合成 fixture 编写但不可记为 live 已通过）

| 任务 | 公共开发测试 | 真实集成/安全验收 |
|---|---|---|
| 许可证清单 | 81条均有可访问仓库 URL/许可状态、协议冲突报告 | 所有实际 import/run 的确切子包与 immutable SHA + transitive notice |
| Hindsight/Memory | 同项目/跨项目的 20 个合成时态/冲突/删除用例 | 真实启动记忆服务和 API，删除派生索引，测试拒绝越权 bank id |
| Crawl4AI | 已授权固定网页 HTML/JS/redirect cases | 实际 JS 呈现提取、SSRF/symlink/私网禁止访问验证 |
| Agent Browser | 5 个无账号本地 HTML 页和导航变化用例 | CLI 冷/热启动、会话清理、真实容器网络政策、关键点击审批验证 |
| Code intelligence | CodeGraph/ast-grep/SolidLSP 同 repository snapshot | AST/call impact 与 golden truth 对照，stale index 拒绝、越项目拒绝 |
| Skill Lab | 3 个成功轨迹、3 个回归、3 个注入攻击 | 独立 grader 私有目录，不能偷看 holdout，候选无法发起 promotion |
| Pydantic Evals | 确定性评分和 trace checker 的单测 | 真实 Hermes/AETHER 同设置实验，报告重算完整 |
| Promptfoo | URL/README/MCP/技能四种投毒输入 | 有限红队环境无秘钥外发、审批拒绝、文件越权测试 |

## 关键依赖替换/新增的否决条件

- 任何候选绕过 Temporal 管理操作生命周期、绕过网关审批、或向同一 production job 直接启动第二个 supervisor。
- 候选把私有会话、浏览器 cookies、主机 secret、源码发到非授权云端。
- 引入 GitNexus 违反 PolyForm-Noncommercial，或将 Serena GPL 主体 / OpenViking AGPL 主体直接复制为闭源模块。
- 只有 README 声称性能提升、没有公平实验；显著增加延迟/成本却没有成功率改善。
- 某一可选组件不可用时 AETHER 强依赖它而无法编程、搜索、记忆或执行核心任务。

## 下一步具体实施顺序

M00-07 先审计许可/供应链与环境；随后 M10-07（离线评分）和 M10-08（离线红队）可与主线独立并行；M06-06 先 memory mock，再实际 pilot；M04-06 和 M05-07/08 仍是可选；M08-06 必须在 M08 基础验收器就绪之后才做受控自我进化试验。M10-09 报告必须保留未运行测试的事实。

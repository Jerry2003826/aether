#!/usr/bin/env python3
"""Validate this SPECIFICATION pack, not the unimplemented AETHER application.

No network, external service, paid model or destructive filesystem operation.
Requires Pydantic 2, PyYAML and jsonschema in the current Python environment.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
try:
    import yaml
    import jsonschema
    from reference.models import (GoalContract, Plan, Citation, Decision, SearchResult,
                                  OperationIntent, SkillManifest)
    from reference.core import validate_plan, citation_matches
except ImportError as exc:
    print(f'MISSING_REFERENCE_DEPENDENCY: {exc}', file=sys.stderr)
    sys.exit(2)

checks: list[str] = []

def check(condition: bool, label: str) -> None:
    if not condition:
        raise ValueError(label)
    checks.append(label)


def load_json(path: str):
    return json.loads((ROOT/path).read_text(encoding='utf-8'))


def load_yaml(path: str):
    return yaml.safe_load((ROOT/path).read_text(encoding='utf-8'))


def refs(value):
    if isinstance(value, dict):
        if '$ref' in value:
            yield value['$ref']
        for child in value.values():
            yield from refs(child)
    elif isinstance(value, list):
        for child in value:
            yield from refs(child)


def resolve_pointer(document, pointer: str):
    check(pointer.startswith('#/'), 'Local schema reference: '+pointer)
    result = document
    for part in pointer[2:].split('/'):
        key = part.replace('~1', '/').replace('~0', '~')
        result = result[key]
    return result


def main() -> None:
    required = [
        'README.md','AGENTS.md','CODEX_START.md','MASTER_SPEC.md','STATUS.json',
        'docs/SOURCES.md','docs/DECISIONS.md','docs/12_integration_details.md',
        'tasks/backlog.yaml','contracts/domain.schema.json','contracts/acceptance.schema.json',
        'contracts/openapi.yaml','contracts/schema.sql','contracts/interfaces.py',
        'config/repositories.yaml','config/models.example.yaml','config/policy.example.yaml',
        'config/tools.example.yaml','config/codegraph.example.yaml','contracts/codegraph.schema.json',
        'fixtures/codegraph_result.json','docs/13_codegraph.md','evals/dev_cases.jsonl','reports/HANDOFF.md',
        'docs/14_ecosystem_audit.md','docs/15_ecosystem_integration.md',
        'CODEX_ECOSYSTEM_UPDATE.md','config/ecosystem_candidates.yaml',
        'config/ecosystem_experiments.example.yaml','evals/ecosystem_public_cases.jsonl','tests/test_ecosystem_spec.py',
        'reference/models.py','reference/core.py','tests/test_reference.py',
    ]
    check(all((ROOT/p).is_file() for p in required), 'All required design files exist')
    check((ROOT/'AGENTS.md').stat().st_size < 32768, 'Root AGENTS.md is below 32 KiB')
    for file in ROOT.rglob('*.json'):
        json.loads(file.read_text(encoding='utf-8'))
    for file in ROOT.rglob('*.yaml'):
        yaml.safe_load(file.read_text(encoding='utf-8'))
    checks.append('All JSON/YAML files parsed')
    domain = load_json('contracts/domain.schema.json')
    params = load_json('contracts/acceptance.schema.json')
    for schema in [domain, params, load_json('contracts/codegraph.schema.json')]:
        jsonschema.Draft202012Validator.check_schema(schema)
        for reference in set(refs(schema)):
            resolve_pointer(schema, reference)
    checks.append('Draft-2020-12 domain and acceptance schemas are structurally valid')
    model_fixtures = {
        'goal.json':GoalContract, 'plan.json':Plan, 'citation.json':Citation,
        'decision.json':Decision, 'search_result.json':SearchResult,
        'intent.json':OperationIntent, 'skill_manifest.json':SkillManifest,
    }
    for file, model in model_fixtures.items():
        value=load_json('fixtures/'+file)
        model.model_validate(value)
        jsonschema.Draft202012Validator({'$defs':domain['$defs'], '$ref':'#/$defs/'+model.__name__}).validate(value)
    jsonschema.Draft202012Validator({'$defs': load_json('contracts/codegraph.schema.json')['$defs'], '$ref': '#/$defs/CodeContextResult'}).validate(load_json('fixtures/codegraph_result.json'))
    checks.append('7 original fixtures + 1 CodeGraph synthetic fixture pass validation')
    goal=GoalContract.model_validate(load_json('fixtures/goal.json'))
    for criterion in goal.criteria:
        jsonschema.Draft202012Validator(params['$defs'][criterion.template]).validate(criterion.parameters)
    validate_plan(Plan.model_validate(load_json('fixtures/plan.json')))
    text=(ROOT/'fixtures/source.txt').read_text(encoding='utf-8')
    check(citation_matches(text,Citation.model_validate(load_json('fixtures/citation.json'))),
          'Synthetic Unicode citation hash, span and quote match source.txt')
    api=load_yaml('contracts/openapi.yaml')
    check(api['openapi']=='3.1.0','OpenAPI version is 3.1.0')
    for reference in set(refs(api)):
        resolve_pointer(api,reference)
    for schema in api['components']['schemas'].values():
        jsonschema.Draft202012Validator.check_schema(schema)
    op_ids=[]
    for path, methods in api['paths'].items():
        names=set(re.findall(r'\{([^}]+)\}', path))
        for method,op in methods.items():
            check(method in {'get','post','put','patch','delete','head','options'}, 'Valid HTTP method '+method+' '+path)
            op_ids.append(op['operationId'])
            actual={p['name'] for p in op.get('parameters',[]) if p['in']=='path'}
            check(names==actual,'Path parameters match '+op['operationId'])
            check(any(str(c).startswith('2') for c in op['responses']), 'Success response specified '+op['operationId'])
    check(len(op_ids)==len(set(op_ids)),'All OpenAPI operation IDs unique')
    check(len(op_ids)>=48,'All designed API operation groups represented')
    backlog=load_yaml('tasks/backlog.yaml');tickets=backlog['tickets'];milestones=backlog['milestones']
    check(len(tickets)==73 and len(milestones)==12,'12 milestones and 73 implementation tickets including 3 CodeGraph and 10 ecosystem optional')
    ids={t['id'] for t in tickets}
    check(len(ids)==len(tickets),'All ticket IDs unique')
    edges={t['id']:set(t['depends_on']) for t in tickets}
    for t in tickets:
        check(edges[t['id']]<=ids,'Known ticket dependencies '+t['id'])
        check(all((ROOT/p).is_file() for p in t['spec_files']),'Ticket specification files exist '+t['id'])
        check(bool(t['implementation'] and t['outputs'] and t['acceptance']),'Action, outputs and acceptance specified '+t['id'])
    resolved=set()
    while len(resolved)<len(ids):
        ready={k for k,v in edges.items() if k not in resolved and v<=resolved}
        if not ready:
            raise ValueError('Backlog dependency cycle')
        resolved.update(ready)
    checks.append('Backlog dependency graph is acyclic')
    cases=[json.loads(s) for s in (ROOT/'evals/dev_cases.jsonl').read_text().splitlines() if s.strip()]
    check(len(cases)==73,'73 public development acceptance scenario specifications')
    check({c['ticket_id'] for c in cases}==ids,'Development scenarios cover all ticket IDs')
    check(all(c['split']=='public_development' and c['result_status']=='not_run' for c in cases),
          'Scenario specs explicitly not hidden or already run')
    repos=load_yaml('config/repositories.yaml')['repositories']
    check(len(repos)==23,'23 repository inventory entries')
    check(len({r['id'] for r in repos})==len(repos),'Repository IDs unique')
    shas=[r['source_snapshot_sha'] for r in repos if r.get('source_snapshot_sha')]
    check(len(shas)==2 and all(re.fullmatch(r'[0-9a-f]{40}',s) for s in shas),'Only two observed full source SHAs supplied')
    check(all(r['runtime_lock_status']=='NOT_RESOLVED_OR_TESTED' for r in repos),'Source inventory not disguised as tested runtime lock')
    config=load_yaml('config/models.example.yaml')
    check(not config['providers']['user_provider']['live_enabled'],'Live paid model calls disabled by default')
    check(config['providers']['user_provider']['model_id'] is None,'No fabricated user model ID')
    check(load_yaml('config/policy.example.yaml')['default']=='deny','Policy design defaults deny')
    check(not load_yaml('config/codegraph.example.yaml')['product_enabled'],'CodeGraph feature is disabled by default')
    eco = load_yaml('config/ecosystem_candidates.yaml')['candidates']
    check(len(eco)==81 and len({x['repo'] for x in eco})==80,'81 ecosystem catalog rows / 80 distinct repos')
    check(all(x['production_enabled'] is False and x['immutable_revision'] is None for x in eco), 'No new ecosystem candidate installed or fictitiously pinned')
    ex = load_yaml('config/ecosystem_experiments.example.yaml')
    check(ex['default']=='disabled' and ex['policy']['license_gate_required'], 'Experiments default to disabled with license gate')
    eco_cases=[json.loads(x) for x in (ROOT/'evals/ecosystem_public_cases.jsonl').read_text().splitlines() if x.strip()]
    check(len(eco_cases)==10 and all(x['status']=='not_run' for x in eco_cases),'10 public optional ecosystem experiment cases are not_run')
    suite=unittest.TestLoader().discover(str(ROOT/'tests'))
    check(suite.countTestCases()==84,'84 executable reference/policy test cases discovered (run separately)')
    sql=(ROOT/'contracts/schema.sql').read_text()
    created=re.findall(r'CREATE TABLE (\w+)\s*\(',sql)
    scoped=[x for x in created if x not in ('owners','auth_sessions','projects')]
    check(len(created)==35 and len(scoped)==32,'DDL contains 35 table declarations, 32 project-scoped business tables')
    check(all(f'ALTER TABLE {t} FORCE ROW LEVEL SECURITY;' in sql for t in scoped),'Project table RLS declarations present; not database-tested')
    check(sql.rstrip().endswith('COMMIT;'),'DDL transaction closing marker present; not SQL execution validation')
    check(len(re.findall(r'\| S\d\d \|',(ROOT/'docs/SOURCES.md').read_text()))==49,'49 official-source bibliography entries')
    check('not_implemented'==load_json('STATUS.json')['product_status'],'Product status honestly not implemented')
    print('SPECIFICATION PACK VALIDATION: PASS')
    print(f'{len(checks)} structural checks passed.')
    print(f'{len(api["paths"])} API paths / {len(op_ids)} operations / {len(tickets)} product tickets / 84 reference+policy tests discovered.')
    print('No Docker/PostgreSQL/Temporal/OpenHands/browser/live-model/evaluation integration was run by this script.')
    print('OpenAPI references/schema shapes checked; no full OpenAPI-validator package or PostgreSQL parser was available.')
    print('Recent check groups:')
    for item in checks[-16:]:
        print(' - '+item)

if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        print(f'SPECIFICATION PACK VALIDATION: FAIL: {type(exc).__name__}: {exc}',file=sys.stderr)
        sys.exit(1)

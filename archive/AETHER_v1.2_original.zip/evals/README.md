# Evaluation data boundaries

`dev_cases.jsonl` contains 60 human-readable acceptance scenario specifications. They are not 60 implemented integration tests, not a held-out benchmark, and not 60 independent evidence points for skill promotion. Codex must implement corresponding tests and store actual results separately.

The 64 currently executable reference tests live in tests/test_reference.py. They check pure domain logic, not the 60 product scenarios.

Training and validation task families must be distinct from release families. A genuinely sealed release benchmark is created and held by an independent evaluator outside actor/learner/Codex writable paths; it is not bundled here. Without such evaluation, do not claim superiority over Hermes. A minimum number of families alone does not ensure adequate power; report confidence intervals and insufficient evidence.

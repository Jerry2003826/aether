# AI Agent 系统 · 开源原材料调研与组装方案（总纲）

> **目标**：为「自研一套超越 Hermes Agent（对标 OpenClaw 等 2026 头部系统）的个人 / 产品级 AI Agent 系统」收集可拼装的开源原材料，并给出组装方案。
> **方法**：6 路并行深度调研（①框架内核 ②记忆/RAG ③工具/沙箱 ④模型+可观测+评测 ⑤交互/通道/调度 ⑥安全/基建）+ 1 轮独立深研引擎交叉验证；数据截止 **2026-10-14**；star 数与许可证尽量实测（GitHub API / LICENSE 原文），未能核实处逐条标注。
> **全文结构**：本总纲（第 0 部分）+ 六章分集群详表（第 1–6 部分，合计约 24 万字节）。

## 目录
- **第 0 部分：总纲（本文件）** — 0.1 市场全景 / 0.2 能力面对标表 / 0.3 五层组装架构 / 0.4 差异化路线 / 0.5 许可证红线速查 / 0.6 下一步
- **第 1 部分**：内核与编排框架（含 OpenClaw 专项核查）→ `01-frameworks.md`
- **第 2 部分**：记忆系统与知识库 / RAG → `02-memory-rag.md`
- **第 3 部分**：工具/技能生态与执行环境 → `03-tools-sandbox.md`
- **第 4 部分**：模型接入/路由 + 可观测性 + 评测 → `04-model-obs-eval.md`
- **第 5 部分**：交互层 / 消息通道 / 调度 / 语音 → `05-ux-channels-sched.md`
- **第 6 部分**：安全护栏 / 密钥 / 身份多租户 / 产品化基建 → `06-security-infra.md`

---

## 0.1 2026 市场全景：两超多强

**平台级（整机系统）**：
- **OpenClaw** 是现象级存在——`github.com/openclaw/openclaw`，**392,024★（GitHub API 实测）**、82.4k forks、MIT、TypeScript、2025-11-24 创建、今天仍高频提交、由 OpenClaw Foundation（501c3）托管。更名链：Warelay → CLAWDIS → Clawdbot → Moltbot → **OpenClaw**（2026-01-30）。
- 定位：自托管 agent 运行时 + 消息路由（"operates directly on your local machine"）；里程碑级生态：NanoClaw、ZeroClaw、Moltis、PicoClaw、Nanobot、NullClaw 等衍生项目一整排。
- 采用率：Stack Overflow pulse survey（2026-04 下旬，n≈1,100）显示 **OpenClaw 17%**（LangChain 22%、LangGraph 14%、OpenAI Agents SDK 14%）——传闻属实。
- ⚠️ 风险面：arXiv 已出现针对它的安全分析论文；有供应链事件记录；技能市场（ClawHub）**仅 6.8% 技能经过验证**。

**库级（可嵌入骨架）**：
- **LangGraph** 是生产标准（checkpoint 断点续跑、interrupt 人工审批、图状态机编排，MIT）。
- 同层选手：Pydantic AI、OpenAI Agents SDK、Claude Agent SDK（权限/HITL hooks 系统最值得抄）、Google ADK、AWS Strands、Mastra（TS）、Agno、LangChain DeepAgents 等。

**Hermes Agent 的位置**：第三方对比普遍把 Hermes 与 OpenClaw 视为**同赛道**（社区甚至流行「OpenClaw 当路由层 + Hermes 当执行层」的混合用法）。所以"超越"的参照物 = **OpenClaw（生态与平台广度）+ Hermes（执行与运维深度）**，再加 OpenAI/Anthropic 官方 SDK 的工程范式。

**行业收敛趋势（选型顺着趋势走）**：
1. 图 / 状态机编排 + 断点续跑 = 标配；
2. MCP 成为工具总线（官方 servers 91k★，生态爆炸）；
3. microVM / OS 级沙箱成为执行层基建（Daytona 闭源反而催生 attention）；
4. OpenTelemetry 式可观测 + trace→评测回归闭环；
5. 技能包（SKILL.md 式**渐进披露**）成为能力分发格式（agentskills 开放标准 26k★）；
6. 记忆从"向量 RAG"升级为"图 + 时序 + 遗忘"。

**2026 关键雷区（已发生的事实）**：
- Mem0（67.2k★）2026-04 起**把图记忆收进云平台**，OSS 版勿按旧教程用；
- Letta 主仓库转历史指引，活跃开发迁至 **letta-code**（memory-first harness）；
- **Daytona 2026-06 起闭源**（教训：沙箱后端必须 driver 化）；
- LLM Guard、Rebuff 已归档；HumanLayer 开源代码废弃（转商业）；
- Langfuse 被 ClickHouse 收购（MIT / 自托管承诺不变）；
- AutoGen → **Microsoft Agent Framework**（AutoGen 进维护模式，且其 LICENSE 竟是 CC-BY-4.0，异常）；
- Dify、Open WebUI、Mastra、PurpleLlama、NapCat、wechaty 等均有附加许可条款（见 0.5）。

## 0.2 对标表：能力面 → 推荐原料

| # | 能力面 | 首选 | 备选 / 备注 |
|---|--------|------|-------------|
| 1 | 多模型路由 | **LiteLLM**（61,263★，MIT+ee） | Portkey Gateway、semantic-router |
| 2 | 编排内核 | **LangGraph**（MIT；state/checkpoint/interrupt） | Pydantic AI、OpenAI Agents SDK |
| 3 | 技能系统 | **agentskills 规范**（26,142★ Apache-2.0，三级渐进披露） | anthropics/skills（181k★，部分 source-available） |
| 4 | 长期记忆 | **Graphiti**（31.8k★ Apache-2.0，双时序+官方 MCP） | Mem0（云）；Letta-code 抄上下文工程 |
| 5 | 知识库/RAG | **LightRAG**（40.1k★ MIT） | RAGFlow（92.2k★，重装） |
| 6 | 工具总线 | **MCP 官方 servers**（91k★）+ 网关模式 | Executor（凭证隔离）、IBM ContextForge、mcpo |
| 7 | 调度执行（沙箱） | **microsandbox**（8.7k★ Apache，本地 microVM） | E2B（14.4k★ Apache，云/自托管） |
| 8 | 浏览器/电脑操作 | **Playwright MCP**（38k★）+ **browser-use**（118k★ MIT） | Stagehand、trycua/cua（29.7k★） |
| 9 | 定时/持久 | APScheduler（起步）→ **Restate / DBOS** | Temporal（重）、Windmill |
| 10 | 多通道接入 | **自研薄网关**：NapCat(QQ·自用可)/PTB(TG)/discord.py + outbox | LangBot / AstrBot 参考实现 |
| 11 | 可观测 | **Langfuse**（35.8k★ MIT+ee） | Phoenix（ELv2 非 OSI） |
| 12 | 评测 | **promptfoo**（26k★ MIT）/ DeepEval + **Inspect AI** | Terminal-Bench（已迁 Harbor 生态） |
| 13 | 密钥/审批 | SOPS+age（起步）→ **Infisical** / OpenBao | Executor 式凭证代理、guardrails-ai、OPA |
| 14 | 前端 / 语音 | **Open WebUI**（155.7k★，≤50 人）或 assistant-ui 自研 | LibreChat；语音 pipecat / LiveKit Agents |

## 0.3 推荐组装：五层架构

```
入口层   Web（Open WebUI / LibreChat 或 assistant-ui 自研） · CLI · 消息薄网关
         （QQ/TG/Discord…；去重(channel,msg_id)+幂等(turn_id)+outbox 退避重试）
   ↓
编排层   LangGraph 主图（状态机 + checkpoint 断点续跑 + interrupt 审批）· 事件总线
   ↓
能力层   技能加载器（SKILL.md 渐进披露） · 工具路由（防上下文爆炸） ·
         MCP 网关 + 凭证代理（OAuth broker / 令牌注入：模型与沙箱永不见密钥）
   ↓
资源层   模型网关（LiteLLM + 语义路由） · 记忆（Graphiti 图，search/remember/forget 三工具面） ·
         知识库（LightRAG） · 沙箱（microsandbox → E2B，driver 化） ·
         浏览器（Playwright MCP / browser-use / cua）
   ↓
底座层   存储（Qdrant/pgvector + Neo4j/FalkorDB） · 密钥（SOPS→Infisical） ·
         观测（Langfuse） · 评测回归（promptfoo/Inspect） · 调度（APScheduler→Restate/DBOS）
```

**「四个必抄」设计模式**（跨项目提炼的精华，直接决定产品质感）：
1. **Executor 式 per-tool 策略 + 凭证隔离**——工具授权与密钥不进模型上下文；
2. **agentskills 三级渐进披露**——技能元数据→指令→资源按需加载，省 context 是省钱+省错；
3. **Graphiti 双时序失效式遗忘**——事实带有效期，能"改口"、能"遗忘"，才像真记忆；
4. **Langfuse trace→dataset→评测回归闭环**——真实失败样本自动进回归集，改 prompt/技能必须过回归。
另加两个工程习惯：**沙箱后端 driver 化**（防 Daytona 式断供）；**通道 outbox + 退避重试 + 死信告警**（消息可靠性）。

## 0.4 怎么才算"超越"：差异化路线

诚实说：拼到 80% 功能不难；拼到"稳定 + 好用 + 可持续"很难。可打的差异化点（按杠杆排序）：
1. **记忆做成一等公民**（双时序图 + 主动遗忘 + 睡眠期整理）——行业普遍弱项，OpenClaw 也不强；
2. **执行可信**（沙箱分层 + 凭证永不进上下文 + per-tool 审批 + 全审计）——企业/敏感场景硬需求；
3. **评测驱动的自我进化**（真实失败 → dataset → prompt/技能迭代 → 回归通过才上线）；
4. **中文/中国区通道第一公民**（QQ/微信生态是 OpenClaw 的空白；我们已有 NapCat 实战经验）；
5. **成本工程**（语义路由 + 本地小模型 + 白盒双记账）；
6. **技能生态差异化**：做"已验证/可审计"的技能市场（对标 ClawHub 仅 6.8% 验证率）。

**反建议**：不做"一次性全能桶"。三个阶段推进——
- **M0 单机自用版**：编排(LangGraph) + 模型网关(LiteLLM) + 沙箱(microsandbox) + 一个通道，先跑通替换；
- **M1 扩展**：记忆(Graphiti) + 评测闭环 + 多通道 + 凭证代理；
- **M2 产品化**：身份/多租户 + 计费(Lago/OpenMeter) + 白标前端 + 审计合规。

## 0.5 许可证红线速查（商用闭源视角）

| 类型 | 项目（示例） | 雷点 |
|------|--------------|------|
| **AGPL** | Skyvern、Zitadel v3、Windmill CE、Khoj、Basic Memory、NapCat（自定义）、wechaty、Smithery CLI | 网络服务须开源（或买授权 / 换实现） |
| **非 OSI / 附加条款** | Open WebUI（品牌条款·50 人线）、Dify（多租户受限）、Mastra（ee/）、PurpleLlama（根许可）、LobeHub（附加条款）、Meilisearch（BUSL）、Phoenix（ELv2） | 去品牌 / 多租户 / SaaS 化会踩线 |
| **BSL / SSPL / SUL** | Restate（BSL1.1）、Inngest（SSPL）、n8n 类（SUL） | 禁止托管转售 |
| **安全（MIT / Apache 系）** | LangGraph、LiteLLM*、Graphiti、LightRAG、microsandbox、E2B、browser-use、Playwright MCP、promptfoo、agentskills | *MIT+ee 双子目录：`ee/` 有商业条款 |

> 完整 28 项许可证审核见第 6 章 6.7「许可证红线速查表」。

## 0.6 下一步（等你拍板）

- **A. 起 M0 骨架**：我把 LangGraph + LiteLLM + microsandbox + 一个通道（QQ 或 Telegram）搭成可跑的 v0.1，后续持续往上装；
- **B. 先深读**：比如把第 1 章 OpenClaw 专项 + 首选对比细过一遍，或者先定产品形态再细化选型；
- **C. 需求面聊清楚**：自用 vs 产品、优先市场、预算线——会直接影响 通道 / 多租户 / 许可 三条线。

---

> **附录说明**：随包附《深研引擎交叉快报》（原始文本，含 OpenClaw 生态第三方资料摘要）；六章中所有未核实数据均已在该章节内显式标注（04 章 0 处、01/02 各 1 处、05 章 2 处、06 章 5 处、03 章 8 处）。
> **文件版本**：v1.0 · 2026-10-14 · 材料来源：GitHub 实测 + 官方仓库 + 第三方对比（Langfuse/Splunk/Reddit/ayautomate 等）。


---

# 01 · Agent 内核与编排框架（自研 Agent 系统选型 · 集群一）

> 调研日期：2026-10-14（UTC）｜仅覆盖"内核与编排"，记忆/RAG、工具沙箱、模型路由、通道调度、安全基建分别见 02–06 章节。
>
> **数据口径（先读）**
> - star/许可证/活跃度以 **shields.io 徽章（数据源=GitHub，2026-10-14 当天读取）** 核实，star 一律记"约"。
> - **GitHub API 精确核实 6 个仓库**（全机共享限流内恰好用满 6 次，另做 1 次免费 rate_limit 探测）：`openclaw/openclaw`、`langgenius/dify`、`agent0ai/agent-zero`、`mastra-ai/mastra`、`bytedance/deer-flow`、`microsoft/agent-framework`（表内标 ★）。
> - 许可证凡徽章无法识别者，均**直接读取仓库 LICENSE 原文**复核：Dify、Mastra、Agent-Zero、AutoGen。
> - 参考素材 4 篇全部抓取（Langfuse / Splunk / ayautomate / Reddit）。**Reddit 帖 r/LangChain/1rnc2u9 经 www、old.reddit、Wayback 三路均不可访问（反爬阻断），仅列链接、不计入结论权重。**
> - 所有条目均为 2024 年后仍存活项目；无法核实处显式标注"未核实/第三方口径"。

---

## 0. 总览速查表

| # | 项目 | star（约） | 许可证 | 语言 | 活跃度（最近提交 / 约月提交） | 一句话定位 |
|---|------|-----------|--------|------|------------------------------|-----------|
| 1 | **OpenClaw** ★ | 392k | MIT | TS（+Swift/Rust 组件） | 今天 / ~1.7 万 | 个人常驻 AI 操作员（网关+技能+本地优先） |
| 2 | LangGraph | 43k | MIT | Python（+JS） | 今天 / ~98 | 图/状态机编排内核（生产最广） |
| 3 | LangChain DeepAgents | 30k | MIT | Python | 今天 / ~443 | 官方"深度代理"harness（子代理+文件系统） |
| 4 | OpenHands | 91k | MIT | Python+TS | 今天 / ~345 | 软件工程自治 agent 平台 |
| 5 | Microsoft Agent Framework ★ | 14k | MIT | Python/.NET/Go | 今天 / ~467 | AutoGen+SK 合并继任者（企业级） |
| 6 | AutoGen（旧代） | 61k | ⚠ CC-BY-4.0（原文核实，异常） | Python/.NET | 2026-04 / 0 | 已交棒 MAF，维护模式 |
| 7 | CrewAI | 60k | MIT | Python | 今天 / ~112 | 角色化多代理协作 |
| 8 | OpenAI Agents SDK | 30k | MIT | Python（+JS） | 今天 / ~238 | 轻量 agent 原语（handoff/guardrail） |
| 9 | Claude Agent SDK | 8.3k（Py 仓） | MIT | Python/TS | 今天 / ~71 | Claude Code 内核 SDK 化 |
| 10 | Google ADK | 22k | Apache-2.0 | Python（+Java） | 今天 / ~563 | Google 官方 agent 开发套件 |
| 11 | Pydantic AI | 21k | MIT | Python | 今天 / ~920 | 类型安全 agent 框架 |
| 12 | AWS Strands | 8.8k | Apache-2.0 | Python（+TS） | 今天 / ~285 | 模型驱动轻量 SDK |
| 13 | Mastra ★ | 29k | Apache-2.0 + `ee/` 受限目录 | TypeScript | 今天 / ~1.8k | TS 全栈 agent 框架 |
| 14 | Agno | 43k | Apache-2.0 | Python | 今天 / ~134 | 高性能多代理运行时 + AgentOS |
| 15 | smolagents | 30k | Apache-2.0 | Python | 本月 / ~5（低速） | HF 极简 code-agent |
| 16 | LlamaIndex Workflows | 53k（仓库） | MIT | Python | 今天 / ~31 | 事件驱动 workflow 引擎 |
| 17 | MetaGPT | 71k | MIT | Python | 2026-01 / 0（停滞） | 软件公司 SOP 多角色框架 |
| 18 | CAMEL | 18k | Apache-2.0 | Python | 上周 / ~4 | 多代理角色扮演研究鼻祖 |
| 19 | Agent-Zero ★ | 19k | MIT（原文核实） | Python | 昨天 / ~125 | "给 agent 一台 Linux 电脑" |
| 20 | Eliza（elizaOS） | 20k | MIT | TypeScript | 今天 / ~9.7k | 多渠道社交/加密生态 agent |
| 21 | DeerFlow ★ | 84k | MIT | Python | 今天 / ~859 | ByteDance 长时程 super-agent harness |
| 22 | Dify ★ | 158k | ⚠ Dify 开源许可（修改版 Apache 2.0） | TS+Python | 今天 / ~851 | 低代码 LLM 应用/agent 平台 |
| 23 | Langflow | 156k | MIT | Python+TS | 今天 / ~343 | 可视化 flow 构建器（编译到 LangChain） |

> ⚠ 本集群**未发现 AGPL/SSPL/纯非商业许可**；需显式注意的受限许可只有两个：**Dify**（修改版 Apache 2.0，含多租户 SaaS 限制与品牌条款）与 **Mastra**（核心 Apache-2.0，但 `ee/` 目录为单独的受限许可）。

---

## 1. 【重点专项】OpenClaw 核查报告

### 1.1 结论（先行）

**OpenClaw 真实存在，且是 2026 年最主流的"个人常驻 AI Agent"系统之一**，但严格说它是**应用/平台底座**而非可嵌入的编排库：

- **仓库**：https://github.com/openclaw/openclaw ｜**star 约 392k**（API 精确值 392,024，2026-10-14）、82.4k forks、**107,954 commits**、今天仍在推送、非归档。
- **许可证**：**MIT**（仓库与 API 双重核实）｜**技术栈**：TypeScript（Wikipedia 另标 Swift；仓库含 `crates/` Rust 目录——按"约"解读）。
- **诞生线**：仓库创建于 **2025-11-24**；经 Wikipedia 核实的改名链：**Warelay（2025-11-24）→ CLAWDIS（12-03）→ Clawdbot（2026-01-02）→ Moltbot（01-27）→ OpenClaw（01-30）**；稳定版 2.0（v2026.8.1）发布于 2026-08-30。
- **治理**：由 **OpenClaw Foundation（美国 501(c)(3) 非营利，openclaw.org）** 托管，官方声明"无企业版、无付费版、全 MIT"；捐赠方含 OpenAI、Amazon、Red Hat、密歇根大学等；创始人 Peter Steinberger 现就职 OpenAI，官网明确"OpenClaw 不是 OpenAI 产品"。
- **一句话定位**（官方）："The AI that really does things. Any OS. Any Platform. The lobster way. 🦞"——发消息即用的**跨平台常驻个人 Agent**。

**"17% 采用率"传闻：证实，且找到原始出处**（见 1.3）。

### 1.2 核查过程（证据链，可复核）

1. 关键词检索 → 命中官方仓库、官网 openclaw.ai、文档 docs.openclaw.ai 及多篇第三方评测；
2. 抓取 GitHub 仓库页：392k stars、"The lobster way"、MIT、© OpenClaw Foundation；
3. **GitHub API（1 次额度）**：392,024 stars｜TypeScript｜created 2025-11-24｜pushed 2026-10-14｜fork 82,427｜未归档；
4. 抓取 Wikipedia 条目：改名史、发布线、"截至 2026-03 约 247,000 stars / 47,700 forks（引 Wired）"；
5. 抓取 arXiv 论文 **2603.27517《A Security Analysis of the OpenClaw AI Agent Framework》**（Texas A&M，2026-04）："2026 年 1 月以 OpenClaw 之名重启后数周内超过 20 万 star"；
6. 抓取 Stack Overflow 官方博客（2026-05-27）：**17% 使用 / 32% 想用**（详见 1.3）；
7. 生态面：NVIDIA **NemoClaw**（GTC 2026-03-16 主题演讲发布，黄仁勋原话"每家公司都需要一个 OpenClaw 战略"）、微软 **Scout**（Build 2026-06-02，基于 OpenClaw 的 M365 常驻助手）、腾讯 OpenClaw 产品套件（03-10）、阿里云/Moonshot/小米（第三方统计口径，未独立复验）；
8. 风险面：上述 arXiv 安全分析（WebSocket 各层信任决策分散）、MoltMatch 事故（Wikipedia 条目）、安全厂商事故盘点、ClawHub 技能市场 6.8% 验证率（第三方统计）。

### 1.3 "17% 采用率"传闻：证实 + 精确出处

出处为 **Stack Overflow 官方博客 2026-05-27（pulse survey，2026-04 下旬，n≈1,100 开发者/职场人）**，原文：

> "For **agent frameworks**, LangChain (22%) and LangGraph (14%) are the top tool choices among well-settled tools… Newcomers that show high usage and high interest are **OpenClaw (17% have used, 32% want to use)**, OpenAI Agents SDK (14% have used, 19% want to use) and Terminal Use (15%)…"

同时该调查显示：AI agent 使用率一年内从 31% → 59%，但**"多代理编排"仍属少数派**（日常多代理用户最常用 Claude Code 70%）。

**口径提醒**：这是"使用过的工具"自报题，不是市场份额；且 OpenClaw 与库类框架不在同一维度（SFAI Labs 明确指出其"是独立应用而非可安装库"，因而未进其框架采用指数）。

### 1.4 能力面与架构（docs.openclaw.ai，2026-10-14 读取）

- **Gateway 多通道**：Discord、Google Chat、iMessage、Matrix、Microsoft Teams、Signal、Slack、Telegram、WhatsApp、Zalo 等 + WebChat + 移动节点；"一个 Gateway 同时服务所有通道插件"。
- **架构口号**（官方文档原文）：**"trusted gateway, untrusted execution, deterministic policy"**——受信网关 / 不受信执行 / 确定性策略三层分离。
- **能力面**：Agents（sessions、context、memory、**multi-agent routing**）、Tools / skills / cron / webhooks、**ClawHub 插件市场**（第三方统计：约 5.2 万技能、1.2 万发布者、仅 6.8% 经官方验证）、Control UI 浏览器控制台。
- **数据面**：本地优先——"Your memories. Your skills. Your models. Your machines."；默认不回传数据（仅每日版本检查）。
- **规模**（第三方统计，谨慎引用）：3.2M 月活、3800 万月网站访问（2026-04 口径）。

### 1.5 与 Hermes Agent / OpenHands 的关系

- **与 Hermes Agent**：第三方对比文章（innfactory、openclawvps、Flowtivity、Medium）将两者并列为 2026 两大自托管个人 Agent；共识差异为"OpenClaw 赢在生态规模（技能/通道/企业层），Hermes 赢在自学习与运行成本"；有第三方转述的社区用法是"OpenClaw 做多通道路由层 + Hermes 做执行层"。**本次核查范围内未发现两者代码同源的证据**——属同赛道竞品/潜在互补。对自研系统而言，OpenClaw 是"产品形态对标"的首要对象。
- **与 OpenHands**：**不同赛道，无代码关系**。OpenHands 是面向软件工程的编码 agent 平台（SDK/CLI/GUI/云），OpenClaw 是常驻个人操作员；社区存在组合玩法（把 OpenHands 作为 OpenClaw 可调用的编码执行器）。

### 1.6 能拿它当什么组件 / 能抄什么

1. **三层架构直接抄**：受信网关（通道接入+路由）/ 不受信执行（沙箱内跑工具）/ 确定性策略（权限+审批）——映射到自研的"通道层 / 执行沙箱 / 权限引擎"三件套；
2. **技能生态机制**：skill 打包规范 + ClawHub 式市场（发布/策展/信任分级），自研"能力市场"的最佳对标；
3. **产品化细节**：`openclaw onboard` 引导流、设备配对（pairing）、Control UI、消息通道即 UI 的交互范式；
4. **本地优先数据面**：记忆/技能/模型全在用户侧，作为"个人数据主权"卖点的实现参考（记忆细节归 02 集群）。

### 1.7 集成注意 / 坑

1. **安全是最大雷区**：官方自己承认执行层"untrusted"；已有专门的 arXiv 安全分析、真实事故与供应链事件，技能市场验证率极低（6.8%）——任何参考都要求先有权限/沙箱/审批设计（详见 06 集群）；
2. **体量劝退 fork**：107,954 commits、约 1.7 万 commits/月（徽章口径）、82.4k forks——巨型高速仓库，建议"抄架构不 fork"；
3. **外部政策依赖**：Anthropic 曾专门调整 Claude 订阅内运行 OpenClaw 等第三方 agent 的政策（2026）；企业层（NemoClaw、Scout）均为第三方衍生产品，法务需单独评估。

---

## 2. 图 / 状态机 / 工作流内核组

### 2.1 LangGraph
- **链接**：https://github.com/langchain-ai/langgraph ｜**star**：约 43k（shields 徽章）｜**许可证**：MIT
- **定位**：低层"图 + 共享状态 + superstep"编排运行时，本集群**生产成熟度标杆**（Splunk 2026 评测列为一号位）。
- **技术栈**：Python（另有 JS 版，未单独核实）｜**活跃度**：最近提交=今天；约 98 commits/月
- **当组件/可抄**：① Checkpointer/thread 持久化模型（Postgres/Redis/SQLite）——**断点续跑**直接落库；② `interrupt()` 暂停-恢复机制做 **HITL 审批**；③ time-travel 回放调试。（第三方口径：2026-04 的 v0.4 强化了 state persistence 与 HITL checkpoint）
- **坑**：① 深绑 LangChain 生态（langchain-core 依赖、LangSmith 商业导流）；② 抽象偏底层，消息/状态建模全手写，曲线陡；③ state channel/reducer 心智负担大。

### 2.2 Microsoft Agent Framework（MAF）
- **链接**：https://github.com/microsoft/agent-framework ★｜**star**：约 14k（API 精确 14,129）｜**许可证**：MIT
- **定位**：**AutoGen + Semantic Kernel 的官方合并继任者**（2025-10 发布，2026 已生产级），企业级多代理编排。前代 AutoGen 自 late-2025 进入**维护模式**（见 2.6，官方迁移指南已出）。
- **技术栈**：Python/.NET/Go（Splunk 口径：.NET 版本略领先）｜**活跃度**：最近提交=今天；约 467 commits/月
- **当组件/可抄**：① Workflows 模型：**executors + typed edges + supersteps**（消息传递型工作流，与 LangGraph 的图范式互为镜像，值得对比后择一）；② 事件驱动 actor 内核（继承自 AutoGen）+ 企业治理/telemetry；③ 双语言 SDK 的 API 设计（同一抽象跨 .NET/Python 保持一致）。
- **坑**：① Python 侧成熟度落后 .NET；② Azure/Foundry 世界观（非 Azure 环境收益打折）；③ 公开时间短（2025-10），生态/文档仍在补齐。

### 2.3 Google ADK（Agent Development Kit）
- **链接**：https://github.com/google/adk-python ｜**star**：约 22k｜**许可证**：Apache-2.0
- **定位**：Google 官方 agent 开发套件（含内置评测），A2A（agent-to-agent）互操作协议的主要推动者。2026-02-27 发布 ADK Tools & Integrations 生态（第三方口径）。
- **技术栈**：Python（另有 Java 版，未单独核实）｜**活跃度**：最近提交=今天；约 563 commits/月
- **当组件/可抄**：① v2 的 `google.adk.Context` 统一工具上下文与会话状态隔离（第三方口径）；② 内置 eval 框架（agent 评测思路）；③ **A2A 协议**的互操作设计——自研系统若要对外互联，这是最现成的协议参考。
- **坑**：① GCP/Vertex 亲和（本地模型支持一般）；② 演进极快（2.0 大改，API 稳定性需跟版本）；③ 文档质量参差。

### 2.4 Pydantic AI
- **链接**：https://github.com/pydantic/pydantic-ai ｜**star**：约 21k｜**许可证**：MIT
- **定位**：**类型安全**的 Python agent 框架（"给 GenAI 的 FastAPI 时刻"），2026 年增速最快的框架之一。
- **技术栈**：Python｜**活跃度**：最近提交=今天；**约 920 commits/月（本集群最高之一）**
- **当组件/可抄**：① Pydantic 模型驱动的 tool schema/结构化输出/**依赖注入**——工具调用内核的最干净实现之一；② 自带 `pydantic-graph` 状态机；③ **durable execution 适配层**（对接 Temporal/DBOS 等持久执行引擎，具体清单以官方文档为准）——断点续跑的"外包"路线。
- **坑**：① 相对年轻（2024 起步），生产案例积累少于 LangGraph；② 生态插件少于 LangChain 系；③ 默认推荐自家 Logfire 可观测（选型时被捆绑一层）。

### 2.5 LlamaIndex Workflows
- **链接**：https://github.com/run-llama/llama_index ｜**star**：约 53k（仓库级）｜**许可证**：MIT
- **定位**：**事件驱动** workflow 引擎（steps + events），与 LlamaIndex 检索/索引栈一体，RAG 型 agent 的顺路之选。
- **技术栈**：Python｜**活跃度**：最近提交=今天；仓库级约 31 commits/月（workflow 模块随 core 发版）
- **当组件/可抄**：① "step 之间用事件解耦"——与 LangGraph 图范式不同的另一条**事件流**路线，对照后择一；② 工作流 streaming 事件模型；③ 与检索/数据生态的原生衔接。
- **坑**：① workflows 嵌在巨型 monorepo 里，版本耦合需盯 release；② 生态重心在 RAG/数据而非通用编排；③ 概念层级多（workflow/agent/query engine 易混）。

### 2.6 Microsoft AutoGen（前代，仅作警示条目）
- **链接**：https://github.com/microsoft/autogen ｜**star**：约 61k｜**许可证**：**⚠ LICENSE 原文为 CC-BY-4.0（"Attribution 4.0 International"，与常见代码许可不同，异常需注意；代码子目录或另有条款，未逐一核实）**
- **活跃度**：最近提交 2026-04；近月 0 commits——**官方维护模式**（Langfuse 口径：late-2025 起仅修 bug/安全补丁，社区托管，微软推荐迁移 MAF）
- **结论**：新项目**不要**以 AutoGen 起步；仅作为多代理辩论/群聊（GroupChat）模式的**设计素材**阅读。

---

## 3. 代码优先的轻量 Agent SDK / Harness

### 3.1 OpenAI Agents SDK
- **链接**：https://github.com/openai/openai-agents-python ｜**star**：约 30k｜**许可证**：MIT
- **定位**：极简 agent 原语：**Agents / Handoffs / Guardrails / Sessions / Tracing**，Swarm 的生产化继承者。
- **技术栈**：Python（另有 JS/TS 版，未单独核实）｜**活跃度**：最近提交=今天；约 238 commits/月
- **当组件/可抄**：① **handoff（交接棒）**——多代理协作的最简建模，比图/黑板轻得多；② guardrails 输入输出校验管线（安全旁路设计）；③ 内置 tracing spans 的埋点模型（自建可观测时的对照，观测另见 04 集群）。
- **坑**：① tracing 默认上报 OpenAI 平台，自建须替换 processor；② 抽象少 → 复杂控制流（循环/并行/长任务）要自搭；③ 双语言版本行为存在差异。

### 3.2 Claude Agent SDK
- **链接**：https://github.com/anthropics/claude-agent-sdk-python ｜**star**：约 8.3k（Python 仓）｜**许可证**：MIT
- **定位**：**Claude Code 内核的 SDK 化**：subagents、hooks、权限系统、MCP、context compaction、技能加载。
- **技术栈**：Python（TS 版本以 Claude Code/主仓形态提供，未单独核实）｜**活跃度**：最近提交=今天；约 71 commits/月
- **当组件/可抄**：① **分层权限模型（allow/ask/deny + 沙箱策略）**——HITL 审批的工业级样板，本集群最有价值的"可抄件"之一；② hooks 生命周期注入点（工具前后、会话事件）；③ subagent 隔离上下文 + compaction 策略（长任务上下文管理的现成答案）。
- **坑**：① 与 Claude 模型绑定较深（换模型体验非对称）；② 订阅/AUP 合规敏感（参见 OpenClaw 在 Claude 订阅上的政策风波）；③ Python 版较新，部分能力 TS/CLI 先行。

### 3.3 AWS Strands Agents
- **链接**：https://github.com/strands-agents/sdk-python ｜**star**：约 8.8k｜**许可证**：Apache-2.0
- **定位**：AWS 出品的"**模型驱动**"轻量 agent SDK（让模型自主决定 loop 与工具调用）。
- **技术栈**：Python（另有 TS 版，未单独核实）｜**活跃度**：最近提交=今天；约 285 commits/月
- **当组件/可抄**：① 极简 agent loop 内核（教学/自研内核的干净参考实现）；② 多代理两种拓扑（swarm / graph）的取舍示例；③ 与 Bedrock 的一体化接入方式。
- **坑**：① AWS 亲和；② star/社区规模在本组偏小；③ Python/TS 双实现的特性对齐需自查。

### 3.4 Mastra
- **链接**：https://github.com/mastra-ai/mastra ★｜**star**：约 29k（API 精确 28,824）｜**许可证**：**Apache-2.0（核心）+ `ee/` 目录单独受限许可（源码可见；README 口径：开发/测试可自由使用，生产使用受限——以 `ee/LICENSE` 为准）**
- **定位**：TypeScript 阵营的全栈 agent 框架（workflows + agents + RAG + evals），Gatsby 团队出品。
- **技术栈**：TypeScript（monorepo）｜**活跃度**：最近提交=今天；**约 1.8k commits/月（本集群最高）**
- **当组件/可抄**：① TS 世界观下的 workflow 引擎（step/分支/挂起）设计与 DX；② `mastra dev` 本地 playground 的产品体验；③ 与 Next.js/React 的集成模式。
- **坑**：① **`ee/` 目录为受限许可——生产集成前必须读 `ee/LICENSE`**；② Mastra Cloud 商业线（自托管 vs 云功能差需对照）；③ TS 单栈，跨语言控制面要另设计。

### 3.5 smolagents
- **链接**：https://github.com/huggingface/smolagents ｜**star**：约 30k｜**许可证**：Apache-2.0
- **定位**：HF 出品**极简 code-agent** 框架——LLM 直接写 Python 代码作为动作空间（而非 JSON 工具调用）。
- **技术栈**：Python｜**活跃度**：最近提交=本月内，但**约 5 commits/月——维护节奏明显放缓（选型需注意）**
- **当组件/可抄**：① **CodeAgent 范式**（代码即动作 + 沙箱执行 E2B/Docker）——自研工具内核的另一种范式对照；② 千行级内核的高可读性实现。
- **坑**：① 低活跃；② 代码执行必须自建沙箱（安全归 03/06 集群）；③ 功能面窄，定位教学/轻量。

### 3.6 LangChain DeepAgents
- **链接**：https://github.com/langchain-ai/deepagents ｜**star**：约 30k｜**许可证**：MIT
- **定位**：LangChain 官方"batteries-included"**深度代理 harness**（planning + 子代理 + 文件系统 + 上下文管理），Claude Code 式长任务代理的开源平替路线。
- **技术栈**：Python（构建于 LangGraph 之上）｜**活跃度**：最近提交=今天；约 443 commits/月
- **当组件/可抄**：① 内置 `task` 工具生成**隔离上下文的临时子代理**（长任务/并行任务模式）；② **可插拔文件系统后端**（本地/沙箱/远程）——agent 的"工作目录"抽象；③ 上下文压缩/总结策略。
- **坑**：① 全套 LangChain 栈依赖；② 较新、API 变动快；③ 面向"深度/多步"场景，通用内核仍需 LangGraph。

---

## 4. 多代理协作 / 角色编排

### 4.1 CrewAI
- **链接**：https://github.com/crewAIInc/crewAI ｜**star**：约 60k｜**许可证**：MIT（企业版为商业产品线）
- **定位**：**角色化多代理**协作框架（Crews=自治协作 / Flows=确定性工作流），多代理原型上手最快之一。
- **技术栈**：Python｜**活跃度**：最近提交=今天；约 112 commits/月
- **当组件/可抄**：① role/goal/backstory 的**prompt 编排模板**（人设即配置）；② "自治 Crews + 确定性 Flows"双模式的产品设计；③ 任务委派/层级流程（manager agent）模式。
- **坑**：① 早期自治循环不可控，生产要切 Flows 补确定性；② 持久化/HITL 较弱需自补（2026 有改进但非强项）；③ 企业版商业线分界需读清。

### 4.2 Agno
- **链接**：https://github.com/agno-agi/agno ｜**star**：约 43k｜**许可证**：Apache-2.0
- **定位**：高性能轻量多代理运行时 + **AgentOS 控制面**（sessions/memory/knowledge 一套 API，可自托管 UI）。
- **技术栈**：Python｜**活跃度**：最近提交=今天；约 134 commits/月
- **当组件/可抄**：① Agent/Team 极简抽象与低开销实例化（以性能为核心卖点，属厂商口径，需自测）；② 控制面（AgentOS）思路——"运行时 + 管理面"的分层；③ 多模态 agent 原语。
- **坑**：① 迭代激进、历史上有 breaking change（v1→v2 大改）；② 营销声量大，生产案例需自行验证；③ 库 + 云平台混合模式。

### 4.3 MetaGPT
- **链接**：https://github.com/FoundationAgents/MetaGPT ｜**star**：约 71k｜**许可证**：MIT
- **定位**：**"软件公司 SOP"**多角色框架（PM/架构/开发/测试顺序协作），学术明星项目。
- **活跃度**：最近提交 2026-01；近月 0 commits——**基本停滞（慎作依赖）**。
- **可抄**：SOP 化的多角色 prompt 流水线、结构化产物（PRD/设计/代码）交接设计。
- **坑**：已不适合作为活跃依赖；代码可作教学素材。

### 4.4 CAMEL
- **链接**：https://github.com/camel-ai/camel ｜**star**：约 18k｜**许可证**：Apache-2.0
- **定位**：最早的多代理**角色扮演/协作研究框架**（2023 起），大规模 agent society 数据生成。
- **活跃度**：最近提交=上周；约 4 commits/月（低强度维护）。
- **可抄**：role-playing 协议、agent 社会模拟、工具/记忆抽象的研究实现。
- **坑**：研究导向，生产设施少；节奏放缓。

### 4.5 Eliza（elizaOS / 原 ai16z）
- **链接**：https://github.com/elizaOS/eliza ｜**star**：约 20k｜**许可证**：MIT
- **定位**：多渠道社交/加密生态 agent 框架（character 人设文件 + 插件体系 + 海量 connector）。
- **技术栈**：TypeScript｜**活跃度**：最近提交=今天；**约 9.7k commits/月（极高，=高速迭代风险）**
- **可抄**：① **character 文件=人设即配置**的产品化思路；② 多渠道 connector 矩阵的工程组织；③ 社区代币化运营（如果做社区产品）。
- **坑**：① 加密语境重（治理/资金波动）；② 框架层频繁重构（breaking 风险高）；③ 与本集群其他框架定位差异大，选型勿混。

---

## 5. 自治常驻 Agent 运行时与平台

### 5.1 OpenHands
- **链接**：https://github.com/OpenHands/OpenHands ｜**star**：约 91k｜**许可证**：MIT
- **定位**：**软件工程自治 agent 平台**（SDK/CLI/本地 GUI/云），"事件流 + 沙箱运行时"架构的代表（原 All-Hands-AI，组织已改名 OpenHands）。
- **技术栈**：Python + TypeScript｜**活跃度**：最近提交=今天；约 345 commits/月
- **当组件/可抄**：① **Event Stream 架构**——一切交互皆事件，可审计/可回放（自研事件流内核的最好样板）；② **agent server（REST/WS）与沙箱 runtime 分离**：执行在容器里、控制面在外；③ HITL/确认模式与权限设计。
- **坑**：① 定位是编码 agent，通用任务需改造；② 组件多（前端/后端/runtime），集成面大；③ 版本迭代快（经历过大重构）。

### 5.2 Agent-Zero
- **链接**：https://github.com/agent0ai/agent-zero ★｜**star**：约 19k（API 精确 19,474）｜**许可证**：**MIT（LICENSE 原文核实，Copyright 2025 Agent Zero, s.r.o）**
- **定位**："**给 agent 一台完整 Linux 电脑**"的自治框架（内置 Web UI、Docker 运行时、多 agent 上下级协作）。
- **技术栈**：Python｜**活跃度**：最近提交=昨天；约 125 commits/月
- **当组件/可抄**：① **agent 层级制**（上级 agent 派生下级，上下文隔离）；② 容器化执行环境 + Web 控制台的开箱组合；③ prompts 可编辑（prompts 目录即行为配置）。
- **坑**：① 设计上全权限，安全边界必须自建；② 小团队/公司维护（19k star 量级）；③ Python 单栈。

### 5.3 DeerFlow
- **链接**：https://github.com/bytedance/deer-flow ★｜**star**：约 84k（API 精确 83,868）｜**许可证**：MIT
- **定位**：ByteDance 开源的**长时程 super-agent harness**（深度研究 → 报告/代码/多媒体交付），2026-02-27 开源 2.0。
- **技术栈**：Python（基于 LangGraph，第三方口径）｜**活跃度**：最近提交=今天；约 859 commits/月
- **当组件/可抄**：① 长时程任务的"计划-执行-反思"编排（研究型 agent 的完整范例）；② **StreamEvents 协议 + headless CLI**（`deerflow --json`，可嵌入自家 UI 的流式事件口）；③ 工具矩阵（搜索/爬虫/代码执行）编排。
- **坑**：① 重度 LangGraph 依赖（换内核成本高）；② 定位偏"深度研究/报告"垂直场景；③ 大厂项目治理（roadmap 受组织影响）。

### 5.4 Dify
- **链接**：https://github.com/langgenius/dify ★｜**star**：约 158k（API 精确 158,486）｜**许可证**：**⚠ "Dify 开源许可"= 修改版 Apache 2.0 + 限制条款**（LICENSE 原文核实；要点：未经授权**不得用于多租户 SaaS**、不得移除/修改品牌标识——细节以 LICENSE 为准）
- **定位**：可视化 LLM 应用/agent 平台（低代码 workflow + RAG + 插件市场 + API 后端）。
- **技术栈**：Python 后端 + TypeScript 前端（GitHub 主语言标 TS）｜**活跃度**：最近提交=今天；约 851 commits/月
- **当组件/可抄**：① **workflow DSL / 编排 UX**（画布 → 可版本化配置）；② 插件市场与"应用即 API"的后端设计；③ 运营/观测后台（日志、标注）的产品形态。
- **坑**：① **许可证限制是硬约束**（拿其做多租户 SaaS 需商业授权）；② 平台属性强，作为"内核"嵌入困难；③ 社区版 vs 云版功能差。

### 5.5 Langflow
- **链接**：https://github.com/langflow-ai/langflow ｜**star**：约 156k｜**许可证**：MIT
- **定位**：可视化拖拽 flow 构建器（编译为 LangChain Python 代码），DataStax 维护。
- **技术栈**：Python + TypeScript｜**活跃度**：最近提交=今天；约 343 commits/月
- **当组件/可抄**：① "可视化编排 → 导出代码"的 UX（比纯 DSL 更亲民）；② 组件库的组织方式。
- **坑**：① 与 LangChain 版本强耦合；② 产品重心在低代码 IDE，自研内核用不上其运行时；③ 云商业化（DataStax）。

---

## 6. 本集群首选 + 备选

### 6.1 首选（唯一骨架级推荐）：**LangGraph**
核心理由（对应考察五维）：**工具调用内核**（任何模型/工具可接）｜**状态机/事件流**（图+superstep，最成熟）｜**HITL 审批**（`interrupt()` 原生）｜**断点续跑**（checkpointer 工业级）｜**多代理**（子图/supervisor 模式齐备）；MIT 无限制、43k star、高活跃。生产成熟度在本集群无出其右。

### 6.2 备选（按场景，与首选组合使用）

| 备选 | 适用场景 |
|------|---------|
| **Pydantic AI** | 想要"类型安全 + 依赖注入"的执行层，或把持久化外包给 Temporal/DBOS 的 durable execution 路线（920 commits/月，增速之王） |
| **OpenAI Agents SDK** | 最快落地、需要 handoffs/guardrails 原语与开箱 tracing；可作 LangGraph 内的"单 agent 执行体" |
| **Claude Agent SDK** | 以 Claude 为主的栈；其**权限/HITL hooks 模型**建议即使不选也照抄 |
| **Microsoft Agent Framework** | .NET/企业/Azure 场景；executors+typed-edges 工作流与 LangGraph 二选一 |
| **OpenHands** | 需要"编码 agent"能力直接嵌入（事件流 + 沙箱 runtime 平台） |
| **Mastra** | 全 TS 栈产品（注意 `ee/` 许可） |
| **DeerFlow** | 起点就是"长时程研究/报告"类 agent（省一轮自研编排） |

**明确不建议作内核**：CrewAI（适合多代理原型，不做底层）、MetaGPT（停滞）、smolagents（低速维护）、AutoGen（维护模式）、Dify/Langflow（平台而非内核；Dify 另有许可证硬约束）、Eliza/CAMEL（定位/维护差异）、Agno（可作快原型，breaking 风险自评）。

### 6.3 "抄作业"映射（自研模块 ← 借鉴对象）

| 自研模块 | 借鉴 |
|---------|------|
| 状态机/持久化/断点续跑 | LangGraph checkpointer + interrupt |
| 事件流与审计回放 | OpenHands Event Stream；DeerFlow StreamEvents |
| HITL 审批与权限 | Claude Agent SDK 权限模型 + hooks；MS AF 企业治理 |
| 工具内核 | Pydantic AI（类型安全）/ smolagents（code-agent 范式对照） |
| 多代理协作 | DeepAgents 子代理隔离；OpenAI SDK handoffs；Agent-Zero 层级制 |
| 网关/通道/技能生态/产品形态 | **OpenClaw**（见第 1 节） |
| 长任务上下文管理 | Claude Agent SDK compaction；DeepAgents 文件系统抽象 |

### 6.4 数据可信度分级（防误用）

- **精确级**（GitHub API，6 次额度内）：OpenClaw、Dify、Agent-Zero、Mastra、DeerFlow、MAF 的 star/语言/时间戳；Dify/Mastra/Agent-Zero/AutoGen 的 LICENSE 原文。
- **实时级**（shields 徽章，数据源=GitHub，当天）：全部 23 条的 star/最近提交/月提交/许可证（star 记"约"）。
- **第三方口径**（未独立复验，引用时保留原标注）：NemoClaw/Scout 细节、ClawHub 技能数、OpenClaw MAU、ADK 生态发布、"v0.4"等版本细节。
- **不可用**：Reddit 帖 r/LangChain/1rnc2u9（反爬阻断，三路重试失败）。


---

# 02 · 记忆系统与知识库 / RAG 集群（开源原材料调研）

> **范围**：长期记忆层、RAG/知识引擎、向量/图谱/检索存储。服务于「自研个人/产品级 AI Agent 系统」的选型与"抄作业"。
> **边界**：本文件不涉及 agent 框架/编排（01）、工具与沙箱（03）、模型/可观测（04）、交互/调度（05）、安全/基建（06）。
> **核实时间**：2026-10-14 UTC（10-15 澳东）。**数据口径**：star 为 GitHub 仓库页精确值（与 API 抽查一致），最后提交来自 `commits.atom`，发版来自 `releases.atom`；许可证读自仓库 LICENSE 原文；个别第三方信息已标注来源。详见附录 C。
> **图例**：🔒 = 许可证有限制性条款；📉 = 停更/归档；✅ = 已核实；🟡 = 未完全核实。

---

## 0. 结论速览（TL;DR）

- **记忆层首选（图 + 本地 + 低耦合）**：**Graphiti**（Apache-2.0，自带 MCP server，双时序知识图谱，Zep 的开源引擎）＋ **Neo4j CE**（GPL-3.0）或 **FalkorDB**（SSPL-1.0，注意条款）作图后端。
- **最值得"抄"上下文工程**：**Letta / letta-code**（可自编辑 memory blocks、git 化记忆仓库 MemFS、`/sleeptime` 空闲期整理）——但它是完整 harness，整机接入 = 高耦合，抄设计 > 用产品。
- **知识库**：轻量本地选 **LightRAG**（MIT，双级检索＋存储可插拔，全本地可跑）；文档解析、引用溯源、MCP 双向能力抄 **RAGFlow**（Apache-2.0，92k★，但基础设施重）。
- **存储三件套**：向量 **Qdrant / pgvector / LanceDB** 三选一；图 **Neo4j CE / FalkorDB**；全文/混合 **Meilisearch**（注意 EE 部分 BUSL）或 Postgres FTS。
- **明确排除/别踩**：Kuzu（📉已归档）、R2R（📉公司转型后停更）、memary / memobase / A-mem（停更或研究代码）、**Mem0 的 OSS 图记忆与本地 MCP 路径（2026 已被移除，勿按旧教程部署）**。
- **三个最大的长期坑**：① LLM 抽取是持续性成本（每条新信息都要过模型）；② 图库（Neo4j/FalkorDB）运维与许可；③ 「OSS 与云版功能剪刀差」——Mem0、Letta、Zep、Supermemory 都在把图记忆/托管能力往商业版迁移。

---

## 1. 记忆层（Memory）

### 1.1 Graphiti ⭐31.8k 【首选：图记忆引擎】
- **链接｜定位**：https://github.com/getzep/graphiti ｜ "Build Real-Time Knowledge Graphs for AI Agents"。Zep 背后的开源时序知识图谱引擎，专为 agent 记忆设计。
- **数据**：⭐31,754（10-14 核实）｜fork 3,267｜Apache-2.0｜Python｜最后提交 **2026-10-14（当日）**，最后发版 2026-09-08（持续高频）。
- **机制**：**写入**=把对话/文档作为 episode 增量摄入，LLM 抽取实体与关系边；**召回**=语义搜索＋BM25＋图遍历混合（含重排）；**更新**=新边令旧边 `invalid_at` 失效；**遗忘**=双时序失效（不物理删除）：每条边带 `valid_at / invalid_at`，可回答"当时是什么"。
- **可当组件/可抄**：官方仓库自带 **MCP server**（`mcp_server/` 目录）+ REST（需自建服务层）；抄：双时序"失效式遗忘"、episode 化增量摄入、混合检索配置（semantic + BM25 + graph）。
- **集成坑**：每个 episode 都要 LLM 抽取（用本地小模型可降本）；图后端运维；**Kuzu 后端已弃用（0.11.2 deprecated）**，官方支持 Neo4j 5.26 / FalkorDB 1.1.2 / Amazon Neptune（＋OpenSearch Serverless 作全文检索）；图库许可见 3.x 节。

### 1.2 Mem0 ⭐67.2k 【可选：抄"抽取-判定"管线；OSS 图记忆已砍】
- **链接｜定位**：https://github.com/mem0ai/mem0 ｜ "The Memory Layer for AI Agents"，事实抽取式记忆的标杆与流量最大的记忆项目。
- **数据**：⭐67,195（10-14 核实）｜fork 7,909｜Apache-2.0｜Python + TypeScript｜最后提交 **2026-10-14（当日）**，最后发版 2026-09-25。
- **机制**：**写入**=LLM 从消息中抽取事实，再与已有记忆比对做 ADD/UPDATE/DELETE/NOOP 决策；**召回**=向量检索＋元数据过滤；**遗忘**=判定为 DELETE 或不再召回。
- **⚠️ 关键变化（2026）**：① 2026-04「New Memory Algorithm」后，**图记忆（Neo4j/Memgraph/Kuzu/AGE/Neptune 驱动，约 4k 行代码）已从 OSS SDK 移除**——图记忆成为 Mem0 Platform（云）专属功能（官方迁移文档 oss-v2-to-v3 明示）；② 本地 MCP 栈 OpenMemory 据第三方梳理已在 2026-07 从 monorepo 删除、独立 `mem0-mcp` 仓库 2026-03 归档，`mem0ai/openmemory` 同名仓库已转为其它产品（98★）；③ 官方 MCP 入口现为**托管云服务**。
- **可当组件/可抄**：OSS 库（`pip install mem0ai`）+ 自托管 Server（monorepo `server/`，`make bootstrap` 起栈，默认开鉴权）；抄：抽取-判定的 prompt 设计、记忆排序/去重策略、LOCOMO 评测方法。
- **集成坑**：想本地 MCP 低耦合接入 → 官方路径已不提供（需自行封装 SDK）；图关系需自带图库（官方 Workaround：Mem0 + Neo4j 自行桥接）；云端功能与 OSS 剪刀差持续扩大。

### 1.3 Zep（名称澄清）⭐5.0k
- **链接**：https://github.com/getzep/zep
- **现状**：该仓库**已不是产品仓库**——README 原文："This repository is **not** Zep's product or service. It contains example code, framework integrations, and tools"（示例/集成集合，⭐4,959，10-14 仍在更新）。Zep 社区版服务器已退役；**开源侧看 Graphiti**，产品侧是 Zep Cloud（商业，自家"Context Graph Engine"专有图库，无需第三方图数据库）。
- **结论**：选型时不要对 `getzep/zep` 抱期待；开源即 Graphiti，托管即 Zep Cloud。

### 1.4 Cognee ⭐32.3k 【可选：pipeline 化记忆平台】
- **链接｜定位**：https://github.com/topoteretes/cognee ｜ "open-source AI memory platform for agents"，主打 ECL（extract→cognify→load）记忆管线 + 图/向量混合。
- **数据**：⭐32,293（10-14 核实）｜fork 3,365｜Apache-2.0｜Python｜最后提交 **2026-10-14（当日）**，发版 2026-10-13。
- **机制**：写入=管线化抽取与"认知化"（建图+建索引）；召回=图+向量检索；更新=重跑管线/追加数据集。
- **可当组件/可抄**：官方 **MCP server（cognee-mcp/）** ✅；集成多个框架；自述支持"小模型免费本地化"（用本地小模型跑记忆管线，看重成本者可抄这条路线）；抄：管线化记忆构建、ontology/数据集概念。
- **集成坑**：项目迭代快、API 变动频繁；体量与生态位与 Graphiti 有重叠，二选一即可。

### 1.5 Letta / letta-code ⭐25.1k（旧仓）/ 3.6k（新仓）【抄上下文工程，不整机接】
- **链接**：https://github.com/letta-ai/letta（MemGPT 正统仓库，现为历史/指引）｜活跃开发：https://github.com/letta-ai/letta-code
- **现状（重要）**：旧仓 README 明示"current source code lives in `letta-ai/letta-code`"，旧 V1 API server 已移入 `archive` 分支退役；旧仓最后提交 2026-09-10（docs 类）、最近发版 2026-05，事实上转入维护状态。
- **新形态**：letta-code（⭐3,612，Apache-2.0，最后提交 10-14，npm `@letta-ai/letta-code`）= "memory-first" agent harness：**memory blocks**（自我改写上下文/系统提示词学习）、**MemFS**（所有上下文含记忆块用 **git 版本化**，可同步 GitHub 仓库）、`/sleeptime`（空闲"做梦"整理）、跨会话/跨 agent 消息搜索、skills、subagents、channels（Telegram/Slack/Discord）、hooks、crons、BYO 模型。研究线：Sleep-time Compute（2025-04）、Context Constitution（2026-04）、Memory Models（2026-06）。
- **可当组件/可抄**：上下文工程最佳范本：① 自编辑记忆块 + token 预算；② 记忆的 git 化（可审计、可回滚、可迁移）；③ 空闲期整合（sleep-time）；④ "记忆不是插件，是 harness 职责"的设计立场（其官方 blog 观点）。
- **集成坑**：它是 harness/运行时，整机接入=替换你的主循环（高耦合）；无独立"记忆库"包可用；作为服务（App Server/SDK）接入需接受其体系。

### 1.6 MemOS ⭐11.9k 【可选：OS 式记忆调度】
- **链接｜定位**：https://github.com/MemTensor/MemOS ｜ "Self-evolving memory OS"，MemCube 记忆单元 + 调度（记忆编排/混合检索/跨任务技能复用；自述 token 节省 35%+）。
- **数据**：⭐11,863（10-14 核实）｜Apache-2.0｜Python｜最后提交 2026-09-22，发版 2026-09-23。
- **可当组件/可抄**：**官方 MCP 服务** ✅（`@memtensor/memos-api-mcp`，npm，支持托管/自部署两种）；本地 Server API（`src/memos/api/server_api.py`，默认 8001 端口）；抄：MemCube 抽象、记忆调度思想。
- **集成坑**：生态画布很大（插件/平台双线），版本迭代快；MCP 包默认连官方 API，纯本地要自行部署 Server API。

### 1.7 Supermemory ⭐31.2k 【可选：本地优先的"记忆+上下文引擎"】
- **链接｜定位**：https://github.com/supermemoryai/supermemory ｜ "Memory and context engine + app"，自述"extremely fast, scalable, and can be run fully locally"。
- **数据**：⭐31,228（10-14 核实）｜MIT｜TypeScript｜最后提交 **2026-10-14（当日）**，发版 2026-10-12（活跃度极高）。
- **可当组件/可抄**：MCP server + 各家编码 agent 插件（Claude Code/Codex/Cursor/OpenCode 等）✅；面向"给任何 assistant 加持久记忆"的产品化路径；抄：插件化分发、profile 与遗忘/管理 API 设计。
- **集成坑**：默认形态偏托管（第三方梳理指其云基于 CF Workers，自托管为可选路径 🟡细节需查文档）；MIT 友好。

### 1.8 Basic Memory ⭐4.2k 【轻量首选：Markdown 派】🔒
- **链接｜定位**：https://github.com/basicmachines-co/basic-memory ｜ 本地 Markdown 文件为"真源"＋SQLite 索引＋MCP 服务，人机双写知识图谱。
- **数据**：⭐4,190（10-14 核实）｜**AGPL-3.0 🔒（强 copyleft，商用/闭源分发需评估）**｜Python｜最后提交 **2026-10-14（当日）**。
- **可当组件/可抄**：**MCP 原生**（38 处 MCP 引用，注册于 MCP Registry）✅；抄："Markdown 文件=记忆真源、DB 只是索引"的架构（可迁移、可人工编辑、与 Obsidian 生态天然兼容）、实体-观测-关系组织。
- **集成坑**：AGPL；能力上限在"人工可读记忆"，非海量自动化抽取。

### 1.9 Redis Agent Memory Server ⭐0.3k 【可选：服务化记忆】
- **链接**：https://github.com/redis/agent-memory-server ｜ Redis 官方出品的"工作记忆（短期）+长期记忆"服务，REST 接口。
- **数据**：⭐322（10-14 核实）｜**Apache-2.0**（LICENSE 原文核实：Copyright 2025 Redis，Apache-2.0）｜Python｜最后提交 2026-09-15。
- **可当组件/可抄**：后台记忆服务形态（低耦合）；抄：把记忆做成独立微服务 + Redis 存储的工程法。🟡 MCP 支持未核实。
- **集成坑**：项目小、需要 Redis 依赖；生态影响力有限。

### 1.10 LangMem ⭐1.7k 【参考：抄 API 设计】
- **链接｜定位**：https://github.com/langchain-ai/langmem ｜ LangChain 官方记忆 SDK：语义/情节/程序性三类记忆 + 提示词优化（procedural）。
- **数据**：⭐1,703（10-14 核实）｜MIT｜Python｜最后提交 2026-10-02。
- **可当组件/可抄**：抄其"记忆类型学"（semantic/episodic/procedural）和后台记忆管理器设计——对自研系统的记忆分类很有参考价值。
- **集成坑**：与 LangGraph 的 Store/长期记忆 API 绑定较深，脱离 LangGraph 需自行移植；项目体量小（是 SDK 非平台）。

### 1.11 其他记忆候选（简评）
- **MemoryOS（BAI-LAB）** ⭐1.6k：https://github.com/BAI-LAB/MemoryOS ｜EMNLP 2025 Oral，短/中/长期三层记忆与热度更新，Apache-2.0，最后提交 2026-07-07（研究代码，参考算法）。
- **HippoRAG（OSU-NLP）** ⭐4.1k：https://github.com/OSU-NLP-Group/HippoRAG ｜NeurIPS'24 + **HippoRAG 2（ICML'25）**，"RAG to Memory"，个性化 PageRank 多跳召回，MIT，最后提交 2026-10-06（活跃研究项目，抄检索算法；见 §2.8）。
- **engram 系列**：名称有多个同名项目（含一个非常活跃的 Go 实现），见附录 B 专述。

---

## 2. 知识 / RAG 层

### 2.1 RAGFlow ⭐92.2k 【首选：重装全功能；抄解析与引用】
- **链接｜定位**：https://github.com/infiniflow/ragflow ｜ 深度文档理解 RAG 引擎，"RAG + Agent"一体化上下文层。
- **数据**：⭐**92,231**（10-14 核实）｜fork 10,986｜Apache-2.0｜**Python + Go（API/MCP 服务已由 Go 实现；GitHub 主语言标注为 Go）**｜最后提交 **2026-10-14（当日）**，发版通道活跃（含 nightly 通道，当日有更新）。
- **能力**：DeepDoc 解析（OCR/版面/表格）、模板化切块、GraphRAG、引用溯源、Agent 工作流与 MCP **双向**支持（既可当 MCP server 暴露检索工具，也可作为 MCP client 连接外部工具）✅。
- **可当组件/可抄**：私有知识库的现成完整产品；抄：文档解析管线、切块模板、引用锚定、"Go API server + MCP endpoint（streamable-HTTP `/mcp`）"的工程化方式。
- **集成坑**：基础设施重——默认栈 = Elasticsearch（或 Infinity）＋MySQL＋Redis＋MinIO，docker compose 全套（经验量级 4-8GB+ 内存，换 Infinity 降低）；UI/产品导向，二次开发成本高于库级方案。

### 2.2 LightRAG ⭐40.1k 【首选：轻量图 RAG；全本地可跑】
- **链接｜定位**：https://github.com/HKUDS/LightRAG ｜（EMNLP 2025）"Simple and Fast Retrieval-Augmented Generation"，轻量图 RAG 的代表。
- **数据**：⭐40,136（10-14 核实）｜fork 5,697｜MIT｜Python｜最后提交 **2026-10-14（当日）**，发版 2026-09-02。
- **能力**：local/global 双级检索、增量插入、**存储可插拔**（图：NetworkX/Neo4j 等；向量：多后端/文件 KV）、官方 Server（WebUI 管理台 `/webui` + 只读移动端 `/workspace`）、Ollama 本地模型支持。
- **可当组件/可抄**：**整架构都可抄**——"实体/关系抽取 → 图 + 向量双写 → 双级检索"是最适合自研系统内嵌的图 RAG 范式；零外部依赖模式（文件存储）适合单机。
- **集成坑**：**未见官方内置 MCP server**（仓库中无 mcp 目录，README 未提；社区有 npm/PyPI 第三方适配器）；图质量依赖抽取用 LLM 的能力；官方 REST API 可自行接主循环。

### 2.3 Microsoft GraphRAG ⭐36.3k 【可选：方法论源头】
- **链接**：https://github.com/microsoft/graphrag ｜ MIT｜Python｜⭐36,338，最后提交 2026-10-08。
- **能力**：社区检测 + 分层摘要（global search）、local search；索引期成本高（大量 LLM 调用），后续 LazyGraphRAG 大幅降本。
- **可当组件/可抄**：抄"社区摘要层级"设计（回答全局性问题）；生产内嵌成本高，一般借鉴思路而非直接用。
- **集成坑**：索引贵、pipeline（parquet 等）工程复杂度高、本地模型上跑得慢。

### 2.4 LlamaIndex ⭐52.5k 【框架-可选】
- **链接**：https://github.com/run-llama/llama_index ｜ MIT｜Python/TS｜⭐52,500，最后提交 10-14（当日）。
- **现状**：自我定位已转向 "document processing platform for AI"（LlamaCloud 商业服务）。
- **可当组件/可抄**：摄取管线（Ingestion Pipeline）、属性图索引、记忆/聊天存储抽象——抄接口设计与管线思想；不一定要用框架。
- **集成坑**：框架税、历史 API 变动多；与自研主循环是"二选一"级的关系（若只是要 RAG 零件，LightRAG/RAGFlow 更直接）。

### 2.5 Haystack ⭐26.7k 【框架-可选】
- **链接**：https://github.com/deepset-ai/haystack ｜ Apache-2.0｜Python｜⭐26,741，最后提交 10-14（当日）。
- **定位**：deepset 的生产级"context-engineered"管线框架（组件化 DAG）。
- **可当组件/可抄**：组件契约、评测体系；比 LlamaIndex 更偏"检索系统工厂"。
- **集成坑**：agent 侧能力薄（本集群无关）；生态增长趋缓。

### 2.6 txtai ⭐13.0k 【可选：嵌入式全家桶】
- **链接**：https://github.com/neuml/txtai ｜ Apache-2.0｜Python｜⭐13,019，最后提交 10-14（当日）。
- **定位**：all-in-one 嵌入检索框架（embeddings DB + LLM 编排 + workflows）。
- **适合**：想用纯 Python 快速搭本地语义检索、又不想引入独立服务；抄其"索引+管线一体"的 API 简洁性。
- **坑**：单机路线，非分布式；自带生态与主流割裂。

### 2.7 Khoj ⭐37.7k 【可选：自托管个人 AI 应用】🔒
- **链接**：https://github.com/khoj-ai/khoj ｜ **AGPL-3.0 🔒**｜Python(Django)+TS｜⭐37,686，最后提交 2026-08-02（近 2.5 个月无提交 ⚠️）。
- **定位**：可自托管的"第二大脑"应用（语义检索个人笔记/文档/网页、自动研究、定时任务）。
- **可当组件/可抄**：个人数据连接器（Obsidian/Notion/PDF 等）与"搜索+对话"产品形态；**应用而非库**，抄能力不如抄连接器矩阵。
- **坑**：AGPL；近期放缓。

### 2.8 HippoRAG 2 ⭐4.1k 【参考：检索算法】
- **链接**：https://github.com/OSU-NLP-Group/HippoRAG ｜ MIT｜Python｜⭐4,062，最后提交 2026-10-06。
- **定位**：类海马体长时记忆框架（NeurIPS'24 HippoRAG → ICML'25 HippoRAG 2），**个性化 PageRank（PPR）** 做多跳检索；官方称离线索引成本显著低于 GraphRAG/LightRAG。
- **可抄**：PPR 召回算法、"RAG→显式记忆"的评估维度（关联性/情节/事实）。
- **坑**：研究代码质量，生产化需重写。

### 2.9 R2R ⭐8.0k 【📉 排除：停更】
- **链接**：https://github.com/SciPhi-AI/R2R ｜ MIT｜Python｜⭐8,019，**最后提交 2025-11-07（已停更约 11 个月）**。
- **背景**：原公司 SciPhi 已转型（YC 资料显示其沿革指向 Event Horizon Labs），云服务关闭，仓库仅存代码。
- **参考价值**：REST 化 RAG 引擎的 API 设计（collections/documents/hybrid search）；**新项目勿采用**。

### 2.10 nano-graphrag ⭐4.0k 【参考：最小实现】
- **链接**：https://github.com/gusye1234/nano-graphrag ｜ MIT｜Python｜⭐4,001，最后提交 2026-01-27（半停更）。
- **价值**：约千行级的最简 GraphRAG 实现，**想把图 RAG 内嵌进自研系统时，直接以它为底改写是最低成本路线**。
- **坑**：半停更、功能面窄。

---

## 3. 向量 / 图谱 / 检索存储

### 3.1 Qdrant ⭐35.1k 【首选向量库（独立部署）】
- **链接**：https://github.com/qdrant/qdrant ｜ Apache-2.0｜**Rust**｜⭐35,076，最后提交 2026-10-05（活跃）。
- **要点**：单二进制/docker 即可；payload 过滤、量化（scalar/binary）、稀疏向量混合检索；REST + gRPC；云版商业。
- **坑**：索引/量化参数需调；过滤字段设计影响性能。

### 3.2 pgvector ⭐23.4k 【首选向量（Postgres 派）】
- **链接**：https://github.com/pgvector/pgvector ｜ **PostgreSQL License**（LICENSE 原文核实，宽松）｜C｜⭐23,362，最后提交 2026-10-01（活跃）。
- **要点**：HNSW/IVFFlat；向量与业务数据同库同事务（一致性是最大优势）；配 Postgres 全文检索可做混合检索。
- **坑**：规模上限（百万~千万级经验值，视参数/内存）；HNSW 构建内存/时间；不适合独立超大规模向量服务。

### 3.3 LanceDB ⭐11.7k 【首选嵌入式向量库】
- **链接**：https://github.com/lancedb/lancedb ｜ Apache-2.0｜**Rust**（Python/TS/Rust SDK）｜⭐11,676，最后提交 10-14（当日）。
- **要点**："SQLite 之于向量"：嵌入式、Lance 列存、版本化/时间旅行、多模态数据友好、零运维。
- **坑**：生态较新，各语言绑定能力有差异；超大规模仍建议独立服务。

### 3.4 Milvus ⭐46.4k 【可选：规模化】
- **链接**：https://github.com/milvus-io/milvus ｜ Apache-2.0｜Go/C++｜⭐46,385，最后提交 10-14（当日）。
- **要点**：分布式向量库标杆；单机可用 standalone docker；有 milvus-lite（嵌入式子集）。
- **坑**：集群组件重（etcd/MinIO/消息队列），资源占用高；个人系统一般用不到。

### 3.5 Weaviate ⭐16.9k 【可选】🔒
- **链接**：https://github.com/weaviate/weaviate ｜ **许可为混合模式**：LICENSE 原文"Source code in this repository is variously licensed under the BSD-3-Clause License, or the Weaviate License"——**部分文件受 Weaviate License 限制 🔒**｜Go｜⭐16,883，最后提交 10-13。
- **要点**：模块系统、混合检索、多租户；企业向。
- **坑**：许可需逐项确认（非纯 BSD）。

### 3.6 Chroma ⭐29.5k 【可选：入门/原型】
- **链接**：https://github.com/chroma-core/chroma ｜ Apache-2.0｜Python/Rust（1.0 大版本核心转向 Rust）｜⭐29,501，最后提交 10-13。
- **要点**：嵌入式优先、上手最快；适合原型与轻量场景。
- **坑**：经历 1.0 重写，历史 API 变动大（升级/迁移注意）；大规模性能口碑一般。

### 3.7 Meilisearch ⭐59.6k 【可选：全文/混合检索】🔒
- **链接**：https://github.com/meilisearch/meilisearch ｜ **`SPDX: MIT AND BUSL-1.1`**——主体 MIT，**Enterprise Edition 部分为 BUSL-1.1 🔒（LICENSE 原文核实）**｜Rust｜⭐59,568，最后提交 10-14（当日）。
- **要点**：typo 容忍全文检索起家，近版本主推 AI/混合检索；极佳 DX。
- **坑**：EE 文件许可注意；向量能力较新，别当通用向量库用。

### 3.8 Typesense ⭐26.9k 【警示：GPL】🔒
- **链接**：https://github.com/typesense/typesense ｜ **GPL-3.0 🔒（衍生产品/分发需开源，商业闭源嵌入需评估）**｜C++｜⭐26,872，最后提交 10-13。
- **要点**：快、typo 容忍、易用，支持向量/混合检索（较新版本加入）。
- **坑**：GPL；内存占用偏高。

### 3.9 Kuzu ⭐4.0k 【📉 排除：已归档】
- **链接**：https://github.com/kuzudb/kuzu ｜ MIT｜C++｜⭐4,022｜**已归档（archived），最后提交 2025-10-10**。
- **README 原文**："Kuzu is working on something new! We are archiving the KuzuDB project here…"（0.11.3 为最后整合版；旧 release 仍可用）。
- **结论**：嵌入式图库的空白很可惜——**新项目不要选**；Graphiti 也已弃用其后端。替代：Neo4j CE / FalkorDB。（注：对自研系统而言"嵌入式 Cypher 图库"生态目前没有同量级替代品，值得关注其团队新项目。）

### 3.10 FalkorDB ⭐9.9k 【图库-可选（注意 SSPL）】🔒
- **链接**：https://github.com/FalkorDB/FalkorDB ｜ **SSPL-1.0（Server Side Public License）🔒**——非 OSI 认证；"将本软件作为服务提供给第三方"受限，自用/内部部署一般可行（合规需法务确认）｜C/Rust｜⭐9,909，最后提交 10-14（当日）。
- **要点**：基于 GraphBLAS 的高性能图库，Redis 兼容协议，Graphiti 支持的后端之一；定位知识图谱/LMM 场景。
- **坑**：SSPL。

### 3.11 Neo4j（社区版）⭐17.3k 【图库-可选】🔒
- **链接**：https://github.com/neo4j/neo4j ｜ **GPL-3.0（Community Edition）🔒**；企业版商业授权｜Java｜⭐17,318，最后提交 2026-09-14。
- **要点**：图数据库事实标准，Cypher、生态最全；Graphiti 的首选后端（5.26+）。
- **坑**：GPL 边界（作为独立服务自用一般无碍，嵌入分发需评估）；内存开销（经验量级 1-2GB+）；社区版与企业版功能差异。

### 3.12 全文/其他（简评）
- **OpenSearch** ⭐13.9k：Apache-2.0，ES 7.10 分叉，AWS 生态；最后提交 10-14。（https://github.com/opensearch-project/OpenSearch）
- **Elasticsearch** ⭐78.3k：**混合许可 🔒**（LICENSE.txt 原文核实：AGPLv3 / SSPL v1 / Elastic License 2.0 三重 + 部分 Apache-2.0 兼容）｜Java｜最后提交 10-14。RAGFlow 默认后端之一；许可复杂（商用注意）。
- **Infinity** ⭐4.7k：Apache-2.0，infiniflow 自家 AI-native 数据库（dense/sparse/tensor + 全文），RAGFlow 配套引擎；最后提交 10-13。（https://github.com/infiniflow/infinity）

---

## 4. 重点横评（五轴）

### 4.1 写入 / 召回机制对比（编·取·更新·遗忘）

| 系统 | 写入（编） | 召回（取） | 更新 | 遗忘 |
|---|---|---|---|---|
| **Graphiti** | episode 增量摄入 → LLM 抽实体/边 | 语义+BM25+图遍历混合重排 | 新边令旧边失效（双时序） | **失效而非删除**（可时间回溯） |
| **Mem0 (OSS)** | LLM 抽取事实 + ADD/UPDATE/DELETE/NOOP 判定 | 向量 + 元数据过滤 | 同上（判定驱动） | DELETE 判定（图记忆已移出 OSS） |
| **Letta Code** | agent 自我改写 memory blocks / MemFS（git 化） | 常驻记忆块 + 消息搜索 + recall 子代理 | 自编辑 | 改写/压缩（"做梦"整合） |
| **Cognee** | ECL 管线（抽取→认知化→载入） | 图+向量 | 重跑管线 | 数据集级删除 |
| **MemOS** | MemCube 创建 + 调度 | 混合检索 | MemCube 更新 | 调度策略（弱） |
| **Basic Memory** | 人/机写 Markdown 文件 | SQLite FTS + 语义 + 双向链接 | 直接改文件 | 删文件 |
| **HippoRAG 2** | 离线建 KG/索引（成本低） | **个性化 PageRank 多跳** | 重建索引 | 无显式遗忘 |
| **LangMem** | 工具/后台管理器写入 | Store 搜索 | manage 工具 | 删除工具 |
| **engram (Go)** | 会话摘要/观测写入 SQLite | FTS5 全文（+可选向量） | 更新观测 | 手工/主题淘汰 |

> 读法：**"遗忘"能力全行业默认最弱**。目前只有 Graphiti 把"更新/遗忘"做成第一等公民（双时序失效），这是自研系统最值得抄的机制。

### 4.2 图记忆 vs 向量记忆

- **向量记忆**（Mem0/Chroma/pgvector 派）：写入便宜（一次嵌入）、召回快；弱点：无关系、无多跳、无时序、"相似≠相关"。
- **图记忆**（Graphiti/LightRAG/HippoRAG 派）：有关系与多跳、可解释（边即证据）、可时序化管理；代价：**每次写入需 LLM 抽取**（持续性成本）、图库运维、抽取错误会污染。
- **行业信号（重要）**：Mem0 2026 把图记忆**从 OSS 移除收进商业云**——说明"图记忆"在商业上被视为高价值环节；开源侧接棒者是 **Graphiti**（Apache-2.0）与 **LightRAG**（MIT，图+向量一体且可全本地）。
- **自研建议**：**混合架构**——图存实体/关系/时序（Graphiti 或 LightRAG 范式），向量存模糊语义检索（Qdrant/pgvector/LanceDB），召回端做融合（RRF/重排）。不要二选一。

### 4.3 上下文工程（context engineering）能力对比

| 能力 | 最佳范本 | 说明 |
|---|---|---|
| 常驻记忆块 + token 预算 | **Letta** | 可自编辑 blocks、系统提示词学习 |
| 记忆的版本化/可审计 | **Letta MemFS（git 化）** | 记忆=文件树+git，可回滚可迁移 |
| 空闲期整合（sleep-time） | **Letta**（`/sleeptime`、dreaming） | 不在推理期烧 token 的整理 |
| 引用溯源/防幻觉 | **RAGFlow** | 答案锚定原文切片 |
| 检索结果预算控制 | LightRAG（双级）、Graphiti（重排） | 控制注入上下文规模 |
| 记忆类型学 | **LangMem**（semantic/episodic/procedural） | 分类写入不同存储 |
| 提示词自我优化 | LangMem（procedural） | 程序性记忆 |
| 全局问题（summary 型） | GraphRAG（社区摘要） | 成本换质量 |

> 自研系统"上下文工程"最小完备集：记忆块（预算制）＋按需召回（工具面）＋失效式遗忘（双时序）＋引用溯源（知识库答案）+ 定期整合任务。

### 4.4 与 Agno / Hermes 类系统的集成难度

| 组件 | 对外形态 | 接入方式 | 耦合度 |
|---|---|---|---|
| **Graphiti** | 库 + **官方 MCP server** | MCP 工具面 / 自建 REST | **低** ✅ |
| **Cognee** | 库 + **MCP（cognee-mcp）** | MCP / pip | 低 |
| **Basic Memory** | **MCP server（原生）** | MCP | 低 |
| **Supermemory** | **MCP server + 插件** | MCP | 低 |
| **MemOS** | **官方 MCP（npm）+ REST** | MCP / REST | 低 |
| **RAGFlow** | 产品 + **MCP server/client** | MCP / REST | 中（要有基建） |
| **LightRAG** | 库 + REST（无官方 MCP） | 自建 MCP/REST 包装 | 中低 |
| **Mem0 (OSS)** | 库 + 自托管 Server（**本地 MCP 已移除**） | SDK/Server API | 中 |
| **Letta Code** | 完整 harness + SDK + App Server | 换主循环（或抄设计） | **高** |
| **Redis AMS** | REST 服务 | REST | 中低 |
| **Qdrant/pgvector/LanceDB** | 存储 | 客户端库 | **最低** |
| **LlamaIndex/Haystack** | 框架 | 框架内开发 | 高（框架税） |

> 低耦合首选路径：**一切经 MCP**（search / remember / forget 三个工具面），主循环只依赖接口不依赖实现，组件可替换。

### 4.5 长期运行成本（经验量级，未实测，以实测为准）

- **LLM 抽取（最大变量）**：Mem0 ≈ 每条消息 1-2 次小模型调用；Graphiti ≈ 每 episode 1-2 次；Cognee/RAGFlow GraphRAG 更重。**用本地 7-8B 小模型可把常态成本压到"电费级"**（Cognee 官方也在打"small models for free"）。
- **嵌入**：一次性为主，本地嵌入模型（bge/nomic 等）免 API 费。
- **常驻内存（粗略量级）**：LanceDB/pgvector（随 PG）≈ 低 → Qdrant ≈ 数百 MB → Neo4j/FalkorDB ≈ 1-2GB → Milvus standalone ≈ 4GB+ → RAGFlow 全套 ≈ 4-8GB+（ES 是大头）。
- **Token 注入成本**：常驻记忆块（Letta 式）每轮都付费；按需召回（MCP 工具式）更省——**自研建议"少量常驻 + 大量按需"**。
- **云版对照**：Zep Cloud / Mem0 Platform / Supermemory / Letta Cloud 均为商业定价（与各自 OSS 功能剪差在扩大）。

---

## 5. 推荐组合（长期记忆 + 知识库）

> 需求：跨会话长期记忆、按需召回、关系/图谱、可本地部署、与 agent 主循环低耦合。

### 方案 A（主推：本地、图优先、低耦合）
```
主循环（自研 agent）
   │  MCP（search / remember / forget）
   ├── Graphiti（Apache-2.0，记忆图：时序+失效式遗忘）
   │      └─ 图后端：Neo4j CE（GPL）或 FalkorDB（SSPL）—— 法务选型二选一
   ├── LightRAG（MIT，知识库：双级检索，存储起步用文件/NetworkX，规模上来换 Neo4j+Qdrant）
   └── 向量：Qdrant（独立）｜或 pgvector（已有 PG 时首选）｜或 LanceDB（嵌入式零运维）
全文：Postgres FTS（若用 PG）或 Meilisearch（MIT 部分）
嵌入/抽取：本地模型（bge-m3 类 + 7-8B 小模型），常态零 API 成本
```
- **抄作业清单**：Letta（记忆块+git 化+sleep-time）、Mem0（抽取-判定 prompt）、Graphiti（双时序失效）、RAGFlow（解析+引用）、nano-graphrag（最小图 RAG）。

### 方案 B（极简单机：文件优先）
- 记忆/知识：**Basic Memory**（Markdown+SQLite+MCP；🔒AGPL 注意）或 **engram（Go 单二进制）**＋ **LanceDB**＋ 文件全文检索。
- 适合：个人使用、代码/笔记场景、不愿运维任何服务；缺点：自动化抽取弱。

### 方案 C（重装全功能：要运维）
- **RAGFlow** 全套（文档解析/引用/Agent）＋ **Graphiti**（记忆图）＋ Qdrant/pgvector；适合把"知识库产品"本身当交付物时。

### 避免清单
- 📉 Kuzu（归档）、R2R（停更）、memary（2024-10 后停更）、memobase（2026-01 后停更）、A-Mem 官方仓库（2025-12 后停更，仅算法参考）。
- 勿按旧教程部署：Mem0 OSS 图记忆（已移除）、Mem0 本地 MCP/OpenMemory（已移除/已转型）。
- 许可红线自检：AGPL（Khoj、Basic Memory）、GPL（Typesense、Neo4j CE）、SSPL（FalkorDB）、BUSL（Meilisearch EE）、Weaviate 混合。
- **成本红线自检**：凡"每次写入都要 LLM"的组件（Graphiti/Mem0/Cognee），先规划小模型或批处理。

---

## 6. 附录

### 附录 A · 停更 / 归档 / 观察名单（2024 年后不再活跃）

| 项目 | 最后提交 | 状态 | 备注 |
|---|---|---|---|
| kingjulio8238/Memary ⭐2.7k | 2024-10-18 | 停更 | KG 记忆层，MIT，勿用 |
| SciPhi-AI/R2R ⭐8.0k | 2025-11-07 | 停更 | 公司转型；API 设计可参考 |
| agiresearch/A-mem ⭐1.2k（官方实现 A-mem-sys ⭐404） | 2025-12-12 / 2025-11-06 | 停更 | NeurIPS'25 论文；"链接演化"算法可参考 |
| memodb-io/memobase ⭐2.9k | 2026-01-11 | 半停更 | 用户画像记忆，参考 |
| gusye1234/nano-graphrag ⭐4.0k | 2026-01-27 | 半停更 | 最小图 RAG，仍是最佳抄写底稿 |
| kuzudb/kuzu ⭐4.0k | 2025-10-10 | **归档** | 勿新用；Graphiti 亦弃用 |
| OSU-NLP-Group/HippoRAG | 2026-10-06 | 活跃 | 研究项目，算法参考 |

### 附录 B · 「engram」名称澄清（任务点名项）
"engram"**不是单一知名项目**，同名者至少 4 个 + 1 篇论文：
| 项目 | ⭐ | 形态 | 活跃 |
|---|---|---|---|
| Gentleman-Programming/engram | 7,199 | Go 单二进制；SQLite+FTS5；MCP/HTTP/CLI/TUI；面向编码 agent | 2026-10-14 ✅ |
| tstockham96/engram | 47 | TS；SQLite+sqlite-vec；MCP；宣称 LOCOMO 84.5（HN 展示过） | 2026-09-02 |
| techtheist/engram | 32 | Rust；可检视图记忆（VS Code/JetBrains 插件） | 2026-10-14 |
| edg-l/engram-mcp | 17 | Rust；git 分支感知会话交接；本地 ONNX 嵌入 | 2026-09-23 |
| arXiv:2511.12960 "ENGRAM" | — | 论文：轻量记忆编排（LoCoMo 上 SOTA 宣称） | 2025-11 |
**结论**：若任务指"记忆系统 engram"，最接近的是 **Gentleman-Programming/engram（MIT，⭐7.2k，架构可抄：单文件 SQLite 记忆 + FTS5 + MCP）**；其余为小项目/论文，不建议作为依赖。

### 附录 C · 核实方法与口径
- star 数：GitHub 仓库页内嵌 JSON（`stargazerCount`）精确值，2026-10-14；其中 6 个项目另用 `api.github.com` 抽查（用量：本代理 6 次；共享配额 54→30，含他代理消耗），页面值与 API 值一致。
- 最后提交：`commits.atom`（默认分支）；发版：`releases.atom`；归档状态：仓库页 `isArchived`。
- 许可证：一律读仓库 LICENSE 原文（Meilisearch、Weaviate、Elasticsearch、FalkorDB、pgvector、Kuzu、redis/agent-memory-server 均逐字核实）。
- 第三方信息（已标注）：Mem0 OpenMemory 移除时间线（mnemoverse 整理）、Letta 研究与产品时间线（letta.com 官网）。
- 🟡 未完全核实项：Redis AMS 的 MCP 支持；Mem0 自托管 Server 是否暴露 MCP；Supermemory 自托管形态细节；Elasticsearch/OpenSearch 未做深度集成测试。
- 本文件为只读调研，未安装任何组件。

---

*文件：`/home/ubuntu/projects/agent-stack/sections/02-memory-rag.md` ｜ 集群：记忆与知识/RAG ｜ 核实日：2026-10-14/15*


---

# 03 · 工具/技能生态与执行环境（工具接入 · 沙箱执行 · 浏览器/计算机操作）

> **核实口径**：数据读取于 2026-10-14（UTC）。star 与许可证标注来源：
> `[API]` = api.github.com 直读（本次共享限流预算内共 6 次）；`[GH]` = github.com 仓库页 + commits.atom 当日直读；未读取到的字段显式标「未核实」。
> **收录门槛**：真实存在、2024 年后仍活跃或有 2024+ 维护记录；已归档/停滞项目单独标注，不作为推荐。
> **边界**：本册只管「工具/技能 + 执行环境 + 浏览器/计算机操作」；框架（01）、记忆（02）、模型/可观测（04）、交互/调度（05）、安全/基建（06）不在此展开。
> **只读调研，未在本机安装任何东西。**

---

## 0. TL;DR（先看这一段）

- **三条最值得抄的架构主线**：① **MCP 网关 + 凭证代理**（密钥不进模型上下文、不进沙箱，工具按策略授权）；② **技能包（SKILL.md）渐进式披露**（元数据常驻、正文按需加载，解决上下文爆炸）；③ **沙箱分层**（OS 原语 → 本地 microVM → 云 microVM，按代码可信度选层，不要一把梭）。
- **单机最小可用组合（全开源）**：`srt`（把 agent 自己关进盒子）+ `microsandbox`（跑不可信生成代码）+ `Playwright MCP`（浏览器）+ `Docker MCP Gateway`/`Executor`（工具接入与策略）。
- **云上多租户组合**：自托管 `E2B`（Apache-2.0 全栈，Firecracker）或自建 Firecracker/Kata 池。
- **许可证雷区（限制性条款，重点盯）**：**Daytona**（2026-06 起生产代码闭源、仓库已归档）、**Skyvern**（AGPL-3.0）、**Judge0**（GPL-3.0，CE 版）、**Nango**（Elastic License 2.0：禁止向第三方提供托管服务）、**anthropics/skills 的 docx/pdf/pptx/xlsx 技能**（source-available，非开源）、**Smithery CLI**（AGPL-3.0）。GPL/AGPL 家族意味着：一旦链接进你的分发产物，传染性条款会咬人；SaaS 形态下 AGPL 的网络条款同样触发。
- **一条血泪教训**：Daytona 曾是「开源沙箱三强」之一，71.5k star、AGPL 核心，2026-06 直接把生产代码闭源、仓库归档、`releases/latest` 停在 **v0.190.0**，GitHub license 字段已清空 `[API]`。**自研系统的沙箱/工具层必须设计成可替换接口（driver/adapter），并在选型时给「许可证与治理风险」单独打分。**

---

## A. 工具与技能生态

### A1. MCP 生态（协议接入层）

#### A1-1. modelcontextprotocol/servers —— MCP 官方参考服务器仓库
- **链接**：https://github.com/modelcontextprotocol/servers
- **定位**：MCP 协议官方参考实现集合（filesystem / fetch / git / memory / sequential-thinking 等），同时是「怎么写 MCP server」的最佳范本。
- **约 star**：91,265 `[GH]`（fork 11,790，watch 635）
- **许可证**：**MIT → 正在迁移 Apache-2.0**（LICENSE 文件明示过渡：新代码规范均 Apache-2.0，文档 CC-BY-4.0；旧 MIT 贡献者未同意重授权部分仍 MIT）。无限制性条款。
- **技术栈**：TypeScript / Python（官方 SDK 双语言），JSON-RPC over stdio / SSE / Streamable HTTP。
- **活跃度**：高（最后提交 2026-10-11；29 个 release）`[GH]`。
- **能当什么组件/能抄什么**：① 直接复用 filesystem/git/fetch 这类「通用工具服务器」；② 抄它的 **tools/resources/prompts 三段式声明**与错误语义；③ 抄「参考实现 vs 归档服务器」的目录治理方式。注：该仓库大部分旧服务器已归档或迁往独立仓库，官方推荐从 registry 发现、按需自建。
- **集成坑**：① stdio 传输下**服务器进程与 agent 同机同权限**，MCP server 一旦被投毒就是宿主 RCE 入口；② 工具描述（description/tool schema）会全额塞进上下文，几十个 server 全挂上去会先把上下文挤爆——必须配工具筛选/路由层；③ 该仓库是「参考」不是「产品」，生产用要自己加固（超时、输出截断、沙箱化执行）。

#### A1-2. punkpeye/awesome-mcp-servers —— MCP 服务器大全（社区清单）
- **链接**：https://github.com/punkpeye/awesome-mcp-servers
- **定位**：规模最大的 MCP server 人工整理清单，按场景分类，含官方/社区/云服务三类标注。
- **约 star**：96,340 `[GH]`
- **许可证**：MIT（无限制性条款）
- **技术栈**：纯 Markdown 清单
- **活跃度**：高（最后提交 2026-10-09）`[GH]`
- **能当什么组件/能抄什么**：选型检索入口；抄它的分类维度（🗂️ 官方 / ☁️ 云 / 🏠 本地 / 🔗 聚合）来做自家工具目录的分类。
- **集成坑**：**收录 ≠ 安全**。清单里的第三方 server 是裸社区代码；引用前必须过一遍源码、权限（它能碰什么文件/网络/凭证）。别把清单当信任白名单。

#### A1-3. 官方 MCP Registry（registry.modelcontextprotocol.io）—— 协议级注册中心
- **链接**：https://registry.modelcontextprotocol.io （规范仓：https://github.com/modelcontextprotocol/registry ）
- **定位**：MCP 官方注册中心，元数据发现层（Anthropic / GitHub / PulseMCP / Microsoft 背书），2026 年已到 API v0.1 冻结；**是权威性来源，不是服务器运行时**。
- **约 star**：服务，star 不适用（registry 规范仓库约 5k+，未核实）
- **许可证**：注册中心 API 为开放规范（仓库 MIT，未逐字核实）
- **技术栈**：REST/JSON 元数据；服务端实现开源
- **活跃度**：高（生态级基础设施）
- **能当什么组件/能抄什么**：自研系统的**工具/连接器元数据层**直接对齐它的 schema（server 名称、传输、认证需求、版本），未来可做「一键导入」。抄它的「元数据与运行时分离」设计。
- **集成坑**：注册中心**不做安全审计也不托管运行**；「官方注册」只表示元数据合规。别把 registry 条目当作可信来源。

#### A1-4. Smithery —— MCP 托管网关 + 注册中心（商业服务混合体）
- **链接**：https://smithery.ai （CLI：https://github.com/smithery-ai/cli ，840★ `[GH]`）
- **定位**：MCP 生态里最接近「Docker Hub + 托管运行时」的平台：7,000+ servers；既支持本地 `npx` 安装，也提供**托管远程 server**（代为管理 OAuth/凭证、会话），提供 Connect API（连接命名空间、JSON-RPC 调用、trigger webhook）。
- **约 star**：平台为服务（无 star）；CLI 仓库 840★
- **许可证**：**CLI 为 AGPL-3.0（限制性！）**；平台本身是商业 SaaS（服务条款约束，未核实细则）
- **技术栈**：TypeScript CLI；托管侧管理 OAuth、传输升级
- **活跃度**：平台活跃；CLI 仓库最后提交 2026-05-31，相对缓慢 `[GH]`
- **能当什么组件/能抄什么**：抄它的**「注册中心 + 托管连接」双形态**：本地跑（token 不出机）vs 托管跑（token 经其网关瞬时传递）——这正是自研系统「工具接入」要做的产品化抽象。托管 OAuth 弹窗、upsert 连接、trigger webhook 都是可抄的模式。
- **集成坑**：① **安全实锤**：GitGuardian 披露过 Smithery 托管功能的路径穿越 → 供应链风险；另有 2026-03 扫描称 100 个 Smithery server 中 22 个存在安全问题（第三方扫描数据，标为参考）。托管 server = 「别人机房里跑着你的凭证使用链」，信任半径巨大；② CLI AGPL-3.0，直接内置进闭源产品要谨慎；③ 托管模式下调用元数据会过第三方。

#### A1-5. mcp.so —— 社区提交制 MCP 目录（最大集散地）
- **链接**：https://mcp.so
- **定位**：19,700+ 条目的社区 MCP 目录（GitHub issue 提交制），广度最大。
- **约 star**：服务，无 star
- **许可证**：目录服务（条目指向的 server 各有其许可证）
- **技术栈**：Web 目录
- **活跃度**：高（社区日更）
- **能当什么组件/能抄什么**：广度调研入口（"这个领域有没有现成 server"）。
- **集成坑**：**零审核**——任何人均可提交，垃圾/钓鱼/停更条目混杂；只当搜索引擎用，不当质量标准用。

#### A1-6. OpenAPI → MCP 桥接器（把自家 REST API 变成工具）
| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 一句话 |
|---|---|---|---|---|---|
| **mcpo** | https://github.com/open-webui/mcpo | 4,401 `[GH]` | MIT | 中低（最后提交 2026-02-27） | 把任意 MCP server 桥成 OpenAPI/HTTP 服务，反向兼容也常用 |
| **fastapi_mcp** | https://github.com/tadata-org/fastapi_mcp | 12,022 `[GH]` | MIT | 慢（最后提交 2025-08-10） | FastAPI 一键暴露为 MCP server，鉴权可透传 |
| **openapi-mcp-server** | https://github.com/snaggle-ai/openapi-mcp-server | 903 `[GH]` | MIT | 中（最后提交 2026-07-07） | OpenAPI spec → MCP tools，适合存量 API 资产 |
| **MCP Inspector** | https://github.com/modelcontextprotocol/inspector | 11,078 `[GH]` | MIT | 高（2026-10-14） | 官方调试/自测工具，开发期必备 |

- **能当什么组件/能抄什么**：自研系统的**工具注册管线**：`OpenAPI spec → 工具 schema → 权限声明 → 发布`。抄 fastapi_mcp 的「按端点粒度为工具 + 鉴权透传」，抄 mcpo 的「一进程多 server 聚合」。
- **集成坑**：① OpenAPI 自动转换会把**每个端点都变成工具**，200 个端点 = 200 个工具直接压垮上下文 → 必须做工具筛选/分组/路由（见 D 节 tool router）；② 参数 schema 噪声（分页、过滤参数）会诱导模型乱填，需手工收窄；③ 鉴权透传别把用户 token 直接塞给模型可见层，走凭证代理（见 D 节）。

---

### A2. 工具执行与授权平台（连得上 + 管得住 + 密钥隔离）

#### A2-1. Composio —— 工具集成与授权平台（生态事实标准）
- **链接**：https://github.com/ComposioHQ/composio
- **定位**：1,000+ toolkits 的集成层：托管 OAuth/令牌刷新、工具检索（tool search）、Tool Router（按意图动态加载工具而非全量挂载）、以及一个 sandboxed workbench 用于执行。
- **约 star**：30,552 `[API]`（fork 4,852，2026-10-14 仍在提交）
- **许可证**：**仓库 MIT**（SDK/工具集）；托管平台为商业 SaaS 计费。**自托管能力存在不同说法**（早期官方联合创始人在 HN 回复「不支持自托管、源码不公开」；另有资料称「SDK 与自托管 MCP server 可 MIT 部署」）→ **以官方文档为准，标未核实**。
- **技术栈**：TypeScript 为主 + Python SDK；REST + SSE/远程 MCP；支持 MCP 客户端接入。
- **活跃度**：高（2026-10-14 提交）`[API]`
- **能当什么组件/能抄什么**：**抄它的 Tool Router 与 tool search**——这正是自研系统解决「工具太多、上下文太少」的正解；抄「connected account」抽象（把 OAuth 连接与工具调用解耦，凭证在平台侧解析再注入请求）；抄它的 toolkit 目录结构。
- **集成坑**：① 走托管平台 = 用户 OAuth token 存在第三方，企业客户会卡合规；② 免费档限速（约 60 req/min/AK，第三方资料）不适合高频工具循环；③ 别把它的 SaaS 当唯一路径——自研至少留「本地凭证代理」替代实现。

#### A2-2. Executor（UsefulSoftwareCo/executor）—— 可自托管的集成层 / MCP 网关
- **链接**：https://github.com/UsefulSoftwareCo/executor
- **定位**：面向 agent 的集成层：把 MCP server、OpenAPI、GraphQL API 统一配置成一份目录，带**认证与 per-tool 策略**，供任意 MCP 兼容 agent 使用；提供 Cloud / Desktop / CLI / Docker 自托管 / Cloudflare Workers 全套部署形态。
- **约 star**：4,180 `[GH]`（YC S26 项目，2026 年内快速增长）
- **许可证**：MIT（无限制性条款）
- **技术栈**：TypeScript（monorepo：core/cli/desktop/local/cloud/self-host）
- **活跃度**：高（最后提交 2026-10-12）`[GH]`
- **能当什么组件/能抄什么**：**自研「工具接入 + 凭证隔离」最直接的开源参考实现**：一个目录管所有集成、策略按工具粒度、凭证隔离在网关侧、沙箱化执行。抄它的 self-host 部署拓扑与 per-tool policy 模型。
- **集成坑**：① 年轻（约一年），核心面足够但生产级评价样本少；② 策略/审计能力相对商业平台仍浅，别指望它直接当企业 IAM。

#### A2-3. MCP 网关三件套（把「工具接入」做成基础设施）
| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 关键能力 / 坑 |
|---|---|---|---|---|---|
| **Docker MCP Gateway** | https://github.com/docker/mcp-gateway | 1,600 `[GH]` | MIT | 中（2026-09-16） | 每个 MCP server 跑在受限容器里 + 网关级配置/凭证/工具审批；AI Governance 集中策略为邀请制；凭证保险库要自己做 |
| **IBM ContextForge** | https://github.com/IBM/mcp-context-forge | 4,634 `[GH]` | Apache-2.0 | 高（2026-10-14） | MCP 注册中心 + **REST→MCP 转换** + 联邦；2026-05-01 GA，v1.0.4（2026-06-23）；重量级，Java/Go 味的企业栈 |
| **microsoft/mcp-gateway** | https://github.com/microsoft/mcp-gateway | 879 `[GH]` | MIT | 高（2026-10-14） | 轻量会话感知网关与路由；微软生态亲和，独立于 Azure 也可跑 |

- **能当什么组件/能抄什么**：**「网关层」是自研系统的必答题**：集中做工具目录、凭证解析、策略评估、审批、审计。抄 Docker 的「server 容器化 + 特权最小化 + 请求审批」，抄 ContextForge 的「注册中心 + 协议转换（REST/OpenAPI → MCP）」。
- **集成坑**：① 纯开源网关普遍**不含凭证保险库与统一审计**（Composio 那篇文章自己也承认：这三个要你自己建）——自研时把它列为独立模块；② 网关成为单点：挂了全挂，需热备与降级（直连模式兜底）；③ 容器隔离 ≠ 强隔离（共享内核），别用 Docker 网关冒充「不可信代码沙箱」。

#### A2-4. 授权/连接平台对照（自托管与许可维度）
| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 说明 |
|---|---|---|---|---|---|
| **Nango** | https://github.com/NangoHQ/nango | 12,663 `[GH]` | **Elastic License 2.0（限制性）** | 高（2026-10-14） | 700+ API 的 OAuth 连接/令牌刷新引擎，可自托管；**Elastic License 禁止把其功能作为托管服务对外提供**，内部用可以 |
| **Arcade** | https://github.com/ArcadeAI/arcade-ai | 1,052 `[GH]` | MIT | 高（2026-10-14） | 工具调用 + 授权（OAuth）框架，体量小、可读性好 |
| **ACI** | https://github.com/aipotheosis-labs/aci | 4,912 `[GH]` | Apache-2.0 | 中低（最后提交 2026-05-28） | 自托管 Composio 类替代（600+ 集成，统一 MCP server）；活跃度走弱，评估风险 |

- **能当什么组件/能抄什么**：**凭证代理（credential broker）**模式：外部 API 的 OAuth 授权、刷新、按 connected account 解析 token、只在实际出站请求时注入。这是「密钥隔离」的实现核心——模型和沙箱永远看不到原始令牌。
- **集成坑**：Elastic License / 商业条款类项目要过法务；「连接即权限」——注意 refresh token 的存储加密与轮换，以及最小 scope 原则。

---

### A3. Agent Skills 规范与社区技能库

#### A3-0. 规范本身（先读这个）
- **Agent Skills 规范**：https://agentskills.io ；规范仓 https://github.com/agentskills/agentskills —— **26,142★ `[GH]`，Apache-2.0**，最后提交 2026-08-09。
- **时间线**：Anthropic 2025-10 随 Claude 推出 Skill 格式；**2025-12-18 发布为开放标准**（规范 + SDK），现由 26+ 平台采用（Claude、OpenAI Codex、Gemini CLI、GitHub Copilot、Cursor、VS Code 等）。
- **核心机制（自研必抄）**：一个技能 = 一个文件夹（`SKILL.md`（YAML frontmatter: name/description + Markdown 正文）+ 可选 `scripts/`、`references/`、`assets/`）。**三级渐进式披露**：① 启动时只加载 name+description（约 100 token/技能）→ ② 命中任务才加载完整 SKILL.md（通常 <5k token）→ ③ 脚本/参考文件按需读取。这是「几百个技能上机也不爆上下文」的关键。
- **集成坑**：① 技能里的 scripts 是**可执行代码**，必须与技能信任级别绑定（不可信技能 = 不可信代码，要过沙箱/策略）；② 描述质量决定命中率，description 写法差的技能等于没装；③ 规范仍在演进（2026 年内多次修订），解析器要容错。

#### A3-1. anthropics/skills —— 官方技能仓库 + 参考实现
- **链接**：https://github.com/anthropics/skills
- **定位**：官方 Skill 集合（creative/design、dev、enterprise/communication、document skills），含 `/spec` 规范文本与 `/template`。
- **约 star**：181,150 `[GH]`（生态热度最高的单体仓之一）
- **许可证**：**多数技能 Apache-2.0；但 `skills/docx`、`skills/pdf`、`skills/pptx`、`skills/xlsx` 四个文档技能是 source-available（非开源）**——官方明说「share as reference」。**限制性条款，商用前必须逐一核对。**
- **技术栈**：Markdown + 附带脚本（Python/JS）；可作为 Claude Code plugin marketplace（`/plugin marketplace add anthropics/skills`）注册。
- **活跃度**：高（最后提交 2026-10-09）`[GH]`
- **能当什么组件/能抄什么**：① 抄「复杂技能长什么样」（文档技能的目录结构、脚本组织、错误处理）；② 直接参考它的 SKILL.md 写作规范；③ 抄 plugin marketplace 分发模型。
- **集成坑**：**许可证是混的**（Apache-2.0 与 source-available 同仓），不要整仓照搬；技能内脚本会调用外部依赖（如 docx 库），离线环境要预置。

#### A3-2. 社区技能库（可直接拿来做自家技能的「种子集」）
| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 特点 |
|---|---|---|---|---|---|
| **addyosmani/agent-skills** | https://github.com/addyosmani/agent-skills | 106,676 `[GH]` | MIT | 高（2026-10-13） | 23 个工程生命周期技能 + 7 个 slash 命令（/spec /plan /build /test /review /ship），含硬性退出标准、反合理化表格，编码 Google 工程文化 |
| **VoltAgent/awesome-agent-skills** | https://github.com/VoltAgent/awesome-agent-skills | 35,720 `[GH]` | MIT | 高（2026-10-13） | 1,000+ 技能索引，跨 Claude Code / Codex / Gemini CLI / Cursor |
| **ComposioHQ/awesome-claude-skills** | https://github.com/ComposioHQ/awesome-claude-skills | 77,121 `[GH]` | **未核实**（页面未解析出 license） | 中（2026-07-24） | 技能清单 + 生态资源索引（含 skills marketplace 入口） |
| **skills.sh（分发平台）** | https://www.skills.sh | 服务 | 服务条款 | 活跃 | `npx skills add <owner/repo>` 一键装技能，带排行榜（按真实使用而非发布热度） |
| **superradcompany/skills** | https://github.com/superradcompany/skills | 未核实 | 未核实 | 与 microsandbox 同步 | microsandbox 自带的「沙箱技能包」，示范「技能 = 安全执行能力 + 指令」捆绑 |

- **能当什么组件/能抄什么**：**自研技能系统的最小闭环**＝`技能目录 + SKILL.md 解析器 + 渐进加载 + 技能级权限与依赖声明 + 沙箱执行 + 分发/安装命令`。addyosmani 那套直接回答「技能里的指令怎么写才有约束力」（退出标准、反合理化）——这是技能质量的关键，比格式重要。
- **集成坑**：① 社区技能**质量方差极大**，很多是 prompt 复读；引入前看最近提交与行为验证；② 技能会改 agent 行为边界（比如偷偷放宽审批），**技能需与权限系统分层：技能不能扩权**；③ 跨平台兼容层不统一（各家的斜杠命令/路径约定不同）。

---

## B. 沙箱与代码执行

> 分层心智模型（按「隔离强度 / 启动成本」排）：
> **L0 OS 原语**（同内核约束，最便宜）→ **L1 本地 microVM**（本机强隔离，~100ms）→ **L2 云 microVM/容器**（多租户规模化）→ **L3 代码执行服务**（API 化的片段执行）。

### B1. 平台级沙箱（云/自托管）

#### B1-1. E2B —— 开源 Firecracker microVM 沙箱（事实标准）
- **链接**：https://github.com/e2b-dev/E2B （自托管全栈：https://github.com/e2b-dev/infra ）
- **定位**：AI agent 代码执行沙箱的参照实现：每个沙箱一台 Firecracker microVM（独立内核）、约 150ms 启动、完整 Linux 文件系统 + 预装 Python/Node 生态；Python/JS SDK；支持自托管。
- **约 star**：14,354 `[API]`；infra 仓库 1,716 `[GH]`
- **许可证**：Apache-2.0（主仓 + infra，均无限制性条款）`[API]`/`[GH]`
- **技术栈**：Python/TS SDK + Firecracker + Go 控制面（infra）；自托管支持 BYOC（AWS/GCP）。
- **活跃度**：高（2026-10-14 双仓均在提交）`[API]`/`[GH]`
- **能当什么组件/能抄什么**：① 自研「云沙箱层」首选底座（自托管）；② 抄它的生命周期 API（create/pause/resume/kill、**pause 后状态持久**）；③ 抄「沙箱 = 带真实工具的环境」定位（装了 git/pip/node，而不只是 REPL）。Manus（27 工具）/Perplexity/HuggingFace 都在用的公开案例可背书。
- **集成坑**：① **无公开合规认证**（其 Trust Center 未见 SOC 2/ISO/HIPAA——第三方对比资料），企业交付要自己扛合规；② 活动会话有时长上限（Hobby 1h / Pro 24h，第三方资料），pause-resume 约 1s 且有配额概念；③ 自托管 SLA 全靠自己；④ 计费按秒（vCPU ~$0.10/h 级，第三方资料），长时间挂机会烧钱。

#### B1-2. microsandbox —— 本地优先 microVM 运行时（单机自研首选）
- **链接**：https://github.com/superradcompany/microsandbox （配套 MCP：https://github.com/superradcompany/microsandbox-mcp ；Agent Skills 包：superradcompany/skills）
- **定位**：「把不可信负载塞进本机 microVM」的运行时与库：AI 生成代码、插件、CI 任务、爬虫、自动化。**可嵌入代码中直接 spawn VM（无常驻 daemon）**，OCI 镜像兼容（Docker Hub/GHCR 直接跑），支持 **fork/snapshot 运行中沙箱**、**密钥「不可泄露」（secret key 从不进入 VM 内）**、跨 Linux/macOS/Windows。
- **约 star**：8,682 `[GH]`
- **许可证**：Apache-2.0（README 自述，无限制性条款）
- **技术栈**：Rust（library + CLI）；microVM（轻量 hypervisor 路线）；内置 MCP server 与 Agent Skills。
- **活跃度**：高（最后提交 2026-10-13）`[GH]`
- **能当什么组件/能抄什么**：**单机版「不可信代码安全执行」的第一选择**：① 抄「secrets 不进 VM」的设计——密钥在宿主侧代理注入，VM 里拿到的是短期凭据；② 抄 fork/snapshot（并行跑 N 个分支试错，或秒级恢复环境）；③ 抄「库化而非服务化」，自研系统可直接嵌进进程。
- **集成坑**：① 年轻项目（约一年），Windows/跨平台路径的成熟度需自测；② 本机 microVM 依赖宿主虚拟化能力（KVM/HVF/WHP），**嵌套虚拟化环境（比如你自己的云 VM）可能开不了**——部署前先验证 `/dev/kvm`；③ 本地方案不做多租户隔离承诺，一人一机场景才是它的定位。

#### B1-3. Daytona —— ⚠️ 已闭源归档（作为风险案例收录，不作为组件推荐）
- **链接**：https://github.com/daytonaio/daytona
- **定位**：曾经的「agent-native 沙箱平台」：Sysbox 容器运行时（VM 级隔离、无硬件虚拟化开销）、sub-90ms 创建宣称、persistent workspaces、fork（copy-on-write）。
- **约 star**：71,547 `[API]`
- **许可证/状态（重点核实项）**：
  - ✅ **2026-06 起生产代码闭源**（Blaxel 对比文明确记载：「Daytona's production codebase became closed-source in June 2026, the open repo's last release is v0.190.0」）；
  - ✅ **最后开源版本 = v0.190.0**（`/releases/latest` 重定向直读确认为 `tag/v0.190.0`）；
  - ✅ **GitHub 仓库现已归档（archived: true），license 字段为空（null）** `[API]`；最后提交 2026-07-24。
  - ⚠️ 「开源部分为 AGPL-3.0」来自社区整理（awesome 清单「AGPL core」）——仓库当前已无 license 声明，**AGPL 一说仅作历史记录，未逐字核实**。
- **技术栈（历史）**：Go 控制面 + Sysbox/OCI 容器 + 可选 Kata/GPU 沙箱类型；SDK 覆盖 Python/TS/Ruby/Go/Java。
- **活跃度**：商业平台继续运营（SOC 2 Type II 2026-07 报告、HIPAA BAA、GDPR DPA、$24M Series A），**开源侧已死**。
- **能当什么组件/能抄什么**：**当反面教材抄三点**：① 沙箱接口必须 adapter 化（今天换 E2B、明天换 microsandbox 不疼）；② 选型评分表里加「治理与许可证风险」项（闭源/归档/换 license 历史）；③ 「开放核心 + 云变现」模式在沙箱赛道已被验证会翻转——别把关键路径押在单一厂商的 OSS 承诺上。
- **集成坑**：① 老教程/清单仍把它写成「开源沙箱」——全是过期信息，照抄会踩空；② 2026-04 其披露过安全公告：**API 凭证可从沙箱内存中被读取**（4-10 已修补，建议轮换密钥）——再强的隔离也怕凭证进沙箱，回到 D 节「密钥不进沙箱」原则。

### B2. OS 级沙箱原语（L0：同内核约束，最轻最便宜）

#### B2-1. Anthropic Sandbox Runtime（`srt`）—— 把任意进程关进 OS 原生盒子
- **链接**：https://github.com/anthropics/sandbox-runtime （npm：`@anthropic-ai/sandbox-runtime`）
- **定位**：轻量沙箱 CLI/库：**用原生 OS 原语对任意进程做文件系统 + 网络限制，不需要容器**。macOS 走 `sandbox-exec`(Seatbelt)，Linux/WSL2 走 `bubblewrap`，网络走 HTTP/HTTPS + SOCKS5 **代理白名单过滤**，带违规监控（macOS sandbox 日志）。明确面向「沙箱化 agent、本地 MCP server、bash 命令」。
- **约 star**：5,543 `[GH]`
- **许可证**：Apache-2.0（无限制性条款）
- **技术栈**：TypeScript（CLI 命令 `srt`，另有 `SandboxManager` 库 API，`~/.srt-settings.json` 配置）
- **活跃度**：高（最后提交 2026-10-14；发布后数小时即数千 star 的热度项目）`[GH]`
- **能当什么组件/能抄什么**：**自研 agent 的「默认外壳」**：所有 exec 类工具都过 srt 包装 →「读哪些目录、连哪些域名」白名单化。抄两件事：① **权限配置文件化**（settings 驱动，而非代码写死）；② **网络层用代理做白名单**（比 iptables/namespace 可移植）——这是「agent 自我约束」最省事的工程解。微软已 fork 为 `microsoft/vscode-sandbox-runtime` 用于 VS Code 分发（生态坐实）。
- **集成坑**：① **它是约束不是隔离**——同内核、同用户权限模型，防的是「agent 手滑」，防不住真攻击者/内核漏洞；**不可信第三方代码不要只靠 srt**；② Linux 强依赖 bubblewrap 的用户命名空间（部分容器环境/发行版会禁用 unprivileged userns，直接失败）；③ macOS 后端依赖 Apple 未文档化的 Seatbelt（未来兼容性风险，官方定位是 research preview，放在 anthropic-experimental 组织下）。

#### B2-2. bubblewrap —— 无特权沙箱构建工具（Linux 事实标准）
- **链接**：https://github.com/containers/bubblewrap
- **定位**：无 setuid 的沙箱构建器：把进程放进新的 namespace（user/pid/net/mount），按需要 bind-mount 目录。Flatpak、ChromeOS 等大量生产使用。
- **约 star**：9,052 `[GH]`
- **许可证**：**LGPL-2.1+**（COPYING 直读确认）——库链接/修改分发有 copyleft 义务，作为独立可执行文件调用无碍
- **技术栈**：C；Linux 内核 namespaces
- **活跃度**：高（最后提交 2026-10-14）`[GH]`
- **能当什么组件/能抄什么**：自研沙箱的**最底层砖块**（srt/自研 wrapper 的 Linux 后端）；抄它的「最小挂载集 + 默认只读」策略。
- **集成坑**：① 需要 unprivileged user namespace（同 srt）；② 它只管挂载/命名空间，**网络与 syscall 过滤要自己加**（seccomp 配 libseccomp）；③ 别忘配好 `--die-with-parent`、`/proc` 隔离等细节，漏一项就漏一个口子。

#### B2-3. nsjail —— Google 的进程隔离器（命名空间 + seccomp + cgroup）
- **链接**：https://github.com/google/nsjail
- **定位**：CTF/判题场景锤炼出来的强约束单进程沙箱：namespaces、seccomp-bpf、capabilities、cgroups、rlimits 一条龙，配置文件驱动（protobuf）。
- **约 star**：4,152 `[GH]`
- **许可证**：Apache-2.0（无限制性条款）
- **技术栈**：C/C++；Linux 内核特性
- **活跃度**：中高（最后提交 2026-10-02）`[GH]`
- **能当什么组件/能抄什么**：**「执行不可信代码片段」的 Linux 侧默认答案**（比 bubblewrap 多出 seccomp 与 cgroup 约束）。抄它的**策略文件化 + 默认拒绝**：把「允许的 syscall/网络/CPU 时间/内存」做成声明式配置，直接进自研系统策略层。
- **集成坑**：① 配置项繁多、写错静默失效（没有默认强策略），必须配套集成测试（故意跑逃逸样本）；② 仍共享内核——是强工程约束，不是硬件隔离；③ 需要宿主 root/CAP_SYS_ADMIN 或 userns 支持。

#### B2-4. sandbox-exec —— macOS 系统级沙箱（无独立仓库）
- **链接**：无公开仓库（XNU Seatbelt 组件，`/usr/bin/sandbox-exec`）
- **定位**：macOS 上所有「OS 级沙箱」方案的底层：以 SBPL（Scheme 式 profile）描述文件/网络/进程规则；`srt` 的 macOS 后端即它。
- **约 star**：系统组件，无 star
- **许可证**：Apple 系统软件（随 macOS）
- **技术栈**：SBPL profile + seatbelt
- **活跃度**：随 macOS 更新，**Apple 未正式文档化/公开支持**，社区长期担忧被移除或收紧
- **能当什么组件/能抄什么**：macOS 交付渠道绕不开它；抄 srt 的封装方式（别自己写 SBPL，太容易写漏）。
- **集成坑**：① 无官方文档、行为随系统版本漂移；② profile 语言没有静态校验，漏一条规则 = 开一个洞；③ 无 Linux 兼容物 → 跨平台方案必须做双后端（这是 srt 存在的理由）。

### B3. 其他隔离底座（自建沙箱时可能直接用到的内核技术）

| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 定位 / 何时用 |
|---|---|---|---|---|---|
| **Firecracker** | https://github.com/firecracker-microvm/firecracker | 37,380 `[GH]` | Apache-2.0 | 高（2026-10-14） | AWS 出的 microVM（E2B/Lambda/Fargate 的底座）；自建「云沙箱池」的终极砖块，但控制面/镜像/网络全部自己写 |
| **gVisor** | https://github.com/google/gvisor | 19,678 `[GH]` | Apache-2.0 | 高（2026-10-14） | 用户态内核（syscall 拦截）：隔离强度介于容器与 VM 之间、无硬件虚拟化需求；Modal 的沙箱底座；性能开销要实测 |
| **Kata Containers** | https://github.com/kata-containers/kata-containers | 8,941 `[GH]` | Apache-2.0 | 高（2026-10-14） | 「K8s 里像容器一样用 VM」；需要 K8s + 嵌套虚拟化；适合已有集群的团队 |

- **集成坑**：这三个都是「自建平台」的原材料，**不是产品**——你需要自己解决镜像构建、快照、端口/网络、池化调度、计费与回收。自研系统的现实路径：先用 E2B 自托管 / microsandbox 顶住，把这三者留作规模化时的替换后端。

### B4. 代码执行服务（L3：API 化片段执行 / 判题式 runner）

| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 定位 / 抄什么 / 坑 |
|---|---|---|---|---|---|
| **Piston** | https://github.com/engineer-man/piston | 2,827 `[GH]` | MIT | 中（最后提交 2026-07-31） | 多语言代码执行引擎（freeCodeCamp 等在用）：HTTP API `execute()`、语言包（package）体系、内置 isolate 级隔离与 rlimit。**抄它的「语言包 = 镜像+元数据」注册模型**，正是工具沙箱「按需装环境」的形态。坑：语言版本更新靠社区包；隔离强度依赖 isolate，高对抗场景不足 |
| **Judge0** | https://github.com/judge0/judge0 | 4,474 `[GH]` | **GPL-3.0（限制性！）** | 高（最后提交 2026-10-08） | 在线判题/代码执行系统：批量提交、多语言、isolate 沙箱、API 完整。**CE 版 GPL-3.0 有传染性**（SaaS 分发同样触发 AGPL 类似义务的 GPL 讨论要过法务）；企业版闭源有额外能力（如更细的资源/隔离控制）。坑：GPL 许可对闭源产品不友好；队列化设计偏「批作业」而非「交互式 agent 循环」 |
| **Jupyter Kernel Gateway** | https://github.com/jupyter-server/kernel_gateway | 562 `[GH]` | BSD-3-Clause（LICENSE.md 直读确认） | **低（最后提交 2024-03-12）** | 把 Jupyter kernel 暴露成 WebSocket/REST：天然多语言、天然有状态执行上下文（变量跨调用存活），与「code interpreter 工具」语义最接近。**抄它的「kernel = 有状态会话」模型**；实现侧更推荐直接用 `jupyter_server` + `jupyter_client`/`enterprise_gateway` 思路自组。坑：上游活跃度低，长期维护风险；kernel 进程本身无强隔离，要套在容器/nsjail 里跑 |

> **对照（非开源，不入库，仅标定坐标）**：Blaxel（microVM，<25ms standby resume，SOC2/ISO/HIPAA）、Modal Sandboxes（gVisor + GPU）、Cloudflare Sandboxes（Workers 原生，**credential injection via egress proxy** 是密钥隔离的好参照）、Vercel Sandbox / Fly Machines / Runloop（Firecracker 系）。它们的**产品抽象（snapshot、standby、egress proxy、per-second 计费）**比实现更值得抄。

---

## C. 浏览器与计算机操作

### C1. 浏览器操作（结构化 DOM vs 视觉两条路线）

#### C1-1. microsoft/playwright-mcp —— 官方 MCP 浏览器（结构化路线首选）
- **链接**：https://github.com/microsoft/playwright-mcp
- **定位**：Playwright 官方 MCP server：基于**无障碍树（accessibility tree）而非截图**给模型看页面，工具化 click/type/navigate/snapshot，天然确定性、省 token；支持 CDP 直连、多标签、网络/控制台观测。
- **约 star**：38,149 `[API]`
- **许可证**：Apache-2.0（无限制性条款）`[API]`
- **技术栈**：TypeScript + Playwright；stdio/SSE MCP
- **活跃度**：高（2026-10-08 最后提交，仍在迭代）`[API]`
- **能当什么组件/能抄什么**：**自研「浏览器工具」的默认实现**：先接它（MCP）就有 90% 能力；抄「结构化快照替代全页截图」的上下文经济账；抄 ref-based 元素寻址（快照返回元素 ref，点击按 ref 而非坐标）。
- **集成坑**：① 重度依赖无障碍树，**canvas/自绘 UI/复杂富文本场景它会「看不见」**——这类页面要回落到截图+视觉模型（Playwright 轨道不是万能的）；② 浏览器跑在宿主上：**会话隔离要自己套容器 + 独立 profile + 网络出口控制**；③ 多会话/并发要自己做池化（它默认单浏览器上下文），否则并发 agent 互相踩 tab。

#### C1-2. browser-use —— 高自由度浏览器 agent 库（生态最大）
- **链接**：https://github.com/browser-use/browser-use （生态：desktop 应用 https://github.com/browser-use/desktop ；自愈 harness https://github.com/browser-use/browser-harness 18,433★ `[GH]`；云 Box 等）
- **定位**：让 LLM 直接读 DOM 并自主操作的 agent 库（Python），「写意图不写选择器」；官方自研 browser 专用模型（`bu-ultra`，宣称 Mind2Web 97% vs Claude 62%——**厂商宣称，未独立核实**）；也提供 SDK 与云服务。
- **约 star**：117,989 `[API]`（browser 赛道最大单体）
- **许可证**：MIT（仓库；其云服务与专用模型 API 另有商业条款）
- **技术栈**：Python + Playwright/CDP；另有 TypeScript SDK
- **活跃度**：高（2026-10-09 最后提交）`[API]`
- **能当什么组件/能抄什么**：① 复杂、未知站点的自主任务可用它直接当「浏览器 agent 引擎」；② **抄 browser-harness 的哲学**：不堆几千行启发式，**把 CDP 原语 + 自定义工具注册交给模型**（模型缺工具就自己加）——这比「穷举式封装」更抗页面演化；③ 抄它「专用小模型 + 通用模型兜底」的成本结构。
- **集成坑**：① 自主循环 token 消耗大、易跑飞——生产必须配步数/成本上限与人工接管；② 稳定性依赖模型能力，同任务重复成功率波动；③ MIT 只覆盖库，**其 benchmark/云盒/专用模型不随之开源**，别混淆。

#### C1-3. Stagehand（Browserbase）—— 代码与自然语言混合的浏览器 SDK
- **链接**：https://github.com/browserbase/stagehand
- **定位**：四个原语 `act / extract / observe / agent`：确定性步骤与自主执行可混写；「自愈」——`act("click submit")` 由 AI 运行时解析，页面改版不碎选择器。
- **约 star**：25,670 `[GH]`
- **许可证**：MIT（无限制性条款）
- **技术栈**：TypeScript（Node）+ 本地 Chrome 或 Browserbase 云浏览器
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**「确定性骨架 + AI 弹性填充」的最佳范式**：把关键路径写成代码（可测、可审计），把脆的定位交给 AI。自研浏览器工具层强烈建议照抄这个分层（act/extract 明确返回结构，observe 给候选动作）。
- **集成坑**：① 云浏览器模式把访问流量/登录态交给 Browserbase（合规要评估），本地模式自管浏览器；② AI 步骤天生非确定，**关键断言别依赖它**（要用 observe 后的确定性点击）；③ extract 的结构化输出仍需 schema 校验。

#### C1-4. Skyvern —— 视觉 + agent 蜂群操作未知站点
- **链接**：https://github.com/Skyvern-AI/skyvern
- **定位**：不依赖 XPath/选择器，用**计算机视觉 + 多 agent 协作**在没见过的站点上执行表单/流程；附带无代码工作流构建器与浏览器扩展。
- **约 star**：23,198 `[GH]`
- **许可证**：**AGPL-3.0（限制性！网络服务条款会咬人）**
- **技术栈**：Python（FastAPI）+ Playwright + VLM
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：抄它的**视觉元素映射（视觉元素 → 可执行动作）与任务模板复用**（工作流沉淀成可重放步骤，第二次执行快且稳）；适合「政府/银行/老站」这类无 DOM 语义的战场。
- **集成坑**：① **AGPL-3.0：SaaS 形态下必须开源你的修改或获取商业许可**——自研产品闭源分发前务必评估；② 视觉路线 token/延迟高、对分辨率与渲染稳定性敏感；③ 复杂流程仍需人工纠错循环。

#### C1-5. Nanobrowser —— 你自己的浏览器里跑多 agent（自带 API key）
- **链接**：https://github.com/nanobrowser/nanobrowser
- **定位**：开源 Chrome 扩展（OpenAI Operator 替代品）：复用**用户已登录的真实浏览器会话**，多 agent 工作流，用户自填 LLM API key，无需云。
- **约 star**：14,089 `[GH]`
- **许可证**：Apache-2.0（无限制性条款）
- **技术栈**：TypeScript + Chrome Extension MV3
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**「浏览器即工具宿主」的分发形态**：不搞云端浏览器农场，把 agent 装进用户浏览器（登录态、Cookie、企业 SSO 零配置）。抄它的**侧边栏多 agent 编排 + 按站点授权模型**；自研个人级产品可以照这个形态做。
- **集成坑**：① 扩展页面脚本与站点 CSP/反爬对抗的现实摩擦；② 用户 key 在本地存储的安全责任在客户端；③ MV3 service worker 生命周期限制（长任务要转移）。

#### C1-6. Midscene（字节 Web Infra）—— 视觉驱动 UI 自动化（跨端）
- **链接**：https://github.com/web-infra-dev/midscene
- **定位**：视觉驱动 UI 自动化：一套 API 驱动 Web/Android/iOS，可接 Playwright/Puppeteer，附 Chrome 扩展、CLI、MCP server；用自然语言 + 视觉定位，输出可断言的 JSON。
- **约 star**：15,262 `[GH]`
- **许可证**：MIT（无限制性条款）
- **技术栈**：TypeScript
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**移动端（Android/iOS）UI 自动化的最短路径**——自研「计算机操作」想要手机覆盖时，比自建 Appium 生态便宜；抄它的「视觉定位 + 数据提取断言」一体 API。
- **集成坑**：① 视觉定位对动态内容/机型适配敏感，需要固定分辨率；② 真机/模拟器集群运维成本另算；③ 上游与 Playwright 版本耦合需锁版本。

### C2. 计算机操作（整机 GUI 控制）

#### C2-1. Cua（trycua/cua）—— 计算机操作的「沙箱底座 + 驱动 + 基准」全家桶
- **链接**：https://github.com/trycua/cua
- **定位**：为 computer-use 提供开源**驱动 + 跨 OS VM 编队 + 基准/数据生成**：让 agent 跑在 macOS/Linux 虚拟机上而不是你的真机；包含 Lume（macOS VM）、computer/agent SDK、benchmarks。
- **约 star**：29,739 `[GH]`
- **许可证**：MIT（`LICENSE.md` 直读确认，© Cua AI）——注意仓库内**组件/数据/模型可能有各自条款**（页面有 artifact-specific 表述），逐项核对
- **技术栈**：Python（SDK）+ macOS/Linux 虚拟化（Apple 虚拟化框架 / QEMU 系）
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**「计算机操作必须在 VM 里做」的完整示范**：① 抄它的分层（VM 管理 / 驱动机 / agent 循环 / 评测）；② 抄「跨 OS 编队 + 快照回滚」——真机 GUI agent 的最大风险是「把宿主搞坏」，快照是保险丝；③ 直接作为自研 computer-use 的运行底座。
- **集成坑**：① macOS VM 受 Apple 许可与虚拟化能力约束（Apple 芯片上可行但定制成本高）；② 虚拟化性能与 GPU 受限，视觉刷新率低的场景体验打折；③ 项目迭代快，API 文档稳定性一般。

#### C2-2. UI-TARS Desktop（字节）—— GUI grounding 专用模型 + 桌面 agent
- **链接**：https://github.com/bytedance/UI-TARS-desktop （含 Agent TARS）
- **定位**：端到端 GUI grounding 训练的模型家族（把 UI 元素理解为一等公民而非像素猜测），配桌面应用 + Agent TARS（CLI/Web UI，视觉 + MCP 工具集成）；宣称 OSWorld 分数高于 Claude Computer Use（**厂商宣称**）；有「System-2 reflection」：每步对比前后截图、走偏了就重规划。
- **约 star**：39,280 `[GH]`
- **许可证**：Apache-2.0（仓库；模型权重另有模型许可，未核实）
- **技术栈**：TypeScript 应用层 + 模型推理（本地或远端）
- **活跃度**：高（2026-10-09 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**抄「行动后截图对比 + 纠正计划」的反射循环**——这是 GUI agent 可靠性的关键增量，比换更强的模型划算；模型可当自研 computer-use 的 grounding 层（本地/自部署）。
- **集成坑**：① 桌面应用模式直控本机，**必须加动作白名单与人工确认**；② 模型与 app 版本耦合（下载大权重、推理硬件要求）；③ 基准分数用其自有评测口径，别直接横比。

#### C2-3. Open Interpreter（openinterpreter/openinterpreter）—— 从「本地代码解释器」转向「开放模型 coding agent」
- **链接**：https://github.com/openinterpreter/openinterpreter （原 OpenInterpreter/open-interpreter，**仓库已改名**）
- **定位**：当年「让 LLM 在你电脑上跑代码」的开创者；当前定位**已转向「面向 Kimi K3 / GLM 5.3 等开放模型的 coding agent」**（仓库描述直读）——形态比早期更接近 CLI coding agent。
- **约 star**：68,579 `[GH]`
- **许可证**：Apache-2.0（无限制性条款）
- **技术栈**：Python（核心）+ 多端前端
- **活跃度**：高（2026-10-11 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**抄它的执行循环与「执行前确认」交互**（自然语言 → 代码 → 展示 → 确认 → 运行 → 把 stderr 喂回模型）；这套「解释器循环」是自研 code-interpreter 工具的教学范本。注意其**运行在宿主**（有 `--safe_mode` 级限制但非强沙箱）。
- **集成坑**：① 直接跑宿主代码，**必须外包一层沙箱**（nsjail/microsandbox）再用；② 定位漂移期，API 与文档要和版本号对齐；③ 旧教程的 `interpreter` 包名/用法可能已变。

#### C2-4. Self-Operating Computer —— 最小可行计算机操作框架（参考用，已停滞）
- **链接**：https://github.com/OthersideAI/self-operating-computer
- **定位**：多模态模型看屏 → 移动鼠标/键盘的最小框架；「computer use」概念的早期样板。
- **约 star**：10,293 `[GH]`
- **许可证**：MIT
- **技术栈**：Python（pyautogui 类控制）
- **活跃度**：**停滞（最后提交 2025-09-19）** `[GH]`
- **能当什么组件/能抄什么**：只抄「截图 → 坐标 → 动作」的最小闭环用于教学/原型；**不建议引入生产**。
- **集成坑**：直控宿主输入设备，无沙箱概念；无维护意味着新模型后端不跟进。

#### C2-5. Bytebot —— 自托管桌面 agent 容器（已归档，仅作参考）
- **链接**：https://github.com/bytebot-ai/bytebot
- **定位**：`docker-compose up` 起一个完整 Linux 虚拟桌面给 agent 用（浏览器、文件系统、密码管理器、任意应用）。
- **约 star**：11,072 `[GH]`｜**许可证**：Apache-2.0｜**活跃度**：**已归档（archived），最后提交 2025-09-11** `[GH]`
- **能当什么组件/能抄什么**：抄「agent 拥有自己的整台虚拟桌面」这一产品形态（与 cua 路线互补）；**归档状态 = 不要依赖**。
- **集成坑**：归档项目无安全修复；VNC/桌面直连的暴露面大。

---

## D. 工具执行栈：推荐组合（对应五项硬需求）

> 设计原则：**每一层都可替换（adapter 接口）+ 默认最小权限 + 密钥永不进入模型上下文与沙箱**。以下组合全部为「已验证存在的开源/可自托管件」，标注缺口与替代。

### D1. 需求映射

| 需求 | 首选 | 备选/兜底 | 关键缺口（要自研） |
|---|---|---|---|
| **① MCP 生态接入** | 官方 SDK + 官方 Registry 元数据对齐；`MCP Inspector` 调试 | Docker MCP Gateway（容器化 + 审批）；IBM ContextForge（REST→MCP 转换）；Executor（自托管集成目录） | 工具**路由/筛选**（tool router / tool search）；schemas 收窄；多 server 生命周期管理 |
| **② 工具授权与密钥隔离** | Nango 模式（自托管 OAuth broker，注意 Elastic License）或 Executor 的 per-tool policy | Composio（托管、快省事，合规受限）；Arcade | **凭证保险库 + egress 代理注入 + 审批流 + 审计**（三件套开源件普遍缺失，必须自建） |
| **③ 不可信代码安全执行** | 单机：**microsandbox**；云：**E2B 自托管（Firecracker）** | 轻量约束：`srt`/`nsjail`/`bubblewrap`；规模化替换后端：Firecracker/gVisor/Kata；片段执行：Piston | 池化调度、快照编排、网络出口策略、资源计费 |
| **④ 浏览器操作** | **Playwright MCP**（结构化默认） | Stagehand（混合控制/自愈）；browser-use（高自主）；Skyvern（视觉/AGPL 慎用） | 浏览器会话隔离（容器 + profile + 出口代理）、并发池化、验证码/风控策略 |
| **⑤ 计算机操作** | **Cua**（VM 底座 + 驱动） | UI-TARS / Agent TARS（grounding + reflection）；Midscene（移动端） | VM 编队管理、动作白名单/确认门、截图审计与回滚 |

### D2. 分层架构（建议实现顺序）

```
┌──────────────────────────────────────────────────────────────┐
│  L5 策略与审计：per-tool policy（默认拒绝）→ 人工审批 → 全量审计日志   │
├──────────────────────────────────────────────────────────────┤
│  L4 工具层：MCP 客户端 → 工具路由（按意图筛选，防上下文爆炸）→ 技能包     │
│      （SKILL.md 渐进披露；技能不扩权）                          │
├──────────────────────────────────────────────────────────────┤
│  L3 接入与凭证：MCP 网关（容器化 server / REST→MCP）              │
│      + 凭证代理：OAuth 连接 → 短期令牌 → egress 代理注入           │
│      （模型/沙箱只见「工具名+参数」，永不见原始密钥）                │
├──────────────────────────────────────────────────────────────┤
│  L2 交互面：浏览器工具（Playwright MCP / Stagehand）              │
│      + 计算机操作（Cua VM / UI-TARS），全部跑在隔离会话里           │
├──────────────────────────────────────────────────────────────┤
│  L1 执行沙箱：microsandbox（本机微 VM）→ E2B 自托管 / Firecracker  │
│      兜底轻量层：srt / nsjail / bubblewrap 包住 agent 自身         │
├──────────────────────────────────────────────────────────────┤
│  L0 基础设施：宿主/云 VM、镜像与快照、网络出口控制、KVM/嵌套虚拟化验证  │
└──────────────────────────────────────────────────────────────┘
```

实现顺序建议：
1. 先做 **L1 轻量层**：用 `srt`（或 Linux 下 `bubblewrap`+`nsjail` 自组）把自家 agent 的所有 exec 调用白名单化——一天内就有收益，防手滑。
2. 再做 **L4 工具路由 + L5 策略**：工具注册表带 `readonly/destructive/network` 等权限标签，路由层按任务筛工具；策略默认拒绝、危险动作要审批。**这一步是自研系统超越裸 Hermes 的关键差异点。**
3. 再做 **L3 凭证代理**：所有外部 API 走集中 broker（OAuth 刷新、令牌注入、scope 收敛、审计），模型侧只给「连接引用」。
4. **L1 强隔离**：`microsandbox` 跑不可信代码（验证 `/dev/kvm`）；上云后换/加 E2B 自托管。
5. **L2 交互面**：Playwright MCP 起步，按需加 Stagehand 自愈与 Cua VM。
6. 规模化时把沙箱后端抽象成 driver（microsandbox / E2B / Firecracker / Kata 四实现），这一层留好接口，**吸取 Daytona 教训**。

### D3. 为什么是这几件（一句话理由）

- **srt**：唯一「官方级、跨 macOS/Linux、配置化、代理级网络白名单」的 agent 自约束盒，Apache-2.0，且被微软 fork 采用。
- **microsandbox**：本地就把「微 VM 隔离 + secrets 不进 VM + fork/snapshot + OCI 兼容 + 内建 MCP」打包齐了，Apache-2.0，单机不可信代码的最短路径。
- **E2B**：Apache-2.0 全栈可自托管 + Firecracker 真隔离 + 已被验证的 pause/resume 语义；是企业化前的最佳云底座。
- **Playwright MCP**：微软维护、无障碍树 = token 经济 + 确定性，是浏览器工具的「默认正确答案」。
- **Cua**：把「computer use 必须跑在 VM 里」工程化，含跨 OS 与基准，MIT。
- **Executor / Docker MCP Gateway / Nango**：分别覆盖「自托管集成目录」「容器化 server + 审批」「OAuth 连接编排」三个自研刚需模块的开源参考。
- **技能层用 agentskills 规范 + addyosmani/agent-skills 做种子**：格式开放（Apache-2.0 规范仓），质量样例丰富，渐进披露机制必须抄。

---

## E. 可抄模式清单（跨项目提炼）

1. **渐进式披露**（Agent Skills 三级加载）：元数据常驻（~100 token/项）→ 命中加载正文 → 脚本/参考按需读。适用于工具、技能、文档一切「many small capabilities」场景。
2. **工具路由/tool search**（Composio Tool Router、browser-harness 的自注册工具）：按意图动态挂载工具，替代「全量入 prompt」。这是上下文爆炸的正解。
3. **凭证代理 + egress 注入**（Cloudflare Sandboxes、microsandbox、Nango、Executor）：密钥只存在于代理层，出站时注入；模型与沙箱只见占位符。**Sandbox 泄露内存也读不到密钥**（Daytona 2026-04 事故的教训）。
4. **per-tool 策略 + 审批门**（Docker MCP Gateway、Executor）：工具粒度声明权限，危险调用走人工确认；技能/插件**不能自扩权**。
5. **沙箱分层与可替换 driver**（E2B/microsandbox/Daytona 教训）：L0 约束 → L1 本地微 VM → L2 云微 VM；统一 `create/exec/upload/snapshot/pause/kill` 接口。
6. **快照 / fork / standby**（microsandbox fork、E2B pause、Blaxel standby、Cua VM 回滚）：状态复用 = 延迟与成本双降；GUI/浏览器 agent 的「保险丝」。
7. **结构化优先、视觉兜底**（Playwright MCP vs Stagehand/Skyvern/UI-TARS）：确定性路径用 DOM/代码，脆的地方才交给模型；行动后**截图对比 + 重规划**（UI-TARS reflection）显著提升可靠性。
8. **技能即「指令 + 可执行资源 + 权限声明」**（anthropics/skills 结构 + microsandbox 技能包）：skill 的执行面必须过沙箱与策略，而不是当作纯 prompt。

---

## F. 风险与坑（汇总，选型时逐条打勾）

**许可证风险（分发/商用前必查）**
- **AGPL-3.0**：Skyvern、Smithery CLI —— SaaS 网络条款触发开源义务。
- **GPL-3.0**：Judge0 CE —— 传染性；闭源产品慎入。
- **Elastic License 2.0**：Nango —— 可自用，**禁止作为托管服务对外提供**。
- **source-available（非开源）**：anthropics/skills 的 docx/pdf/pptx/xlsx；「参考可以，照搬不行」。
- **许可字段缺失**：daytonaio/daytona 仓库已归档、license 为空 `[API]` —— 老版本 AGPL 说法仅存于社区记录，勿当依据。
- **混许可仓**：anthropics/skills（Apache-2.0 与 source-available 混装）、cua（仓库 MIT 但内页有 artifact-specific 表述）——逐目录核对。

**供应链/信任风险**
- MCP 生态：注册中心与清单**均不做安全审计**；Smithery 有路径穿越历史 + 第三方扫描发现 22/100 server 有安全问题；**stdio server 与 agent 同权限**，投毒即宿主沦陷 → 所有第三方 server 进容器、限权、限网络。
- 社区技能同风险：SKILL.md 里的 scripts 就是代码，按不可信代码对待。
- 老教程污染严重：Daytona「开源」、Open Interpreter 的旧包名/定位、bytebot 仍在被推荐（实为归档）——所有二手清单都要回源验证。

**工程坑**
- 嵌套虚拟化：microsandbox/Firecracker/Kata 需要宿主 KVM/HVF 直通，云 VM 里默认可能没有 → 先验证再选型。
- 共享内核 ≠ 硬件隔离：bubblewrap/nsjail/Docker 提升成本但拦不住内核漏洞；不可信代码只放 microVM。
- 无文档的 Apple 原语：sandbox-exec/Seatbelt 无正式支持，跨平台必须双后端。
- 浏览器会话隔离与并发：浏览器跑宿主时，profile、剪贴板、扩展、出口网络都是泄漏面；并发 agent 必须池化。
- 上下文与成本：工具全量挂载、视觉截图流、自主浏览器循环是三大 token 黑洞——只能靠路由、结构化快照、步数/成本上限压制。

---

## G. 附录

### G1. 核实方法
- `[API]`（6 次预算内）：daytonaio/daytona、e2b-dev/E2B、browser-use/browser-use、microsoft/playwright-mcp、ComposioHQ/composio（另有一次重定向失败，未计入有效结果）。
- `[GH]`：其余全部条目通过 github.com 仓库页（star/归档/license 字段）与 `commits.atom`（最后提交时间）当日直读；许可文件（MIT/AGPL/BSD/Elastic/LGPL）通过 `raw.githubusercontent.com` 的 LICENSE/COPYING 文件直读确认。
- 「第三方资料」仅用于产品行为描述（E2B 会话上限、Daytona 闭源时间线、Smithery 规模与安全扫描），已在文中标注。
- 未核实项：ComposioHQ/awesome-claude-skills 许可证、Composio 自托管结论、Daytona 历史 AGPL、部分模型权重许可。

### G2. 参考素材
- wincent《Coding Agent Sandboxes》gist（2026-05 汇编）：https://gist.github.com/wincent/2752d8d97727577050c043e4ff9e386e
- Blaxel《Code execution sandboxes for AI agents》对比（2026-08 更新口径）：https://blaxel.ai/blog/code-execution-sandboxes-for-ai-agents
- Anmol Baranwal《Open Source Toolkit for Building AI Agents in 2026》：https://dev.to/anmolbaranwal/open-source-toolkit-for-building-ai-agents-in-2026-55h1
- Agent Skills 规范：https://agentskills.io ｜ Anthropic 工程博客《Equipping agents for the real world with Agent Skills》
- MCP 注册中心对比（第三方）：callsphere.ai / truefoundry.com 的 2026 registry 评测；GitGuardian《Breaking MCP Server Hosting》


---

# 04 · 模型接入 / 路由 + 可观测性 + 评测 —— 开源组件调研

> **调研时间**：2026-10-14（UTC）｜**簇范围**：多模型接入/路由网关、本地推理引擎、LLM/Agent 可观测性、评测框架与基准。
> （框架/记忆/工具沙箱/交互调度/安全基建见 01/02/03/05/06 区，本文不交叉。）
>
> **星标核实方式**：6 个关键仓库经 `api.github.com` 于 2026-10-14 实测，标注"**已核实**"；其余经 ungh.cc 镜像实测（标注"**镜像核实**"，可能存在小时级延迟）。许可证优先按仓库 `LICENSE` 原文核实。
>
> **收录规则**：真实存在且 2024 年后活跃；**⚠️ 表示已停更/下线/风险项**，保留仅作参考。闭源 SaaS（OpenRouter、LangSmith、Braintrust 等）不在收录范围。收购/合并后许可证可能变化，落地前请复核。

## 0. 结论速览（一句话选型）

| 层 | 首选 | 备选 | 一句话理由 |
|---|---|---|---|
| 多 provider 统一网关 | **LiteLLM**（61k★） | Portkey Gateway / Helicone | provider 覆盖、预算熔断、callbacks 生态最全 |
| 本地推理 | **vLLM**（服务端）+ **Ollama**（开发机） | SGLang / llama.cpp / LMDeploy | OpenAI 兼容，云/本一体切换 |
| 可观测 | **Langfuse** 自托管（36k★） | Opik / Phoenix（⚠️ ELv2） | OTel 原生 + trace→评测闭环 + prompt 管理 |
| 埋点 | Langfuse SDK 或 OpenLLMetry（**二选一，勿双挂**） | OpenInference | 一次埋点多处复用 |
| CI 回归 | **promptfoo**（26k★） | DeepEval（指标级单测） | 分钟级、YAML、产出可存档重放 |
| 深度评测 | **Inspect AI + inspect_evals** | 官方 harness（SWE-bench / Terminal-Bench·Harbor / τ²-bench） | 一套框架跑全部基准，自带沙箱与日志 |

> ⚠️ **三个先记住的雷区**：**Phoenix 是 Elastic License 2.0（非 OSI 开源）**；**RouteLLM 停更约 2 年**；**Lunary 主仓库与 GAIA 的 GitHub 仓库均已下线（404，2026-10-14 实测）**。

---

## 1. 多模型接入与路由（Gateway / Router）

### 1.1 LiteLLM —— 统一网关 + 成本账本的主力
- **链接**：https://github.com/BerriAI/litellm
- **定位**：100+ provider 统一 OpenAI 兼容接口。两种用法：Python SDK（进程内）与 Proxy 网关（独立服务，带 virtual key、预算、限流、UI）。
- **Star**：**61,263**（2026-10-14 经 api.github.com 已核实）
- **许可证**：**MIT（核心）+ 商业（enterprise/ 目录）**。根 LICENSE 原文："`enterprise/` 目录下内容按 `enterprise/LICENSE` 授权"——即 BerriAI Enterprise License（商业授权）；其余部分 MIT。GitHub 显示 NOASSERTION 即因双许可并存。
- **技术栈**：Python（FastAPI、Pydantic）；可选 Postgres（预算/用量/密钥）、Redis（缓存/限流）；另有 TS SDK。
- **活跃度**：2026-10-14 当日推送；发版与社区极活跃。
- **能当什么组件**：agent 主循环的**唯一模型出口**——fallback 链、按 tag/权重路由、超时重试、预算熔断、**成本账本**；**success/failure callbacks 是接可观测后端（Langfuse 等）最省力的埋点**（一次配置、全量落库）；streaming 全透传。
- **能抄什么**：virtual key/预算数据模型、模型定价表（cost map）、provider 适配与参数转义层、路由 DSL。
- **集成坑**：① Proxy 模式多一跳开销（部署位置决定，需实测）；② 各 provider 的流式 tool_calls / reasoning 字段差异需逐家实测；③ SSO/RBAC/审计等企业功能闭源；④ 迭代快、偶有破坏性变更，生产 pin 版本；⑤ 自托管把 Postgres/Redis 变成隐性运维成本。

### 1.2 Portkey AI Gateway —— 低延迟 TS 网关 & guardrails 体系
- **链接**：https://github.com/Portkey-AI/gateway
- **定位**：TypeScript/Node 高性能 AI Gateway：1,600+ 模型（250+ LLM 供应商），内置 50+ guardrails；统一 API + 权重/fallback/缓存/超时；可部署为 Node 服务/容器（可上边缘）。
- **Star**：约 **13.2k**（2026-10-14 经镜像核实）
- **许可证**：**MIT**（仓库 LICENSE 原文核实，© 2024 Portkey Inc）。⚠️ 注意：官方正在做 **Gateway 2.0——把企业版网关合并进开源**（pre-release 分支），合并后许可条款请按新版本复核。
- **技术栈**：TypeScript/Node；配置驱动（JSON：route→targets→fallback/cache/guardrails 插件）。
- **活跃度**：镜像显示默认分支最近推送 2026-05（合并期开发主要在 pre-release 分支），13k★ 级、社区活跃。
- **能当什么组件**：低延迟网关备选；**guardrails 插件体系（PII、提示注入检测等 50+）值得直接抄**；给多服务 agent 做统一出口时比 LiteLLM Proxy 更轻。
- **集成坑**：① 与 Python agent 主循环跨语言；② OSS 与商业平台的功能边界要自己拉清单；③ 插件行为差异大、测试成本；④ 2.0 迁移期注意版本节奏。

### 1.3 RouteLLM ⚠️（停更）—— 只抄算法，别当依赖
- **链接**：https://github.com/lm-sys/RouteLLM
- **定位**：按查询难度在强/弱模型间路由（矩阵分解/BERT/因果分类器），LMSYS 研究项目，论文+训练脚本齐全。
- **Star**：约 **5.6k**（镜像核实）
- **许可证**：Apache-2.0（LICENSE 原文核实）
- **技术栈**：Python（PyTorch/transformers，2024 年的旧依赖栈）。
- **活跃度**：⚠️ **镜像显示最后推送 2024-08-10，约 2 年未更新**。
- **能当什么组件**：只作**算法参考**——"用便宜模型分流简单请求省成本"的可行性验证与 router 训练/评估方法可抄。
- **集成坑**：依赖 2024 年的 vLLM/transformers 版本；无维护；无 tool-calling 感知。生产建议：把"难度路由"思想用 LiteLLM 的规则路由 + 自训小分类器落地。

### 1.4 semantic-router —— 语义向量决策层
- **链接**：https://github.com/aurelio-labs/semantic-router
- **定位**：基于 embedding 的语义路由/意图分类/工具选择（不限于选模型），可挂向量库或接 LLM 做动态路由。
- **Star**：约 **3.9k**（镜像核实）
- **许可证**：MIT（原文核实，© 2026 Aurelio AI）
- **技术栈**：Python（sentence-transformers；可选向量库/LLM 增强动态路由）。
- **活跃度**：2026-09-29 推送，活跃。
- **能当什么组件**：主循环前置的"**意图→模型/工具**"分发层；可作为 LiteLLM 之上的动态路由补丁，或用于工具选择（参考 03 区工具集群）。
- **集成坑**：embedding 模型选型影响大；冷启动需要样本；推理多一次向量查询延迟；长尾/新意图泛化有限。

### 1.5 aisuite —— 极简多 provider SDK（参考向）
- **链接**：https://github.com/andrewyng/aisuite
- **定位**：Andrew Ng 团队的极简统一 SDK：`client.chat.completions.create(model="openai:gpt-…")` 风格，provider 前缀路由。
- **Star**：约 **16.3k**（镜像核实）
- **许可证**：MIT（原文核实，© 2024 Andrew Ng）
- **技术栈**：Python（极轻量 provider 适配器）。
- **活跃度**：2026-09-18 推送，中等。
- **能当什么组件**：**抄它的 API 设计**（provider 前缀、极简抽象）；教学/示例价值。**不适合当生产网关**。
- **集成坑**：无预算/限流/fallback/可观测、无 proxy 模式；生产特性薄。

### 1.6 Helicone —— 观测 + 网关一体
- **链接**：https://github.com/Helicone/helicone
- **定位**：LLM 可观测平台（Rust AI Gateway/代理 + Next.js 控制台）：日志、成本、缓存、限流、会话，兼做路由出口。
- **Star**：约 **6.2k**（镜像核实）
- **许可证**：Apache-2.0（LICENSE 原文核实）
- **技术栈**：Rust（代理）、TypeScript/Next.js、ClickHouse。
- **活跃度**：2026-10-10 推送，活跃。
- **能当什么组件**：想"一个系统同时解决日志+成本+缓存"时直接用其 Rust 代理；**成本计算/缓存命中实现值得抄**。与 LiteLLM **二选一**（叠两层代理无意义）。
- **集成坑**：① 模型支持面与路由能力不如 LiteLLM；② 自托管要跑代理+web+worker+ClickHouse 一整套；③ 云版与 OSS 功能边界需自查（未逐项核实）。

---

## 2. 本地推理引擎（Local Inference）

> 共同结论：**开发机用 Ollama、服务端用 vLLM 或 SGLang**；所有引擎都提供 OpenAI 兼容 endpoint，经 LiteLLM 统一接入后对上层 agent 透明——这就是"本地推理可选"的实现方式。

### 2.1 Ollama —— 开发机/端侧一键推理
- **链接**：https://github.com/ollama/ollama
- **定位**：本地一键跑模型（CLI + 常驻服务），OpenAI 兼容 API；Modelfile 管理；全平台。
- **Star**：**183,177**（2026-10-14 经 api.github.com 已核实）
- **许可证**：MIT（API 核实）
- **技术栈**：Go（推理内核基于 llama.cpp 系）。
- **活跃度**：2026-10-14 当日推送。
- **能当什么组件**：**开发/测试环境的本地 provider**；CI 中不需要 GPU 的冒烟回归；主循环里当"离线兜底模型"。
- **集成坑**：① 并发吞吐远低于 vLLM，**不要用于生产多请求**；② 拉模型依赖 registry 网络；③ 与生产引擎（vLLM/SGLang）的 tokenizer/采样细节有差异，评测结果别混口径。

### 2.2 llama.cpp —— C/C++ 推理与 GGUF 量化生态
- **链接**：https://github.com/ggml-org/llama.cpp
- **定位**：全平台（CPU/GPU/Apple Silicon）推理引擎，GGUF 量化模型事实标准；`llama-server` 提供 OpenAI 兼容。
- **Star**：约 **131,188**（镜像核实）
- **许可证**：MIT（原文核实，© 2023-2026 The ggml authors）
- **活跃度**：2026-10-14 当日推送，极活跃。
- **能当什么组件**：无 GPU 环境的评测/工具链验证；端侧模型部署；KV cache/投机解码等推理内核参考。
- **集成坑**：并发/长上下文 agent 负载需调优；量化有质量损失，评测口径要注明。

### 2.3 vLLM —— 生产级高吞吐服务
- **链接**：https://github.com/vllm-project/vllm
- **定位**：PagedAttention、连续批处理、前缀缓存、张量/流水并行的推理服务引擎；OpenAI 兼容 server。
- **Star**：**93,799**（2026-10-14 经 api.github.com 已核实）
- **许可证**：Apache-2.0（API 核实）
- **技术栈**：Python + CUDA kernels（PyTorch），多硬件后端。
- **活跃度**：2026-10-14 当日推送，极活跃。
- **能当什么组件**：自托管推理的**默认选型**；离线批量评测的推理后端；与 LiteLLM 组合成"统一入口→本地 GPU 池"。
- **集成坑**：① GPU 依赖重、部署运维成本高；② 版本间破坏性变更多，pin 版本；③ 显存/KV cache/并行参数调优门槛；④ 新特性（multi-LoRA、投机解码等）按版本核对。

### 2.4 SGLang —— agent 工作负载的吞吐王者候选
- **链接**：https://github.com/sgl-project/sglang
- **定位**：RadixAttention（前缀树缓存）+ 结构化输出（JSON schema/regex 约束解码）；多轮 agent 共享前缀场景吞吐/延迟常领先 vLLM。
- **Star**：约 **37,099**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **活跃度**：2026-10-14 当日推送，极活跃。
- **能当什么组件**：agent 场景的推理后端首选之一；**其"结构化生成"对工具调用可靠性的提升值得抄**。
- **集成坑**：部分新模型支持比 vLLM 晚；文档/生态相对年轻；API 与 vLLM 不完全对齐。

### 2.5 LMDeploy —— 量化部署工具箱
- **链接**：https://github.com/InternLM/lmdeploy
- **定位**：上海 AI Lab 推理工具箱：TurboMind 引擎、AWQ W4A16 量化、多模态；偏"部署套件"。
- **Star**：约 **8.1k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **活跃度**：2026-10-09 推送。
- **能当什么组件**：量化部署（AWQ）路线参考；国产硬件/内网环境适配。
- **集成坑**：社区规模小一档；更新节奏慢些。

---

## 3. 可观测性（LLM / Agent Observability）

> 先记三条硬事实：① 以下推荐项都支持自托管 + OTel 或 SDK 回调；② 埋点有三条路——框架回调（LiteLLM→Langfuse）、OTel 直传、SDK 装饰器；③ **OpenLLMetry 自动埋点与 Langfuse SDK 同开会重复上报，二选一**。

### 3.1 Langfuse —— 观测主后端（自托管首选）
- **链接**：https://github.com/langfuse/langfuse
- **定位**：LLM 工程平台：trace（OTel 原生）、评测、prompt 版本管理、数据集与 playground；官网口径 50,000+ 公司使用。
- **Star**：**35,829**（2026-10-14 经 api.github.com 已核实）
- **许可证**：**MIT（核心）+ 企业许可（ee/ 目录）**。仓库原文：核心 MIT，"外围部分（ee/）为商业许可"（含 RBAC/SSO/审计等）。**GitHub 显示 NOASSERTION 即因双许可**。
- **公司动态（重要）**：**2026-01 被 ClickHouse 收购**（与 $400M Series D 同时宣布），官方承诺 MIT/自托管/路线不变；2026-03 起数据模型向 ClickHouse 深化。长期选型时作为风险项记录。
- **技术栈**：TS/Next.js、Postgres、ClickHouse、Redis、S3（docker-compose / k8s 自托管）。
- **活跃度**：2026-10-14 当日推送，极活跃。
- **埋点成本（对自建主循环）**：**低**。三选一：Python/JS SDK `@observe` 装饰器；OTel OTLP 直传；**接 LiteLLM success/failure callback（一次配置，全量模型调用自动落库）**。
- **能当什么组件**：观测主后端 + **"trace→dataset→experiment"评测闭环**（生产失败案例直接变回归集）+ prompt 版本管理。
- **能抄什么**：trace/observation 数据模型（trace→span→generation/score）、"失败 trace 转数据集"工作流、prompt 编译（label 版本）。
- **集成坑**：① 自托管组件多（ClickHouse 资源占用/运维）；② v3 后是 OTel-first 架构，网上老教程会误导；③ EE 功能命名容易误当 OSS；④ 高吞吐下存储成本要预估。

### 3.2 Arize Phoenix —— 本地调试首选，⚠️ 许可注意
- **链接**：https://github.com/Arize-ai/phoenix
- **定位**：OTel 原生 tracing + evals 平台，本地单进程即可跑（pip 安装），适合开发期调试 RAG/agent。
- **Star**：约 **11.8k**（镜像核实）
- **许可证**：**Elastic License 2.0（ELv2）—— 非 OSI 开源**（仓库 LICENSE 原文核实）。可自用/内部修改；**不能作为托管服务提供给第三方、不能移除许可声明**。内部工具无碍，对外产品嵌入需法务评估。
- **技术栈**：Python(FastAPI) + Next.js UI；OpenInference instrumentation（Apache-2.0，**可独立于 Phoenix 使用**）；存储 DuckDB/Postgres。
- **活跃度**：2026-10-14 当日推送，活跃。
- **埋点成本**：低~中。OpenInference 自动埋点覆盖主流框架（LangChain/LlamaIndex/OpenAI 等）；手动 span API 简洁。
- **能当什么组件**：开发期本地观测（起本地后端看一眼 trace）；生产规模化不如 Langfuse。**OpenInference 埋点包（Apache-2.0）可以单独抄用**。
- **集成坑**：① ELv2（见上）；② UI/API 迭代快；③ 规模化持久化配置。

### 3.3 OpenLLMetry（Traceloop）—— 纯埋点层（后端无关）
- **链接**：https://github.com/traceloop/openllmetry
- **定位**：**OTel instrumentation 库集**（Python/TS），不绑定后端——发给任何 OTLP 后端（Langfuse/ClickHouse/Tempo…）。
- **Star**：约 **7.5k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **活跃度**：2026-10-13 推送。
- **能当什么组件**：想"**换观测后端不换埋点**"就选它；monkey-patch 自动插桩覆盖面广（OpenAI/Anthropic/LangChain/LlamaIndex/CrewAI 等），加一行 init 就能全量采集。
- **能抄什么**：自动插桩的封装范式（零侵入埋点）。
- **集成坑**：① 自动埋点是黑盒，自定义属性要补手动 span；② 各框架大版本适配有滞后；③ GenAI Semantic Conventions 仍在演进，字段名会变，需锁版本；④ 与 Langfuse 原生 SDK 同开=重复上报。

### 3.4 Opik（Comet）—— 观测+评测一体化
- **链接**：https://github.com/comet-ml/opik
- **定位**：LLM 观测 + 评测 + guardrails 平台（Comet 出品），可自托管；社区增长快。
- **Star**：约 **22.6k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：Python + React；ClickHouse/MySQL/Redis。
- **活跃度**：2026-10-14 当日推送。
- **能当什么组件**：偏"评测驱动"团队的 Langfuse 平替；内置 LLM-judge 指标与数据集实验，**评估模板可抄**。
- **集成坑**：自托管组件数量与 Langfuse 类似；集成生态数量稍逊；由商业公司主导路线。

### 3.5 AgentOps —— agent 专用观测（事件模型值得抄）
- **链接**：https://github.com/AgentOps-AI/agentops
- **定位**：面向 agent 的可观测：会话回放（session replay）、step/tool 事件、成本、错误归因。
- **Star**：约 **5.9k**（镜像核实）
- **许可证**：MIT（原文核实）
- **技术栈**：Python SDK + 服务端（托管为主，支持自托管）。
- **活跃度**：镜像最后推送 2026-06-25，节奏一般。
- **能当什么组件**：其"**session/step/tool_call 事件模型**"对自建 agent 埋点设计有直接参考价值；SDK 装饰器接入快。
- **集成坑**：最强形态在 SaaS，自托管成熟度一般；数据出域顾虑；框架适配参差。

### 3.6 Lunary ⚠️（主仓库已下线）—— 不推荐新采用
- **链接**：https://github.com/lunary-ai/lunary **→ 404（2026-10-14 实测）**；官网 lunary.ai 仍在线（企业向 SaaS）。
- **结论**：开源侧已不可用/不可复现（组织仅剩 SDK 子仓库），**不纳入选型**；有历史依赖的迁往 Langfuse/Opik。未能找到官方下线公告，作为事实记录。

---

## 4. 评测框架与基准（Eval）

> 分两层：**框架**（能把你自己的 agent 接进去跑回归）与**基准/数据集**（标准考卷）。
> 回归策略建议"快-慢"两档：**promptfoo/DeepEval 进 CI（分钟级）；Inspect+基准进夜间/周级（小时级、要 Docker，SWE-bench 级要磁盘）**。

### 4.1 Inspect AI（UK AISI）—— 深度评测主干
- **链接**：https://github.com/UKGovernmentBEIS/inspect_ai
- **定位**：英国 AI 安全研究院的评测框架：Dataset/Solver/Scorer 三件套 + 内置 agent 循环 + Docker 沙箱 + `inspect view` 日志查看器；可本地跑、可 CI；支持 OpenAI/Anthropic/Google/…/vLLM/Ollama 等众多 provider（PyPI 版本 0.3.268，2026-09）。
- **Star**：**3,005**（2026-10-14 经 api.github.com 已核实）
- **许可证**：MIT（API 核实）
- **技术栈**：Python（≥3.10，Pydantic）；Docker 用于沙箱。
- **活跃度**：2026-10-14 当日推送；公共资金支持、无商业平台绑定。
- **配套（强烈建议一起用）**：**inspect_evals**（https://github.com/UKGovernmentBEIS/inspect_evals ，约 704★ 镜像核实，MIT）——200+ 现成基准：**GAIA、SWE-bench、Cybench、Terminal-Bench（经 Inspect Harbor）** 等；截至 2026-09 注册 171 项。
- **能当什么组件**：自建 agent 的"考卷系统"——把你的 agent 包成 solver 跑全部标准基准；其 EvalLog 日志格式与沙箱管理可直接借鉴。
- **能抄什么**：solver/scorer 抽象、"评测即 Python 任务"的组织方式、日志（每条 sample 全记录，可重放）。
- **集成坑**：① 概念抽象要学一阵（solver/scorer/sandbox）；② 深度接 agent 需写 adapter（它默认"模型+solver"结构）；③ 跑基准要 Docker，SWE-bench 类吃磁盘（详见 4.6）。

### 4.2 promptfoo —— CI 回归闸门
- **链接**：https://github.com/promptfoo/promptfoo
- **定位**：CLI/Node 的评测 + 红队工具：YAML 定义用例，断言（含 LLM-rubric、自定义 JS/Python），多 provider 对比矩阵，CI 集成，web viewer；含红队扫描（OWASP LLM Top10 等）。
- **Star**：**26,000**（2026-10-14 经 api.github.com 已核实）
- **许可证**：MIT（API 核实）
- **技术栈**：TypeScript/Node（npm CLI/库）；自定义断言支持 JS/Python。
- **活跃度**：2026-10-14 当日推送，极活跃。
- **能当什么组件**：**回归测试闸门**（改 prompt/换模型/调工具就 `promptfoo eval` 对比基线）；评测输出 JSON 可存档、可复跑（失败的"重放"主要在它这层）；本地跑、零服务端。
- **集成坑**：① 粒度偏 input→output，**多轮 agent 轨迹**要用 custom provider/transforms 包一层；② 复杂断言仍要写脚本；③ Node 依赖（纯 Python 团队有摩擦）。

### 4.3 DeepEval —— "LLM 的 pytest"（指标级）
- **链接**：https://github.com/confident-ai/deepeval
- **定位**：50+ 指标（G-Eval、幻觉、回答相关性、**tool correctness、agentic task completion** 等），pytest 风格、本地跑。
- **Star**：约 **18.9k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：Python（pytest 风格插件）。
- **活跃度**：2026-10-12 推送。
- **能当什么组件**：单测级质量指标进 CI；**agentic 指标（任务完成度、工具调用正确性）的评估模板可抄**。
- **集成坑**：① LLM-judge 有成本与抖动（要 seed/多轮平均）；② 部分指标中文场景需自验；③ 商业公司主导（Confident AI），OSS/云边界注意。

### 4.4 RAGAS —— RAG 指标集 + 合成数据
- **链接**：https://github.com/explodinggradients/ragas
- **定位**：RAG 评测指标（faithfulness、context precision/recall、answer correctness 等）+ 合成测试集生成。
- **Star**：约 **16.0k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：Python（pip 包；指标依赖外部 LLM judge）。
- **活跃度**：镜像最后推送 2026-02-24，**活跃度走低**（用前看一眼仓库）。
- **能当什么组件**：知识库类 agent 的指标参考；**合成数据生成器可抄**。
- **集成坑**：依赖 judge 模型；API 迭代变动；只管 RAG、不等于 agent 全貌。

### 4.5 SWE-bench 官方 harness —— 编码 agent 的"真考卷"
- **链接**：https://github.com/SWE-bench/SWE-bench （原 princeton-nlp/SWE-bench 已重定向）
- **定位**：真实 GitHub issue 修复基准（harness + 数据集）：Docker 三层镜像（base→env→instance）、测试驱动判定、`swebench.harness.run_evaluation` 跑 predictions 文件；数据集分 full/Lite/Verified/Multimodal；文档在 swebench.com。
- **Star**：约 **6.0k**（镜像核实）
- **许可证**：MIT（原文核实）
- **技术栈**：Python（`swebench` 包）+ Docker（base→env→instance 三层镜像）。
- **活跃度**：2026-09-18 推送。
- **官方资源要求（文档口径）**：x86_64、≥120GB 磁盘、16GB 内存、8 核；arm64 仅实验性支持；`--max_workers` 建议 < min(0.75×CPU, 24)。
- **能当什么组件**：编码 agent 回归标尺；**环境快照/测试判定/补丁应用机制值得抄进自建回归**。另：inspect_evals 里有原生实现（默认用 Epoch AI 的 ghcr 预构建镜像，判定委托上游 harness）。
- **集成坑**：① 重（镜像多、耗时长、成本高）；② 镜像构建/网络问题多；③ **防泄漏**：任务可联网时 agent 可能读到你放盘的答案；④ 本地建议只跑子集（Verified/Lite 抽样）。

### 4.6 Terminal-Bench 2.0 + Harbor —— 终端 agent 基准
- **链接**：https://github.com/harbor-framework/terminal-bench （新主页，约 895★ 镜像核实，Apache-2.0）；https://github.com/laude-institute/terminal-bench （原仓库，约 2.6k★，2026-07 后低推送）；runner/框架：https://github.com/harbor-framework/harbor （约 **6.1k**★ 镜像核实，Apache-2.0，当日活跃）。
- **Star**：约 895（新主页）/ 约 2.6k（原仓库）/ 约 6.1k（Harbor）（均 2026-10-14 镜像核实）
- **许可证**：Apache-2.0（Harbor 与 terminal-bench 仓库标识；Harbor LICENSE 原文核实）
- **活跃度**：新主页与 Harbor 当日活跃；原仓库 2026-07 后低推送
- **定位**：Stanford × Laude Institute 的 CLI/终端 agent 基准：任务=自然语言指令 + Docker 沙箱 + pytest 式**终态验证**；**2.0 版经 Harbor 注册表分发**：`harbor run -d terminal-bench@2.0`；支持并行容器沙箱（Modal/Daytona 等）；ICLR 2026 论文（arXiv 2601.11868）。
- **能当什么组件**：终端/CLI agent 回归标尺；**"任务即代码"（说明+dockerfile+tests）的编写格式直接抄**；Harbor 作为通用"跑 agent 任务的 harness"值得研究。
- **集成坑**：① 版本迭代快（1.x→2.0 换了 harness，命令/数据集 ID 以最新文档为准）；② 需要容器基础设施；③ 任务质量持续修订中。

### 4.7 GAIA ⚠️（GitHub 仓库已下线）
- **现状**：github.com/gaia-benchmark/GAIA **已 404（2026-10-14 实测）**；官方载体现为 HuggingFace：数据集 `gaia-benchmark/GAIA`（**gated**，需账号申请）+ HF leaderboard space。
- **定位**：通用助手基准：450+ 题、3 档难度（L1/L2/L3）、多跳+工具+多模态；单轮、exact-match 判分；公开验证集约 165 题常被引用自测。
- **技术栈**：HuggingFace datasets（gated 数据集 + 评测 space）；无官方本地 runner。
- **能当什么组件**：通用 agent 能力标尺；**题目设计（多跳、文件处理）可抄**。
- **集成坑**：① **无官方本地 runner**（可用 inspect_evals 的 GAIA 实现）；② 数据集 gated/防爬；③ 判分严格（答案格式），自测易挫败。

### 4.8 WebArena —— 自托管 Web 环境基准
- **链接**：https://github.com/web-arena-x/webarena
- **定位**：仿真互联网（电商/论坛/CMS 等多站点自托管）+ 浏览器操作任务。
- **Star**：约 **1.6k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：Docker 编排的多站点 Web 应用 + 浏览器自动化（Playwright 系）。
- **活跃度**：镜像最后推送 2025-11-26，维护趋缓。
- **能当什么组件**：browser agent 评测环境蓝图（站点容器 + 浏览器控制）。
- **集成坑**：部署重、任务集年代偏旧、浏览器/网络不稳定导致 flaky。

### 4.9 OSWorld —— 真实 OS 内 computer-use 基准
- **链接**：https://github.com/xlang-ai/OSWorld
- **定位**：真实 OS（Ubuntu/Win/macOS）里 369 个 computer-use 任务；VM/VNC 基建。
- **Star**：约 **3.2k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：虚拟机 + Python 任务脚本 + VNC 观测。
- **活跃度**：2026-09-14 推送。
- **能当什么组件**：CUA（computer-use agent）评测；**VM 基建与任务脚本参考**。
- **集成坑**：重（VM×任务）、慢、结果方差大——建议抽样而非全量。

### 4.10 τ²-bench（Sierra）—— 多轮工具对话的"性价比最高"评测
- **链接**：https://github.com/sierra-research/tau2-bench （旧版：https://github.com/sierra-research/tau-bench ，约 1.5k★，2026-03 后低推送）
- **定位**：**工具-对话 agent 评测**：模拟用户 + 领域工具（airline/retail/telecom/banking 知识库），**校验数据库终态** + `pass^k` 可靠性指标；τ²（2025-06）引入 **dual-control**（用户也能改世界）；2026 年扩展语音（τ-voice）与 τ³ 修订；CLI `tau2 run/view`，**本地可跑（只需 LLM API）**；榜单 taubench.com。
- **Star**：约 **2.2k**（镜像核实）
- **许可证**：MIT（原文核实，© 2025 Sierra Research）
- **技术栈**：Python CLI（`tau2`）；agent 与被模拟用户均需 LLM API。
- **活跃度**：2026-10-14 当日推送，活跃。
- **能当什么组件**：**多轮 agent 回归的模板级参考**——任务生成器、用户模拟器、终态判定、pass^k 指标，全部可抄进自建评测体系。
- **集成坑**：① 需 LLM 模拟用户（成本）；② **用户模拟器自身有错误率**（论文报告 retail/airline 严重错误率 12~13%，telecom 域降至 6%）——结论要留误差意识；③ 域有限（客服场景为主）。

---

## 5. 集成对照：与自建 agent 主循环的埋点成本（Otel/回调）

| 组件 | 埋点机制 | 侵入度 | 流式请求 | 失败重放路径 |
|---|---|---|---|---|
| **LiteLLM** | 内置 callbacks / 请求日志 | 极低（网关一次性配置，**全量生效**） | 支持（流式透传+用量统计） | 请求日志可回放请求体（注意脱敏） |
| **Langfuse** | SDK `@observe` / OTLP / LiteLLM 回调 | 低 | 支持（含流式合并更新） | **trace→dataset→experiment**；playground 单条重发 |
| OpenLLMetry | OTel 自动插桩 | 最低（黑盒） | 支持 | 依赖所选后端 |
| Phoenix | OpenInference 自动 + 手动 span | 低 | 支持 | 本地日志/复跑 |
| Opik | SDK 装饰器 / 集成 | 低 | 支持 | 数据集实验 |
| AgentOps | 装饰器 | 低 | 支持 | session replay（SaaS 为主） |
| promptfoo | 黑盒外部测（不埋点） | 零 | 以最终输出为主 | **eval 输出 JSON 存档复跑** |
| Inspect AI | adapter 包装（日志=全记录） | 中（写 adapter） | 支持（事件流记录） | `inspect view` + 单样本重跑 |

**设计要点（可抄）**：
1. **一 trace 三层粒度**：session/trace → step（主循环每轮）→ generation（模型调用）+ tool_call；用 OTel GenAI conventions 打底，自加 agent 语义属性（task_id、step_index、retry_of）。
2. **成本双记账**：网关层（LiteLLM spend logs）管预算熔断，观测层（Langfuse）管归因分析；两边定期对账防漂移。
3. **失败重放闭环**：观测后端把 bad case 导出成数据集 → 转成 promptfoo/Inspect 用例 → CI 守门 → 修复后再回归。这是"观测"与"评测"两个集群唯一的正确连接方式。
4. **流式细节**：确认所选 SDK 在 streaming 下记录**完整** prompt/completion（如 Langfuse 的 generation 更新模式），否则重放价值大打折扣。
5. **埋点只挂一层**：网关回调（LiteLLM→Langfuse）与 SDK 装饰器**不重复**记录同一模型调用，避免双份数据。

---

## 6. 推荐组合（多 provider 统一 / 成本追踪 / 失败重放 / 回归测试 / 本地推理可选）

### 6.1 主组合（全自托管可行，个人→产品级均适用）

```
Agent 主循环
 ├─ 模型调用统一走 LiteLLM（Proxy 网关 或 进程内 SDK，二选一）
 │    ├─ 云端 provider：OpenAI / Anthropic / Gemini / …（OpenAI 兼容层转义）
 │    ├─ 本地 GPU：vLLM 或 SGLang（OpenAI 兼容 endpoint）
 │    ├─ 开发机：Ollama（同协议，随时切换）
 │    ├─ 策略：fallback 链 + 重试 + 预算/限流 + tag 路由
 │    ├─ callbacks → Langfuse（模型调用级 trace 起点）
 │    └─ spend logs → 成本账本（预算熔断在网关层）
 ├─ Agent 语义埋点：Langfuse SDK（@observe 包主循环与工具调用）；
 │    （若想后端无关：换 OpenLLMetry 自动埋点，二选一）
 ├─ 数据面：Langfuse 自托管（Postgres + ClickHouse + Redis + S3）
 └─ 评测三层：
      ├─ CI 快闸门（每次提交）：promptfoo（YAML 用例/断言/基线对比）+ DeepEval（pytest 指标）
      ├─ 深度回归（夜间/周级）：Inspect AI + inspect_evals
      │    ├─ GAIA 验证集子集（通用能力）
      │    ├─ SWE-bench Lite/Verified 抽样（编码）
      │    ├─ Terminal-Bench 2.0 抽样（CLI，经 Harbor/Inspect Harbor）
      │    └─ τ²-bench（多轮工具对话 + pass^k，最能反映 agent 真实质量）
      └─ 闭环：Langfuse 失败 trace → 数据集 → promptfoo/Inspect 用例
```

**逐项对照（parent 要求）**：
| 要求 | 方案 | 说明 |
|---|---|---|
| 多 provider 统一 | LiteLLM | 100+ provider、OpenAI 兼容、本地/云同口径 |
| 成本追踪 | LiteLLM spend logs + Langfuse 面板 | 网关管熔断、观测管归因，双记账互对账 |
| 失败重放 | Langfuse（trace→dataset/playground）+ promptfoo（eval 存档复跑）+ Inspect（单样本重跑） | 三层重放粒度 |
| 回归测试 | promptfoo/DeepEval（CI）+ Inspect+基准（夜间） | 快慢两档，成本可控 |
| 本地推理可选 | vLLM/SGLang（服务）+ Ollama（开发） | 全部经 LiteLLM 同一接口，随时切换 |

### 6.2 变体（按偏好替换）
- **轻量起步**：本地调试用 Phoenix（单进程）→ 上生产再换 Langfuse（注意 Phoenix 是 ELv2）。
- **评测驱动**：主观测后端直接用 Opik（观测+评测一体）。
- **TS 栈/边缘**：Portkey Gateway 替代 LiteLLM（2.0 合并后再评估）；网关+日志二合一可用 Helicone。
- **纯后端无关埋点**：OpenLLMetry → 自建 OTLP 收集器（ClickHouse/Tempo）→ 自看板。
- **中文/国产生态评测补充**：OpenCompass（约 7.5k★）、EvalScope（ModelScope，约 3.5k★），对本地/国产模型评测友好。

### 6.3 拍板清单（选型时明确的取舍）
1. **Langfuse vs Phoenix**：功能与规模化选 Langfuse（MIT 核心）；本地快速调试选 Phoenix（⚠️ ELv2 不可当托管服务转卖）。
2. **LiteLLM vs Portkey vs Helicone**：Python 生态+功能齐全 = LiteLLM；边缘低延迟 = Portkey；"网关+观测"二合一 = Helicone。**不要叠加多个代理**。
3. **Inspect vs promptfoo**：分工=深度/基准/沙箱 vs CI 快闸门/红队，**两个都上**。
4. **RouteLLM/semantic-router**：前者停更只抄思想；后者适合意图/工具路由，别指望单靠它大幅省钱。
5. **基准怎么选**：编码=SWE-bench 抽样 + Terminal-Bench；通用助手=GAIA（gated）；web=WebArena（重）；桌面=OSWorld（重）；**多轮工具对话=τ²-bench（投入产出比最高）**。
6. **Langfuse 归属 ClickHouse（2026-01）**：MIT/自托管承诺不变，但作为长期风险项记录；数据模型持续向 ClickHouse 深化。

---

## 7. 附录

### 7.1 其他值得一看（均已镜像核实，2026-10-14）
| 项目 | 链接 | 定位 | 约 star | 许可证 | 备注 |
|---|---|---|---|---|---|
| Bifrost | https://github.com/maximhq/bifrost | Go 高性能 LLM 网关 | 约 8.8k | Apache-2.0（原文核实） | 2026-10-13 推送，增长快 |
| LangWatch | https://github.com/langwatch/langwatch | 观测 + 评测/guardrail | 约 4.9k | Apache-2.0（原文核实） | 当日活跃 |
| Agenta | https://github.com/agenta-ai/agenta | 观测+评测+prompt 一体 | 约 4.8k | MIT + ee/ 商业（open-core，原文核实） | 当日活跃 |
| EvalScope | https://github.com/modelscope/evalscope | 模型评测（ModelScope） | 约 3.5k | Apache-2.0（原文核实） | 国产/本地模型友好 |
| OpenCompass | https://github.com/open-compass/opencompass | 模型评测 | 约 7.5k | Apache-2.0（原文核实） | 中文生态，当日活跃 |
| OpenInference | https://github.com/Arize-ai/openinference | OTel 埋点包（独立可用） | 约 1.3k | Apache-2.0（原文核实） | 配合任意 OTLP 后端 |
| inspect_evals | https://github.com/UKGovernmentBEIS/inspect_evals | Inspect 的基准套件库 | 约 704 | MIT（原文核实） | GAIA/SWE-bench/Cybench 等 200+ |

### 7.2 核实方法与信源
- **Star 核实**：6 仓库经 `api.github.com`（2026-10-14 UTC，本文档集群预算内）；其余经 ungh.cc 镜像。镜像有小时级延迟；停更/下线状态为实测（404/最后推送时间）。
- **许可证核实**：优先 curl 仓库 `LICENSE` / `ee/LICENSE` / `enterprise/LICENSE.md` 原文（Langfuse、LiteLLM、Phoenix、Portkey、Helicone、Bifrost、Agenta、Inspect 系、Harbor、SWE-bench、τ² 等均如此核实）。
- **关键信源**：
  - ClickHouse 收购 Langfuse：https://clickhouse.com/blog/clickhouse-acquires-langfuse-open-source-llm-observability
  - Langfuse 官方文档/仓库：https://langfuse.com/docs/observability/overview
  - Portkey Gateway 2.0 合并公告：https://github.com/Portkey-AI/gateway/discussions/1576
  - SWE-bench 官方文档（harness/资源要求）：https://www.swebench.com/SWE-bench
  - Terminal-Bench 论文（ICLR 2026）：https://arxiv.org/html/2601.11868v1 ；Harbor：https://harborframework.com/docs
  - τ²-bench/τ-voice 官方博客与榜单：https://sierra.ai/uk/blog/benchmarking-agents-in-collaborative-real-world-scenarios ；https://taubench.com
  - GAIA：https://huggingface.co/datasets/gaia-benchmark/GAIA
  - Inspect/Inspect Evals：https://www.aisi.gov.uk/blog/inspect-evals
- **未能核实项**：Lunary 的下线/整合背景（无官方公告）；Portkey 2.0 合并后的最终许可条款；各 SaaS 云版与 OSS 的功能边界明细。落地前请按当时仓库状态复核。

*（本文档为只读调研产物，未安装任何组件；所有星标/许可证/状态以 2026-10-14 实测为准。）*


---

# 05 · 交互层 / 消息通道 / 调度 / 语音 —— 开源组件调研

> 调研日期：2026-10-14（UTC）。本文件是 6 路并行调研的第 5 路，覆盖：聊天前端、终端 Agent、消息通道桥、整机助理参考、语音、调度/持久执行、通知。
> 不重复评估：框架编排（01）、记忆（02）、工具/沙箱（03）、模型/可观测（04）、安全/基建（06）。
>
> **核实方法（全文统一）**
> - ★ 数字：2026-10-14 从 GitHub 仓库页面 star 计数器抓取；其中 5 项另经 `api.github.com` 交叉核实（open-webui、wechaty、AstrBot、LangBot、ntfy，页面值与 API 值一致），标注「API 核实」；其余标注「页面核实」或「页面抓取（约）」。
> - 许可证：抓取仓库 `raw.githubusercontent.com` 的 LICENSE 原文判读，关键条款直接引用原文含义。
> - 活跃度：`commits.atom` 最新提交时间（默认分支）。
> - 收录规则：真实存在且 2024 年后仍活跃的项目为主；**已停更项目只作反面警示并明确标注**。
> - ⚠️ 标出「非标准开源 / 有附加限制」的许可证：Open WebUI 品牌条款、NapCat 自定义许可、Inngest（SSPL）、Restate（BSL）、Windmill（AGPL+专有组件）、LobeHub Community License、wechaty（第三方付费 Token 生态）。

---

## 0. 结论速览

**推荐组合（一句话）**：自研薄「Agent 网关（channel gateway）」统管各通道 → 调度用 **APScheduler 起步、Restate/DBOS 承接持久工作流**（重型备选 Temporal）→ 语音可选 **pipecat / LiveKit Agents** → 通知 **ntfy + Apprise**。

**最需警惕的雷区（按严重度）**
1. **NapCat（当前最好用的 QQ 协议端）自定义许可禁止商用、限制再分发** —— 产品化前必须联系作者授权，或换协议端路线（Lagrange/LuckyLilliaBot，但各有许可/维护问题）。
2. **Open WebUI ≥50 用户（滚动 30 天）禁止去除/修改 "Open WebUI" 品牌**（v0.6.6 起，2025-04-19）；白标商用需企业授权。
3. **Fair-code 类许可**：Inngest = SSPL（非 OSI 开源）；Restate = BSL 1.1（自用免费、禁止做公共托管平台）；Windmill 社区版 = AGPLv3 + 专有发行物。
4. **停更/半停更**：go-cqhttp（2024-05 停，QQ 协议封禁）、Vocode（2024-11 后无提交）、wechaty 核心仓（2025-12 后无提交）、aider / Ultravox / Chainlit / Continue（节奏明显放缓）。
5. 非官方协议通道（QQ 注入、WhatsApp 网页协议、微信个人号）**全部有封号与合规风险**，务必专用小号 + 隔离部署。

---

## 1. 聊天前端（Web 端 / 产品级 UI）

### 1.1 Open WebUI
**Open WebUI** ｜ [open-webui/open-webui](https://github.com/open-webui/open-webui) ｜ ★155,699（API 核实）
- 定位：自托管多模型聊天前端 / 一站式 AI 平台（Ollama 与 OpenAI 兼容后端）。
- 许可：⚠️ **Open WebUI License**（= BSD-3-Clause + 品牌保护条款）。条款要点（LICENSE 原文）：v0.6.6（2025-04-19）起，任何部署/分发不得删除、遮挡、替换 "Open WebUI" 品牌（名称、Logo、界面标识），除非 ① 滚动 30 天内终端用户 ≤50 人，② 获得书面许可，③ 持有企业许可；否则构成重大违约。贡献需签 CLA；**≤v0.6.5 的代码仍为 BSD-3，可无限制 fork**。
- 技术栈：Python（FastAPI）+ Svelte；Docker 单镜像可跑。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：「开箱即用 Web 门面」性价比第一：用户/权限、多模型路由、RAG/文件、PWA、OpenAI 兼容 API 层，把后端换成你的 agent 即可先用起来；可抄其插件钩子（Functions）与模型配置体验。
- 集成坑：品牌条款（白标/商用需企业授权，产品级自研要提前决策）；版本迭代快、破坏性变更常有；企业功能闭源；对「agent 工具审批流/长任务」展示能力弱。

### 1.2 LibreChat
**LibreChat** ｜ [LibreChat-AI/LibreChat](https://github.com/LibreChat-AI/LibreChat)（原 danny-avila/LibreChat，已迁移组织） ｜ ★45,693（页面核实）
- 定位：ChatGPT 式多供应商聊天平台（Agents、MCP、多用户、预设/分享）。
- 许可：MIT。
- 技术栈：TypeScript（Node + React）+ MongoDB。
- 活跃度：高（2026-10-06）。
- 组件/可抄：多供应商配置中心、Agents + MCP 集成、按用户/按模型限流、对话分享；比 Open WebUI 更"多用户 SaaS 化"。
- 集成坑：组件较重（Mongo，可选 Redis）；Agents 深度编排不如专用框架；组织迁移需更新链接。

### 1.3 LobeChat（现 lobehub/lobehub）
**LobeChat / LobeHub** ｜ [lobehub/lobehub](https://github.com/lobehub/lobehub)（原 lobehub/lobe-chat，仓库已合并更名） ｜ ★83,237（页面核实）
- 定位：现代设计聊天 UI，现定位升级为「Agent 运营平台」（页面标题与描述已改为 LobeHub "Chief Agent Operator"）。
- 许可：⚠️ **LobeHub Community License**（"based on Apache License 2.0 with additional conditions"，附加条款未逐条核实，采用前读全文）。
- 技术栈：Next.js / TypeScript。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：UI/主题/多端体验、插件与市场设计、模型供应商配置体系。
- 集成坑：不是纯 Apache-2.0（有附加条款）；仓库合并/品牌调整进行中；开源版与官方云服务存在功能落差。

### 1.4 Chainlit
**Chainlit** ｜ [Chainlit/chainlit](https://github.com/Chainlit/chainlit) ｜ ★12,518（页面核实）
- 定位：Python 对话式 AI 应用框架（几分钟给 agent 套上对话 UI）。
- 许可：Apache-2.0。
- 技术栈：Python（装饰器式 API）。
- 活跃度：中（2026-08-26 后暂无提交）；⚠️ 治理风险：2025 年官方停止 Literal AI（服务 2025-10-31 关停）并**公开寻找 Chainlit 新维护者**，处于"社区接棒期"。
- 组件/可抄：`@cl.on_message` 极简模型、Step/元素 UI、与 Python 生态（LangChain 等）的即插即用。
- 集成坑：生产化薄弱（多租户/鉴权/横向扩展有限）；维护权交接未完成，长期支持不确定；仅适合原型与内部工具。

### 1.5 assistant-ui
**assistant-ui** ｜ [assistant-ui/assistant-ui](https://github.com/assistant-ui/assistant-ui) ｜ ★12,541（页面核实）
- 定位：React/TypeScript 聊天 UI 组件库（"AI 聊天界的 shadcn"）。
- 许可：MIT。
- 技术栈：TypeScript / React。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：流式消息渲染、线程列表、输入框/附件/工具调用状态展示等成套组件——自研 Web 前端时直接薅。
- 集成坑：纯前端库，需自建后端协议层（配合 Vercel AI SDK 或自研 SSE）；迭代快。

### 1.6 Vercel AI SDK
**Vercel AI SDK** ｜ [vercel/ai](https://github.com/vercel/ai) ｜ ★27,317（页面核实）
- 定位：TypeScript AI 应用工具包（模型抽象 + 流式 UI 协议）。
- 许可：Apache-2.0。
- 技术栈：TypeScript（core + React/Vue/Svelte 绑定 + 服务端）。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：**UI Message Stream 协议**（前后端流式契约，含工具调用中间态）是行业事实标准之一，建议自研系统直接对齐它；多 provider 抽象与类型安全工具定义也值得照搬。
- 集成坑：主战场 TS，Python 后端需自行实现等价协议；大版本升级协议有变更，锁版本。

### 1.7 CopilotKit
**CopilotKit** ｜ [CopilotKit/CopilotKit](https://github.com/CopilotKit/CopilotKit) ｜ ★38,013（页面核实）
- 定位：应用内 Agent/Copilot 前端栈（AG-UI 协议、Generative UI、前端共享状态）。
- 许可：MIT。
- 技术栈：TypeScript / React + 自托管 Runtime。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：**agent ↔ 前端的交互协议（AG-UI）**：状态同步、前端动作调用、组件级生成式 UI——做「产品级交互」时是最全面的参考。
- 集成坑：绑定 React 生态；runtime 需自托管；协议仍在快速演进，跟进成本高。

---

## 2. 终端侧（CLI/TUI，可直接复用或抄设计）

### 2.1 opencode
**opencode** ｜ [anomalyco/opencode](https://github.com/anomalyco/opencode)（原 sst/opencode，SST 团队已更名 Anomaly） ｜ ★213,518（页面核实）
- 定位：开源终端编码 Agent（TUI 客户端 + 本地 server 架构）。
- 许可：MIT。
- 技术栈：TypeScript + Go（TUI）。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：**「TUI ↔ 本地 server」分层**（多客户端/多会话共享、会话持久化）、工具审批/权限 UI、provider 无关配置——终端交互层的头号参考，也可直接当现成 CLI 使用。
- 集成坑：组织更名史（sst→anomalyco、与已归档的 opencode-ai/opencode 易混淆）；产品节奏极快。附注：原版 [opencode-ai/opencode](https://github.com/opencode-ai/opencode) ★13,808，**已归档（2025-09）**，勿选用。

### 2.2 aider
**aider** ｜ [Aider-AI/aider](https://github.com/Aider-AI/aider) ｜ ★49,550（页面核实）
- 定位：终端 AI 结对编程（repo-map、diff 式编辑、git 自动提交）。
- 许可：Apache-2.0。
- 技术栈：Python。
- 活跃度：⚠️ 放缓（2026-05-22 后无提交，页面核实）。
- 组件/可抄：repo-map（代码库结构图）、edit formats、每次修改自动 commit 的纪律——经典设计仍值得抄。
- 集成坑：维护节奏放缓，作为参考而非核心依赖。

### 2.3 goose
**goose** ｜ [aaif-goose/goose](https://github.com/aaif-goose/goose)（原 block/goose） ｜ ★55,287（页面核实）
- 定位：local-first 通用 AI Agent（CLI + 桌面双端）。
- 许可：Apache-2.0。
- 技术栈：Rust。
- 活跃度：极活跃（2026-10-14 当日有提交）；治理：**2026-04 由 Block 捐赠给 Linux Foundation 旗下 Agentic AI Foundation（AAIF）**。
- 组件/可抄：extensions/MCP 生命周期管理、recipes（可复用任务配方）、本地优先架构与权限模型。
- 集成坑：治理迁移期路线待观察；Rust 栈与 Python 网关集成需 RPC/子进程方案。

### 2.4 Continue
**Continue** ｜ [continuedev/continue](https://github.com/continuedev/continue) ｜ ★36,225（页面核实）
- 定位：IDE + CLI 编码助手（配置驱动的模型/规则/上下文）。
- 许可：Apache-2.0。
- 技术栈：TypeScript。
- 活跃度：中（2026-07-21 后无提交，页面核实）。
- 组件/可抄：config.yaml 式统一配置（models / rules / context providers）、IDE 与 CLI 共享内核的双形态设计。
- 集成坑：重心仍在 IDE 插件；headless/CLI 场景成熟度不如 opencode；节奏放缓。

---

## 3. 消息通道桥（QQ / TG / Discord / Slack / WhatsApp / Signal / Matrix / 客服）

### 3.1 官方 Bot SDK

**python-telegram-bot** ｜ [python-telegram-bot/python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot) ｜ ★29,516（页面核实）
- 定位：Telegram 官方 Bot API 的 Python 封装（事实标准）。
- 许可：LGPL-3.0（README/PyPI 元数据声明；⚠️ 仓库 LICENSE 文件为 GPLv3 全文，两处文本不一致，法务敏感场景留意）。
- 技术栈：Python（async）。
- 活跃度：高（2026-10-11）。
- 组件/可抄：handler 分组、ConversationHandler（FSM）、消息/媒体处理；直接用作 TG 通道适配器。
- 集成坑：Bot API 限制（读不到其他 bot 消息、callback 超时）；LGPL 对"修改库本身并分发"有传染，正常依赖使用无碍。

**aiogram**（补充） ｜ [aiogram/aiogram](https://github.com/aiogram/aiogram) ｜ ★5,892（页面抓取）
- 定位：另一主流 TG Bot 框架（路由/中间件/FSM 更 Pythonic）。
- 许可：MIT；技术栈：Python asyncio；活跃度：高（2026-10-11）。
- 组件/可抄：middleware 体系与依赖注入设计。
- 集成坑：生态小于 PTB，二选一即可。

**discord.py** ｜ [Rapptz/discord.py](https://github.com/Rapptz/discord.py) ｜ ★16,197（页面核实）
- 定位：Discord Bot 标准库。
- 许可：MIT；技术栈：Python；活跃度：中（2026-09-01）。
- 组件/可抄：cogs/extensions 插件模型、事件分发；直接用作 Discord 通道适配器。
- 集成坑：Message Content 等特权 intent 需申请；**不可用于个人账号自动化（违反 ToS）**；限流与断线恢复逻辑复杂。

**Slack Bolt**（bolt-python ★1,329 页面核实 / bolt-js ★约2,948 页面抓取） ｜ [slackapi/bolt-python](https://github.com/slackapi/bolt-python)、[slackapi/bolt-js](https://github.com/slackapi/bolt-js)
- 定位：Slack 官方 app 框架（Python/JS 双版本）。
- 许可：MIT；技术栈：Python / TypeScript；活跃度：高（2026-10-09）。
- 组件/可抄：Socket Mode（开发期免公网）、Block Kit、OAuth 安装流。
- 集成坑：需工作区管理员安装审批；企业分发审核；消息格式（Block Kit）与通用 Markdown 转换成本。

### 3.2 非官方协议通道（封号/合规风险，务必隔离部署）

**Baileys** ｜ [WhiskeySockets/Baileys](https://github.com/WhiskeySockets/Baileys) ｜ ★11,340（页面核实）
- 定位：WhatsApp Web 多设备协议的纯 WebSocket TS 实现（无需浏览器）。
- 许可：MIT；技术栈：TypeScript/Node；活跃度：中（2026-08-04）。
- 组件/可抄：协议级实现（无 Selenium/Puppeteer）、多设备配对（二维码）、auth state 持久化模式。
- 集成坑：**非官方渠道 → 封号风险**；协议随 WA 更新漂移；商用应走官方 Cloud API。

**wppconnect** ｜ [wppconnect-team/wppconnect](https://github.com/wppconnect-team/wppconnect) ｜ ★3,472（页面核实）
- 定位：Puppeteer 驱动 WhatsApp Web 的开源实现（Baileys 的浏览器方案替代）。
- 许可：⚠️ **LGPL-3.0**（不是 Apache，原文确认）；技术栈：TypeScript + Puppeteer；活跃度：高（2026-10-13）。
- 组件/可抄：浏览器路线的兜底方案；token 会话持久化。
- 集成坑：重（需跑 Chromium）；对 WA Web UI 变动敏感；封号风险同上。

**signal-cli** ｜ [AsamK/signal-cli](https://github.com/AsamK/signal-cli) ｜ ★4,983（页面核实）
- 定位：Signal 非官方命令行/库。
- 许可：GPL-3.0；技术栈：Java（GraalVM 原生镜像）；活跃度：高（2026-10-14 当日）。
- 组件/可抄：**JSON-RPC daemon 模式（socket/HTTP）** 天然适合做网关的下游进程——收到消息转发给你的网关、网关回发；`link` 设备配对流程也值得参考。
- 集成坑：GPL 传染（分发修改版注意）；需手机端扫码 link；官方非支持渠道，条款灰色。

**mautrix（家族）** ｜ [mautrix/whatsapp](https://github.com/mautrix/whatsapp)（另有 telegram/signal 等桥） ｜ ★1,905（页面核实）
- 定位：Matrix ↔ 各 IM 的 puppeting bridge（portal/puppet、double puppeting、E2EE）。
- 许可：AGPL-3.0；技术栈：Go；活跃度：高（2026-10-14 当日）。
- 组件/可抄：**「把各 IM 桥接进统一协议（Matrix）再让 bot 只对接一个协议」** 的架构范式——与你自研「统一网关」思路同构，是重要参照；对加密会话、多端同步的处理成熟。
- 集成坑：需要自建 Matrix homeserver（Synapse/Conduit）；AGPL；运维复杂度高；适合"以 Matrix 为内网总线"的重型方案。

### 3.3 QQ 专项（国内场景重点）

**NapCat** ｜ [NapNeko/NapCatQQ](https://github.com/NapNeko/NapCatQQ) ｜ ★10,960（页面核实）
- 定位：基于官方 QQNT 客户端的现代协议端（OneBot 11，HTTP/WS 正反向 + WebUI）。
- 许可：⚠️ **自定义 "Limited Redistribution License"（非开源许可）**——原文要点：未经作者明确许可禁止使用/复制/修改/分发；再分发须保留许可全文并注明来源；**禁止任何商用**；修改后的代码不得公开发布。产品化/商用必须先与作者沟通授权。
- 技术栈：TypeScript（QQNT 注入）；活跃度：高（2026-10-12）。
- 组件/可抄：当前 QQ 生态最完整的 OneBot 11 实现（接口覆盖全、无头部署成熟）；若你现系统已在用 OneBot 路线，保留可平滑迁移。
- 集成坑：**许可限制是最大坑**（商用禁止）；封号风险；QQNT 版本更新常破坏注入；社区不解答基础对接问题；建议专用小号 + 只绑内网 + 独立账号部署，协议端设计成可插拔层（见 §8）。

**NoneBot2** ｜ [nonebot/nonebot2](https://github.com/nonebot/nonebot2) ｜ ★7,743（页面核实）
- 定位：跨平台 Python 异步机器人框架（适配 OneBot v11/v12、TG、Discord、飞书等）。
- 许可：MIT；技术栈：Python asyncio；活跃度：高（2026-10-12）。
- 组件/可抄：国内最大的 QQ 插件生态；把 NapCat 当协议端、NoneBot 当事件路由层是成熟组合；其适配器（driver/adapter）抽象值得抄。
- 集成坑：OneBot 依赖第三方协议端（go-cqhttp 已死，见下）；与自研内核整合需要走事件桥（不要同时跑两套业务逻辑）。

**Lagrange.Core**（补充） ｜ [LagrangeDev/Lagrange.Core](https://github.com/LagrangeDev/Lagrange.Core) ｜ ★约2,991（页面抓取）
- 定位：纯 C# 实现的 NTQQ 协议（不依赖 QQNT 客户端）。
- 许可：⚠️ 仓库未发现标准 LICENSE 文件（页面核实），商用/再分发前需向作者确认。
- 技术栈：C#；活跃度：中（2026-09-07）。
- 组件/可抄：轻量部署路线（无需装 QQ 客户端）。
- 集成坑：许可不明确；协议实现需跟随官方变化；跨语言集成（.NET）。

**LLOneBot（现 LuckyLilliaBot）**（补充） ｜ [LLOneBot/LLOneBot](https://github.com/LLOneBot/LLOneBot) ｜ ★约3,665（页面抓取）
- 定位：QQNT 插件形态的协议端（支持 OneBot 11 / Satori / Milky）。
- 许可：GPL-2.0；技术栈：TypeScript；活跃度：高（2026-10-12）。
- 集成坑：GPL-2.0 传染性（修改分发需开源）；作为插件依赖桌面 QQNT 环境，无头场景弱于 NapCat。

**⚠️ go-cqhttp（反面案例，勿用）** ｜ [Mrs4s/go-cqhttp](https://github.com/Mrs4s/go-cqhttp) ｜ ★10,618
- 已停更（最后提交 2024-05；协议被 QQ 官方封禁，社区共识"已接近不可用"）。教训：**QQ 协议端生命周期不可预期，网关架构必须把"协议端"设计成可替换插槽**。

### 3.4 微信 / 综合

**wechaty** ｜ [wechaty/wechaty](https://github.com/wechaty/wechaty) ｜ ★23,366（API 核实）
- 定位：Conversational RPA SDK（"puppet" 协议可插拔，主打微信生态）。
- 许可：Apache-2.0（代码本体）＋ ⚠️ **依赖生态付费**：官方明确不售卖 Token，稳定通道由第三方 CPSP（Commercial Puppet Service Providers）提供 Token，属付费闭源服务。
- 技术栈：TypeScript；活跃度：⚠️ **核心仓库 2025-12-21 后无提交（页面核实），实质半停更**。
- 组件/可抄：puppet 抽象（协议层可插拔）+ Token 网关远程托管模式——架构思想有参考价值。
- 集成坑：微信个人号自动化有封号/诉讼风险；免费 puppet 基本不可用；核心停滞 → 不建议新产品依赖。

### 3.5 客服式统一收件箱

**Chatwoot** ｜ [chatwoot/chatwoot](https://github.com/chatwoot/chatwoot) ｜ ★37,793（页面核实）
- 定位：开源全渠道客服平台（网站/邮件/WA/TG 等统一收件箱 + 人工坐席）。
- 许可：MIT（除 `enterprise/` 目录专有，LICENSE 原文明确）；技术栈：Ruby on Rails + Vue；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**conversation/assignment/webhook/Agent Bot API 的数据模型**——做「agent 接管 + 人工兜底」交互形态的最佳借鉴。
- 集成坑：Rails 单体较重；定位是客服而非通用 agent；深度集成（把 agent 当 bot 坐席）需要二次开发。

### 3.6 额外发现：多通道 Agent 平台（最贴近目标形态）

**LangBot** ｜ [langbot-app/LangBot](https://github.com/langbot-app/LangBot)（原 RockChinQ/LangBot） ｜ ★18,164（API 核实）
- 定位：生产级多平台 Agentic IM Bot 平台（QQ/QQ 频道/微信/TG/Discord/Slack/飞书等统一接入 + Web 管理面板 + 插件）。
- 许可：Apache-2.0；技术栈：Python；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**"平台适配器 → 消息管道/插件 → LLM 内核"三层架构** 与你自研目标高度同构，是现成对照实现；其多平台适配器清单可作为通道优先级参考。
- 集成坑：作为整机方案直接采用则定制受限（取其架构、不照搬）；各平台适配质量参差；中文文档为主。

**AstrBot** ｜ [AstrBotDevs/AstrBot](https://github.com/AstrBotDevs/AstrBot) ｜ ★41,881（API 核实）
- 定位：多平台 LLM 聊天机器人框架 + 插件生态（QQ/微信/TG/Discord/飞书等；自带 WebUI 与 agent 能力）。
- 许可：⚠️ **AGPL-3.0**（修改后提供网络服务需开源对应修改）；技术栈：Python；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：适配器抽象、事件总线、插件市场与运营面板——国内生态里功能覆盖最全的参考实现之一。
- 集成坑：AGPL 传染性（自用无碍，产品化二次开发注意）；历史架构大改过，资料时效性参差。

---

## 4. 整机个人助理参考

### 4.1 Leon
**Leon** ｜ [leon-ai/leon](https://github.com/leon-ai/leon) ｜ ★17,576（页面核实）
- 定位：开源个人助理（技能/意图 + NLU 管线起家）。
- 许可：MIT；技术栈：TypeScript/Node；活跃度：高（2026-10-12），**当前处于 2.0 Developer Preview 重构**（转向工具/上下文/记忆/agentic 执行）。
- 组件/可抄：个人助理的"技能注册 + NLU 路由"经典结构；2.0 的 agentic 重构方向与你的目标一致，值得跟踪。
- 集成坑：2.0 未稳定；社区规模有限；作为"架构参考"而非依赖。

### 4.2 OpenVoiceOS（OVOS）
**OpenVoiceOS** ｜ [OpenVoiceOS/ovos-core](https://github.com/OpenVoiceOS/ovos-core) ｜ ★296（核心仓，页面核实；生态多仓库）
- 定位：FOSS 语音助理整机平台（Mycroft 遗产的社区延续）。
- 许可：Apache-2.0；技术栈：Python；活跃度：中（2026-10-08）。
- 组件/可抄：**消息总线（ovos-bus）+ 技能服务插件 + 唤醒词/STT/TTS 管线** 的整机架构，是"语音助理 = 家庭设备"路线的最佳开源对照。
- 集成坑：生态碎片化（几十个仓库）、部署重；中文资源需自建；整体热度低。

### 4.3 Willow
**Willow** ｜ [HeyWillow/willow](https://github.com/HeyWillow/willow)（原 toverainc/willow） ｜ ★3,126（页面核实；配套 [willow-inference-server](https://github.com/toverainc/willow-inference-server) ★511）
- 定位：低成本本地语音助理（ESP32 硬件 + 本地推理服务，HA 集成）。
- 许可：Apache-2.0；技术栈：ESP32 固件（C）+ Python/Rust 推理服务；活跃度：中（2026-08-04 / 2026-02-12）。
- 组件/可抄：**"廉价拾音终端 + 独立推理服务器"** 的拆分部署模式；消费级硬件交互设计。
- 集成坑：硬件向、社区热度下降；中文/自定义模型需改造；依赖 Home Assistant 生态。

---

## 5. 语音（实时语音 Agent）

### 5.1 pipecat
**pipecat** ｜ [pipecat-ai/pipecat](https://github.com/pipecat-ai/pipecat) ｜ ★16,473（页面核实）
- 定位：实时语音/多模态 agent 管线框架（"Open Source framework for voice agents"）。
- 许可：BSD-2-Clause；技术栈：Python；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**frame/pipeline 处理链抽象**（processor 依次串起 VAD/STT/LLM/TTS/传输）、打断（interruption）与回合检测、多家供应商与传输（WebSocket/电话）集成——语音接入的首选起点。
- 集成坑：实时链路调试门槛高；云端 STT/TTS 成本；生产监控/降级自建。

### 5.2 LiveKit Agents
**LiveKit Agents** ｜ [livekit/agents](https://github.com/livekit/agents) ｜ ★14,740（页面核实）
- 定位：基于 LiveKit/WebRTC 的实时语音 AI agent 框架。
- 许可：Apache-2.0；技术栈：Python（+Node SDK）；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：worker/job 调度模型、房间/参与者抽象、与 WebRTC 前端及电话（SIP）打通——产品级实时语音基础设施最完备。
- 集成坑：需部署 LiveKit 服务（自托管/云）；概念较多；模型组合自选（接 04 章节的模型方案）。

### 5.3 Vocode（⚠️ 停更）
**Vocode** ｜ [vocodedev/vocode-core](https://github.com/vocodedev/vocode-core) ｜ ★3,802（页面核实）
- 定位：voice-based LLM agent 框架（曾主打电话场景）。
- 许可：MIT；技术栈：Python；活跃度：⚠️ **停更（最后提交 2024-11-15）**。
- 处理：仅作"电话 + 语音 agent 抽象"的历史参考；新项目用 pipecat / LiveKit Agents 替代。

### 5.4 openai-realtime-agents
**openai-realtime-agents** ｜ [openai/openai-realtime-agents](https://github.com/openai/openai-realtime-agents) ｜ ★7,002（页面核实）
- 定位：OpenAI Realtime API 多 agent 交接官方样例。
- 许可：MIT；技术栈：TypeScript/Next.js；活跃度：低-中（最后提交 2026-01-07）。
- 组件/可抄：多 agent handoff、实时工具调用事件处理模式（演示性质）。
- 集成坑：样例代码，非生产框架；绑定 OpenAI Realtime。

### 5.5 Ultravox
**Ultravox** ｜ [fixie-ai/ultravox](https://github.com/fixie-ai/ultravox) ｜ ★4,578（页面核实）
- 定位：speech-native 多模态 LLM（语音直接进模型）。
- 许可：MIT（代码）；⚠️ **模型权重许可各版本不同，部署前逐模型核实**（未逐一核实）。
- 技术栈：Python（+GPU 推理）；活跃度：低（2025-12-12 后无提交）。
- 组件/可抄：语音直入 LLM 的建模/推理参考，可自托管（需 GPU）。
- 集成坑：更新放缓；权重许可不一；中文支持有限。

---

## 6. 调度与持久执行

### 6.1 Temporal
**Temporal** ｜ [temporalio/temporal](https://github.com/temporalio/temporal) ｜ ★23,707（页面核实）
- 定位：durable execution 引擎（工作流即代码，服务端持久化）。
- 许可：MIT；技术栈：Go（server）+ 多语言 SDK（Python/TS/Go/Java 等）；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**长任务/定时任务的最强底座**：workflow/activity 分离、自动重试、durable timer（长睡眠不占进程）、signal/query（外部审批注入）、cron workflow、版本化。把"agent 回合"建模为 workflow + activity 是教科书解法。
- 集成坑：组件多（server + Postgres/Cassandra + UI）、概念门槛高；workflow 确定性约束（副作用必须放 activity）；Python SDK 异步优先。

### 6.2 Windmill
**Windmill** ｜ [windmill-labs/windmill](https://github.com/windmill-labs/windmill) ｜ ★18,185（页面核实）
- 定位：开发者平台（脚本 → Flows → cron → Web UI 一体化）。
- 许可：⚠️ **Fair-code 组合**（LICENSE 原文）：backend/frontend 除 "enterprise" flag 代码外为 AGPLv3；SDK/OpenAPI 为 Apache-2.0；官方发行版（ghcr 镜像/GitHub Release）**含专有代码**：免费使用但有配额限制，禁止转售/托管服务/封装。
- 技术栈：Rust + TypeScript；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：脚本→流程→调度的 UI 化体验、worker 拉取队列模型、多语言 worker。
- 集成坑：许可边界（白标/商用/托管注意 AGPL 与专有条款）；定位偏数据运维，agent 集成自建。

### 6.3 Inngest
**Inngest** ｜ [inngest/inngest](https://github.com/inngest/inngest) ｜ ★5,942（页面核实）
- 定位：事件驱动 durable workflow / step functions（TS 生态最友好之一）。
- 许可：⚠️ **SSPL v1.0**（LICENSE 原文 "Server Side Public License"）+ 声明未来转 Apache-2.0。SSPL 非 OSI 开源；**若把其自托管版作为对外服务提供，SSPL 要求开源整个服务栈** —— 产品化慎用。
- 技术栈：Go/TypeScript；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：事件触发 + step 编排、fan-out、sleep/延迟步骤、本地 dev server 体验。
- 集成坑：SSPL 风险（自用/内部无碍）；Python SDK 弱于 TS；自托管运维。

### 6.4 Restate
**Restate** ｜ [restatedev/restate](https://github.com/restatedev/restate) ｜ ★4,559（页面核实）
- 定位：轻量 durable execution 平台（单二进制；journal 恢复；virtual object/工作流即代码）。
- 许可：⚠️ **BSL 1.1**（原文）：Additional Use Grant —— 允许自用（含生产部署自用），**禁止把 Restate 本体作为公共托管平台服务**（供第三方注册/调用其服务）对外售卖；Change License: Apache-2.0（未来生效）。
- 技术栈：Rust；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**virtual object（按用户隔离的持久状态机）+ workflow 代码化 + 单二进制部署** —— 与"每用户助理会话/长任务状态"高度契合，是自研系统调度层的重点备选（轻于 Temporal）。
- 集成坑：BSL 非开源（自用免费）；生态年轻、资料少；团队规模小，需评估长期支持。

### 6.5 DBOS
**DBOS** ｜ [dbos-inc/dbos-transact-py](https://github.com/dbos-inc/dbos-transact-py) ｜ ★1,629（页面核实）
- 定位：数据库支撑的 durable workflows（存储 = Postgres）。
- 许可：MIT；技术栈：Python/TypeScript；活跃度：高（2026-10-13）。
- 组件/可抄：**装饰器式 durable workflow、Postgres 即工作流状态存储**（零新增基础设施）——已有 Postgres 的极简派首选。
- 集成坑：年轻；性能/规模上限未经大规模验证；强依赖 Postgres。

### 6.6 APScheduler
**APScheduler** ｜ [agronholm/apscheduler](https://github.com/agronholm/apscheduler) ｜ ★7,655（页面核实）
- 定位：Python 进程内任务调度（cron/interval/date 触发器）。
- 许可：MIT；技术栈：Python；活跃度：中-高（2026-10-12）。
- 组件/可抄：trigger/jobstore/executor 三段模型；持久化 jobstore 后可重启恢复——个人系统 v1 的 cron 首选。
- 集成坑：进程内调度（多实例/分布式不适用）；3.x→4.x 演进期 API 变动；时区配置坑。

### 6.7 Celery
**Celery** ｜ [celery/celery](https://github.com/celery/celery) ｜ ★28,981（页面核实）
- 定位：分布式任务队列（broker/worker 模式）。
- 许可：BSD-3-Clause（仓库 LICENSE 为 BSD 文本）；技术栈：Python；活跃度：中-高（2026-10-14）。
- 组件/可抄：成熟的重试/路由/beat 调度；适合短副作用任务（发通知、抓取、批处理）。
- 集成坑：**at-least-once 语义**（需幂等）；长任务中断恢复弱；**不建议裸跑 agent 长任务**（无持久状态 → 重复执行/丢失）；需维护 broker。

---

## 7. 通知推送

### 7.1 ntfy
**ntfy** ｜ [binwiederhier/ntfy](https://github.com/binwiederhier/ntfy) ｜ ★34,819（API 核实）
- 定位：自托管推送通知服务（HTTP publish/subscribe，Android/iOS/Web 客户端）。
- 许可：Apache-2.0；技术栈：Go（server）；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**把「agent 需要你确认 / 任务完成」推到手机**的最简方案：curl 即可发推送，支持附件、Action 按钮（回连你的网关做审批）、访问令牌。
- 集成坑：iOS 自托管推送需经 ntfy.sh 中继（APNs 限制），纯离线自托管 iOS 受限；主题默认公开，必须用 token/ACL 保护。

### 7.2 Apprise
**Apprise** ｜ [caronc/apprise](https://github.com/caronc/apprise) ｜ ★17,587（页面核实）
- 定位：一个库/CLI 覆盖 100+ 通知服务（TG/Slack/邮件/Discord/Webhook……）。
- 许可：BSD-2-Clause（原文确认，非 MIT）；技术栈：Python；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**通知兜底标准件**——统一 URL 语法（`tgram://`、`mailto://`、`json://`…）做多路告警/降级链。
- 集成坑：各服务限流与格式差异需处理；凭据管理自建。

---

## 8. 『多通道接入 + 调度』推荐组合（交付重点）

### 8.1 需求拆解
- 多端：QQ / TG / Discord / CLI / Web（+可选 Slack / WhatsApp / Signal）
- 消息：去重、路由、可靠投递
- 调度：cron 定时 + 持久工作流（长任务跨重启/断线恢复）
- 语音：可选（锦上添花，不建议一期做）

### 8.2 推荐组合（总表）

| 层 | 首选 | 备选 / 替换 |
|---|---|---|
| **QQ** | NapCat（OneBot 11 WS，⚠️仅自用/需授权商用） | Lagrange.Core、LuckyLilliaBot（注意各自许可）；应用层可叠 NoneBot2 |
| **Telegram** | python-telegram-bot | aiogram |
| **Discord** | discord.py | 官方 interactions webhook（仅斜杠命令场景） |
| **Slack（可选）** | Slack Bolt（Python/JS） | — |
| **WhatsApp（可选）** | Baileys | wppconnect / 官方 Cloud API |
| **Signal（可选）** | signal-cli（daemon 模式） | mautrix（若走 Matrix 路线） |
| **CLI** | 自研 REPL（抄 opencode 的 TUI↔server 分层） | 直接复用 opencode |
| **Web** | Open WebUI（≤50 人自用；白标需授权） | LibreChat（MIT）或 assistant-ui + Vercel AI SDK 自研（产品级） |
| **调度（v1）** | APScheduler + 任务表（Postgres/SQLite） | Celery（仅短任务） |
| **调度（持久）** | Restate（轻）或 DBOS（已有 PG 极简） | Temporal（重但最稳）；Windmill（要 UI）；Inngest（TS 生态，⚠️SSPL） |
| **语音（可选）** | pipecat | LiveKit Agents（需 WebRTC/电话时） |
| **通知** | ntfy（手机推送）+ Apprise（多路兜底） | — |
| **整体参考实现** | LangBot / AstrBot（架构对照） | Leon（经典技能结构）、Chatwoot（人工兜底模型） |

### 8.3 考察点一：通道抽象与鉴权模式

**统一事件模型（网关内唯一事实）**
```
INBOUND  { channel, instance_id, chat{id,type,thread_id}, sender{id,name},
           msg{platform_msg_id, ts, text, attachments[], raw}, received_at }
OUTBOUND { channel, chat, reply_to, content(text|media), idempotency_key }
```
- **每通道一个 adapter**：只做协议翻译 + 连接管理（重连/心跳/限流/分片/格式转换），不含业务逻辑。NapCat/OneBot、PTB、discord.py、Bolt、signal-cli daemon 各自封装成 adapter，网关其余部分对通道无感知 → 协议端可插拔（吸取 go-cqhttp 死亡教训）。
- **鉴权隔离**：平台凭证（bot token / WS token / QR 会话）统一进 secrets（env/keyring），不进代码库；Webhook 入口必须验签（TG `secret_token`、Slack signing secret、Discord Ed25519 interactions）；QQ 的 OneBot WS 只绑 127.0.0.1/内网 + token，NapCat WebUI 严禁公网暴露。
- **用户 ACL**：owner 白名单 + 配对码（pairing）制绑定；`identity` 映射表把 (channel, platform_user) 归一为内部统一用户，跨端共享会话与记忆。
- **高风险通道**（QQ 注入、WA/微信非官方）默认只接小号、仅私聊/白名单群、限频。

### 8.4 考察点二：消息可靠性（去重 / 重试 / 有序）

- **去重（防重复触发 agent）**：入库 `seen_messages(platform, instance, platform_msg_id)` 唯一约束 + TTL（≥7 天）；在"入队前"执行；同时处理 edit/recall 事件（更新而非新触发）。各平台重投递源：TG 更新重试、Discord gateway resume、OneBot 重复事件。
- **幂等（副作用护栏）**：每次 agent 触发生成 `turn_id`（=去重键）；所有副作用（发消息、写状态、调工具）以 turn_id 幂等键执行，重试安全。
- **有序（防上下文交错）**：以 `channel+chat(+thread)` 为 session key，**每会话串行队列（并发 1）**，跨会话可并发；同一会话的多条消息排队进入 agent，避免历史交错。
- **Outbox 模式（防丢回复）**：回复先落 `outbox` 表 → 异步 sender 发送 → 成功回执落库；失败指数退避 + 抖动重试；超限进死信表并触发告警（ntfy）。启动时扫 outbox 补发。
- **平台细节**：TG 429 `retry_after` 实测遵守；Discord 限流桶按路由；QQ 消息分片（不同平台长度上限）；每 chat 独立限速器。
- **语义定档**：端到端为"**至少一次投递 + 幂等消费**"（"恰好一次"在分布式下不现实）；所有动作留审计日志（与 06 章节呼应）。

### 8.5 考察点三：调度器与 Agent 长任务融合

**模式 A（v1，轻量）**：APScheduler（cron）+ 任务表
`cron 触发 → 生成 run（idempotency_key = task_id + scheduled_slot）→ 串行执行器跑 agent 回合 → 结果写 outbox`
- 要点：run 落库（状态机 pending/running/done/failed）、重启时恢复"未完成"任务、同一 slot 幂等。

**模式 B（v2，持久工作流，推荐）**：把"agent 回合"建模为 workflow
- LLM/工具调用 = step/activity（独立重试、超时控制）
- 等用户确认 = signal（配合 ntfy Action 按钮 / 聊天回执）
- 定时/延期 = **durable timer**（不占进程，跨重启存活，替代"sleep 等到明天再问"）
- 长驻状态 = 每会话一个 workflow / Restate virtual object（按用户隔离的持久状态机）
- 选型：**Restate（单二进制、轻、virtual object 契合度最高）**；已有 Postgres 走 **DBOS**；规模上来或要强治理走 **Temporal**。
- 反模式：Celery 裸跑长 LLM 任务（无持久状态 + at-least-once → 重复执行/丢进度）；cron 直接群发不设幂等键。

**模式 C（可选）**：Windmill（脚本+UI+cron，运维型任务可视化）/ Inngest（TS 事件流，⚠️SSPL）。

**融合接口（一条线）**：
`Scheduler → workflow.start(session_key, task_type, payload, idem_key) → agent runtime（工具=activity）→ outbox → channel adapter`——调度层与消息层通过 outbox 表解耦，互不感知对方实现。

### 8.6 分阶段路线
- **v1（个人系统，1-2 周）**：网关（Python asyncio）+ QQ（OneBot WS 直连）+ TG 适配 + SQLite（dedup/outbox/任务表）+ APScheduler + CLI。
- **v2（多端+可靠）**：接入 Discord（+可选 Slack）；会话串行/ACL/身份归一；调度迁移 Restate 或 DBOS；ntfy 通知；Web 先用 Open WebUI 反向接自研后端（≤50 人自用合规）。
- **v3（产品化）**：Web 自研（assistant-ui + Vercel AI SDK，避开品牌条款）或 LibreChat；语音接入 pipecat；监控/审计/配额（配合 04/06 章节）。

### 8.7 替换关系速查
- NapCat 许可不可接受 → Lagrange.Core / LuckyLilliaBot（确认许可后）或暂缓 QQ 协议端
- Open WebUI 白标/商用 → LibreChat 或自研前端
- Temporal 太重 → Restate（首选轻量替代）/ DBOS
- 已有 Postgres → DBOS / Windmill
- TS 全栈团队 → Vercel AI SDK / CopilotKit / Inngest（注意 SSPL）
- 只需服务器端语音管线 → pipecat；要 WebRTC 通话/电话 → LiveKit Agents
- Matrix 总线路线 → mautrix 家族整体替换直连方案

---

## 附录 A：不推荐依赖清单
| 项目 | 原因 |
|---|---|
| go-cqhttp | 停更（2024-05），协议被封 |
| Vocode | 停更（2024-11 后无提交） |
| wechaty（核心） | 半停更（2025-12 后无提交）+ 付费第三方 Token 生态 + 微信合规风险 |
| opencode-ai/opencode | 已归档（用 anomalyco/opencode） |
| NapCat 用于商用/再分发 | 自定义许可禁止商用/限制分发（自用可） |
| aider / Ultravox / Continue / Chainlit | 可作参考，但上线依赖前需评估维护节奏与治理风险 |

## 附录 B：核实与未核实项（2026-10-14）
- **API 交叉核实（5/6 次额度）**：open-webui 155,699 · wechaty 23,366 · AstrBot 41,881 · LangBot 18,164 · ntfy 34,819。
- **页面抓取核实**：其余全部条目（见各条目标注）。
- **约值（页面抓取，未 API 交叉）**：Lagrange.Core ★约2,991、LuckyLilliaBot ★约3,665、aiogram ★约5,892、bolt-js ★约2,948。
- **未核实**：Ultravox 各模型权重许可（逐模型核对前勿商用）；LobeHub Community License 附加条款细则（采用前读全文）；Lagrange.Core 未见标准 LICENSE 文件。
- **方法备注**：星数为当日快照；活跃度对"最后提交时间"敏感，选型前建议再复查一次。


---

# 06 · 安全护栏 / 密钥 / 身份多租户 / 产品化基建

> 本文为『自研个人/产品级 AI Agent 系统 · 开源原材料调研』第 06 部分（安全与产品化集群）。
> **集群定位**：回答"Agent 敢不敢给别人用、怎么不出事、怎么收钱"——护栏与注入防御、密钥管理、身份/多租户、计量计费、策略与审计。
> **调研日期**：2026-10-14（UTC）。**方式**：只读调研（未安装任何软件），GitHub 主页 + 官方文档 + 2025–2026 第三方来源交叉核查。
> **核实说明**：6 个仓库经 `api.github.com` 直调核实（★/许可证/推送时间为精确值）；其余 ★ 经 shields.io 徽章读取（2026-10-14 快照）；没有任何来源的标『约/未核实』。许可证除标"实测/原文"外为项目通行信息，商用前请以仓库 LICENSE 为准。
> **收录口径**：只收真实存在、2024 后活跃的项目；已停更项目（LLM Guard、Rebuff、HumanLayer 开源部分）保留为**警示条目/模式来源**，活跃度字段已明确标注。
> **边界**：沙箱/容器隔离见 03 章，观测后端选型见 04 章，框架内置护栏（LangGraph interrupt 等）见 01 章，本文不重复。

---

## 0. TL;DR（结论先行）

- **单机自用最小集**：SOPS+age（密钥）＋ guardrails-ai 或 NeMo Guardrails（护栏）＋ 高危工具人工确认钩子 ＋ Postgres 用量日志。零重型组件。
- **产品化平滑升级链**：身份 `Better Auth/Keycloak → Zitadel`；密钥 `SOPS → Infisical → OpenBao`；计量 `PG 日志 → OpenMeter → Lago`；授权 `白名单 → OPA`。每层都走标准接口（OIDC / secret 引用 / policy bundle），换组件不动 agent 侧代码。
- **许可证红线 3 条**：`Zitadel(v3+)`、`Lago` 为 AGPL-3.0；`Bitwarden` 部分目录为专有许可（含 Secrets Manager）；`PurpleLlama` 根仓库为 Llama 社区许可（但其 LlamaFirewall 代码目录实测为 MIT）。其余主选（Apache-2.0/MIT/MPL-2.0）均可安全用于商用闭源产品。
- **已停更 3 坑**：LLM Guard（2026-07 归档）、Rebuff（2025 归档）、HumanLayer 开源代码（已废弃，转商业产品）——学思路，别做依赖。

---

## 6.1 护栏与注入防御

护栏在系统里的位置：**输入侧**（注入/越狱检测、话题边界）、**执行侧**（工具调用前策略、参数校验）、**输出侧**（内容合规、泄密检测）三段。下面项目按这三段分工。

### 6.1.1 NVIDIA NeMo Guardrails（推荐主选）
- **GitHub**：https://github.com/NVIDIA-NeMo/Guardrails （原 `NVIDIA/NeMo-Guardrails`，已迁移到 NVIDIA-NeMo 组织）
- **定位**：可编程 LLM/agent 护栏工具箱——用 Colang DSL 定义"什么输入/输出/话题/动作该被拦截"（rails），覆盖输入审查、输出审查、对话流约束、工具执行控制。
- **Star**：7,299 ★（api.github.com 核实，2026-10-14）
- **许可证**：Apache-2.0（`LICENSE.md`，SPDX 头实测）✅ 商用闭源无碍
- **技术栈**：Python + Colang DSL；提供 LangChain 集成与独立 server 模式
- **活跃度**：极高——2026-10-14 当日仍有推送（api 核实 `pushed_at`）
- **能当什么组件 / 能抄什么**：① 直接当"输入→推理→输出"的拦截中间件；② 抄分层 rail 设计：**input rails → dialog/topical rails（话题边界）→ output rails → tool/execution rails**；③ 流式输出场景的拦截点设计。
- **集成坑**：Colang 有学习曲线，且 2.0 换过语法——网上老例子可能过时；LLM-based rail 增加延迟与 token 成本（建议"轻量分类器 rail + LLM rail"分级混用）；它面向对话系统抽象，接入自研 agent loop 需要自写适配层。
- **上手速评**：接入成本=中；自托管=天然（本地库/自建 server）；框架集成=对 LangChain 现成、自研 loop 需包装；许可=✅。

### 6.1.2 Guardrails AI（推荐主选）
- **GitHub**：https://github.com/guardrails-ai/guardrails
- **定位**：Python 声明式"输入/输出校验"框架——用 pydantic/RAIL 定义 schema，从 Guardrails Hub 装 validators（毒性、PII、幻觉、正则等），校验不过自动 re-ask/修正。
- **Star**：7,521 ★（api.github.com 核实，2026-10-14）
- **许可证**：Apache-2.0（api 实测）✅；⚠️ 但 **Hub 上每个 validator 是独立包、许可各自不同**（少数带使用限制或需要外部 API key），商用需逐个核对。
- **技术栈**：Python（纯库）
- **活跃度**：高（2026-10-09 推送）
- **能当什么组件 / 能抄什么**：① 结构化输出 + 校验 + 失败重试闭环——agent 输出管道的"质检站"；② validator 即插即拔的注册表模式；③ "校验失败如何反馈给模型再生成"的 prompt 流程直接抄。
- **集成坑**：re-ask 循环 = 翻倍 token/延迟，必须设重试上限；Hub validator 需联网安装（离线环境要预打包）；1.0 前后有 breaking change，锁版本；部分 validator 依赖模型权重下载。
- **上手速评**：接入成本=低（一个 decorator）；自托管=天然；框架集成=任意 Python agent 直接调用；许可=✅（注意 validator）。

### 6.1.3 LLM Guard（⚠️ 已归档，2026-07-09）
- **GitHub**：https://github.com/protectai/llm-guard
- **定位**：输入/输出安全扫描器全家桶（提示注入、PII、毒性、敏感内容、密钥泄漏……），可组合成 pipeline。
- **Star**：约 3.2k ★（GitHub 页面快照）
- **许可证**：MIT（未逐一实测）。
- **活跃度**：❌ **2026-07-09 被所有者归档（只读）**；母体 Protect AI 2025 年被 Palo Alto Networks 收购（第三方来源；官方未将归档与收购关联）。
- **能当什么组件 / 能抄什么**：扫描器清单与"每类风险一个检测器 + 可调阈值"的组织方式值得抄；代码可 fork 自维护，但不再有上游补丁。
- **集成坑**：归档 = 无安全修复、无新攻击特征更新；存量使用需尽快替换或自行 fork 维护；替换路径：NeMo/guardrails-ai + PromptGuard 类分类器（见 6.1.4）。
- **上手速评**：新项目=不要依赖；存量=迁移。

### 6.1.4 LlamaFirewall / PurpleLlama（Meta；分类器可单用）
- **GitHub**：https://github.com/meta-llama/PurpleLlama （LlamaFirewall 位于子目录，含论文《LlamaFirewall: An open source guardrail system for building secure AI agents》）
- **定位**：Meta 的 agent 护栏框架三件套——**PromptGuard 2**（轻量注入/越狱分类模型）、**AlignmentCheck**（对推理链做对齐审查）、**CodeShield**（代码安全扫描，支持多语言语法感知）。
- **Star**：4,431 ★（PurpleLlama 仓库整体，api.github.com 核实，2026-10-14）
- **许可证**：⚠️ **分组件**！仓库根 `LICENSE` = **Llama 3.2 Community License**（raw 原文实测）；`LlamaFirewall/` 子目录自带 **MIT License**（raw 实测）；**PromptGuard 2 等模型权重**另按 Llama 许可（含 700M MAU 阈值、可接受使用政策、署名等条款）。商用前逐组件确认。
- **技术栈**：Python；需 HuggingFace 访问下载模型
- **活跃度**：高（2026-10-12 推送）
- **能当什么组件 / 能抄什么**：① **PromptGuard 2 可单独拿来当"注入/越狱分类器"**（比自训便宜）；② 多层防御架构（输入分类 → 推理审查 → 工具输出审查）值得抄；③ agent 写代码场景用 CodeShield 做静态检查。
- **集成坑**：AlignmentCheck 需再挂一个审查 LLM（成本/延迟叠加）；模型下载依赖网络与 HF 访问；许可条款需逐组件核（代码 MIT ≠ 权重 MIT）。
- **上手速评**：接入成本=中（较新，文档/社区案例少于 NeMo）；自托管=是；框架集成=独立 Python 库。

### 6.1.5 Rebuff（⚠️ 已归档）
- **GitHub**：https://github.com/protectai/rebuff
- **定位**：提示注入检测库（启发式 + LLM + 向量相似库 + canary token 四层融合）。
- **Star**：约 1.5k ★（页面快照）
- **许可证**：MIT（未核实）
- **活跃度**：❌ 已归档（仓库显示 Public archive；第三方称 2025-05 起停更）
- **能当什么组件 / 能抄什么**："canary token"（在上下文中埋已知答案，检测是否被诱导泄漏）与多检测器投票融合，思路仍值得参考。
- **集成坑**：特征库不再更新，现代越狱大概率绕过；**禁止作为生产依赖**。

### 6.1.6 garak（NVIDIA；护栏的"红队陪练"，推荐）
- **GitHub**：https://github.com/NVIDIA/garak
- **定位**：LLM 漏洞扫描器（红队工具）——静态/动态/自适应 probes，检测越狱、注入、数据泄漏等；对 agent 系统而言它是"攻击方"，用来**验证你的护栏到底有没有用**。
- **Star**：9.6k ★（shields.io 读取，2026-10-14）
- **许可证**：Apache-2.0（页面原文实测："Apache license v2"）✅
- **技术栈**：Python；支持 20+ 模型后端/API
- **活跃度**：高（NVIDIA 官方红队项目，2026 年仍在迭代）
- **能当什么组件 / 能抄什么**：把 garak 放进 CI 做"安全回归"：每次改护栏/提示词后跑一轮 probe，产出报告当调参依据；它的 probe 组织方式（风险类别 × 攻击手法）也可借鉴到自研测试集。
- **集成坑**：扫描组合多、全量跑耗时长（CI 里取子集）；需要配各家模型 API key；主要打模型/对话端点，agent 工具链级攻击面（MCP、工具误用）还需自己补测试。
- **上手速评**：接入成本=低-中；自托管=天然；与护栏项目互补（不是防御组件）。

### 6.1.7 HITL 人工审批：HumanLayer（模式来源）＋ 自研模式清单
- **项目**：https://github.com/humanlayer/humanlayer
- **Star**：11,695 ★（api 核实，2026-10-14）；**许可证**：Apache-2.0（`LICENSE` 原文实测）
- **⚠️ 现状**：仓库已转 issues-only，README 原文写明"代码基本全部废弃（pretty much all deprecated）"，重建版为人工审查类**商业产品**（humanlayer.com）；最后推送 2026-06-19。→ **只当模式库收录，不要做依赖。**
- **它贡献的模式（现在仍可抄）**：`@require_approval` 装饰器（函数级审批门）；`human_as_tool`（把"问人"做成一个工具）；审批请求路由到 Slack/Email/SMS；审批结果回填、agent 继续执行。
- **自研审批模式清单**（综合 LangGraph `interrupt()`、CrewAI `human_input`、Open WebUI 审批讨论等公开实践）：
  1. **工具级闸门**：危险工具调用前挂起（中断-持久化-恢复状态机），等待 approve/reject；
  2. **人即工具**：`ask_human(question)` 工具，agent 主动求决策；
  3. **异步通道**：审批推送 Slack/邮件/站内信；超时策略=默认拒绝或降级为只读；
  4. **风险分级**：只读自动放行；写操作按影响面审批；资金/删除/对外发送类=双人复核。
- **集成坑**：审批状态机必须持久化（人工响应可能几小时）；审批人身份要强校验（防伪造 approve）；每条审批必须进审计日志（谁、何时、批了什么）。

---

## 6.2 密钥管理（"密钥不落明文"）

### 6.2.1 Infisical（推荐主选）
- **GitHub**：https://github.com/Infisical/infisical
- **定位**：开源密钥/证书/PKI/特权访问平台；2026 官方定位已面向 "AI Agents" 场景（仓库简介原文包含 securing … AI Agents）。
- **Star**：29,763 ★（api.github.com 核实，2026-10-14）
- **许可证**：**MIT（expat）主体 + `ee/` 目录为专有企业许可**（README/官方文档原文）——闭源商用 OK；ee 功能（企业 SSO、部分细粒度 RBAC/审计等）需购买 license。
- **技术栈**：TypeScript + Go；docker compose / K8s 自托管
- **活跃度**：极高（2026-10-14 当日推送）
- **能当什么组件 / 能抄什么**：产品化"密钥中心"：machine identity（服务身份）、SDK 注入（`infisical run` 把密钥变进程环境变量）、轮换、动态密钥（DB/云）、secret sync、PKI。**抄它的 secret reference 模型**：代码里只出现路径/引用，值在运行时注入。
- **集成坑**：ee 边界要提前确认（哪些能力要花钱）；自托管需 PG + Redis，发版频繁升级要跟；"注入子进程环境变量"的密钥仍可能被进程 dump——高敏感场景用短时凭证而非长期静态值。
- **上手速评**：接入成本=低-中；自托管=友好；框架集成=SDK 全语言；许可=✅（ee 除外）。

### 6.2.2 OpenBao（推荐：产品期"加密服务"）
- **GitHub**：https://github.com/openbao/openbao
- **定位**：HashiCorp Vault 的社区 fork（Vault 改 BUSL 后从最后一个 MPL 版 1.14 分叉），Linux Foundation 治理，坚持 MPL-2.0。
- **Star**：8.4k ★（shields.io 读取）
- **许可证**：MPL-2.0（页面实测）——文件级 copyleft，作为独立服务使用无碍 ✅
- **技术栈**：Go；独立服务 + 存储后端（Raft/PG 等）
- **活跃度**：高（2026 年仍在发版，约 2026-09 发布 v2.7，第三方来源；部分企业特性仍在追赶上游 Vault）
- **能当什么组件 / 能抄什么**：① **transit 引擎 = 信封加密**（把用户的 API key/凭据加密落库，明文只在内存）；② 动态凭证（给 agent 发短时 DB 账号）；③ audit device（每次取密钥留痕）；④ PKI。抄"短期 token 生命周期 + 审计设备"这套模型。
- **集成坑**：运维成本真实（unseal、升级、灾备）；插件生态小于 Vault、少数企业功能缺失；API 与 Vault 高度兼容但有细节碎片，别照抄 Vault 文档。
- **上手速评**：接入成本=中（运维门槛）；自托管=核心场景；集成=HTTP API + 多语言 SDK；许可=✅。

### 6.2.3 SOPS + age（推荐：单机起步）
- **GitHub**：https://github.com/getsops/sops
- **定位**：文件级加密（"把密钥文件加密后放心进 git"），配合 age/KMS/PGP 管理收件人。
- **Star**：23k ★（shields.io 读取）
- **许可证**：MPL-2.0（通行信息，未逐一实测）
- **技术栈**：Go CLI；对接 git 工作流 / GitOps（Flux、Argo 生态广泛使用）
- **活跃度**：高
- **能当什么组件 / 能抄什么**：**单机自用阶段最省事的"密钥不落明文"方案**——SOPS(age) 加密 `.env`/配置进仓库，CI/部署时解密注入；也可当 Infisical/OpenBao 的 bootstrap 密钥载体。
- **集成坑**：静态加密 ≠ 运行时管理（无轮换/无审计/无动态凭证）；多人协作要管好 age 收件人列表；改一个值需重加密整个文件（小文件无碍）。
- **上手速评**：接入成本=低；自托管=本地即是；许可=✅。

### 6.2.4 Bitwarden（⚠️ 人用，不是 agent 基建）
- **GitHub**：https://github.com/bitwarden/server
- **定位**：面向人（和团队）的密码/凭据保管，含 Secrets Manager 产品。
- **Star**：20k ★（server 仓库，shields.io 读取）
- **许可证**：⚠️ 仓库默认 GPL-3.0，部分目录 Bitwarden License v1.0（专有）；**Secrets Manager 未按 GPL 发布**（社区讨论确认，二手来源）
- **技术栈**：C#/.NET 服务端 + 全平台客户端；vaultwarden（Rust）为兼容实现但不含 Secrets Manager
- **活跃度**：高（官方持续开发）
- **能当什么组件 / 能抄什么**：给"人"用的共享凭据/应急访问；**不建议作为 agent 运行时 secret 后端**（SM 非开源、自托管边界复杂）。
- **集成坑**：许可边界（GPL 主体 + 专有 SM）+ 商标条款；与 agent 链路集成性价比低。
- **上手速评**：人用 ✓；agent 基建 ✗。

---

## 6.3 身份与多租户（自用 → 多用户产品平滑升级）

### 6.3.1 Better Auth（TS 栈 MVP 首选）
- **GitHub**：https://github.com/better-auth/better-auth
- **定位**：TypeScript 生态新一代 auth **框架（库，不是独立服务）**——用户/会话/组织/API key/SSO/passkey 全靠插件；**organization 插件 = 多租户**（组织、成员、邀请、角色）。
- **Star**：30,292 ★（api.github.com 核实，2026-10-14）；2024-05 建仓，2024 后最猛的 auth 项目之一
- **许可证**：MIT（api 实测）✅
- **技术栈**：TypeScript（框架无关，Node/Bun/边缘运行时均可）
- **活跃度**：极高（2026-10-14 当日推送）
- **能当什么组件 / 能抄什么**：TS 栈产品的身份层首选——身份数据存自己 DB；抄"组织-成员-邀请-角色"数据模型与插件架构。
- **集成坑**：只有 TS 生态（Python 主栈需另架 Node 服务、或选 Keycloak/Zitadel）；项目年轻，插件质量参差；企业级能力（SCIM/审计）弱于老牌 IdP。
- **上手速评**：接入成本=低（TS）；自托管=天然（与应用同库）；许可=✅。

### 6.3.2 Keycloak（语言无关、许可最安全的成熟 IdP）
- **GitHub**：https://github.com/keycloak/keycloak
- **定位**：最成熟的开源 IdP/SSO（Red Hat 血统）：OIDC/SAML、管理台、扩展 SPI；新版引入 **Organizations** 组织模型做 B2B 多租户。
- **Star**：37k ★（shields.io 读取）
- **许可证**：Apache-2.0（通行信息）✅——本清单"许可 + 成熟度"综合最稳的身份基座
- **技术栈**：Java（JVM，资源占用大）
- **活跃度**：高（发版节奏稳定）
- **能当什么组件 / 能抄什么**：语言无关的产品身份层（Python/Go/Rust 栈都走标准 OIDC）；多租户用 Organizations，或 realm-per-tenant（**仅建议 5–20 个租户**，再多了会变成"在运营一个 IAM 平台"——来源：KeycloakPro 指南）。
- **集成坑**：重（内存/管理复杂度）；大版本升级有坑；realm 泛滥难治理；登录页/邮件定制要花功夫。
- **上手速评**：接入成本=中；自托管=成熟（官方容器/Helm）；许可=✅。

### 6.3.3 Zitadel（多租户 DX 最好，⚠️ AGPL）
- **GitHub**：https://github.com/zitadel/zitadel
- **定位**：云原生 IdP/CIAM，多租户一等公民（Organization/Project/Role 原生模型），OIDC/SAML/SCIM + Actions 钩子。
- **Star**：15k ★（shields.io 读取）
- **许可证**：⚠️ **AGPL-3.0-only（v3 起；`LICENSING.md` 原文实测：proto/、docs 目录 Apache-2.0，login 等目录 MIT）**。v2 时代曾为 Apache-2.0——在意许可可考虑 v2 时代版本或接受 AGPL。合规含义：**修改其代码并作为网络服务对外提供时需开源修改部分**；原样自托管通常可控，但项目方自己也在 LICENSING.md 里建议咨询法务。
- **技术栈**：Go；compose/K8s 自托管友好
- **活跃度**：高
- **能当什么组件 / 能抄什么**：产品期多租户身份层 DX 最好之一（每个客户=一个 org、自带品牌化/自助注册）；抄其多租户身份数据模型。
- **集成坑**：AGPL 需法务评估；部分企业功能付费；v3 迁移有变更；社区资料少于 Keycloak。
- **上手速评**：接入成本=中低；自托管=友好；许可=⚠️。

### 6.3.4 Supabase（抄 RLS 模式 > 上全家桶）
- **GitHub**：https://github.com/supabase/supabase
- **定位**：BaaS 全家桶（Postgres + Auth + Storage + Realtime + Edge Functions）。
- **Star**：112k ★（shields.io 读取）
- **许可证**：Apache-2.0（通行信息）✅
- **活跃度**：极高
- **能当什么组件 / 能抄什么**：① 若本来就用 Supabase 云，Auth + **RLS** 直接给到多租户基石：每行带 `tenant_id`，JWT claim 进 RLS 策略（`auth.uid()`）——**这个模式即使不用 Supabase 也能在纯 Postgres 复刻，是本集群最值得抄的单一模式**；② Auth 的 JWT 与数据库耦合设计。
- **集成坑**：自托管栈庞大，官方明说 CLI 本地栈"not hardened for production"、部分能力云限定；全量自托管 ≈ 自己运营一个平台。
- **上手速评**：抄模式=零成本；上全家桶（自托管）=重。

### 6.3.5 Authelia（管理面"门卫"）
- **GitHub**：https://github.com/authelia/authelia
- **定位**：自托管 SSO 门户 + 反向代理 forward-auth（2FA 门禁），并提供 OIDC Provider。
- **Star**：29k ★（shields.io 读取）
- **许可证**：Apache-2.0（通行信息）✅
- **技术栈**：Go；常配 nginx/Traefik/Caddy
- **活跃度**：高
- **能当什么组件 / 能抄什么**：给管理后台/内部工具/gateway 加统一登录与 2FA；forward-auth 模式（网关问 Authelia"这个请求是谁"）。
- **集成坑**：定位是"门卫"不是 CIAM——没有产品级自助注册/多租户概念；OIDC 能力比 Keycloak 简单。
- **上手速评**：接入成本=低（若已用反代）；适合阶段 1 护住内部面。

### 6.3.6 扩展候选（一行，未核实）
- **Ory Kratos**（≈14k★，shields 读取；Apache-2.0 通行）——身份服务组件，但无内置多租户，需自配 Hydra/Keto 组合，工程量大；适合"愿意自己拼"的团队。

---

## 6.4 计量与计费（可计费）

### 6.4.1 OpenMeter（Kong 旗下，推荐起点）
- **GitHub**：https://github.com/openmeterio/openmeter
- **定位**：AI/API 用量计量 + entitlements（额度/功能开关）——为"按 token/按调用计费"而生。
- **Star**：2.4k ★（shields.io 读取 + GitHub org 页快照一致）
- **许可证**：Apache-2.0（README 原文实测）✅
- **技术栈**：Go；事件流 Kafka + 分析 ClickHouse（较重）
- **活跃度**：中-高；**2025-09 被 Kong 收购**（官方公告），收购后继续开源（官网仍以 OSS 宣传）；路线图受 Kong 影响需关注。
- **能当什么组件 / 能抄什么**：计费中间层——agent 产出 usage events（tenant、model、tokens、工具调用）→ 聚合/额度判定 → Stripe 出账；抄其**事件 schema + entitlement 模型**。
- **集成坑**：自托管组件重（Kafka+ClickHouse）；官方 Helm chart 注记"仅供开发部署"（README 原文）——生产自托管要自己吃透部署；社区规模较小；收购后长期路线不确定性。
- **上手速评**：接入成本=中；自托管=可行但重；许可=✅。

### 6.4.2 Lago（⚠️ AGPL；完整账单引擎）
- **GitHub**：https://github.com/getlago/lago
- **定位**：开源计量 + 订阅计费 + 发票引擎（"开源 Stripe Billing"），仓库内带 agentic AI 计费示例（`examples/agentic-ai-demo`）。
- **Star**：11k ★（shields.io 读取）
- **许可证**：⚠️ **AGPL-3.0（页面原文实测）**——自托管免费；修改并以 SaaS 形式对外提供需开源修改部分；闭源产品以 API 方式集成也建议法务评估。
- **技术栈**：Ruby（API）+ React；事件引擎 ClickHouse，依赖 Kafka 等
- **活跃度**：高
- **能当什么组件 / 能抄什么**：真的需要"订阅管理 + 发票 + 税务 + 信用额度"成品时再上；早期 OpenMeter + Stripe 到不了这个复杂度。抄其"事件 → 定价模型 → 发票"流水线。
- **集成坑**：AGPL；自托管组件多（PG/Redis/CH/Kafka）运维重；定价模型配置有学习成本。
- **上手速评**：接入成本=中高；自托管=重；许可=⚠️。

---

## 6.5 策略与审计

### 6.5.1 OPA（推荐主选）
- **GitHub**：https://github.com/open-policy-agent/opa
- **定位**：通用策略引擎（策略即代码，Rego 语言）：输入（谁/租户/工具/上下文）→ 决策（allow/deny/带条件 permit）。
- **Star**：12k ★（shields.io 读取）
- **许可证**：Apache-2.0（通行信息）✅；CNCF 毕业项目
- **技术栈**：Go；进程内库 / REST sidecar / WASM 三形态
- **活跃度**：高
- **能当什么组件 / 能抄什么**：**agent 工具调用的授权决策点**——每次 tool call 前问 OPA"这个 tenant 的这个用户能不能跑这个工具、参数是否越权"；decision log 直接进审计。抄"策略与代码分离 + 决策日志"的治理模型。
- **集成坑**：Rego 学习曲线陡；非 Go 栈高频调用建议 sidecar/本地部署（远程 REST 加延迟）；多租户=多策略包，策略分发/版本管理要配套（→ OPAL）。
- **上手速评**：接入成本=中；自托管=友好（单二进制）；许可=✅。

### 6.5.2 OPAL（OPA 分发层）
- **GitHub**：https://github.com/permitio/opal
- **定位**：OPA 的"管理面"——监听策略/数据变化，实时推送到 OPA 集群（Permit.io 出品）。
- **Star**：5.5k ★（shields.io 读取）
- **许可证**：Apache-2.0（页面实测）✅
- **活跃度**：中-高
- **能当什么组件 / 能抄什么**：多租户下"每租户一套策略包"的实时分发；抄其发布-订阅更新模型。
- **集成坑**：多一个组件；单机/小规模用不上（OPA 自带 bundle 拉取可能就够）。

### 6.5.3 Cedar（OPA 备选，语法更友好）
- **GitHub**：https://github.com/cedar-policy/cedar
- **定位**：AWS 出品的授权策略语言/引擎（比 Rego 接近自然语言、强类型）。
- **Star**：1.8k ★（shields.io 读取）
- **许可证**：Apache-2.0（页面原文实测："This project is licensed under the Apache-2.0 License"）✅
- **技术栈**：Rust 核心；官方绑定以 Rust/Java/Go 等为主
- **活跃度**：中-高（AWS 在推）
- **能当什么组件 / 能抄什么**：agent 工具授权直接可用（principal × action × resource × context）；建议与 OPA 做小规模 POC 对比后定。
- **集成坑**：生态远小于 OPA；语言绑定少（Python 侧暂无官方一等支持）；资料多来自 AWS 文档。

### 6.5.4 OpenFGA / SpiceDB（ReBAC 扩展，一行）
- https://github.com/openfga/openfga （6k★）/ https://github.com/authzed/spicedb （7.1k★）（shields 读取；Apache-2.0 通行，未核实）——Google Zanzibar 风格"用户-关系-资源"授权，适合资源级权限天然是关系图的多租户场景；与 OPA（规则型）互补。

### 6.5.5 OpenTelemetry GenAI 语义约定（审计字段标准）
- **仓库**：https://github.com/open-telemetry/semantic-conventions （⚠️ 2026-06 起 GenAI 部分已迁至 `open-telemetry/semantic-conventions-genai` 独立仓库继续迭代）
- **定位**：不是工具，是 LLM/agent 遥测的**字段标准**：`gen_ai.request.model`、usage tokens、工具调用、MCP 等。
- **许可证**：Apache-2.0（规范仓库，通行）
- **状态/活跃度**：活跃演进；⚠️ **仍未稳定**——第三方核查（2026-07）：GenAI 类别无任何 span/attribute 标记 Stable，全部处于 Development。
- **能当什么组件 / 能抄什么**：① 审计与计费共用的字段字典（用量事件直接对齐 `gen_ai.*`）；② "未稳定期保留原始 attributes"的兼容落库策略。
- **集成坑**：未 Stable = 字段会变，别把字段名焊死在数据库 schema 里；具体观测后端选型见 04 章（本文只管字段标准）。

---

## 6.6 『安全与多租户』推荐组合（核心交付）

### 6.6.1 三阶段演进路线（单机自用 → 多用户产品，平滑升级）

| 能力 | 阶段 0 · 单机自用 | 阶段 1 · 小团队（邀请制） | 阶段 2 · 多租户产品 |
|---|---|---|---|
| 身份 | 单用户 API key | Better Auth（TS）或 Keycloak | Zitadel 或 Keycloak Organizations + 企业 SSO/SCIM |
| 密钥 | SOPS + age | Infisical 自托管（machine identity） | ＋OpenBao（transit 信封加密 / 动态凭证） |
| 护栏 | guardrails-ai 或 NeMo 轻量挂钩 ＋ 高危人工确认 | NeMo rails ＋ garak 定期红队回归 | 同上 ＋ 按租户/风险分级策略 |
| 授权 | 静态白名单 | OPA sidecar（单租户策略） | OPA 多租户策略包（OPAL 分发）＋ DB 层 RLS 兜底 |
| 审批 | CLI/IM 确认 | 自研审批队列（分级+异步+超时拒绝） | 审批工作流产品化（SLA/双人复核/审计） |
| 计量 | Postgres 用量日志 | OpenMeter | OpenMeter ＋（需要时）Lago |
| 审计 | 本地日志 | OTel GenAI 字段 ＋ PG | append-only ＋ OPA decision logs ＋ 留存策略 |

**升级不重做原则**：agent 侧只依赖抽象接口（OIDC / secret 引用 / policy 决策 API），底层组件可换——这是平滑升级的关键工程决策。

### 6.6.2 要求①「密钥不落明文」落地清单
1. **静态**：仓库里只有密文（SOPS）或引用（Infisical path / OpenBao path），永远没有明文 `.env`。
2. **运行时**：进程启动时向密钥中心拉取（machine identity + 短时 token）；工具在服务端执行，**密钥不进 LLM 上下文、不进 prompt**。
3. **用户密钥（BYOK）**：OpenBao transit（或云 KMS）信封加密落库；解密只发生在内存；每次使用写审计。
4. **生命周期**：定期轮换 + 按身份撤销 + 过期回收；证书走同一平台 PKI。
5. **出口**：日志/错误上报统一 redact 中间件；CI 加 secret 扫描。

### 6.6.3 要求②「审批 / 越权防护」四层
- **L1 决策**：OPA/Cedar 在每次工具调用前授权（tenant/user/tool/args 全量输入）；deny-by-default。
- **L2 审批**：风险分级——只读自动；写操作异步审批（Slack/邮件/站内）；资金/删除/对外发送=双人复核；超时默认拒绝。
- **L3 隔离**：每租户独立沙箱/命名空间 + 网络白名单 + 最小权限凭证（详见 03 章）。
- **L4 审计**：全量 tool 调用 + 决策日志 + 审批记录，append-only；异常检测接 04 章观测栈。

### 6.6.4 要求③「可计费」流水线
用量事件（`tenant_id`、`model`、`tokens_in/out`、`tool_calls`、时长，字段对齐 `gen_ai.*`）→ 聚合/额度（OpenMeter）→ 定价/账单（Stripe；需要发票/订阅/税再上 Lago）→ 对账（审计日志）。**阶段 0 就把事件 schema 定对，后面换引擎零迁移。**

---

## 6.7 许可证红线速查（商用闭源视角）

| 项目 | 许可证（核实方式） | 对"商用闭源产品"的含义 |
|---|---|---|
| Zitadel v3+ | AGPL-3.0-only（LICENSING.md 实测） | ⚠️ 修改并作为网络服务提供需开源修改部分；原样自托管通常可控，建议法务评估 |
| Lago | AGPL-3.0（页面实测） | ⚠️ 同上；API 集成方式较常见，衍生判定仍需法务 |
| Bitwarden server | GPL-3.0 默认 + Bitwarden License v1.0（部分，含 Secrets Manager） | ⚠️ 部分非开源；勿嵌入 agent 产品链路 |
| PurpleLlama 根仓库 / PromptGuard 权重 | Llama 3.2 Community License（raw 实测） | ⚠️ 商用有条件：700M MAU 阈值、AUP、署名；“Built with Llama” |
| LlamaFirewall 子目录（代码） | MIT（raw 实测） | ✅（模型权重另算） |
| Infisical | MIT + `ee/` 专有（README/文档实测） | ✅ 核心可用；ee 功能需购买 |
| NeMo Guardrails | Apache-2.0（LICENSE.md 实测） | ✅ |
| guardrails-ai / garak / OPA / OPAL / Cedar / Keycloak / Supabase / Authelia / OpenMeter / OpenFGA / SpiceDB | Apache-2.0（多为页面实测/通行） | ✅ |
| OpenBao / SOPS | MPL-2.0 | ✅（文件级 copyleft，独立服务使用无碍） |
| Better Auth | MIT（api 实测） | ✅ |

> 惯例提醒：以上非法律意见；AGPL/GPL 的具体义务（尤其"修改版对外提供"）请过法务。

---

## 6.8 快速对比矩阵（重点考察四维）

| 项目 | 类别 | 自托管友好度 | 接入成本 | 与 agent 框架现成集成 | 商用闭源 |
|---|---|---|---|---|---|
| NeMo Guardrails | 护栏 | 高（库/server） | 中 | LangChain 现成；自研 loop 需包装 | ✅ |
| guardrails-ai | 护栏 | 高 | 低 | Python 库即插 | ✅ |
| LlamaFirewall | 护栏 | 高 | 中 | 独立库；分类器可单用 | ⚠️ 权重许可 |
| garak | 红队测试 | 高 | 低-中 | 引擎无关（打端点） | ✅ |
| HumanLayer | HITL 模式 | —（已废弃） | — | 仅模式参考 | ✅（代码） |
| Infisical | 密钥 | 高（compose） | 低-中 | SDK 全语言 | ✅（ee 除外） |
| OpenBao | 密钥/加密 | 中（运维门槛） | 中 | HTTP API/SDK | ✅ |
| SOPS | 密钥（静态） | 高（本地） | 低 | 无（文件层） | ✅ |
| Bitwarden | 密钥（人用） | 中 | 中 | 差 | ⚠️ 部分专有 |
| Better Auth | 身份 | 高（库） | 低（TS） | TS 生态原生 | ✅ |
| Keycloak | 身份 | 高 | 中 | OIDC 全语言 | ✅ |
| Zitadel | 身份 | 高 | 中低 | OIDC 全语言 | ⚠️ AGPL |
| Supabase | 身份/DB | 低（重） | 低（云）/高（自托管） | RLS 模式可移植 | ✅ |
| Authelia | 身份（门卫） | 高 | 低 | 反代层 | ✅ |
| OpenMeter | 计量 | 中（重） | 中 | HTTP API | ✅ |
| Lago | 计费 | 低-中（重） | 中高 | HTTP API | ⚠️ AGPL |
| OPA | 策略 | 高 | 中 | sidecar/库/WASM | ✅ |
| OPAL | 策略分发 | 高 | 中 | 配 OPA | ✅ |
| Cedar | 策略 | 高 | 中 | 绑定较少 | ✅ |
| OTel GenAI semconv | 审计标准 | —（规范） | 低 | 字段字典 | ✅ |

---

## 6.9 来源与核实记录

- **api.github.com 直调核实（2026-10-14，共 6 次）**：PurpleLlama 4,431★（license 识别为 Other——根 LICENSE 为 Llama 3.2 社区许可）｜NVIDIA-NeMo/Guardrails 7,299★（当日有推送）｜guardrails-ai/guardrails 7,521★ Apache-2.0｜Infisical 29,763★｜better-auth 30,292★ MIT｜humanlayer 11,695★（最后推送 2026-06-19）。
- **shields.io 徽章读取（2026-10-14）**：openbao 8.4k｜zitadel 15k｜keycloak 37k｜supabase 112k｜authelia 29k｜sops 23k｜opa 12k｜opal 5.5k｜lago 11k｜garak 9.6k｜bitwarden/server 20k｜cedar 1.8k｜openmeter 2.4k｜openfga 6k｜spicedb 7.1k｜kratos 14k。
- **关键事实的外部来源**：
  - LLM Guard 归档（2026-07-09）：https://github.com/protectai/llm-guard/issues/232
  - Rebuff 归档：https://github.com/protectai/rebuff
  - Kong 收购 OpenMeter（2025-09-03）：https://konghq.com/blog/news/kong-acquires-openmeter
  - Zitadel v3 → AGPL：https://zitadel.com/blog/zitadel-v3-announcement
  - NeMo Guardrails 组织迁移：https://github.com/NVIDIA-NeMo/Guardrails
  - Supabase 自托管警告：https://supabase.com/docs/guides/self-hosting
  - Keycloak 多租户实践：https://keycloakpro.com/blog/keycloak-multi-tenancy-organizations-guide
  - OTel GenAI 迁移与未稳定状态：https://praesidia.ai/blog/opentelemetry-genai-semantic-conventions-status ；https://john-hodge.com/blog/opentelemetry-genai-semantic-conventions
  - HumanLayer 现状：https://github.com/humanlayer/humanlayer （README 原文）
  - LlamaFirewall 论文/文档：https://github.com/meta-llama/PurpleLlama
  - OpenBao 版本现状（v2.7，2026-09）：第三方评测文章
- **诚实声明**：标『约/未核实』处为依据页面快照或项目通行信息；所有 star 均为 2026-10-14 快照，会随时间变化。本文未安装任何软件，未对项目做功能验证。

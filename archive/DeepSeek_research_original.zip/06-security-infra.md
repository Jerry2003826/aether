# 06 · 安全护栏 / 密钥 / 身份多租户 / 产品化基建

> 本文为『自研个人/产品级 AI Agent 系统 · 开源原材料调研』第 06 部分（安全与产品化集群）。
> **集群定位**：回答"Agent 敢不敢给别人用、怎么不出事、怎么收钱"——护栏与注入防御、密钥管理、身份/多租户、计量计费、策略与审计。
> **调研日期**：2026-10-14（UTC）。**方式**：只读调研（未安装任何软件），GitHub 主页 + 官方文档 + 2025–2026 第三方来源交叉核查。
> **核实说明**：6 个仓库经 `api.github.com` 直调核实（★/许可证/推送时间为精确值）；其余 ★ 经 shields.io 徽章读取（2026-10-14 快照）；没有任何来源的标『约/未核实』。许可证除标"实测/原文"外为项目通行信息，商用前请以仓库 LICENSE 为准。
> **收录口径**：只收真实存在、2024 后活跃的项目；已停更项目（LLM Guard、Rebuff、HumanLayer 开源部分）保留为**警示条目/模式来源**，活跃度字段已明确标注。
> **边界**：沙箱/容器隔离见 03 章，观测后端选型见 04 章，框架内置护栏（LangGraph interrupt 等）见 01 章，本文不重复。

---

## 0. TL;DR（结论先行）

- **单机自用最小集**：SOPS+age（密钥）＋ guardrails-ai 或 NeMo Guardrails（护栏）＋ 高危工具人工确认钩子 ＋ Postgres 用量日志。零重型组件。
- **产品化平滑升级链**：身份 `Better Auth/Keycloak → Zitadel`；密钥 `SOPS → Infisical → OpenBao`；计量 `PG 日志 → OpenMeter → Lago`；授权 `白名单 → OPA`。每层都走标准接口（OIDC / secret 引用 / policy bundle），换组件不动 agent 侧代码。
- **许可证红线 3 条**：`Zitadel(v3+)`、`Lago` 为 AGPL-3.0；`Bitwarden` 部分目录为专有许可（含 Secrets Manager）；`PurpleLlama` 根仓库为 Llama 社区许可（但其 LlamaFirewall 代码目录实测为 MIT）。其余主选（Apache-2.0/MIT/MPL-2.0）均可安全用于商用闭源产品。
- **已停更 3 坑**：LLM Guard（2026-07 归档）、Rebuff（2025 归档）、HumanLayer 开源代码（已废弃，转商业产品）——学思路，别做依赖。

---

## 6.1 护栏与注入防御

护栏在系统里的位置：**输入侧**（注入/越狱检测、话题边界）、**执行侧**（工具调用前策略、参数校验）、**输出侧**（内容合规、泄密检测）三段。下面项目按这三段分工。

### 6.1.1 NVIDIA NeMo Guardrails（推荐主选）
- **GitHub**：https://github.com/NVIDIA-NeMo/Guardrails （原 `NVIDIA/NeMo-Guardrails`，已迁移到 NVIDIA-NeMo 组织）
- **定位**：可编程 LLM/agent 护栏工具箱——用 Colang DSL 定义"什么输入/输出/话题/动作该被拦截"（rails），覆盖输入审查、输出审查、对话流约束、工具执行控制。
- **Star**：7,299 ★（api.github.com 核实，2026-10-14）
- **许可证**：Apache-2.0（`LICENSE.md`，SPDX 头实测）✅ 商用闭源无碍
- **技术栈**：Python + Colang DSL；提供 LangChain 集成与独立 server 模式
- **活跃度**：极高——2026-10-14 当日仍有推送（api 核实 `pushed_at`）
- **能当什么组件 / 能抄什么**：① 直接当"输入→推理→输出"的拦截中间件；② 抄分层 rail 设计：**input rails → dialog/topical rails（话题边界）→ output rails → tool/execution rails**；③ 流式输出场景的拦截点设计。
- **集成坑**：Colang 有学习曲线，且 2.0 换过语法——网上老例子可能过时；LLM-based rail 增加延迟与 token 成本（建议"轻量分类器 rail + LLM rail"分级混用）；它面向对话系统抽象，接入自研 agent loop 需要自写适配层。
- **上手速评**：接入成本=中；自托管=天然（本地库/自建 server）；框架集成=对 LangChain 现成、自研 loop 需包装；许可=✅。

### 6.1.2 Guardrails AI（推荐主选）
- **GitHub**：https://github.com/guardrails-ai/guardrails
- **定位**：Python 声明式"输入/输出校验"框架——用 pydantic/RAIL 定义 schema，从 Guardrails Hub 装 validators（毒性、PII、幻觉、正则等），校验不过自动 re-ask/修正。
- **Star**：7,521 ★（api.github.com 核实，2026-10-14）
- **许可证**：Apache-2.0（api 实测）✅；⚠️ 但 **Hub 上每个 validator 是独立包、许可各自不同**（少数带使用限制或需要外部 API key），商用需逐个核对。
- **技术栈**：Python（纯库）
- **活跃度**：高（2026-10-09 推送）
- **能当什么组件 / 能抄什么**：① 结构化输出 + 校验 + 失败重试闭环——agent 输出管道的"质检站"；② validator 即插即拔的注册表模式；③ "校验失败如何反馈给模型再生成"的 prompt 流程直接抄。
- **集成坑**：re-ask 循环 = 翻倍 token/延迟，必须设重试上限；Hub validator 需联网安装（离线环境要预打包）；1.0 前后有 breaking change，锁版本；部分 validator 依赖模型权重下载。
- **上手速评**：接入成本=低（一个 decorator）；自托管=天然；框架集成=任意 Python agent 直接调用；许可=✅（注意 validator）。

### 6.1.3 LLM Guard（⚠️ 已归档，2026-07-09）
- **GitHub**：https://github.com/protectai/llm-guard
- **定位**：输入/输出安全扫描器全家桶（提示注入、PII、毒性、敏感内容、密钥泄漏……），可组合成 pipeline。
- **Star**：约 3.2k ★（GitHub 页面快照）
- **许可证**：MIT（未逐一实测）。
- **活跃度**：❌ **2026-07-09 被所有者归档（只读）**；母体 Protect AI 2025 年被 Palo Alto Networks 收购（第三方来源；官方未将归档与收购关联）。
- **能当什么组件 / 能抄什么**：扫描器清单与"每类风险一个检测器 + 可调阈值"的组织方式值得抄；代码可 fork 自维护，但不再有上游补丁。
- **集成坑**：归档 = 无安全修复、无新攻击特征更新；存量使用需尽快替换或自行 fork 维护；替换路径：NeMo/guardrails-ai + PromptGuard 类分类器（见 6.1.4）。
- **上手速评**：新项目=不要依赖；存量=迁移。

### 6.1.4 LlamaFirewall / PurpleLlama（Meta；分类器可单用）
- **GitHub**：https://github.com/meta-llama/PurpleLlama （LlamaFirewall 位于子目录，含论文《LlamaFirewall: An open source guardrail system for building secure AI agents》）
- **定位**：Meta 的 agent 护栏框架三件套——**PromptGuard 2**（轻量注入/越狱分类模型）、**AlignmentCheck**（对推理链做对齐审查）、**CodeShield**（代码安全扫描，支持多语言语法感知）。
- **Star**：4,431 ★（PurpleLlama 仓库整体，api.github.com 核实，2026-10-14）
- **许可证**：⚠️ **分组件**！仓库根 `LICENSE` = **Llama 3.2 Community License**（raw 原文实测）；`LlamaFirewall/` 子目录自带 **MIT License**（raw 实测）；**PromptGuard 2 等模型权重**另按 Llama 许可（含 700M MAU 阈值、可接受使用政策、署名等条款）。商用前逐组件确认。
- **技术栈**：Python；需 HuggingFace 访问下载模型
- **活跃度**：高（2026-10-12 推送）
- **能当什么组件 / 能抄什么**：① **PromptGuard 2 可单独拿来当"注入/越狱分类器"**（比自训便宜）；② 多层防御架构（输入分类 → 推理审查 → 工具输出审查）值得抄；③ agent 写代码场景用 CodeShield 做静态检查。
- **集成坑**：AlignmentCheck 需再挂一个审查 LLM（成本/延迟叠加）；模型下载依赖网络与 HF 访问；许可条款需逐组件核（代码 MIT ≠ 权重 MIT）。
- **上手速评**：接入成本=中（较新，文档/社区案例少于 NeMo）；自托管=是；框架集成=独立 Python 库。

### 6.1.5 Rebuff（⚠️ 已归档）
- **GitHub**：https://github.com/protectai/rebuff
- **定位**：提示注入检测库（启发式 + LLM + 向量相似库 + canary token 四层融合）。
- **Star**：约 1.5k ★（页面快照）
- **许可证**：MIT（未核实）
- **活跃度**：❌ 已归档（仓库显示 Public archive；第三方称 2025-05 起停更）
- **能当什么组件 / 能抄什么**："canary token"（在上下文中埋已知答案，检测是否被诱导泄漏）与多检测器投票融合，思路仍值得参考。
- **集成坑**：特征库不再更新，现代越狱大概率绕过；**禁止作为生产依赖**。

### 6.1.6 garak（NVIDIA；护栏的"红队陪练"，推荐）
- **GitHub**：https://github.com/NVIDIA/garak
- **定位**：LLM 漏洞扫描器（红队工具）——静态/动态/自适应 probes，检测越狱、注入、数据泄漏等；对 agent 系统而言它是"攻击方"，用来**验证你的护栏到底有没有用**。
- **Star**：9.6k ★（shields.io 读取，2026-10-14）
- **许可证**：Apache-2.0（页面原文实测："Apache license v2"）✅
- **技术栈**：Python；支持 20+ 模型后端/API
- **活跃度**：高（NVIDIA 官方红队项目，2026 年仍在迭代）
- **能当什么组件 / 能抄什么**：把 garak 放进 CI 做"安全回归"：每次改护栏/提示词后跑一轮 probe，产出报告当调参依据；它的 probe 组织方式（风险类别 × 攻击手法）也可借鉴到自研测试集。
- **集成坑**：扫描组合多、全量跑耗时长（CI 里取子集）；需要配各家模型 API key；主要打模型/对话端点，agent 工具链级攻击面（MCP、工具误用）还需自己补测试。
- **上手速评**：接入成本=低-中；自托管=天然；与护栏项目互补（不是防御组件）。

### 6.1.7 HITL 人工审批：HumanLayer（模式来源）＋ 自研模式清单
- **项目**：https://github.com/humanlayer/humanlayer
- **Star**：11,695 ★（api 核实，2026-10-14）；**许可证**：Apache-2.0（`LICENSE` 原文实测）
- **⚠️ 现状**：仓库已转 issues-only，README 原文写明"代码基本全部废弃（pretty much all deprecated）"，重建版为人工审查类**商业产品**（humanlayer.com）；最后推送 2026-06-19。→ **只当模式库收录，不要做依赖。**
- **它贡献的模式（现在仍可抄）**：`@require_approval` 装饰器（函数级审批门）；`human_as_tool`（把"问人"做成一个工具）；审批请求路由到 Slack/Email/SMS；审批结果回填、agent 继续执行。
- **自研审批模式清单**（综合 LangGraph `interrupt()`、CrewAI `human_input`、Open WebUI 审批讨论等公开实践）：
  1. **工具级闸门**：危险工具调用前挂起（中断-持久化-恢复状态机），等待 approve/reject；
  2. **人即工具**：`ask_human(question)` 工具，agent 主动求决策；
  3. **异步通道**：审批推送 Slack/邮件/站内信；超时策略=默认拒绝或降级为只读；
  4. **风险分级**：只读自动放行；写操作按影响面审批；资金/删除/对外发送类=双人复核。
- **集成坑**：审批状态机必须持久化（人工响应可能几小时）；审批人身份要强校验（防伪造 approve）；每条审批必须进审计日志（谁、何时、批了什么）。

---

## 6.2 密钥管理（"密钥不落明文"）

### 6.2.1 Infisical（推荐主选）
- **GitHub**：https://github.com/Infisical/infisical
- **定位**：开源密钥/证书/PKI/特权访问平台；2026 官方定位已面向 "AI Agents" 场景（仓库简介原文包含 securing … AI Agents）。
- **Star**：29,763 ★（api.github.com 核实，2026-10-14）
- **许可证**：**MIT（expat）主体 + `ee/` 目录为专有企业许可**（README/官方文档原文）——闭源商用 OK；ee 功能（企业 SSO、部分细粒度 RBAC/审计等）需购买 license。
- **技术栈**：TypeScript + Go；docker compose / K8s 自托管
- **活跃度**：极高（2026-10-14 当日推送）
- **能当什么组件 / 能抄什么**：产品化"密钥中心"：machine identity（服务身份）、SDK 注入（`infisical run` 把密钥变进程环境变量）、轮换、动态密钥（DB/云）、secret sync、PKI。**抄它的 secret reference 模型**：代码里只出现路径/引用，值在运行时注入。
- **集成坑**：ee 边界要提前确认（哪些能力要花钱）；自托管需 PG + Redis，发版频繁升级要跟；"注入子进程环境变量"的密钥仍可能被进程 dump——高敏感场景用短时凭证而非长期静态值。
- **上手速评**：接入成本=低-中；自托管=友好；框架集成=SDK 全语言；许可=✅（ee 除外）。

### 6.2.2 OpenBao（推荐：产品期"加密服务"）
- **GitHub**：https://github.com/openbao/openbao
- **定位**：HashiCorp Vault 的社区 fork（Vault 改 BUSL 后从最后一个 MPL 版 1.14 分叉），Linux Foundation 治理，坚持 MPL-2.0。
- **Star**：8.4k ★（shields.io 读取）
- **许可证**：MPL-2.0（页面实测）——文件级 copyleft，作为独立服务使用无碍 ✅
- **技术栈**：Go；独立服务 + 存储后端（Raft/PG 等）
- **活跃度**：高（2026 年仍在发版，约 2026-09 发布 v2.7，第三方来源；部分企业特性仍在追赶上游 Vault）
- **能当什么组件 / 能抄什么**：① **transit 引擎 = 信封加密**（把用户的 API key/凭据加密落库，明文只在内存）；② 动态凭证（给 agent 发短时 DB 账号）；③ audit device（每次取密钥留痕）；④ PKI。抄"短期 token 生命周期 + 审计设备"这套模型。
- **集成坑**：运维成本真实（unseal、升级、灾备）；插件生态小于 Vault、少数企业功能缺失；API 与 Vault 高度兼容但有细节碎片，别照抄 Vault 文档。
- **上手速评**：接入成本=中（运维门槛）；自托管=核心场景；集成=HTTP API + 多语言 SDK；许可=✅。

### 6.2.3 SOPS + age（推荐：单机起步）
- **GitHub**：https://github.com/getsops/sops
- **定位**：文件级加密（"把密钥文件加密后放心进 git"），配合 age/KMS/PGP 管理收件人。
- **Star**：23k ★（shields.io 读取）
- **许可证**：MPL-2.0（通行信息，未逐一实测）
- **技术栈**：Go CLI；对接 git 工作流 / GitOps（Flux、Argo 生态广泛使用）
- **活跃度**：高
- **能当什么组件 / 能抄什么**：**单机自用阶段最省事的"密钥不落明文"方案**——SOPS(age) 加密 `.env`/配置进仓库，CI/部署时解密注入；也可当 Infisical/OpenBao 的 bootstrap 密钥载体。
- **集成坑**：静态加密 ≠ 运行时管理（无轮换/无审计/无动态凭证）；多人协作要管好 age 收件人列表；改一个值需重加密整个文件（小文件无碍）。
- **上手速评**：接入成本=低；自托管=本地即是；许可=✅。

### 6.2.4 Bitwarden（⚠️ 人用，不是 agent 基建）
- **GitHub**：https://github.com/bitwarden/server
- **定位**：面向人（和团队）的密码/凭据保管，含 Secrets Manager 产品。
- **Star**：20k ★（server 仓库，shields.io 读取）
- **许可证**：⚠️ 仓库默认 GPL-3.0，部分目录 Bitwarden License v1.0（专有）；**Secrets Manager 未按 GPL 发布**（社区讨论确认，二手来源）
- **技术栈**：C#/.NET 服务端 + 全平台客户端；vaultwarden（Rust）为兼容实现但不含 Secrets Manager
- **活跃度**：高（官方持续开发）
- **能当什么组件 / 能抄什么**：给"人"用的共享凭据/应急访问；**不建议作为 agent 运行时 secret 后端**（SM 非开源、自托管边界复杂）。
- **集成坑**：许可边界（GPL 主体 + 专有 SM）+ 商标条款；与 agent 链路集成性价比低。
- **上手速评**：人用 ✓；agent 基建 ✗。

---

## 6.3 身份与多租户（自用 → 多用户产品平滑升级）

### 6.3.1 Better Auth（TS 栈 MVP 首选）
- **GitHub**：https://github.com/better-auth/better-auth
- **定位**：TypeScript 生态新一代 auth **框架（库，不是独立服务）**——用户/会话/组织/API key/SSO/passkey 全靠插件；**organization 插件 = 多租户**（组织、成员、邀请、角色）。
- **Star**：30,292 ★（api.github.com 核实，2026-10-14）；2024-05 建仓，2024 后最猛的 auth 项目之一
- **许可证**：MIT（api 实测）✅
- **技术栈**：TypeScript（框架无关，Node/Bun/边缘运行时均可）
- **活跃度**：极高（2026-10-14 当日推送）
- **能当什么组件 / 能抄什么**：TS 栈产品的身份层首选——身份数据存自己 DB；抄"组织-成员-邀请-角色"数据模型与插件架构。
- **集成坑**：只有 TS 生态（Python 主栈需另架 Node 服务、或选 Keycloak/Zitadel）；项目年轻，插件质量参差；企业级能力（SCIM/审计）弱于老牌 IdP。
- **上手速评**：接入成本=低（TS）；自托管=天然（与应用同库）；许可=✅。

### 6.3.2 Keycloak（语言无关、许可最安全的成熟 IdP）
- **GitHub**：https://github.com/keycloak/keycloak
- **定位**：最成熟的开源 IdP/SSO（Red Hat 血统）：OIDC/SAML、管理台、扩展 SPI；新版引入 **Organizations** 组织模型做 B2B 多租户。
- **Star**：37k ★（shields.io 读取）
- **许可证**：Apache-2.0（通行信息）✅——本清单"许可 + 成熟度"综合最稳的身份基座
- **技术栈**：Java（JVM，资源占用大）
- **活跃度**：高（发版节奏稳定）
- **能当什么组件 / 能抄什么**：语言无关的产品身份层（Python/Go/Rust 栈都走标准 OIDC）；多租户用 Organizations，或 realm-per-tenant（**仅建议 5–20 个租户**，再多了会变成"在运营一个 IAM 平台"——来源：KeycloakPro 指南）。
- **集成坑**：重（内存/管理复杂度）；大版本升级有坑；realm 泛滥难治理；登录页/邮件定制要花功夫。
- **上手速评**：接入成本=中；自托管=成熟（官方容器/Helm）；许可=✅。

### 6.3.3 Zitadel（多租户 DX 最好，⚠️ AGPL）
- **GitHub**：https://github.com/zitadel/zitadel
- **定位**：云原生 IdP/CIAM，多租户一等公民（Organization/Project/Role 原生模型），OIDC/SAML/SCIM + Actions 钩子。
- **Star**：15k ★（shields.io 读取）
- **许可证**：⚠️ **AGPL-3.0-only（v3 起；`LICENSING.md` 原文实测：proto/、docs 目录 Apache-2.0，login 等目录 MIT）**。v2 时代曾为 Apache-2.0——在意许可可考虑 v2 时代版本或接受 AGPL。合规含义：**修改其代码并作为网络服务对外提供时需开源修改部分**；原样自托管通常可控，但项目方自己也在 LICENSING.md 里建议咨询法务。
- **技术栈**：Go；compose/K8s 自托管友好
- **活跃度**：高
- **能当什么组件 / 能抄什么**：产品期多租户身份层 DX 最好之一（每个客户=一个 org、自带品牌化/自助注册）；抄其多租户身份数据模型。
- **集成坑**：AGPL 需法务评估；部分企业功能付费；v3 迁移有变更；社区资料少于 Keycloak。
- **上手速评**：接入成本=中低；自托管=友好；许可=⚠️。

### 6.3.4 Supabase（抄 RLS 模式 > 上全家桶）
- **GitHub**：https://github.com/supabase/supabase
- **定位**：BaaS 全家桶（Postgres + Auth + Storage + Realtime + Edge Functions）。
- **Star**：112k ★（shields.io 读取）
- **许可证**：Apache-2.0（通行信息）✅
- **活跃度**：极高
- **能当什么组件 / 能抄什么**：① 若本来就用 Supabase 云，Auth + **RLS** 直接给到多租户基石：每行带 `tenant_id`，JWT claim 进 RLS 策略（`auth.uid()`）——**这个模式即使不用 Supabase 也能在纯 Postgres 复刻，是本集群最值得抄的单一模式**；② Auth 的 JWT 与数据库耦合设计。
- **集成坑**：自托管栈庞大，官方明说 CLI 本地栈"not hardened for production"、部分能力云限定；全量自托管 ≈ 自己运营一个平台。
- **上手速评**：抄模式=零成本；上全家桶（自托管）=重。

### 6.3.5 Authelia（管理面"门卫"）
- **GitHub**：https://github.com/authelia/authelia
- **定位**：自托管 SSO 门户 + 反向代理 forward-auth（2FA 门禁），并提供 OIDC Provider。
- **Star**：29k ★（shields.io 读取）
- **许可证**：Apache-2.0（通行信息）✅
- **技术栈**：Go；常配 nginx/Traefik/Caddy
- **活跃度**：高
- **能当什么组件 / 能抄什么**：给管理后台/内部工具/gateway 加统一登录与 2FA；forward-auth 模式（网关问 Authelia"这个请求是谁"）。
- **集成坑**：定位是"门卫"不是 CIAM——没有产品级自助注册/多租户概念；OIDC 能力比 Keycloak 简单。
- **上手速评**：接入成本=低（若已用反代）；适合阶段 1 护住内部面。

### 6.3.6 扩展候选（一行，未核实）
- **Ory Kratos**（≈14k★，shields 读取；Apache-2.0 通行）——身份服务组件，但无内置多租户，需自配 Hydra/Keto 组合，工程量大；适合"愿意自己拼"的团队。

---

## 6.4 计量与计费（可计费）

### 6.4.1 OpenMeter（Kong 旗下，推荐起点）
- **GitHub**：https://github.com/openmeterio/openmeter
- **定位**：AI/API 用量计量 + entitlements（额度/功能开关）——为"按 token/按调用计费"而生。
- **Star**：2.4k ★（shields.io 读取 + GitHub org 页快照一致）
- **许可证**：Apache-2.0（README 原文实测）✅
- **技术栈**：Go；事件流 Kafka + 分析 ClickHouse（较重）
- **活跃度**：中-高；**2025-09 被 Kong 收购**（官方公告），收购后继续开源（官网仍以 OSS 宣传）；路线图受 Kong 影响需关注。
- **能当什么组件 / 能抄什么**：计费中间层——agent 产出 usage events（tenant、model、tokens、工具调用）→ 聚合/额度判定 → Stripe 出账；抄其**事件 schema + entitlement 模型**。
- **集成坑**：自托管组件重（Kafka+ClickHouse）；官方 Helm chart 注记"仅供开发部署"（README 原文）——生产自托管要自己吃透部署；社区规模较小；收购后长期路线不确定性。
- **上手速评**：接入成本=中；自托管=可行但重；许可=✅。

### 6.4.2 Lago（⚠️ AGPL；完整账单引擎）
- **GitHub**：https://github.com/getlago/lago
- **定位**：开源计量 + 订阅计费 + 发票引擎（"开源 Stripe Billing"），仓库内带 agentic AI 计费示例（`examples/agentic-ai-demo`）。
- **Star**：11k ★（shields.io 读取）
- **许可证**：⚠️ **AGPL-3.0（页面原文实测）**——自托管免费；修改并以 SaaS 形式对外提供需开源修改部分；闭源产品以 API 方式集成也建议法务评估。
- **技术栈**：Ruby（API）+ React；事件引擎 ClickHouse，依赖 Kafka 等
- **活跃度**：高
- **能当什么组件 / 能抄什么**：真的需要"订阅管理 + 发票 + 税务 + 信用额度"成品时再上；早期 OpenMeter + Stripe 到不了这个复杂度。抄其"事件 → 定价模型 → 发票"流水线。
- **集成坑**：AGPL；自托管组件多（PG/Redis/CH/Kafka）运维重；定价模型配置有学习成本。
- **上手速评**：接入成本=中高；自托管=重；许可=⚠️。

---

## 6.5 策略与审计

### 6.5.1 OPA（推荐主选）
- **GitHub**：https://github.com/open-policy-agent/opa
- **定位**：通用策略引擎（策略即代码，Rego 语言）：输入（谁/租户/工具/上下文）→ 决策（allow/deny/带条件 permit）。
- **Star**：12k ★（shields.io 读取）
- **许可证**：Apache-2.0（通行信息）✅；CNCF 毕业项目
- **技术栈**：Go；进程内库 / REST sidecar / WASM 三形态
- **活跃度**：高
- **能当什么组件 / 能抄什么**：**agent 工具调用的授权决策点**——每次 tool call 前问 OPA"这个 tenant 的这个用户能不能跑这个工具、参数是否越权"；decision log 直接进审计。抄"策略与代码分离 + 决策日志"的治理模型。
- **集成坑**：Rego 学习曲线陡；非 Go 栈高频调用建议 sidecar/本地部署（远程 REST 加延迟）；多租户=多策略包，策略分发/版本管理要配套（→ OPAL）。
- **上手速评**：接入成本=中；自托管=友好（单二进制）；许可=✅。

### 6.5.2 OPAL（OPA 分发层）
- **GitHub**：https://github.com/permitio/opal
- **定位**：OPA 的"管理面"——监听策略/数据变化，实时推送到 OPA 集群（Permit.io 出品）。
- **Star**：5.5k ★（shields.io 读取）
- **许可证**：Apache-2.0（页面实测）✅
- **活跃度**：中-高
- **能当什么组件 / 能抄什么**：多租户下"每租户一套策略包"的实时分发；抄其发布-订阅更新模型。
- **集成坑**：多一个组件；单机/小规模用不上（OPA 自带 bundle 拉取可能就够）。

### 6.5.3 Cedar（OPA 备选，语法更友好）
- **GitHub**：https://github.com/cedar-policy/cedar
- **定位**：AWS 出品的授权策略语言/引擎（比 Rego 接近自然语言、强类型）。
- **Star**：1.8k ★（shields.io 读取）
- **许可证**：Apache-2.0（页面原文实测："This project is licensed under the Apache-2.0 License"）✅
- **技术栈**：Rust 核心；官方绑定以 Rust/Java/Go 等为主
- **活跃度**：中-高（AWS 在推）
- **能当什么组件 / 能抄什么**：agent 工具授权直接可用（principal × action × resource × context）；建议与 OPA 做小规模 POC 对比后定。
- **集成坑**：生态远小于 OPA；语言绑定少（Python 侧暂无官方一等支持）；资料多来自 AWS 文档。

### 6.5.4 OpenFGA / SpiceDB（ReBAC 扩展，一行）
- https://github.com/openfga/openfga （6k★）/ https://github.com/authzed/spicedb （7.1k★）（shields 读取；Apache-2.0 通行，未核实）——Google Zanzibar 风格"用户-关系-资源"授权，适合资源级权限天然是关系图的多租户场景；与 OPA（规则型）互补。

### 6.5.5 OpenTelemetry GenAI 语义约定（审计字段标准）
- **仓库**：https://github.com/open-telemetry/semantic-conventions （⚠️ 2026-06 起 GenAI 部分已迁至 `open-telemetry/semantic-conventions-genai` 独立仓库继续迭代）
- **定位**：不是工具，是 LLM/agent 遥测的**字段标准**：`gen_ai.request.model`、usage tokens、工具调用、MCP 等。
- **许可证**：Apache-2.0（规范仓库，通行）
- **状态/活跃度**：活跃演进；⚠️ **仍未稳定**——第三方核查（2026-07）：GenAI 类别无任何 span/attribute 标记 Stable，全部处于 Development。
- **能当什么组件 / 能抄什么**：① 审计与计费共用的字段字典（用量事件直接对齐 `gen_ai.*`）；② "未稳定期保留原始 attributes"的兼容落库策略。
- **集成坑**：未 Stable = 字段会变，别把字段名焊死在数据库 schema 里；具体观测后端选型见 04 章（本文只管字段标准）。

---

## 6.6 『安全与多租户』推荐组合（核心交付）

### 6.6.1 三阶段演进路线（单机自用 → 多用户产品，平滑升级）

| 能力 | 阶段 0 · 单机自用 | 阶段 1 · 小团队（邀请制） | 阶段 2 · 多租户产品 |
|---|---|---|---|
| 身份 | 单用户 API key | Better Auth（TS）或 Keycloak | Zitadel 或 Keycloak Organizations + 企业 SSO/SCIM |
| 密钥 | SOPS + age | Infisical 自托管（machine identity） | ＋OpenBao（transit 信封加密 / 动态凭证） |
| 护栏 | guardrails-ai 或 NeMo 轻量挂钩 ＋ 高危人工确认 | NeMo rails ＋ garak 定期红队回归 | 同上 ＋ 按租户/风险分级策略 |
| 授权 | 静态白名单 | OPA sidecar（单租户策略） | OPA 多租户策略包（OPAL 分发）＋ DB 层 RLS 兜底 |
| 审批 | CLI/IM 确认 | 自研审批队列（分级+异步+超时拒绝） | 审批工作流产品化（SLA/双人复核/审计） |
| 计量 | Postgres 用量日志 | OpenMeter | OpenMeter ＋（需要时）Lago |
| 审计 | 本地日志 | OTel GenAI 字段 ＋ PG | append-only ＋ OPA decision logs ＋ 留存策略 |

**升级不重做原则**：agent 侧只依赖抽象接口（OIDC / secret 引用 / policy 决策 API），底层组件可换——这是平滑升级的关键工程决策。

### 6.6.2 要求①「密钥不落明文」落地清单
1. **静态**：仓库里只有密文（SOPS）或引用（Infisical path / OpenBao path），永远没有明文 `.env`。
2. **运行时**：进程启动时向密钥中心拉取（machine identity + 短时 token）；工具在服务端执行，**密钥不进 LLM 上下文、不进 prompt**。
3. **用户密钥（BYOK）**：OpenBao transit（或云 KMS）信封加密落库；解密只发生在内存；每次使用写审计。
4. **生命周期**：定期轮换 + 按身份撤销 + 过期回收；证书走同一平台 PKI。
5. **出口**：日志/错误上报统一 redact 中间件；CI 加 secret 扫描。

### 6.6.3 要求②「审批 / 越权防护」四层
- **L1 决策**：OPA/Cedar 在每次工具调用前授权（tenant/user/tool/args 全量输入）；deny-by-default。
- **L2 审批**：风险分级——只读自动；写操作异步审批（Slack/邮件/站内）；资金/删除/对外发送=双人复核；超时默认拒绝。
- **L3 隔离**：每租户独立沙箱/命名空间 + 网络白名单 + 最小权限凭证（详见 03 章）。
- **L4 审计**：全量 tool 调用 + 决策日志 + 审批记录，append-only；异常检测接 04 章观测栈。

### 6.6.4 要求③「可计费」流水线
用量事件（`tenant_id`、`model`、`tokens_in/out`、`tool_calls`、时长，字段对齐 `gen_ai.*`）→ 聚合/额度（OpenMeter）→ 定价/账单（Stripe；需要发票/订阅/税再上 Lago）→ 对账（审计日志）。**阶段 0 就把事件 schema 定对，后面换引擎零迁移。**

---

## 6.7 许可证红线速查（商用闭源视角）

| 项目 | 许可证（核实方式） | 对"商用闭源产品"的含义 |
|---|---|---|
| Zitadel v3+ | AGPL-3.0-only（LICENSING.md 实测） | ⚠️ 修改并作为网络服务提供需开源修改部分；原样自托管通常可控，建议法务评估 |
| Lago | AGPL-3.0（页面实测） | ⚠️ 同上；API 集成方式较常见，衍生判定仍需法务 |
| Bitwarden server | GPL-3.0 默认 + Bitwarden License v1.0（部分，含 Secrets Manager） | ⚠️ 部分非开源；勿嵌入 agent 产品链路 |
| PurpleLlama 根仓库 / PromptGuard 权重 | Llama 3.2 Community License（raw 实测） | ⚠️ 商用有条件：700M MAU 阈值、AUP、署名；“Built with Llama” |
| LlamaFirewall 子目录（代码） | MIT（raw 实测） | ✅（模型权重另算） |
| Infisical | MIT + `ee/` 专有（README/文档实测） | ✅ 核心可用；ee 功能需购买 |
| NeMo Guardrails | Apache-2.0（LICENSE.md 实测） | ✅ |
| guardrails-ai / garak / OPA / OPAL / Cedar / Keycloak / Supabase / Authelia / OpenMeter / OpenFGA / SpiceDB | Apache-2.0（多为页面实测/通行） | ✅ |
| OpenBao / SOPS | MPL-2.0 | ✅（文件级 copyleft，独立服务使用无碍） |
| Better Auth | MIT（api 实测） | ✅ |

> 惯例提醒：以上非法律意见；AGPL/GPL 的具体义务（尤其"修改版对外提供"）请过法务。

---

## 6.8 快速对比矩阵（重点考察四维）

| 项目 | 类别 | 自托管友好度 | 接入成本 | 与 agent 框架现成集成 | 商用闭源 |
|---|---|---|---|---|---|
| NeMo Guardrails | 护栏 | 高（库/server） | 中 | LangChain 现成；自研 loop 需包装 | ✅ |
| guardrails-ai | 护栏 | 高 | 低 | Python 库即插 | ✅ |
| LlamaFirewall | 护栏 | 高 | 中 | 独立库；分类器可单用 | ⚠️ 权重许可 |
| garak | 红队测试 | 高 | 低-中 | 引擎无关（打端点） | ✅ |
| HumanLayer | HITL 模式 | —（已废弃） | — | 仅模式参考 | ✅（代码） |
| Infisical | 密钥 | 高（compose） | 低-中 | SDK 全语言 | ✅（ee 除外） |
| OpenBao | 密钥/加密 | 中（运维门槛） | 中 | HTTP API/SDK | ✅ |
| SOPS | 密钥（静态） | 高（本地） | 低 | 无（文件层） | ✅ |
| Bitwarden | 密钥（人用） | 中 | 中 | 差 | ⚠️ 部分专有 |
| Better Auth | 身份 | 高（库） | 低（TS） | TS 生态原生 | ✅ |
| Keycloak | 身份 | 高 | 中 | OIDC 全语言 | ✅ |
| Zitadel | 身份 | 高 | 中低 | OIDC 全语言 | ⚠️ AGPL |
| Supabase | 身份/DB | 低（重） | 低（云）/高（自托管） | RLS 模式可移植 | ✅ |
| Authelia | 身份（门卫） | 高 | 低 | 反代层 | ✅ |
| OpenMeter | 计量 | 中（重） | 中 | HTTP API | ✅ |
| Lago | 计费 | 低-中（重） | 中高 | HTTP API | ⚠️ AGPL |
| OPA | 策略 | 高 | 中 | sidecar/库/WASM | ✅ |
| OPAL | 策略分发 | 高 | 中 | 配 OPA | ✅ |
| Cedar | 策略 | 高 | 中 | 绑定较少 | ✅ |
| OTel GenAI semconv | 审计标准 | —（规范） | 低 | 字段字典 | ✅ |

---

## 6.9 来源与核实记录

- **api.github.com 直调核实（2026-10-14，共 6 次）**：PurpleLlama 4,431★（license 识别为 Other——根 LICENSE 为 Llama 3.2 社区许可）｜NVIDIA-NeMo/Guardrails 7,299★（当日有推送）｜guardrails-ai/guardrails 7,521★ Apache-2.0｜Infisical 29,763★｜better-auth 30,292★ MIT｜humanlayer 11,695★（最后推送 2026-06-19）。
- **shields.io 徽章读取（2026-10-14）**：openbao 8.4k｜zitadel 15k｜keycloak 37k｜supabase 112k｜authelia 29k｜sops 23k｜opa 12k｜opal 5.5k｜lago 11k｜garak 9.6k｜bitwarden/server 20k｜cedar 1.8k｜openmeter 2.4k｜openfga 6k｜spicedb 7.1k｜kratos 14k。
- **关键事实的外部来源**：
  - LLM Guard 归档（2026-07-09）：https://github.com/protectai/llm-guard/issues/232
  - Rebuff 归档：https://github.com/protectai/rebuff
  - Kong 收购 OpenMeter（2025-09-03）：https://konghq.com/blog/news/kong-acquires-openmeter
  - Zitadel v3 → AGPL：https://zitadel.com/blog/zitadel-v3-announcement
  - NeMo Guardrails 组织迁移：https://github.com/NVIDIA-NeMo/Guardrails
  - Supabase 自托管警告：https://supabase.com/docs/guides/self-hosting
  - Keycloak 多租户实践：https://keycloakpro.com/blog/keycloak-multi-tenancy-organizations-guide
  - OTel GenAI 迁移与未稳定状态：https://praesidia.ai/blog/opentelemetry-genai-semantic-conventions-status ；https://john-hodge.com/blog/opentelemetry-genai-semantic-conventions
  - HumanLayer 现状：https://github.com/humanlayer/humanlayer （README 原文）
  - LlamaFirewall 论文/文档：https://github.com/meta-llama/PurpleLlama
  - OpenBao 版本现状（v2.7，2026-09）：第三方评测文章
- **诚实声明**：标『约/未核实』处为依据页面快照或项目通行信息；所有 star 均为 2026-10-14 快照，会随时间变化。本文未安装任何软件，未对项目做功能验证。

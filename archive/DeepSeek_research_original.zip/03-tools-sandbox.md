# 03 · 工具/技能生态与执行环境（工具接入 · 沙箱执行 · 浏览器/计算机操作）

> **核实口径**：数据读取于 2026-10-14（UTC）。star 与许可证标注来源：
> `[API]` = api.github.com 直读（本次共享限流预算内共 6 次）；`[GH]` = github.com 仓库页 + commits.atom 当日直读；未读取到的字段显式标「未核实」。
> **收录门槛**：真实存在、2024 年后仍活跃或有 2024+ 维护记录；已归档/停滞项目单独标注，不作为推荐。
> **边界**：本册只管「工具/技能 + 执行环境 + 浏览器/计算机操作」；框架（01）、记忆（02）、模型/可观测（04）、交互/调度（05）、安全/基建（06）不在此展开。
> **只读调研，未在本机安装任何东西。**

---

## 0. TL;DR（先看这一段）

- **三条最值得抄的架构主线**：① **MCP 网关 + 凭证代理**（密钥不进模型上下文、不进沙箱，工具按策略授权）；② **技能包（SKILL.md）渐进式披露**（元数据常驻、正文按需加载，解决上下文爆炸）；③ **沙箱分层**（OS 原语 → 本地 microVM → 云 microVM，按代码可信度选层，不要一把梭）。
- **单机最小可用组合（全开源）**：`srt`（把 agent 自己关进盒子）+ `microsandbox`（跑不可信生成代码）+ `Playwright MCP`（浏览器）+ `Docker MCP Gateway`/`Executor`（工具接入与策略）。
- **云上多租户组合**：自托管 `E2B`（Apache-2.0 全栈，Firecracker）或自建 Firecracker/Kata 池。
- **许可证雷区（限制性条款，重点盯）**：**Daytona**（2026-06 起生产代码闭源、仓库已归档）、**Skyvern**（AGPL-3.0）、**Judge0**（GPL-3.0，CE 版）、**Nango**（Elastic License 2.0：禁止向第三方提供托管服务）、**anthropics/skills 的 docx/pdf/pptx/xlsx 技能**（source-available，非开源）、**Smithery CLI**（AGPL-3.0）。GPL/AGPL 家族意味着：一旦链接进你的分发产物，传染性条款会咬人；SaaS 形态下 AGPL 的网络条款同样触发。
- **一条血泪教训**：Daytona 曾是「开源沙箱三强」之一，71.5k star、AGPL 核心，2026-06 直接把生产代码闭源、仓库归档、`releases/latest` 停在 **v0.190.0**，GitHub license 字段已清空 `[API]`。**自研系统的沙箱/工具层必须设计成可替换接口（driver/adapter），并在选型时给「许可证与治理风险」单独打分。**

---

## A. 工具与技能生态

### A1. MCP 生态（协议接入层）

#### A1-1. modelcontextprotocol/servers —— MCP 官方参考服务器仓库
- **链接**：https://github.com/modelcontextprotocol/servers
- **定位**：MCP 协议官方参考实现集合（filesystem / fetch / git / memory / sequential-thinking 等），同时是「怎么写 MCP server」的最佳范本。
- **约 star**：91,265 `[GH]`（fork 11,790，watch 635）
- **许可证**：**MIT → 正在迁移 Apache-2.0**（LICENSE 文件明示过渡：新代码规范均 Apache-2.0，文档 CC-BY-4.0；旧 MIT 贡献者未同意重授权部分仍 MIT）。无限制性条款。
- **技术栈**：TypeScript / Python（官方 SDK 双语言），JSON-RPC over stdio / SSE / Streamable HTTP。
- **活跃度**：高（最后提交 2026-10-11；29 个 release）`[GH]`。
- **能当什么组件/能抄什么**：① 直接复用 filesystem/git/fetch 这类「通用工具服务器」；② 抄它的 **tools/resources/prompts 三段式声明**与错误语义；③ 抄「参考实现 vs 归档服务器」的目录治理方式。注：该仓库大部分旧服务器已归档或迁往独立仓库，官方推荐从 registry 发现、按需自建。
- **集成坑**：① stdio 传输下**服务器进程与 agent 同机同权限**，MCP server 一旦被投毒就是宿主 RCE 入口；② 工具描述（description/tool schema）会全额塞进上下文，几十个 server 全挂上去会先把上下文挤爆——必须配工具筛选/路由层；③ 该仓库是「参考」不是「产品」，生产用要自己加固（超时、输出截断、沙箱化执行）。

#### A1-2. punkpeye/awesome-mcp-servers —— MCP 服务器大全（社区清单）
- **链接**：https://github.com/punkpeye/awesome-mcp-servers
- **定位**：规模最大的 MCP server 人工整理清单，按场景分类，含官方/社区/云服务三类标注。
- **约 star**：96,340 `[GH]`
- **许可证**：MIT（无限制性条款）
- **技术栈**：纯 Markdown 清单
- **活跃度**：高（最后提交 2026-10-09）`[GH]`
- **能当什么组件/能抄什么**：选型检索入口；抄它的分类维度（🗂️ 官方 / ☁️ 云 / 🏠 本地 / 🔗 聚合）来做自家工具目录的分类。
- **集成坑**：**收录 ≠ 安全**。清单里的第三方 server 是裸社区代码；引用前必须过一遍源码、权限（它能碰什么文件/网络/凭证）。别把清单当信任白名单。

#### A1-3. 官方 MCP Registry（registry.modelcontextprotocol.io）—— 协议级注册中心
- **链接**：https://registry.modelcontextprotocol.io （规范仓：https://github.com/modelcontextprotocol/registry ）
- **定位**：MCP 官方注册中心，元数据发现层（Anthropic / GitHub / PulseMCP / Microsoft 背书），2026 年已到 API v0.1 冻结；**是权威性来源，不是服务器运行时**。
- **约 star**：服务，star 不适用（registry 规范仓库约 5k+，未核实）
- **许可证**：注册中心 API 为开放规范（仓库 MIT，未逐字核实）
- **技术栈**：REST/JSON 元数据；服务端实现开源
- **活跃度**：高（生态级基础设施）
- **能当什么组件/能抄什么**：自研系统的**工具/连接器元数据层**直接对齐它的 schema（server 名称、传输、认证需求、版本），未来可做「一键导入」。抄它的「元数据与运行时分离」设计。
- **集成坑**：注册中心**不做安全审计也不托管运行**；「官方注册」只表示元数据合规。别把 registry 条目当作可信来源。

#### A1-4. Smithery —— MCP 托管网关 + 注册中心（商业服务混合体）
- **链接**：https://smithery.ai （CLI：https://github.com/smithery-ai/cli ，840★ `[GH]`）
- **定位**：MCP 生态里最接近「Docker Hub + 托管运行时」的平台：7,000+ servers；既支持本地 `npx` 安装，也提供**托管远程 server**（代为管理 OAuth/凭证、会话），提供 Connect API（连接命名空间、JSON-RPC 调用、trigger webhook）。
- **约 star**：平台为服务（无 star）；CLI 仓库 840★
- **许可证**：**CLI 为 AGPL-3.0（限制性！）**；平台本身是商业 SaaS（服务条款约束，未核实细则）
- **技术栈**：TypeScript CLI；托管侧管理 OAuth、传输升级
- **活跃度**：平台活跃；CLI 仓库最后提交 2026-05-31，相对缓慢 `[GH]`
- **能当什么组件/能抄什么**：抄它的**「注册中心 + 托管连接」双形态**：本地跑（token 不出机）vs 托管跑（token 经其网关瞬时传递）——这正是自研系统「工具接入」要做的产品化抽象。托管 OAuth 弹窗、upsert 连接、trigger webhook 都是可抄的模式。
- **集成坑**：① **安全实锤**：GitGuardian 披露过 Smithery 托管功能的路径穿越 → 供应链风险；另有 2026-03 扫描称 100 个 Smithery server 中 22 个存在安全问题（第三方扫描数据，标为参考）。托管 server = 「别人机房里跑着你的凭证使用链」，信任半径巨大；② CLI AGPL-3.0，直接内置进闭源产品要谨慎；③ 托管模式下调用元数据会过第三方。

#### A1-5. mcp.so —— 社区提交制 MCP 目录（最大集散地）
- **链接**：https://mcp.so
- **定位**：19,700+ 条目的社区 MCP 目录（GitHub issue 提交制），广度最大。
- **约 star**：服务，无 star
- **许可证**：目录服务（条目指向的 server 各有其许可证）
- **技术栈**：Web 目录
- **活跃度**：高（社区日更）
- **能当什么组件/能抄什么**：广度调研入口（"这个领域有没有现成 server"）。
- **集成坑**：**零审核**——任何人均可提交，垃圾/钓鱼/停更条目混杂；只当搜索引擎用，不当质量标准用。

#### A1-6. OpenAPI → MCP 桥接器（把自家 REST API 变成工具）
| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 一句话 |
|---|---|---|---|---|---|
| **mcpo** | https://github.com/open-webui/mcpo | 4,401 `[GH]` | MIT | 中低（最后提交 2026-02-27） | 把任意 MCP server 桥成 OpenAPI/HTTP 服务，反向兼容也常用 |
| **fastapi_mcp** | https://github.com/tadata-org/fastapi_mcp | 12,022 `[GH]` | MIT | 慢（最后提交 2025-08-10） | FastAPI 一键暴露为 MCP server，鉴权可透传 |
| **openapi-mcp-server** | https://github.com/snaggle-ai/openapi-mcp-server | 903 `[GH]` | MIT | 中（最后提交 2026-07-07） | OpenAPI spec → MCP tools，适合存量 API 资产 |
| **MCP Inspector** | https://github.com/modelcontextprotocol/inspector | 11,078 `[GH]` | MIT | 高（2026-10-14） | 官方调试/自测工具，开发期必备 |

- **能当什么组件/能抄什么**：自研系统的**工具注册管线**：`OpenAPI spec → 工具 schema → 权限声明 → 发布`。抄 fastapi_mcp 的「按端点粒度为工具 + 鉴权透传」，抄 mcpo 的「一进程多 server 聚合」。
- **集成坑**：① OpenAPI 自动转换会把**每个端点都变成工具**，200 个端点 = 200 个工具直接压垮上下文 → 必须做工具筛选/分组/路由（见 D 节 tool router）；② 参数 schema 噪声（分页、过滤参数）会诱导模型乱填，需手工收窄；③ 鉴权透传别把用户 token 直接塞给模型可见层，走凭证代理（见 D 节）。

---

### A2. 工具执行与授权平台（连得上 + 管得住 + 密钥隔离）

#### A2-1. Composio —— 工具集成与授权平台（生态事实标准）
- **链接**：https://github.com/ComposioHQ/composio
- **定位**：1,000+ toolkits 的集成层：托管 OAuth/令牌刷新、工具检索（tool search）、Tool Router（按意图动态加载工具而非全量挂载）、以及一个 sandboxed workbench 用于执行。
- **约 star**：30,552 `[API]`（fork 4,852，2026-10-14 仍在提交）
- **许可证**：**仓库 MIT**（SDK/工具集）；托管平台为商业 SaaS 计费。**自托管能力存在不同说法**（早期官方联合创始人在 HN 回复「不支持自托管、源码不公开」；另有资料称「SDK 与自托管 MCP server 可 MIT 部署」）→ **以官方文档为准，标未核实**。
- **技术栈**：TypeScript 为主 + Python SDK；REST + SSE/远程 MCP；支持 MCP 客户端接入。
- **活跃度**：高（2026-10-14 提交）`[API]`
- **能当什么组件/能抄什么**：**抄它的 Tool Router 与 tool search**——这正是自研系统解决「工具太多、上下文太少」的正解；抄「connected account」抽象（把 OAuth 连接与工具调用解耦，凭证在平台侧解析再注入请求）；抄它的 toolkit 目录结构。
- **集成坑**：① 走托管平台 = 用户 OAuth token 存在第三方，企业客户会卡合规；② 免费档限速（约 60 req/min/AK，第三方资料）不适合高频工具循环；③ 别把它的 SaaS 当唯一路径——自研至少留「本地凭证代理」替代实现。

#### A2-2. Executor（UsefulSoftwareCo/executor）—— 可自托管的集成层 / MCP 网关
- **链接**：https://github.com/UsefulSoftwareCo/executor
- **定位**：面向 agent 的集成层：把 MCP server、OpenAPI、GraphQL API 统一配置成一份目录，带**认证与 per-tool 策略**，供任意 MCP 兼容 agent 使用；提供 Cloud / Desktop / CLI / Docker 自托管 / Cloudflare Workers 全套部署形态。
- **约 star**：4,180 `[GH]`（YC S26 项目，2026 年内快速增长）
- **许可证**：MIT（无限制性条款）
- **技术栈**：TypeScript（monorepo：core/cli/desktop/local/cloud/self-host）
- **活跃度**：高（最后提交 2026-10-12）`[GH]`
- **能当什么组件/能抄什么**：**自研「工具接入 + 凭证隔离」最直接的开源参考实现**：一个目录管所有集成、策略按工具粒度、凭证隔离在网关侧、沙箱化执行。抄它的 self-host 部署拓扑与 per-tool policy 模型。
- **集成坑**：① 年轻（约一年），核心面足够但生产级评价样本少；② 策略/审计能力相对商业平台仍浅，别指望它直接当企业 IAM。

#### A2-3. MCP 网关三件套（把「工具接入」做成基础设施）
| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 关键能力 / 坑 |
|---|---|---|---|---|---|
| **Docker MCP Gateway** | https://github.com/docker/mcp-gateway | 1,600 `[GH]` | MIT | 中（2026-09-16） | 每个 MCP server 跑在受限容器里 + 网关级配置/凭证/工具审批；AI Governance 集中策略为邀请制；凭证保险库要自己做 |
| **IBM ContextForge** | https://github.com/IBM/mcp-context-forge | 4,634 `[GH]` | Apache-2.0 | 高（2026-10-14） | MCP 注册中心 + **REST→MCP 转换** + 联邦；2026-05-01 GA，v1.0.4（2026-06-23）；重量级，Java/Go 味的企业栈 |
| **microsoft/mcp-gateway** | https://github.com/microsoft/mcp-gateway | 879 `[GH]` | MIT | 高（2026-10-14） | 轻量会话感知网关与路由；微软生态亲和，独立于 Azure 也可跑 |

- **能当什么组件/能抄什么**：**「网关层」是自研系统的必答题**：集中做工具目录、凭证解析、策略评估、审批、审计。抄 Docker 的「server 容器化 + 特权最小化 + 请求审批」，抄 ContextForge 的「注册中心 + 协议转换（REST/OpenAPI → MCP）」。
- **集成坑**：① 纯开源网关普遍**不含凭证保险库与统一审计**（Composio 那篇文章自己也承认：这三个要你自己建）——自研时把它列为独立模块；② 网关成为单点：挂了全挂，需热备与降级（直连模式兜底）；③ 容器隔离 ≠ 强隔离（共享内核），别用 Docker 网关冒充「不可信代码沙箱」。

#### A2-4. 授权/连接平台对照（自托管与许可维度）
| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 说明 |
|---|---|---|---|---|---|
| **Nango** | https://github.com/NangoHQ/nango | 12,663 `[GH]` | **Elastic License 2.0（限制性）** | 高（2026-10-14） | 700+ API 的 OAuth 连接/令牌刷新引擎，可自托管；**Elastic License 禁止把其功能作为托管服务对外提供**，内部用可以 |
| **Arcade** | https://github.com/ArcadeAI/arcade-ai | 1,052 `[GH]` | MIT | 高（2026-10-14） | 工具调用 + 授权（OAuth）框架，体量小、可读性好 |
| **ACI** | https://github.com/aipotheosis-labs/aci | 4,912 `[GH]` | Apache-2.0 | 中低（最后提交 2026-05-28） | 自托管 Composio 类替代（600+ 集成，统一 MCP server）；活跃度走弱，评估风险 |

- **能当什么组件/能抄什么**：**凭证代理（credential broker）**模式：外部 API 的 OAuth 授权、刷新、按 connected account 解析 token、只在实际出站请求时注入。这是「密钥隔离」的实现核心——模型和沙箱永远看不到原始令牌。
- **集成坑**：Elastic License / 商业条款类项目要过法务；「连接即权限」——注意 refresh token 的存储加密与轮换，以及最小 scope 原则。

---

### A3. Agent Skills 规范与社区技能库

#### A3-0. 规范本身（先读这个）
- **Agent Skills 规范**：https://agentskills.io ；规范仓 https://github.com/agentskills/agentskills —— **26,142★ `[GH]`，Apache-2.0**，最后提交 2026-08-09。
- **时间线**：Anthropic 2025-10 随 Claude 推出 Skill 格式；**2025-12-18 发布为开放标准**（规范 + SDK），现由 26+ 平台采用（Claude、OpenAI Codex、Gemini CLI、GitHub Copilot、Cursor、VS Code 等）。
- **核心机制（自研必抄）**：一个技能 = 一个文件夹（`SKILL.md`（YAML frontmatter: name/description + Markdown 正文）+ 可选 `scripts/`、`references/`、`assets/`）。**三级渐进式披露**：① 启动时只加载 name+description（约 100 token/技能）→ ② 命中任务才加载完整 SKILL.md（通常 <5k token）→ ③ 脚本/参考文件按需读取。这是「几百个技能上机也不爆上下文」的关键。
- **集成坑**：① 技能里的 scripts 是**可执行代码**，必须与技能信任级别绑定（不可信技能 = 不可信代码，要过沙箱/策略）；② 描述质量决定命中率，description 写法差的技能等于没装；③ 规范仍在演进（2026 年内多次修订），解析器要容错。

#### A3-1. anthropics/skills —— 官方技能仓库 + 参考实现
- **链接**：https://github.com/anthropics/skills
- **定位**：官方 Skill 集合（creative/design、dev、enterprise/communication、document skills），含 `/spec` 规范文本与 `/template`。
- **约 star**：181,150 `[GH]`（生态热度最高的单体仓之一）
- **许可证**：**多数技能 Apache-2.0；但 `skills/docx`、`skills/pdf`、`skills/pptx`、`skills/xlsx` 四个文档技能是 source-available（非开源）**——官方明说「share as reference」。**限制性条款，商用前必须逐一核对。**
- **技术栈**：Markdown + 附带脚本（Python/JS）；可作为 Claude Code plugin marketplace（`/plugin marketplace add anthropics/skills`）注册。
- **活跃度**：高（最后提交 2026-10-09）`[GH]`
- **能当什么组件/能抄什么**：① 抄「复杂技能长什么样」（文档技能的目录结构、脚本组织、错误处理）；② 直接参考它的 SKILL.md 写作规范；③ 抄 plugin marketplace 分发模型。
- **集成坑**：**许可证是混的**（Apache-2.0 与 source-available 同仓），不要整仓照搬；技能内脚本会调用外部依赖（如 docx 库），离线环境要预置。

#### A3-2. 社区技能库（可直接拿来做自家技能的「种子集」）
| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 特点 |
|---|---|---|---|---|---|
| **addyosmani/agent-skills** | https://github.com/addyosmani/agent-skills | 106,676 `[GH]` | MIT | 高（2026-10-13） | 23 个工程生命周期技能 + 7 个 slash 命令（/spec /plan /build /test /review /ship），含硬性退出标准、反合理化表格，编码 Google 工程文化 |
| **VoltAgent/awesome-agent-skills** | https://github.com/VoltAgent/awesome-agent-skills | 35,720 `[GH]` | MIT | 高（2026-10-13） | 1,000+ 技能索引，跨 Claude Code / Codex / Gemini CLI / Cursor |
| **ComposioHQ/awesome-claude-skills** | https://github.com/ComposioHQ/awesome-claude-skills | 77,121 `[GH]` | **未核实**（页面未解析出 license） | 中（2026-07-24） | 技能清单 + 生态资源索引（含 skills marketplace 入口） |
| **skills.sh（分发平台）** | https://www.skills.sh | 服务 | 服务条款 | 活跃 | `npx skills add <owner/repo>` 一键装技能，带排行榜（按真实使用而非发布热度） |
| **superradcompany/skills** | https://github.com/superradcompany/skills | 未核实 | 未核实 | 与 microsandbox 同步 | microsandbox 自带的「沙箱技能包」，示范「技能 = 安全执行能力 + 指令」捆绑 |

- **能当什么组件/能抄什么**：**自研技能系统的最小闭环**＝`技能目录 + SKILL.md 解析器 + 渐进加载 + 技能级权限与依赖声明 + 沙箱执行 + 分发/安装命令`。addyosmani 那套直接回答「技能里的指令怎么写才有约束力」（退出标准、反合理化）——这是技能质量的关键，比格式重要。
- **集成坑**：① 社区技能**质量方差极大**，很多是 prompt 复读；引入前看最近提交与行为验证；② 技能会改 agent 行为边界（比如偷偷放宽审批），**技能需与权限系统分层：技能不能扩权**；③ 跨平台兼容层不统一（各家的斜杠命令/路径约定不同）。

---

## B. 沙箱与代码执行

> 分层心智模型（按「隔离强度 / 启动成本」排）：
> **L0 OS 原语**（同内核约束，最便宜）→ **L1 本地 microVM**（本机强隔离，~100ms）→ **L2 云 microVM/容器**（多租户规模化）→ **L3 代码执行服务**（API 化的片段执行）。

### B1. 平台级沙箱（云/自托管）

#### B1-1. E2B —— 开源 Firecracker microVM 沙箱（事实标准）
- **链接**：https://github.com/e2b-dev/E2B （自托管全栈：https://github.com/e2b-dev/infra ）
- **定位**：AI agent 代码执行沙箱的参照实现：每个沙箱一台 Firecracker microVM（独立内核）、约 150ms 启动、完整 Linux 文件系统 + 预装 Python/Node 生态；Python/JS SDK；支持自托管。
- **约 star**：14,354 `[API]`；infra 仓库 1,716 `[GH]`
- **许可证**：Apache-2.0（主仓 + infra，均无限制性条款）`[API]`/`[GH]`
- **技术栈**：Python/TS SDK + Firecracker + Go 控制面（infra）；自托管支持 BYOC（AWS/GCP）。
- **活跃度**：高（2026-10-14 双仓均在提交）`[API]`/`[GH]`
- **能当什么组件/能抄什么**：① 自研「云沙箱层」首选底座（自托管）；② 抄它的生命周期 API（create/pause/resume/kill、**pause 后状态持久**）；③ 抄「沙箱 = 带真实工具的环境」定位（装了 git/pip/node，而不只是 REPL）。Manus（27 工具）/Perplexity/HuggingFace 都在用的公开案例可背书。
- **集成坑**：① **无公开合规认证**（其 Trust Center 未见 SOC 2/ISO/HIPAA——第三方对比资料），企业交付要自己扛合规；② 活动会话有时长上限（Hobby 1h / Pro 24h，第三方资料），pause-resume 约 1s 且有配额概念；③ 自托管 SLA 全靠自己；④ 计费按秒（vCPU ~$0.10/h 级，第三方资料），长时间挂机会烧钱。

#### B1-2. microsandbox —— 本地优先 microVM 运行时（单机自研首选）
- **链接**：https://github.com/superradcompany/microsandbox （配套 MCP：https://github.com/superradcompany/microsandbox-mcp ；Agent Skills 包：superradcompany/skills）
- **定位**：「把不可信负载塞进本机 microVM」的运行时与库：AI 生成代码、插件、CI 任务、爬虫、自动化。**可嵌入代码中直接 spawn VM（无常驻 daemon）**，OCI 镜像兼容（Docker Hub/GHCR 直接跑），支持 **fork/snapshot 运行中沙箱**、**密钥「不可泄露」（secret key 从不进入 VM 内）**、跨 Linux/macOS/Windows。
- **约 star**：8,682 `[GH]`
- **许可证**：Apache-2.0（README 自述，无限制性条款）
- **技术栈**：Rust（library + CLI）；microVM（轻量 hypervisor 路线）；内置 MCP server 与 Agent Skills。
- **活跃度**：高（最后提交 2026-10-13）`[GH]`
- **能当什么组件/能抄什么**：**单机版「不可信代码安全执行」的第一选择**：① 抄「secrets 不进 VM」的设计——密钥在宿主侧代理注入，VM 里拿到的是短期凭据；② 抄 fork/snapshot（并行跑 N 个分支试错，或秒级恢复环境）；③ 抄「库化而非服务化」，自研系统可直接嵌进进程。
- **集成坑**：① 年轻项目（约一年），Windows/跨平台路径的成熟度需自测；② 本机 microVM 依赖宿主虚拟化能力（KVM/HVF/WHP），**嵌套虚拟化环境（比如你自己的云 VM）可能开不了**——部署前先验证 `/dev/kvm`；③ 本地方案不做多租户隔离承诺，一人一机场景才是它的定位。

#### B1-3. Daytona —— ⚠️ 已闭源归档（作为风险案例收录，不作为组件推荐）
- **链接**：https://github.com/daytonaio/daytona
- **定位**：曾经的「agent-native 沙箱平台」：Sysbox 容器运行时（VM 级隔离、无硬件虚拟化开销）、sub-90ms 创建宣称、persistent workspaces、fork（copy-on-write）。
- **约 star**：71,547 `[API]`
- **许可证/状态（重点核实项）**：
  - ✅ **2026-06 起生产代码闭源**（Blaxel 对比文明确记载：「Daytona's production codebase became closed-source in June 2026, the open repo's last release is v0.190.0」）；
  - ✅ **最后开源版本 = v0.190.0**（`/releases/latest` 重定向直读确认为 `tag/v0.190.0`）；
  - ✅ **GitHub 仓库现已归档（archived: true），license 字段为空（null）** `[API]`；最后提交 2026-07-24。
  - ⚠️ 「开源部分为 AGPL-3.0」来自社区整理（awesome 清单「AGPL core」）——仓库当前已无 license 声明，**AGPL 一说仅作历史记录，未逐字核实**。
- **技术栈（历史）**：Go 控制面 + Sysbox/OCI 容器 + 可选 Kata/GPU 沙箱类型；SDK 覆盖 Python/TS/Ruby/Go/Java。
- **活跃度**：商业平台继续运营（SOC 2 Type II 2026-07 报告、HIPAA BAA、GDPR DPA、$24M Series A），**开源侧已死**。
- **能当什么组件/能抄什么**：**当反面教材抄三点**：① 沙箱接口必须 adapter 化（今天换 E2B、明天换 microsandbox 不疼）；② 选型评分表里加「治理与许可证风险」项（闭源/归档/换 license 历史）；③ 「开放核心 + 云变现」模式在沙箱赛道已被验证会翻转——别把关键路径押在单一厂商的 OSS 承诺上。
- **集成坑**：① 老教程/清单仍把它写成「开源沙箱」——全是过期信息，照抄会踩空；② 2026-04 其披露过安全公告：**API 凭证可从沙箱内存中被读取**（4-10 已修补，建议轮换密钥）——再强的隔离也怕凭证进沙箱，回到 D 节「密钥不进沙箱」原则。

### B2. OS 级沙箱原语（L0：同内核约束，最轻最便宜）

#### B2-1. Anthropic Sandbox Runtime（`srt`）—— 把任意进程关进 OS 原生盒子
- **链接**：https://github.com/anthropics/sandbox-runtime （npm：`@anthropic-ai/sandbox-runtime`）
- **定位**：轻量沙箱 CLI/库：**用原生 OS 原语对任意进程做文件系统 + 网络限制，不需要容器**。macOS 走 `sandbox-exec`(Seatbelt)，Linux/WSL2 走 `bubblewrap`，网络走 HTTP/HTTPS + SOCKS5 **代理白名单过滤**，带违规监控（macOS sandbox 日志）。明确面向「沙箱化 agent、本地 MCP server、bash 命令」。
- **约 star**：5,543 `[GH]`
- **许可证**：Apache-2.0（无限制性条款）
- **技术栈**：TypeScript（CLI 命令 `srt`，另有 `SandboxManager` 库 API，`~/.srt-settings.json` 配置）
- **活跃度**：高（最后提交 2026-10-14；发布后数小时即数千 star 的热度项目）`[GH]`
- **能当什么组件/能抄什么**：**自研 agent 的「默认外壳」**：所有 exec 类工具都过 srt 包装 →「读哪些目录、连哪些域名」白名单化。抄两件事：① **权限配置文件化**（settings 驱动，而非代码写死）；② **网络层用代理做白名单**（比 iptables/namespace 可移植）——这是「agent 自我约束」最省事的工程解。微软已 fork 为 `microsoft/vscode-sandbox-runtime` 用于 VS Code 分发（生态坐实）。
- **集成坑**：① **它是约束不是隔离**——同内核、同用户权限模型，防的是「agent 手滑」，防不住真攻击者/内核漏洞；**不可信第三方代码不要只靠 srt**；② Linux 强依赖 bubblewrap 的用户命名空间（部分容器环境/发行版会禁用 unprivileged userns，直接失败）；③ macOS 后端依赖 Apple 未文档化的 Seatbelt（未来兼容性风险，官方定位是 research preview，放在 anthropic-experimental 组织下）。

#### B2-2. bubblewrap —— 无特权沙箱构建工具（Linux 事实标准）
- **链接**：https://github.com/containers/bubblewrap
- **定位**：无 setuid 的沙箱构建器：把进程放进新的 namespace（user/pid/net/mount），按需要 bind-mount 目录。Flatpak、ChromeOS 等大量生产使用。
- **约 star**：9,052 `[GH]`
- **许可证**：**LGPL-2.1+**（COPYING 直读确认）——库链接/修改分发有 copyleft 义务，作为独立可执行文件调用无碍
- **技术栈**：C；Linux 内核 namespaces
- **活跃度**：高（最后提交 2026-10-14）`[GH]`
- **能当什么组件/能抄什么**：自研沙箱的**最底层砖块**（srt/自研 wrapper 的 Linux 后端）；抄它的「最小挂载集 + 默认只读」策略。
- **集成坑**：① 需要 unprivileged user namespace（同 srt）；② 它只管挂载/命名空间，**网络与 syscall 过滤要自己加**（seccomp 配 libseccomp）；③ 别忘配好 `--die-with-parent`、`/proc` 隔离等细节，漏一项就漏一个口子。

#### B2-3. nsjail —— Google 的进程隔离器（命名空间 + seccomp + cgroup）
- **链接**：https://github.com/google/nsjail
- **定位**：CTF/判题场景锤炼出来的强约束单进程沙箱：namespaces、seccomp-bpf、capabilities、cgroups、rlimits 一条龙，配置文件驱动（protobuf）。
- **约 star**：4,152 `[GH]`
- **许可证**：Apache-2.0（无限制性条款）
- **技术栈**：C/C++；Linux 内核特性
- **活跃度**：中高（最后提交 2026-10-02）`[GH]`
- **能当什么组件/能抄什么**：**「执行不可信代码片段」的 Linux 侧默认答案**（比 bubblewrap 多出 seccomp 与 cgroup 约束）。抄它的**策略文件化 + 默认拒绝**：把「允许的 syscall/网络/CPU 时间/内存」做成声明式配置，直接进自研系统策略层。
- **集成坑**：① 配置项繁多、写错静默失效（没有默认强策略），必须配套集成测试（故意跑逃逸样本）；② 仍共享内核——是强工程约束，不是硬件隔离；③ 需要宿主 root/CAP_SYS_ADMIN 或 userns 支持。

#### B2-4. sandbox-exec —— macOS 系统级沙箱（无独立仓库）
- **链接**：无公开仓库（XNU Seatbelt 组件，`/usr/bin/sandbox-exec`）
- **定位**：macOS 上所有「OS 级沙箱」方案的底层：以 SBPL（Scheme 式 profile）描述文件/网络/进程规则；`srt` 的 macOS 后端即它。
- **约 star**：系统组件，无 star
- **许可证**：Apple 系统软件（随 macOS）
- **技术栈**：SBPL profile + seatbelt
- **活跃度**：随 macOS 更新，**Apple 未正式文档化/公开支持**，社区长期担忧被移除或收紧
- **能当什么组件/能抄什么**：macOS 交付渠道绕不开它；抄 srt 的封装方式（别自己写 SBPL，太容易写漏）。
- **集成坑**：① 无官方文档、行为随系统版本漂移；② profile 语言没有静态校验，漏一条规则 = 开一个洞；③ 无 Linux 兼容物 → 跨平台方案必须做双后端（这是 srt 存在的理由）。

### B3. 其他隔离底座（自建沙箱时可能直接用到的内核技术）

| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 定位 / 何时用 |
|---|---|---|---|---|---|
| **Firecracker** | https://github.com/firecracker-microvm/firecracker | 37,380 `[GH]` | Apache-2.0 | 高（2026-10-14） | AWS 出的 microVM（E2B/Lambda/Fargate 的底座）；自建「云沙箱池」的终极砖块，但控制面/镜像/网络全部自己写 |
| **gVisor** | https://github.com/google/gvisor | 19,678 `[GH]` | Apache-2.0 | 高（2026-10-14） | 用户态内核（syscall 拦截）：隔离强度介于容器与 VM 之间、无硬件虚拟化需求；Modal 的沙箱底座；性能开销要实测 |
| **Kata Containers** | https://github.com/kata-containers/kata-containers | 8,941 `[GH]` | Apache-2.0 | 高（2026-10-14） | 「K8s 里像容器一样用 VM」；需要 K8s + 嵌套虚拟化；适合已有集群的团队 |

- **集成坑**：这三个都是「自建平台」的原材料，**不是产品**——你需要自己解决镜像构建、快照、端口/网络、池化调度、计费与回收。自研系统的现实路径：先用 E2B 自托管 / microsandbox 顶住，把这三者留作规模化时的替换后端。

### B4. 代码执行服务（L3：API 化片段执行 / 判题式 runner）

| 项目 | 链接 | 约 star | 许可证 | 活跃度 | 定位 / 抄什么 / 坑 |
|---|---|---|---|---|---|
| **Piston** | https://github.com/engineer-man/piston | 2,827 `[GH]` | MIT | 中（最后提交 2026-07-31） | 多语言代码执行引擎（freeCodeCamp 等在用）：HTTP API `execute()`、语言包（package）体系、内置 isolate 级隔离与 rlimit。**抄它的「语言包 = 镜像+元数据」注册模型**，正是工具沙箱「按需装环境」的形态。坑：语言版本更新靠社区包；隔离强度依赖 isolate，高对抗场景不足 |
| **Judge0** | https://github.com/judge0/judge0 | 4,474 `[GH]` | **GPL-3.0（限制性！）** | 高（最后提交 2026-10-08） | 在线判题/代码执行系统：批量提交、多语言、isolate 沙箱、API 完整。**CE 版 GPL-3.0 有传染性**（SaaS 分发同样触发 AGPL 类似义务的 GPL 讨论要过法务）；企业版闭源有额外能力（如更细的资源/隔离控制）。坑：GPL 许可对闭源产品不友好；队列化设计偏「批作业」而非「交互式 agent 循环」 |
| **Jupyter Kernel Gateway** | https://github.com/jupyter-server/kernel_gateway | 562 `[GH]` | BSD-3-Clause（LICENSE.md 直读确认） | **低（最后提交 2024-03-12）** | 把 Jupyter kernel 暴露成 WebSocket/REST：天然多语言、天然有状态执行上下文（变量跨调用存活），与「code interpreter 工具」语义最接近。**抄它的「kernel = 有状态会话」模型**；实现侧更推荐直接用 `jupyter_server` + `jupyter_client`/`enterprise_gateway` 思路自组。坑：上游活跃度低，长期维护风险；kernel 进程本身无强隔离，要套在容器/nsjail 里跑 |

> **对照（非开源，不入库，仅标定坐标）**：Blaxel（microVM，<25ms standby resume，SOC2/ISO/HIPAA）、Modal Sandboxes（gVisor + GPU）、Cloudflare Sandboxes（Workers 原生，**credential injection via egress proxy** 是密钥隔离的好参照）、Vercel Sandbox / Fly Machines / Runloop（Firecracker 系）。它们的**产品抽象（snapshot、standby、egress proxy、per-second 计费）**比实现更值得抄。

---

## C. 浏览器与计算机操作

### C1. 浏览器操作（结构化 DOM vs 视觉两条路线）

#### C1-1. microsoft/playwright-mcp —— 官方 MCP 浏览器（结构化路线首选）
- **链接**：https://github.com/microsoft/playwright-mcp
- **定位**：Playwright 官方 MCP server：基于**无障碍树（accessibility tree）而非截图**给模型看页面，工具化 click/type/navigate/snapshot，天然确定性、省 token；支持 CDP 直连、多标签、网络/控制台观测。
- **约 star**：38,149 `[API]`
- **许可证**：Apache-2.0（无限制性条款）`[API]`
- **技术栈**：TypeScript + Playwright；stdio/SSE MCP
- **活跃度**：高（2026-10-08 最后提交，仍在迭代）`[API]`
- **能当什么组件/能抄什么**：**自研「浏览器工具」的默认实现**：先接它（MCP）就有 90% 能力；抄「结构化快照替代全页截图」的上下文经济账；抄 ref-based 元素寻址（快照返回元素 ref，点击按 ref 而非坐标）。
- **集成坑**：① 重度依赖无障碍树，**canvas/自绘 UI/复杂富文本场景它会「看不见」**——这类页面要回落到截图+视觉模型（Playwright 轨道不是万能的）；② 浏览器跑在宿主上：**会话隔离要自己套容器 + 独立 profile + 网络出口控制**；③ 多会话/并发要自己做池化（它默认单浏览器上下文），否则并发 agent 互相踩 tab。

#### C1-2. browser-use —— 高自由度浏览器 agent 库（生态最大）
- **链接**：https://github.com/browser-use/browser-use （生态：desktop 应用 https://github.com/browser-use/desktop ；自愈 harness https://github.com/browser-use/browser-harness 18,433★ `[GH]`；云 Box 等）
- **定位**：让 LLM 直接读 DOM 并自主操作的 agent 库（Python），「写意图不写选择器」；官方自研 browser 专用模型（`bu-ultra`，宣称 Mind2Web 97% vs Claude 62%——**厂商宣称，未独立核实**）；也提供 SDK 与云服务。
- **约 star**：117,989 `[API]`（browser 赛道最大单体）
- **许可证**：MIT（仓库；其云服务与专用模型 API 另有商业条款）
- **技术栈**：Python + Playwright/CDP；另有 TypeScript SDK
- **活跃度**：高（2026-10-09 最后提交）`[API]`
- **能当什么组件/能抄什么**：① 复杂、未知站点的自主任务可用它直接当「浏览器 agent 引擎」；② **抄 browser-harness 的哲学**：不堆几千行启发式，**把 CDP 原语 + 自定义工具注册交给模型**（模型缺工具就自己加）——这比「穷举式封装」更抗页面演化；③ 抄它「专用小模型 + 通用模型兜底」的成本结构。
- **集成坑**：① 自主循环 token 消耗大、易跑飞——生产必须配步数/成本上限与人工接管；② 稳定性依赖模型能力，同任务重复成功率波动；③ MIT 只覆盖库，**其 benchmark/云盒/专用模型不随之开源**，别混淆。

#### C1-3. Stagehand（Browserbase）—— 代码与自然语言混合的浏览器 SDK
- **链接**：https://github.com/browserbase/stagehand
- **定位**：四个原语 `act / extract / observe / agent`：确定性步骤与自主执行可混写；「自愈」——`act("click submit")` 由 AI 运行时解析，页面改版不碎选择器。
- **约 star**：25,670 `[GH]`
- **许可证**：MIT（无限制性条款）
- **技术栈**：TypeScript（Node）+ 本地 Chrome 或 Browserbase 云浏览器
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**「确定性骨架 + AI 弹性填充」的最佳范式**：把关键路径写成代码（可测、可审计），把脆的定位交给 AI。自研浏览器工具层强烈建议照抄这个分层（act/extract 明确返回结构，observe 给候选动作）。
- **集成坑**：① 云浏览器模式把访问流量/登录态交给 Browserbase（合规要评估），本地模式自管浏览器；② AI 步骤天生非确定，**关键断言别依赖它**（要用 observe 后的确定性点击）；③ extract 的结构化输出仍需 schema 校验。

#### C1-4. Skyvern —— 视觉 + agent 蜂群操作未知站点
- **链接**：https://github.com/Skyvern-AI/skyvern
- **定位**：不依赖 XPath/选择器，用**计算机视觉 + 多 agent 协作**在没见过的站点上执行表单/流程；附带无代码工作流构建器与浏览器扩展。
- **约 star**：23,198 `[GH]`
- **许可证**：**AGPL-3.0（限制性！网络服务条款会咬人）**
- **技术栈**：Python（FastAPI）+ Playwright + VLM
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：抄它的**视觉元素映射（视觉元素 → 可执行动作）与任务模板复用**（工作流沉淀成可重放步骤，第二次执行快且稳）；适合「政府/银行/老站」这类无 DOM 语义的战场。
- **集成坑**：① **AGPL-3.0：SaaS 形态下必须开源你的修改或获取商业许可**——自研产品闭源分发前务必评估；② 视觉路线 token/延迟高、对分辨率与渲染稳定性敏感；③ 复杂流程仍需人工纠错循环。

#### C1-5. Nanobrowser —— 你自己的浏览器里跑多 agent（自带 API key）
- **链接**：https://github.com/nanobrowser/nanobrowser
- **定位**：开源 Chrome 扩展（OpenAI Operator 替代品）：复用**用户已登录的真实浏览器会话**，多 agent 工作流，用户自填 LLM API key，无需云。
- **约 star**：14,089 `[GH]`
- **许可证**：Apache-2.0（无限制性条款）
- **技术栈**：TypeScript + Chrome Extension MV3
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**「浏览器即工具宿主」的分发形态**：不搞云端浏览器农场，把 agent 装进用户浏览器（登录态、Cookie、企业 SSO 零配置）。抄它的**侧边栏多 agent 编排 + 按站点授权模型**；自研个人级产品可以照这个形态做。
- **集成坑**：① 扩展页面脚本与站点 CSP/反爬对抗的现实摩擦；② 用户 key 在本地存储的安全责任在客户端；③ MV3 service worker 生命周期限制（长任务要转移）。

#### C1-6. Midscene（字节 Web Infra）—— 视觉驱动 UI 自动化（跨端）
- **链接**：https://github.com/web-infra-dev/midscene
- **定位**：视觉驱动 UI 自动化：一套 API 驱动 Web/Android/iOS，可接 Playwright/Puppeteer，附 Chrome 扩展、CLI、MCP server；用自然语言 + 视觉定位，输出可断言的 JSON。
- **约 star**：15,262 `[GH]`
- **许可证**：MIT（无限制性条款）
- **技术栈**：TypeScript
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**移动端（Android/iOS）UI 自动化的最短路径**——自研「计算机操作」想要手机覆盖时，比自建 Appium 生态便宜；抄它的「视觉定位 + 数据提取断言」一体 API。
- **集成坑**：① 视觉定位对动态内容/机型适配敏感，需要固定分辨率；② 真机/模拟器集群运维成本另算；③ 上游与 Playwright 版本耦合需锁版本。

### C2. 计算机操作（整机 GUI 控制）

#### C2-1. Cua（trycua/cua）—— 计算机操作的「沙箱底座 + 驱动 + 基准」全家桶
- **链接**：https://github.com/trycua/cua
- **定位**：为 computer-use 提供开源**驱动 + 跨 OS VM 编队 + 基准/数据生成**：让 agent 跑在 macOS/Linux 虚拟机上而不是你的真机；包含 Lume（macOS VM）、computer/agent SDK、benchmarks。
- **约 star**：29,739 `[GH]`
- **许可证**：MIT（`LICENSE.md` 直读确认，© Cua AI）——注意仓库内**组件/数据/模型可能有各自条款**（页面有 artifact-specific 表述），逐项核对
- **技术栈**：Python（SDK）+ macOS/Linux 虚拟化（Apple 虚拟化框架 / QEMU 系）
- **活跃度**：高（2026-10-14 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**「计算机操作必须在 VM 里做」的完整示范**：① 抄它的分层（VM 管理 / 驱动机 / agent 循环 / 评测）；② 抄「跨 OS 编队 + 快照回滚」——真机 GUI agent 的最大风险是「把宿主搞坏」，快照是保险丝；③ 直接作为自研 computer-use 的运行底座。
- **集成坑**：① macOS VM 受 Apple 许可与虚拟化能力约束（Apple 芯片上可行但定制成本高）；② 虚拟化性能与 GPU 受限，视觉刷新率低的场景体验打折；③ 项目迭代快，API 文档稳定性一般。

#### C2-2. UI-TARS Desktop（字节）—— GUI grounding 专用模型 + 桌面 agent
- **链接**：https://github.com/bytedance/UI-TARS-desktop （含 Agent TARS）
- **定位**：端到端 GUI grounding 训练的模型家族（把 UI 元素理解为一等公民而非像素猜测），配桌面应用 + Agent TARS（CLI/Web UI，视觉 + MCP 工具集成）；宣称 OSWorld 分数高于 Claude Computer Use（**厂商宣称**）；有「System-2 reflection」：每步对比前后截图、走偏了就重规划。
- **约 star**：39,280 `[GH]`
- **许可证**：Apache-2.0（仓库；模型权重另有模型许可，未核实）
- **技术栈**：TypeScript 应用层 + 模型推理（本地或远端）
- **活跃度**：高（2026-10-09 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**抄「行动后截图对比 + 纠正计划」的反射循环**——这是 GUI agent 可靠性的关键增量，比换更强的模型划算；模型可当自研 computer-use 的 grounding 层（本地/自部署）。
- **集成坑**：① 桌面应用模式直控本机，**必须加动作白名单与人工确认**；② 模型与 app 版本耦合（下载大权重、推理硬件要求）；③ 基准分数用其自有评测口径，别直接横比。

#### C2-3. Open Interpreter（openinterpreter/openinterpreter）—— 从「本地代码解释器」转向「开放模型 coding agent」
- **链接**：https://github.com/openinterpreter/openinterpreter （原 OpenInterpreter/open-interpreter，**仓库已改名**）
- **定位**：当年「让 LLM 在你电脑上跑代码」的开创者；当前定位**已转向「面向 Kimi K3 / GLM 5.3 等开放模型的 coding agent」**（仓库描述直读）——形态比早期更接近 CLI coding agent。
- **约 star**：68,579 `[GH]`
- **许可证**：Apache-2.0（无限制性条款）
- **技术栈**：Python（核心）+ 多端前端
- **活跃度**：高（2026-10-11 最后提交）`[GH]`
- **能当什么组件/能抄什么**：**抄它的执行循环与「执行前确认」交互**（自然语言 → 代码 → 展示 → 确认 → 运行 → 把 stderr 喂回模型）；这套「解释器循环」是自研 code-interpreter 工具的教学范本。注意其**运行在宿主**（有 `--safe_mode` 级限制但非强沙箱）。
- **集成坑**：① 直接跑宿主代码，**必须外包一层沙箱**（nsjail/microsandbox）再用；② 定位漂移期，API 与文档要和版本号对齐；③ 旧教程的 `interpreter` 包名/用法可能已变。

#### C2-4. Self-Operating Computer —— 最小可行计算机操作框架（参考用，已停滞）
- **链接**：https://github.com/OthersideAI/self-operating-computer
- **定位**：多模态模型看屏 → 移动鼠标/键盘的最小框架；「computer use」概念的早期样板。
- **约 star**：10,293 `[GH]`
- **许可证**：MIT
- **技术栈**：Python（pyautogui 类控制）
- **活跃度**：**停滞（最后提交 2025-09-19）** `[GH]`
- **能当什么组件/能抄什么**：只抄「截图 → 坐标 → 动作」的最小闭环用于教学/原型；**不建议引入生产**。
- **集成坑**：直控宿主输入设备，无沙箱概念；无维护意味着新模型后端不跟进。

#### C2-5. Bytebot —— 自托管桌面 agent 容器（已归档，仅作参考）
- **链接**：https://github.com/bytebot-ai/bytebot
- **定位**：`docker-compose up` 起一个完整 Linux 虚拟桌面给 agent 用（浏览器、文件系统、密码管理器、任意应用）。
- **约 star**：11,072 `[GH]`｜**许可证**：Apache-2.0｜**活跃度**：**已归档（archived），最后提交 2025-09-11** `[GH]`
- **能当什么组件/能抄什么**：抄「agent 拥有自己的整台虚拟桌面」这一产品形态（与 cua 路线互补）；**归档状态 = 不要依赖**。
- **集成坑**：归档项目无安全修复；VNC/桌面直连的暴露面大。

---

## D. 工具执行栈：推荐组合（对应五项硬需求）

> 设计原则：**每一层都可替换（adapter 接口）+ 默认最小权限 + 密钥永不进入模型上下文与沙箱**。以下组合全部为「已验证存在的开源/可自托管件」，标注缺口与替代。

### D1. 需求映射

| 需求 | 首选 | 备选/兜底 | 关键缺口（要自研） |
|---|---|---|---|
| **① MCP 生态接入** | 官方 SDK + 官方 Registry 元数据对齐；`MCP Inspector` 调试 | Docker MCP Gateway（容器化 + 审批）；IBM ContextForge（REST→MCP 转换）；Executor（自托管集成目录） | 工具**路由/筛选**（tool router / tool search）；schemas 收窄；多 server 生命周期管理 |
| **② 工具授权与密钥隔离** | Nango 模式（自托管 OAuth broker，注意 Elastic License）或 Executor 的 per-tool policy | Composio（托管、快省事，合规受限）；Arcade | **凭证保险库 + egress 代理注入 + 审批流 + 审计**（三件套开源件普遍缺失，必须自建） |
| **③ 不可信代码安全执行** | 单机：**microsandbox**；云：**E2B 自托管（Firecracker）** | 轻量约束：`srt`/`nsjail`/`bubblewrap`；规模化替换后端：Firecracker/gVisor/Kata；片段执行：Piston | 池化调度、快照编排、网络出口策略、资源计费 |
| **④ 浏览器操作** | **Playwright MCP**（结构化默认） | Stagehand（混合控制/自愈）；browser-use（高自主）；Skyvern（视觉/AGPL 慎用） | 浏览器会话隔离（容器 + profile + 出口代理）、并发池化、验证码/风控策略 |
| **⑤ 计算机操作** | **Cua**（VM 底座 + 驱动） | UI-TARS / Agent TARS（grounding + reflection）；Midscene（移动端） | VM 编队管理、动作白名单/确认门、截图审计与回滚 |

### D2. 分层架构（建议实现顺序）

```
┌──────────────────────────────────────────────────────────────┐
│  L5 策略与审计：per-tool policy（默认拒绝）→ 人工审批 → 全量审计日志   │
├──────────────────────────────────────────────────────────────┤
│  L4 工具层：MCP 客户端 → 工具路由（按意图筛选，防上下文爆炸）→ 技能包     │
│      （SKILL.md 渐进披露；技能不扩权）                          │
├──────────────────────────────────────────────────────────────┤
│  L3 接入与凭证：MCP 网关（容器化 server / REST→MCP）              │
│      + 凭证代理：OAuth 连接 → 短期令牌 → egress 代理注入           │
│      （模型/沙箱只见「工具名+参数」，永不见原始密钥）                │
├──────────────────────────────────────────────────────────────┤
│  L2 交互面：浏览器工具（Playwright MCP / Stagehand）              │
│      + 计算机操作（Cua VM / UI-TARS），全部跑在隔离会话里           │
├──────────────────────────────────────────────────────────────┤
│  L1 执行沙箱：microsandbox（本机微 VM）→ E2B 自托管 / Firecracker  │
│      兜底轻量层：srt / nsjail / bubblewrap 包住 agent 自身         │
├──────────────────────────────────────────────────────────────┤
│  L0 基础设施：宿主/云 VM、镜像与快照、网络出口控制、KVM/嵌套虚拟化验证  │
└──────────────────────────────────────────────────────────────┘
```

实现顺序建议：
1. 先做 **L1 轻量层**：用 `srt`（或 Linux 下 `bubblewrap`+`nsjail` 自组）把自家 agent 的所有 exec 调用白名单化——一天内就有收益，防手滑。
2. 再做 **L4 工具路由 + L5 策略**：工具注册表带 `readonly/destructive/network` 等权限标签，路由层按任务筛工具；策略默认拒绝、危险动作要审批。**这一步是自研系统超越裸 Hermes 的关键差异点。**
3. 再做 **L3 凭证代理**：所有外部 API 走集中 broker（OAuth 刷新、令牌注入、scope 收敛、审计），模型侧只给「连接引用」。
4. **L1 强隔离**：`microsandbox` 跑不可信代码（验证 `/dev/kvm`）；上云后换/加 E2B 自托管。
5. **L2 交互面**：Playwright MCP 起步，按需加 Stagehand 自愈与 Cua VM。
6. 规模化时把沙箱后端抽象成 driver（microsandbox / E2B / Firecracker / Kata 四实现），这一层留好接口，**吸取 Daytona 教训**。

### D3. 为什么是这几件（一句话理由）

- **srt**：唯一「官方级、跨 macOS/Linux、配置化、代理级网络白名单」的 agent 自约束盒，Apache-2.0，且被微软 fork 采用。
- **microsandbox**：本地就把「微 VM 隔离 + secrets 不进 VM + fork/snapshot + OCI 兼容 + 内建 MCP」打包齐了，Apache-2.0，单机不可信代码的最短路径。
- **E2B**：Apache-2.0 全栈可自托管 + Firecracker 真隔离 + 已被验证的 pause/resume 语义；是企业化前的最佳云底座。
- **Playwright MCP**：微软维护、无障碍树 = token 经济 + 确定性，是浏览器工具的「默认正确答案」。
- **Cua**：把「computer use 必须跑在 VM 里」工程化，含跨 OS 与基准，MIT。
- **Executor / Docker MCP Gateway / Nango**：分别覆盖「自托管集成目录」「容器化 server + 审批」「OAuth 连接编排」三个自研刚需模块的开源参考。
- **技能层用 agentskills 规范 + addyosmani/agent-skills 做种子**：格式开放（Apache-2.0 规范仓），质量样例丰富，渐进披露机制必须抄。

---

## E. 可抄模式清单（跨项目提炼）

1. **渐进式披露**（Agent Skills 三级加载）：元数据常驻（~100 token/项）→ 命中加载正文 → 脚本/参考按需读。适用于工具、技能、文档一切「many small capabilities」场景。
2. **工具路由/tool search**（Composio Tool Router、browser-harness 的自注册工具）：按意图动态挂载工具，替代「全量入 prompt」。这是上下文爆炸的正解。
3. **凭证代理 + egress 注入**（Cloudflare Sandboxes、microsandbox、Nango、Executor）：密钥只存在于代理层，出站时注入；模型与沙箱只见占位符。**Sandbox 泄露内存也读不到密钥**（Daytona 2026-04 事故的教训）。
4. **per-tool 策略 + 审批门**（Docker MCP Gateway、Executor）：工具粒度声明权限，危险调用走人工确认；技能/插件**不能自扩权**。
5. **沙箱分层与可替换 driver**（E2B/microsandbox/Daytona 教训）：L0 约束 → L1 本地微 VM → L2 云微 VM；统一 `create/exec/upload/snapshot/pause/kill` 接口。
6. **快照 / fork / standby**（microsandbox fork、E2B pause、Blaxel standby、Cua VM 回滚）：状态复用 = 延迟与成本双降；GUI/浏览器 agent 的「保险丝」。
7. **结构化优先、视觉兜底**（Playwright MCP vs Stagehand/Skyvern/UI-TARS）：确定性路径用 DOM/代码，脆的地方才交给模型；行动后**截图对比 + 重规划**（UI-TARS reflection）显著提升可靠性。
8. **技能即「指令 + 可执行资源 + 权限声明」**（anthropics/skills 结构 + microsandbox 技能包）：skill 的执行面必须过沙箱与策略，而不是当作纯 prompt。

---

## F. 风险与坑（汇总，选型时逐条打勾）

**许可证风险（分发/商用前必查）**
- **AGPL-3.0**：Skyvern、Smithery CLI —— SaaS 网络条款触发开源义务。
- **GPL-3.0**：Judge0 CE —— 传染性；闭源产品慎入。
- **Elastic License 2.0**：Nango —— 可自用，**禁止作为托管服务对外提供**。
- **source-available（非开源）**：anthropics/skills 的 docx/pdf/pptx/xlsx；「参考可以，照搬不行」。
- **许可字段缺失**：daytonaio/daytona 仓库已归档、license 为空 `[API]` —— 老版本 AGPL 说法仅存于社区记录，勿当依据。
- **混许可仓**：anthropics/skills（Apache-2.0 与 source-available 混装）、cua（仓库 MIT 但内页有 artifact-specific 表述）——逐目录核对。

**供应链/信任风险**
- MCP 生态：注册中心与清单**均不做安全审计**；Smithery 有路径穿越历史 + 第三方扫描发现 22/100 server 有安全问题；**stdio server 与 agent 同权限**，投毒即宿主沦陷 → 所有第三方 server 进容器、限权、限网络。
- 社区技能同风险：SKILL.md 里的 scripts 就是代码，按不可信代码对待。
- 老教程污染严重：Daytona「开源」、Open Interpreter 的旧包名/定位、bytebot 仍在被推荐（实为归档）——所有二手清单都要回源验证。

**工程坑**
- 嵌套虚拟化：microsandbox/Firecracker/Kata 需要宿主 KVM/HVF 直通，云 VM 里默认可能没有 → 先验证再选型。
- 共享内核 ≠ 硬件隔离：bubblewrap/nsjail/Docker 提升成本但拦不住内核漏洞；不可信代码只放 microVM。
- 无文档的 Apple 原语：sandbox-exec/Seatbelt 无正式支持，跨平台必须双后端。
- 浏览器会话隔离与并发：浏览器跑宿主时，profile、剪贴板、扩展、出口网络都是泄漏面；并发 agent 必须池化。
- 上下文与成本：工具全量挂载、视觉截图流、自主浏览器循环是三大 token 黑洞——只能靠路由、结构化快照、步数/成本上限压制。

---

## G. 附录

### G1. 核实方法
- `[API]`（6 次预算内）：daytonaio/daytona、e2b-dev/E2B、browser-use/browser-use、microsoft/playwright-mcp、ComposioHQ/composio（另有一次重定向失败，未计入有效结果）。
- `[GH]`：其余全部条目通过 github.com 仓库页（star/归档/license 字段）与 `commits.atom`（最后提交时间）当日直读；许可文件（MIT/AGPL/BSD/Elastic/LGPL）通过 `raw.githubusercontent.com` 的 LICENSE/COPYING 文件直读确认。
- 「第三方资料」仅用于产品行为描述（E2B 会话上限、Daytona 闭源时间线、Smithery 规模与安全扫描），已在文中标注。
- 未核实项：ComposioHQ/awesome-claude-skills 许可证、Composio 自托管结论、Daytona 历史 AGPL、部分模型权重许可。

### G2. 参考素材
- wincent《Coding Agent Sandboxes》gist（2026-05 汇编）：https://gist.github.com/wincent/2752d8d97727577050c043e4ff9e386e
- Blaxel《Code execution sandboxes for AI agents》对比（2026-08 更新口径）：https://blaxel.ai/blog/code-execution-sandboxes-for-ai-agents
- Anmol Baranwal《Open Source Toolkit for Building AI Agents in 2026》：https://dev.to/anmolbaranwal/open-source-toolkit-for-building-ai-agents-in-2026-55h1
- Agent Skills 规范：https://agentskills.io ｜ Anthropic 工程博客《Equipping agents for the real world with Agent Skills》
- MCP 注册中心对比（第三方）：callsphere.ai / truefoundry.com 的 2026 registry 评测；GitGuardian《Breaking MCP Server Hosting》

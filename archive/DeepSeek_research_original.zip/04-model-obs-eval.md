# 04 · 模型接入 / 路由 + 可观测性 + 评测 —— 开源组件调研

> **调研时间**：2026-10-14（UTC）｜**簇范围**：多模型接入/路由网关、本地推理引擎、LLM/Agent 可观测性、评测框架与基准。
> （框架/记忆/工具沙箱/交互调度/安全基建见 01/02/03/05/06 区，本文不交叉。）
>
> **星标核实方式**：6 个关键仓库经 `api.github.com` 于 2026-10-14 实测，标注"**已核实**"；其余经 ungh.cc 镜像实测（标注"**镜像核实**"，可能存在小时级延迟）。许可证优先按仓库 `LICENSE` 原文核实。
>
> **收录规则**：真实存在且 2024 年后活跃；**⚠️ 表示已停更/下线/风险项**，保留仅作参考。闭源 SaaS（OpenRouter、LangSmith、Braintrust 等）不在收录范围。收购/合并后许可证可能变化，落地前请复核。

## 0. 结论速览（一句话选型）

| 层 | 首选 | 备选 | 一句话理由 |
|---|---|---|---|
| 多 provider 统一网关 | **LiteLLM**（61k★） | Portkey Gateway / Helicone | provider 覆盖、预算熔断、callbacks 生态最全 |
| 本地推理 | **vLLM**（服务端）+ **Ollama**（开发机） | SGLang / llama.cpp / LMDeploy | OpenAI 兼容，云/本一体切换 |
| 可观测 | **Langfuse** 自托管（36k★） | Opik / Phoenix（⚠️ ELv2） | OTel 原生 + trace→评测闭环 + prompt 管理 |
| 埋点 | Langfuse SDK 或 OpenLLMetry（**二选一，勿双挂**） | OpenInference | 一次埋点多处复用 |
| CI 回归 | **promptfoo**（26k★） | DeepEval（指标级单测） | 分钟级、YAML、产出可存档重放 |
| 深度评测 | **Inspect AI + inspect_evals** | 官方 harness（SWE-bench / Terminal-Bench·Harbor / τ²-bench） | 一套框架跑全部基准，自带沙箱与日志 |

> ⚠️ **三个先记住的雷区**：**Phoenix 是 Elastic License 2.0（非 OSI 开源）**；**RouteLLM 停更约 2 年**；**Lunary 主仓库与 GAIA 的 GitHub 仓库均已下线（404，2026-10-14 实测）**。

---

## 1. 多模型接入与路由（Gateway / Router）

### 1.1 LiteLLM —— 统一网关 + 成本账本的主力
- **链接**：https://github.com/BerriAI/litellm
- **定位**：100+ provider 统一 OpenAI 兼容接口。两种用法：Python SDK（进程内）与 Proxy 网关（独立服务，带 virtual key、预算、限流、UI）。
- **Star**：**61,263**（2026-10-14 经 api.github.com 已核实）
- **许可证**：**MIT（核心）+ 商业（enterprise/ 目录）**。根 LICENSE 原文："`enterprise/` 目录下内容按 `enterprise/LICENSE` 授权"——即 BerriAI Enterprise License（商业授权）；其余部分 MIT。GitHub 显示 NOASSERTION 即因双许可并存。
- **技术栈**：Python（FastAPI、Pydantic）；可选 Postgres（预算/用量/密钥）、Redis（缓存/限流）；另有 TS SDK。
- **活跃度**：2026-10-14 当日推送；发版与社区极活跃。
- **能当什么组件**：agent 主循环的**唯一模型出口**——fallback 链、按 tag/权重路由、超时重试、预算熔断、**成本账本**；**success/failure callbacks 是接可观测后端（Langfuse 等）最省力的埋点**（一次配置、全量落库）；streaming 全透传。
- **能抄什么**：virtual key/预算数据模型、模型定价表（cost map）、provider 适配与参数转义层、路由 DSL。
- **集成坑**：① Proxy 模式多一跳开销（部署位置决定，需实测）；② 各 provider 的流式 tool_calls / reasoning 字段差异需逐家实测；③ SSO/RBAC/审计等企业功能闭源；④ 迭代快、偶有破坏性变更，生产 pin 版本；⑤ 自托管把 Postgres/Redis 变成隐性运维成本。

### 1.2 Portkey AI Gateway —— 低延迟 TS 网关 & guardrails 体系
- **链接**：https://github.com/Portkey-AI/gateway
- **定位**：TypeScript/Node 高性能 AI Gateway：1,600+ 模型（250+ LLM 供应商），内置 50+ guardrails；统一 API + 权重/fallback/缓存/超时；可部署为 Node 服务/容器（可上边缘）。
- **Star**：约 **13.2k**（2026-10-14 经镜像核实）
- **许可证**：**MIT**（仓库 LICENSE 原文核实，© 2024 Portkey Inc）。⚠️ 注意：官方正在做 **Gateway 2.0——把企业版网关合并进开源**（pre-release 分支），合并后许可条款请按新版本复核。
- **技术栈**：TypeScript/Node；配置驱动（JSON：route→targets→fallback/cache/guardrails 插件）。
- **活跃度**：镜像显示默认分支最近推送 2026-05（合并期开发主要在 pre-release 分支），13k★ 级、社区活跃。
- **能当什么组件**：低延迟网关备选；**guardrails 插件体系（PII、提示注入检测等 50+）值得直接抄**；给多服务 agent 做统一出口时比 LiteLLM Proxy 更轻。
- **集成坑**：① 与 Python agent 主循环跨语言；② OSS 与商业平台的功能边界要自己拉清单；③ 插件行为差异大、测试成本；④ 2.0 迁移期注意版本节奏。

### 1.3 RouteLLM ⚠️（停更）—— 只抄算法，别当依赖
- **链接**：https://github.com/lm-sys/RouteLLM
- **定位**：按查询难度在强/弱模型间路由（矩阵分解/BERT/因果分类器），LMSYS 研究项目，论文+训练脚本齐全。
- **Star**：约 **5.6k**（镜像核实）
- **许可证**：Apache-2.0（LICENSE 原文核实）
- **技术栈**：Python（PyTorch/transformers，2024 年的旧依赖栈）。
- **活跃度**：⚠️ **镜像显示最后推送 2024-08-10，约 2 年未更新**。
- **能当什么组件**：只作**算法参考**——"用便宜模型分流简单请求省成本"的可行性验证与 router 训练/评估方法可抄。
- **集成坑**：依赖 2024 年的 vLLM/transformers 版本；无维护；无 tool-calling 感知。生产建议：把"难度路由"思想用 LiteLLM 的规则路由 + 自训小分类器落地。

### 1.4 semantic-router —— 语义向量决策层
- **链接**：https://github.com/aurelio-labs/semantic-router
- **定位**：基于 embedding 的语义路由/意图分类/工具选择（不限于选模型），可挂向量库或接 LLM 做动态路由。
- **Star**：约 **3.9k**（镜像核实）
- **许可证**：MIT（原文核实，© 2026 Aurelio AI）
- **技术栈**：Python（sentence-transformers；可选向量库/LLM 增强动态路由）。
- **活跃度**：2026-09-29 推送，活跃。
- **能当什么组件**：主循环前置的"**意图→模型/工具**"分发层；可作为 LiteLLM 之上的动态路由补丁，或用于工具选择（参考 03 区工具集群）。
- **集成坑**：embedding 模型选型影响大；冷启动需要样本；推理多一次向量查询延迟；长尾/新意图泛化有限。

### 1.5 aisuite —— 极简多 provider SDK（参考向）
- **链接**：https://github.com/andrewyng/aisuite
- **定位**：Andrew Ng 团队的极简统一 SDK：`client.chat.completions.create(model="openai:gpt-…")` 风格，provider 前缀路由。
- **Star**：约 **16.3k**（镜像核实）
- **许可证**：MIT（原文核实，© 2024 Andrew Ng）
- **技术栈**：Python（极轻量 provider 适配器）。
- **活跃度**：2026-09-18 推送，中等。
- **能当什么组件**：**抄它的 API 设计**（provider 前缀、极简抽象）；教学/示例价值。**不适合当生产网关**。
- **集成坑**：无预算/限流/fallback/可观测、无 proxy 模式；生产特性薄。

### 1.6 Helicone —— 观测 + 网关一体
- **链接**：https://github.com/Helicone/helicone
- **定位**：LLM 可观测平台（Rust AI Gateway/代理 + Next.js 控制台）：日志、成本、缓存、限流、会话，兼做路由出口。
- **Star**：约 **6.2k**（镜像核实）
- **许可证**：Apache-2.0（LICENSE 原文核实）
- **技术栈**：Rust（代理）、TypeScript/Next.js、ClickHouse。
- **活跃度**：2026-10-10 推送，活跃。
- **能当什么组件**：想"一个系统同时解决日志+成本+缓存"时直接用其 Rust 代理；**成本计算/缓存命中实现值得抄**。与 LiteLLM **二选一**（叠两层代理无意义）。
- **集成坑**：① 模型支持面与路由能力不如 LiteLLM；② 自托管要跑代理+web+worker+ClickHouse 一整套；③ 云版与 OSS 功能边界需自查（未逐项核实）。

---

## 2. 本地推理引擎（Local Inference）

> 共同结论：**开发机用 Ollama、服务端用 vLLM 或 SGLang**；所有引擎都提供 OpenAI 兼容 endpoint，经 LiteLLM 统一接入后对上层 agent 透明——这就是"本地推理可选"的实现方式。

### 2.1 Ollama —— 开发机/端侧一键推理
- **链接**：https://github.com/ollama/ollama
- **定位**：本地一键跑模型（CLI + 常驻服务），OpenAI 兼容 API；Modelfile 管理；全平台。
- **Star**：**183,177**（2026-10-14 经 api.github.com 已核实）
- **许可证**：MIT（API 核实）
- **技术栈**：Go（推理内核基于 llama.cpp 系）。
- **活跃度**：2026-10-14 当日推送。
- **能当什么组件**：**开发/测试环境的本地 provider**；CI 中不需要 GPU 的冒烟回归；主循环里当"离线兜底模型"。
- **集成坑**：① 并发吞吐远低于 vLLM，**不要用于生产多请求**；② 拉模型依赖 registry 网络；③ 与生产引擎（vLLM/SGLang）的 tokenizer/采样细节有差异，评测结果别混口径。

### 2.2 llama.cpp —— C/C++ 推理与 GGUF 量化生态
- **链接**：https://github.com/ggml-org/llama.cpp
- **定位**：全平台（CPU/GPU/Apple Silicon）推理引擎，GGUF 量化模型事实标准；`llama-server` 提供 OpenAI 兼容。
- **Star**：约 **131,188**（镜像核实）
- **许可证**：MIT（原文核实，© 2023-2026 The ggml authors）
- **活跃度**：2026-10-14 当日推送，极活跃。
- **能当什么组件**：无 GPU 环境的评测/工具链验证；端侧模型部署；KV cache/投机解码等推理内核参考。
- **集成坑**：并发/长上下文 agent 负载需调优；量化有质量损失，评测口径要注明。

### 2.3 vLLM —— 生产级高吞吐服务
- **链接**：https://github.com/vllm-project/vllm
- **定位**：PagedAttention、连续批处理、前缀缓存、张量/流水并行的推理服务引擎；OpenAI 兼容 server。
- **Star**：**93,799**（2026-10-14 经 api.github.com 已核实）
- **许可证**：Apache-2.0（API 核实）
- **技术栈**：Python + CUDA kernels（PyTorch），多硬件后端。
- **活跃度**：2026-10-14 当日推送，极活跃。
- **能当什么组件**：自托管推理的**默认选型**；离线批量评测的推理后端；与 LiteLLM 组合成"统一入口→本地 GPU 池"。
- **集成坑**：① GPU 依赖重、部署运维成本高；② 版本间破坏性变更多，pin 版本；③ 显存/KV cache/并行参数调优门槛；④ 新特性（multi-LoRA、投机解码等）按版本核对。

### 2.4 SGLang —— agent 工作负载的吞吐王者候选
- **链接**：https://github.com/sgl-project/sglang
- **定位**：RadixAttention（前缀树缓存）+ 结构化输出（JSON schema/regex 约束解码）；多轮 agent 共享前缀场景吞吐/延迟常领先 vLLM。
- **Star**：约 **37,099**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **活跃度**：2026-10-14 当日推送，极活跃。
- **能当什么组件**：agent 场景的推理后端首选之一；**其"结构化生成"对工具调用可靠性的提升值得抄**。
- **集成坑**：部分新模型支持比 vLLM 晚；文档/生态相对年轻；API 与 vLLM 不完全对齐。

### 2.5 LMDeploy —— 量化部署工具箱
- **链接**：https://github.com/InternLM/lmdeploy
- **定位**：上海 AI Lab 推理工具箱：TurboMind 引擎、AWQ W4A16 量化、多模态；偏"部署套件"。
- **Star**：约 **8.1k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **活跃度**：2026-10-09 推送。
- **能当什么组件**：量化部署（AWQ）路线参考；国产硬件/内网环境适配。
- **集成坑**：社区规模小一档；更新节奏慢些。

---

## 3. 可观测性（LLM / Agent Observability）

> 先记三条硬事实：① 以下推荐项都支持自托管 + OTel 或 SDK 回调；② 埋点有三条路——框架回调（LiteLLM→Langfuse）、OTel 直传、SDK 装饰器；③ **OpenLLMetry 自动埋点与 Langfuse SDK 同开会重复上报，二选一**。

### 3.1 Langfuse —— 观测主后端（自托管首选）
- **链接**：https://github.com/langfuse/langfuse
- **定位**：LLM 工程平台：trace（OTel 原生）、评测、prompt 版本管理、数据集与 playground；官网口径 50,000+ 公司使用。
- **Star**：**35,829**（2026-10-14 经 api.github.com 已核实）
- **许可证**：**MIT（核心）+ 企业许可（ee/ 目录）**。仓库原文：核心 MIT，"外围部分（ee/）为商业许可"（含 RBAC/SSO/审计等）。**GitHub 显示 NOASSERTION 即因双许可**。
- **公司动态（重要）**：**2026-01 被 ClickHouse 收购**（与 $400M Series D 同时宣布），官方承诺 MIT/自托管/路线不变；2026-03 起数据模型向 ClickHouse 深化。长期选型时作为风险项记录。
- **技术栈**：TS/Next.js、Postgres、ClickHouse、Redis、S3（docker-compose / k8s 自托管）。
- **活跃度**：2026-10-14 当日推送，极活跃。
- **埋点成本（对自建主循环）**：**低**。三选一：Python/JS SDK `@observe` 装饰器；OTel OTLP 直传；**接 LiteLLM success/failure callback（一次配置，全量模型调用自动落库）**。
- **能当什么组件**：观测主后端 + **"trace→dataset→experiment"评测闭环**（生产失败案例直接变回归集）+ prompt 版本管理。
- **能抄什么**：trace/observation 数据模型（trace→span→generation/score）、"失败 trace 转数据集"工作流、prompt 编译（label 版本）。
- **集成坑**：① 自托管组件多（ClickHouse 资源占用/运维）；② v3 后是 OTel-first 架构，网上老教程会误导；③ EE 功能命名容易误当 OSS；④ 高吞吐下存储成本要预估。

### 3.2 Arize Phoenix —— 本地调试首选，⚠️ 许可注意
- **链接**：https://github.com/Arize-ai/phoenix
- **定位**：OTel 原生 tracing + evals 平台，本地单进程即可跑（pip 安装），适合开发期调试 RAG/agent。
- **Star**：约 **11.8k**（镜像核实）
- **许可证**：**Elastic License 2.0（ELv2）—— 非 OSI 开源**（仓库 LICENSE 原文核实）。可自用/内部修改；**不能作为托管服务提供给第三方、不能移除许可声明**。内部工具无碍，对外产品嵌入需法务评估。
- **技术栈**：Python(FastAPI) + Next.js UI；OpenInference instrumentation（Apache-2.0，**可独立于 Phoenix 使用**）；存储 DuckDB/Postgres。
- **活跃度**：2026-10-14 当日推送，活跃。
- **埋点成本**：低~中。OpenInference 自动埋点覆盖主流框架（LangChain/LlamaIndex/OpenAI 等）；手动 span API 简洁。
- **能当什么组件**：开发期本地观测（起本地后端看一眼 trace）；生产规模化不如 Langfuse。**OpenInference 埋点包（Apache-2.0）可以单独抄用**。
- **集成坑**：① ELv2（见上）；② UI/API 迭代快；③ 规模化持久化配置。

### 3.3 OpenLLMetry（Traceloop）—— 纯埋点层（后端无关）
- **链接**：https://github.com/traceloop/openllmetry
- **定位**：**OTel instrumentation 库集**（Python/TS），不绑定后端——发给任何 OTLP 后端（Langfuse/ClickHouse/Tempo…）。
- **Star**：约 **7.5k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **活跃度**：2026-10-13 推送。
- **能当什么组件**：想"**换观测后端不换埋点**"就选它；monkey-patch 自动插桩覆盖面广（OpenAI/Anthropic/LangChain/LlamaIndex/CrewAI 等），加一行 init 就能全量采集。
- **能抄什么**：自动插桩的封装范式（零侵入埋点）。
- **集成坑**：① 自动埋点是黑盒，自定义属性要补手动 span；② 各框架大版本适配有滞后；③ GenAI Semantic Conventions 仍在演进，字段名会变，需锁版本；④ 与 Langfuse 原生 SDK 同开=重复上报。

### 3.4 Opik（Comet）—— 观测+评测一体化
- **链接**：https://github.com/comet-ml/opik
- **定位**：LLM 观测 + 评测 + guardrails 平台（Comet 出品），可自托管；社区增长快。
- **Star**：约 **22.6k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：Python + React；ClickHouse/MySQL/Redis。
- **活跃度**：2026-10-14 当日推送。
- **能当什么组件**：偏"评测驱动"团队的 Langfuse 平替；内置 LLM-judge 指标与数据集实验，**评估模板可抄**。
- **集成坑**：自托管组件数量与 Langfuse 类似；集成生态数量稍逊；由商业公司主导路线。

### 3.5 AgentOps —— agent 专用观测（事件模型值得抄）
- **链接**：https://github.com/AgentOps-AI/agentops
- **定位**：面向 agent 的可观测：会话回放（session replay）、step/tool 事件、成本、错误归因。
- **Star**：约 **5.9k**（镜像核实）
- **许可证**：MIT（原文核实）
- **技术栈**：Python SDK + 服务端（托管为主，支持自托管）。
- **活跃度**：镜像最后推送 2026-06-25，节奏一般。
- **能当什么组件**：其"**session/step/tool_call 事件模型**"对自建 agent 埋点设计有直接参考价值；SDK 装饰器接入快。
- **集成坑**：最强形态在 SaaS，自托管成熟度一般；数据出域顾虑；框架适配参差。

### 3.6 Lunary ⚠️（主仓库已下线）—— 不推荐新采用
- **链接**：https://github.com/lunary-ai/lunary **→ 404（2026-10-14 实测）**；官网 lunary.ai 仍在线（企业向 SaaS）。
- **结论**：开源侧已不可用/不可复现（组织仅剩 SDK 子仓库），**不纳入选型**；有历史依赖的迁往 Langfuse/Opik。未能找到官方下线公告，作为事实记录。

---

## 4. 评测框架与基准（Eval）

> 分两层：**框架**（能把你自己的 agent 接进去跑回归）与**基准/数据集**（标准考卷）。
> 回归策略建议"快-慢"两档：**promptfoo/DeepEval 进 CI（分钟级）；Inspect+基准进夜间/周级（小时级、要 Docker，SWE-bench 级要磁盘）**。

### 4.1 Inspect AI（UK AISI）—— 深度评测主干
- **链接**：https://github.com/UKGovernmentBEIS/inspect_ai
- **定位**：英国 AI 安全研究院的评测框架：Dataset/Solver/Scorer 三件套 + 内置 agent 循环 + Docker 沙箱 + `inspect view` 日志查看器；可本地跑、可 CI；支持 OpenAI/Anthropic/Google/…/vLLM/Ollama 等众多 provider（PyPI 版本 0.3.268，2026-09）。
- **Star**：**3,005**（2026-10-14 经 api.github.com 已核实）
- **许可证**：MIT（API 核实）
- **技术栈**：Python（≥3.10，Pydantic）；Docker 用于沙箱。
- **活跃度**：2026-10-14 当日推送；公共资金支持、无商业平台绑定。
- **配套（强烈建议一起用）**：**inspect_evals**（https://github.com/UKGovernmentBEIS/inspect_evals ，约 704★ 镜像核实，MIT）——200+ 现成基准：**GAIA、SWE-bench、Cybench、Terminal-Bench（经 Inspect Harbor）** 等；截至 2026-09 注册 171 项。
- **能当什么组件**：自建 agent 的"考卷系统"——把你的 agent 包成 solver 跑全部标准基准；其 EvalLog 日志格式与沙箱管理可直接借鉴。
- **能抄什么**：solver/scorer 抽象、"评测即 Python 任务"的组织方式、日志（每条 sample 全记录，可重放）。
- **集成坑**：① 概念抽象要学一阵（solver/scorer/sandbox）；② 深度接 agent 需写 adapter（它默认"模型+solver"结构）；③ 跑基准要 Docker，SWE-bench 类吃磁盘（详见 4.6）。

### 4.2 promptfoo —— CI 回归闸门
- **链接**：https://github.com/promptfoo/promptfoo
- **定位**：CLI/Node 的评测 + 红队工具：YAML 定义用例，断言（含 LLM-rubric、自定义 JS/Python），多 provider 对比矩阵，CI 集成，web viewer；含红队扫描（OWASP LLM Top10 等）。
- **Star**：**26,000**（2026-10-14 经 api.github.com 已核实）
- **许可证**：MIT（API 核实）
- **技术栈**：TypeScript/Node（npm CLI/库）；自定义断言支持 JS/Python。
- **活跃度**：2026-10-14 当日推送，极活跃。
- **能当什么组件**：**回归测试闸门**（改 prompt/换模型/调工具就 `promptfoo eval` 对比基线）；评测输出 JSON 可存档、可复跑（失败的"重放"主要在它这层）；本地跑、零服务端。
- **集成坑**：① 粒度偏 input→output，**多轮 agent 轨迹**要用 custom provider/transforms 包一层；② 复杂断言仍要写脚本；③ Node 依赖（纯 Python 团队有摩擦）。

### 4.3 DeepEval —— "LLM 的 pytest"（指标级）
- **链接**：https://github.com/confident-ai/deepeval
- **定位**：50+ 指标（G-Eval、幻觉、回答相关性、**tool correctness、agentic task completion** 等），pytest 风格、本地跑。
- **Star**：约 **18.9k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：Python（pytest 风格插件）。
- **活跃度**：2026-10-12 推送。
- **能当什么组件**：单测级质量指标进 CI；**agentic 指标（任务完成度、工具调用正确性）的评估模板可抄**。
- **集成坑**：① LLM-judge 有成本与抖动（要 seed/多轮平均）；② 部分指标中文场景需自验；③ 商业公司主导（Confident AI），OSS/云边界注意。

### 4.4 RAGAS —— RAG 指标集 + 合成数据
- **链接**：https://github.com/explodinggradients/ragas
- **定位**：RAG 评测指标（faithfulness、context precision/recall、answer correctness 等）+ 合成测试集生成。
- **Star**：约 **16.0k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：Python（pip 包；指标依赖外部 LLM judge）。
- **活跃度**：镜像最后推送 2026-02-24，**活跃度走低**（用前看一眼仓库）。
- **能当什么组件**：知识库类 agent 的指标参考；**合成数据生成器可抄**。
- **集成坑**：依赖 judge 模型；API 迭代变动；只管 RAG、不等于 agent 全貌。

### 4.5 SWE-bench 官方 harness —— 编码 agent 的"真考卷"
- **链接**：https://github.com/SWE-bench/SWE-bench （原 princeton-nlp/SWE-bench 已重定向）
- **定位**：真实 GitHub issue 修复基准（harness + 数据集）：Docker 三层镜像（base→env→instance）、测试驱动判定、`swebench.harness.run_evaluation` 跑 predictions 文件；数据集分 full/Lite/Verified/Multimodal；文档在 swebench.com。
- **Star**：约 **6.0k**（镜像核实）
- **许可证**：MIT（原文核实）
- **技术栈**：Python（`swebench` 包）+ Docker（base→env→instance 三层镜像）。
- **活跃度**：2026-09-18 推送。
- **官方资源要求（文档口径）**：x86_64、≥120GB 磁盘、16GB 内存、8 核；arm64 仅实验性支持；`--max_workers` 建议 < min(0.75×CPU, 24)。
- **能当什么组件**：编码 agent 回归标尺；**环境快照/测试判定/补丁应用机制值得抄进自建回归**。另：inspect_evals 里有原生实现（默认用 Epoch AI 的 ghcr 预构建镜像，判定委托上游 harness）。
- **集成坑**：① 重（镜像多、耗时长、成本高）；② 镜像构建/网络问题多；③ **防泄漏**：任务可联网时 agent 可能读到你放盘的答案；④ 本地建议只跑子集（Verified/Lite 抽样）。

### 4.6 Terminal-Bench 2.0 + Harbor —— 终端 agent 基准
- **链接**：https://github.com/harbor-framework/terminal-bench （新主页，约 895★ 镜像核实，Apache-2.0）；https://github.com/laude-institute/terminal-bench （原仓库，约 2.6k★，2026-07 后低推送）；runner/框架：https://github.com/harbor-framework/harbor （约 **6.1k**★ 镜像核实，Apache-2.0，当日活跃）。
- **Star**：约 895（新主页）/ 约 2.6k（原仓库）/ 约 6.1k（Harbor）（均 2026-10-14 镜像核实）
- **许可证**：Apache-2.0（Harbor 与 terminal-bench 仓库标识；Harbor LICENSE 原文核实）
- **活跃度**：新主页与 Harbor 当日活跃；原仓库 2026-07 后低推送
- **定位**：Stanford × Laude Institute 的 CLI/终端 agent 基准：任务=自然语言指令 + Docker 沙箱 + pytest 式**终态验证**；**2.0 版经 Harbor 注册表分发**：`harbor run -d terminal-bench@2.0`；支持并行容器沙箱（Modal/Daytona 等）；ICLR 2026 论文（arXiv 2601.11868）。
- **能当什么组件**：终端/CLI agent 回归标尺；**"任务即代码"（说明+dockerfile+tests）的编写格式直接抄**；Harbor 作为通用"跑 agent 任务的 harness"值得研究。
- **集成坑**：① 版本迭代快（1.x→2.0 换了 harness，命令/数据集 ID 以最新文档为准）；② 需要容器基础设施；③ 任务质量持续修订中。

### 4.7 GAIA ⚠️（GitHub 仓库已下线）
- **现状**：github.com/gaia-benchmark/GAIA **已 404（2026-10-14 实测）**；官方载体现为 HuggingFace：数据集 `gaia-benchmark/GAIA`（**gated**，需账号申请）+ HF leaderboard space。
- **定位**：通用助手基准：450+ 题、3 档难度（L1/L2/L3）、多跳+工具+多模态；单轮、exact-match 判分；公开验证集约 165 题常被引用自测。
- **技术栈**：HuggingFace datasets（gated 数据集 + 评测 space）；无官方本地 runner。
- **能当什么组件**：通用 agent 能力标尺；**题目设计（多跳、文件处理）可抄**。
- **集成坑**：① **无官方本地 runner**（可用 inspect_evals 的 GAIA 实现）；② 数据集 gated/防爬；③ 判分严格（答案格式），自测易挫败。

### 4.8 WebArena —— 自托管 Web 环境基准
- **链接**：https://github.com/web-arena-x/webarena
- **定位**：仿真互联网（电商/论坛/CMS 等多站点自托管）+ 浏览器操作任务。
- **Star**：约 **1.6k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：Docker 编排的多站点 Web 应用 + 浏览器自动化（Playwright 系）。
- **活跃度**：镜像最后推送 2025-11-26，维护趋缓。
- **能当什么组件**：browser agent 评测环境蓝图（站点容器 + 浏览器控制）。
- **集成坑**：部署重、任务集年代偏旧、浏览器/网络不稳定导致 flaky。

### 4.9 OSWorld —— 真实 OS 内 computer-use 基准
- **链接**：https://github.com/xlang-ai/OSWorld
- **定位**：真实 OS（Ubuntu/Win/macOS）里 369 个 computer-use 任务；VM/VNC 基建。
- **Star**：约 **3.2k**（镜像核实）
- **许可证**：Apache-2.0（原文核实）
- **技术栈**：虚拟机 + Python 任务脚本 + VNC 观测。
- **活跃度**：2026-09-14 推送。
- **能当什么组件**：CUA（computer-use agent）评测；**VM 基建与任务脚本参考**。
- **集成坑**：重（VM×任务）、慢、结果方差大——建议抽样而非全量。

### 4.10 τ²-bench（Sierra）—— 多轮工具对话的"性价比最高"评测
- **链接**：https://github.com/sierra-research/tau2-bench （旧版：https://github.com/sierra-research/tau-bench ，约 1.5k★，2026-03 后低推送）
- **定位**：**工具-对话 agent 评测**：模拟用户 + 领域工具（airline/retail/telecom/banking 知识库），**校验数据库终态** + `pass^k` 可靠性指标；τ²（2025-06）引入 **dual-control**（用户也能改世界）；2026 年扩展语音（τ-voice）与 τ³ 修订；CLI `tau2 run/view`，**本地可跑（只需 LLM API）**；榜单 taubench.com。
- **Star**：约 **2.2k**（镜像核实）
- **许可证**：MIT（原文核实，© 2025 Sierra Research）
- **技术栈**：Python CLI（`tau2`）；agent 与被模拟用户均需 LLM API。
- **活跃度**：2026-10-14 当日推送，活跃。
- **能当什么组件**：**多轮 agent 回归的模板级参考**——任务生成器、用户模拟器、终态判定、pass^k 指标，全部可抄进自建评测体系。
- **集成坑**：① 需 LLM 模拟用户（成本）；② **用户模拟器自身有错误率**（论文报告 retail/airline 严重错误率 12~13%，telecom 域降至 6%）——结论要留误差意识；③ 域有限（客服场景为主）。

---

## 5. 集成对照：与自建 agent 主循环的埋点成本（Otel/回调）

| 组件 | 埋点机制 | 侵入度 | 流式请求 | 失败重放路径 |
|---|---|---|---|---|
| **LiteLLM** | 内置 callbacks / 请求日志 | 极低（网关一次性配置，**全量生效**） | 支持（流式透传+用量统计） | 请求日志可回放请求体（注意脱敏） |
| **Langfuse** | SDK `@observe` / OTLP / LiteLLM 回调 | 低 | 支持（含流式合并更新） | **trace→dataset→experiment**；playground 单条重发 |
| OpenLLMetry | OTel 自动插桩 | 最低（黑盒） | 支持 | 依赖所选后端 |
| Phoenix | OpenInference 自动 + 手动 span | 低 | 支持 | 本地日志/复跑 |
| Opik | SDK 装饰器 / 集成 | 低 | 支持 | 数据集实验 |
| AgentOps | 装饰器 | 低 | 支持 | session replay（SaaS 为主） |
| promptfoo | 黑盒外部测（不埋点） | 零 | 以最终输出为主 | **eval 输出 JSON 存档复跑** |
| Inspect AI | adapter 包装（日志=全记录） | 中（写 adapter） | 支持（事件流记录） | `inspect view` + 单样本重跑 |

**设计要点（可抄）**：
1. **一 trace 三层粒度**：session/trace → step（主循环每轮）→ generation（模型调用）+ tool_call；用 OTel GenAI conventions 打底，自加 agent 语义属性（task_id、step_index、retry_of）。
2. **成本双记账**：网关层（LiteLLM spend logs）管预算熔断，观测层（Langfuse）管归因分析；两边定期对账防漂移。
3. **失败重放闭环**：观测后端把 bad case 导出成数据集 → 转成 promptfoo/Inspect 用例 → CI 守门 → 修复后再回归。这是"观测"与"评测"两个集群唯一的正确连接方式。
4. **流式细节**：确认所选 SDK 在 streaming 下记录**完整** prompt/completion（如 Langfuse 的 generation 更新模式），否则重放价值大打折扣。
5. **埋点只挂一层**：网关回调（LiteLLM→Langfuse）与 SDK 装饰器**不重复**记录同一模型调用，避免双份数据。

---

## 6. 推荐组合（多 provider 统一 / 成本追踪 / 失败重放 / 回归测试 / 本地推理可选）

### 6.1 主组合（全自托管可行，个人→产品级均适用）

```
Agent 主循环
 ├─ 模型调用统一走 LiteLLM（Proxy 网关 或 进程内 SDK，二选一）
 │    ├─ 云端 provider：OpenAI / Anthropic / Gemini / …（OpenAI 兼容层转义）
 │    ├─ 本地 GPU：vLLM 或 SGLang（OpenAI 兼容 endpoint）
 │    ├─ 开发机：Ollama（同协议，随时切换）
 │    ├─ 策略：fallback 链 + 重试 + 预算/限流 + tag 路由
 │    ├─ callbacks → Langfuse（模型调用级 trace 起点）
 │    └─ spend logs → 成本账本（预算熔断在网关层）
 ├─ Agent 语义埋点：Langfuse SDK（@observe 包主循环与工具调用）；
 │    （若想后端无关：换 OpenLLMetry 自动埋点，二选一）
 ├─ 数据面：Langfuse 自托管（Postgres + ClickHouse + Redis + S3）
 └─ 评测三层：
      ├─ CI 快闸门（每次提交）：promptfoo（YAML 用例/断言/基线对比）+ DeepEval（pytest 指标）
      ├─ 深度回归（夜间/周级）：Inspect AI + inspect_evals
      │    ├─ GAIA 验证集子集（通用能力）
      │    ├─ SWE-bench Lite/Verified 抽样（编码）
      │    ├─ Terminal-Bench 2.0 抽样（CLI，经 Harbor/Inspect Harbor）
      │    └─ τ²-bench（多轮工具对话 + pass^k，最能反映 agent 真实质量）
      └─ 闭环：Langfuse 失败 trace → 数据集 → promptfoo/Inspect 用例
```

**逐项对照（parent 要求）**：
| 要求 | 方案 | 说明 |
|---|---|---|
| 多 provider 统一 | LiteLLM | 100+ provider、OpenAI 兼容、本地/云同口径 |
| 成本追踪 | LiteLLM spend logs + Langfuse 面板 | 网关管熔断、观测管归因，双记账互对账 |
| 失败重放 | Langfuse（trace→dataset/playground）+ promptfoo（eval 存档复跑）+ Inspect（单样本重跑） | 三层重放粒度 |
| 回归测试 | promptfoo/DeepEval（CI）+ Inspect+基准（夜间） | 快慢两档，成本可控 |
| 本地推理可选 | vLLM/SGLang（服务）+ Ollama（开发） | 全部经 LiteLLM 同一接口，随时切换 |

### 6.2 变体（按偏好替换）
- **轻量起步**：本地调试用 Phoenix（单进程）→ 上生产再换 Langfuse（注意 Phoenix 是 ELv2）。
- **评测驱动**：主观测后端直接用 Opik（观测+评测一体）。
- **TS 栈/边缘**：Portkey Gateway 替代 LiteLLM（2.0 合并后再评估）；网关+日志二合一可用 Helicone。
- **纯后端无关埋点**：OpenLLMetry → 自建 OTLP 收集器（ClickHouse/Tempo）→ 自看板。
- **中文/国产生态评测补充**：OpenCompass（约 7.5k★）、EvalScope（ModelScope，约 3.5k★），对本地/国产模型评测友好。

### 6.3 拍板清单（选型时明确的取舍）
1. **Langfuse vs Phoenix**：功能与规模化选 Langfuse（MIT 核心）；本地快速调试选 Phoenix（⚠️ ELv2 不可当托管服务转卖）。
2. **LiteLLM vs Portkey vs Helicone**：Python 生态+功能齐全 = LiteLLM；边缘低延迟 = Portkey；"网关+观测"二合一 = Helicone。**不要叠加多个代理**。
3. **Inspect vs promptfoo**：分工=深度/基准/沙箱 vs CI 快闸门/红队，**两个都上**。
4. **RouteLLM/semantic-router**：前者停更只抄思想；后者适合意图/工具路由，别指望单靠它大幅省钱。
5. **基准怎么选**：编码=SWE-bench 抽样 + Terminal-Bench；通用助手=GAIA（gated）；web=WebArena（重）；桌面=OSWorld（重）；**多轮工具对话=τ²-bench（投入产出比最高）**。
6. **Langfuse 归属 ClickHouse（2026-01）**：MIT/自托管承诺不变，但作为长期风险项记录；数据模型持续向 ClickHouse 深化。

---

## 7. 附录

### 7.1 其他值得一看（均已镜像核实，2026-10-14）
| 项目 | 链接 | 定位 | 约 star | 许可证 | 备注 |
|---|---|---|---|---|---|
| Bifrost | https://github.com/maximhq/bifrost | Go 高性能 LLM 网关 | 约 8.8k | Apache-2.0（原文核实） | 2026-10-13 推送，增长快 |
| LangWatch | https://github.com/langwatch/langwatch | 观测 + 评测/guardrail | 约 4.9k | Apache-2.0（原文核实） | 当日活跃 |
| Agenta | https://github.com/agenta-ai/agenta | 观测+评测+prompt 一体 | 约 4.8k | MIT + ee/ 商业（open-core，原文核实） | 当日活跃 |
| EvalScope | https://github.com/modelscope/evalscope | 模型评测（ModelScope） | 约 3.5k | Apache-2.0（原文核实） | 国产/本地模型友好 |
| OpenCompass | https://github.com/open-compass/opencompass | 模型评测 | 约 7.5k | Apache-2.0（原文核实） | 中文生态，当日活跃 |
| OpenInference | https://github.com/Arize-ai/openinference | OTel 埋点包（独立可用） | 约 1.3k | Apache-2.0（原文核实） | 配合任意 OTLP 后端 |
| inspect_evals | https://github.com/UKGovernmentBEIS/inspect_evals | Inspect 的基准套件库 | 约 704 | MIT（原文核实） | GAIA/SWE-bench/Cybench 等 200+ |

### 7.2 核实方法与信源
- **Star 核实**：6 仓库经 `api.github.com`（2026-10-14 UTC，本文档集群预算内）；其余经 ungh.cc 镜像。镜像有小时级延迟；停更/下线状态为实测（404/最后推送时间）。
- **许可证核实**：优先 curl 仓库 `LICENSE` / `ee/LICENSE` / `enterprise/LICENSE.md` 原文（Langfuse、LiteLLM、Phoenix、Portkey、Helicone、Bifrost、Agenta、Inspect 系、Harbor、SWE-bench、τ² 等均如此核实）。
- **关键信源**：
  - ClickHouse 收购 Langfuse：https://clickhouse.com/blog/clickhouse-acquires-langfuse-open-source-llm-observability
  - Langfuse 官方文档/仓库：https://langfuse.com/docs/observability/overview
  - Portkey Gateway 2.0 合并公告：https://github.com/Portkey-AI/gateway/discussions/1576
  - SWE-bench 官方文档（harness/资源要求）：https://www.swebench.com/SWE-bench
  - Terminal-Bench 论文（ICLR 2026）：https://arxiv.org/html/2601.11868v1 ；Harbor：https://harborframework.com/docs
  - τ²-bench/τ-voice 官方博客与榜单：https://sierra.ai/uk/blog/benchmarking-agents-in-collaborative-real-world-scenarios ；https://taubench.com
  - GAIA：https://huggingface.co/datasets/gaia-benchmark/GAIA
  - Inspect/Inspect Evals：https://www.aisi.gov.uk/blog/inspect-evals
- **未能核实项**：Lunary 的下线/整合背景（无官方公告）；Portkey 2.0 合并后的最终许可条款；各 SaaS 云版与 OSS 的功能边界明细。落地前请按当时仓库状态复核。

*（本文档为只读调研产物，未安装任何组件；所有星标/许可证/状态以 2026-10-14 实测为准。）*

# 05 · 交互层 / 消息通道 / 调度 / 语音 —— 开源组件调研

> 调研日期：2026-10-14（UTC）。本文件是 6 路并行调研的第 5 路，覆盖：聊天前端、终端 Agent、消息通道桥、整机助理参考、语音、调度/持久执行、通知。
> 不重复评估：框架编排（01）、记忆（02）、工具/沙箱（03）、模型/可观测（04）、安全/基建（06）。
>
> **核实方法（全文统一）**
> - ★ 数字：2026-10-14 从 GitHub 仓库页面 star 计数器抓取；其中 5 项另经 `api.github.com` 交叉核实（open-webui、wechaty、AstrBot、LangBot、ntfy，页面值与 API 值一致），标注「API 核实」；其余标注「页面核实」或「页面抓取（约）」。
> - 许可证：抓取仓库 `raw.githubusercontent.com` 的 LICENSE 原文判读，关键条款直接引用原文含义。
> - 活跃度：`commits.atom` 最新提交时间（默认分支）。
> - 收录规则：真实存在且 2024 年后仍活跃的项目为主；**已停更项目只作反面警示并明确标注**。
> - ⚠️ 标出「非标准开源 / 有附加限制」的许可证：Open WebUI 品牌条款、NapCat 自定义许可、Inngest（SSPL）、Restate（BSL）、Windmill（AGPL+专有组件）、LobeHub Community License、wechaty（第三方付费 Token 生态）。

---

## 0. 结论速览

**推荐组合（一句话）**：自研薄「Agent 网关（channel gateway）」统管各通道 → 调度用 **APScheduler 起步、Restate/DBOS 承接持久工作流**（重型备选 Temporal）→ 语音可选 **pipecat / LiveKit Agents** → 通知 **ntfy + Apprise**。

**最需警惕的雷区（按严重度）**
1. **NapCat（当前最好用的 QQ 协议端）自定义许可禁止商用、限制再分发** —— 产品化前必须联系作者授权，或换协议端路线（Lagrange/LuckyLilliaBot，但各有许可/维护问题）。
2. **Open WebUI ≥50 用户（滚动 30 天）禁止去除/修改 "Open WebUI" 品牌**（v0.6.6 起，2025-04-19）；白标商用需企业授权。
3. **Fair-code 类许可**：Inngest = SSPL（非 OSI 开源）；Restate = BSL 1.1（自用免费、禁止做公共托管平台）；Windmill 社区版 = AGPLv3 + 专有发行物。
4. **停更/半停更**：go-cqhttp（2024-05 停，QQ 协议封禁）、Vocode（2024-11 后无提交）、wechaty 核心仓（2025-12 后无提交）、aider / Ultravox / Chainlit / Continue（节奏明显放缓）。
5. 非官方协议通道（QQ 注入、WhatsApp 网页协议、微信个人号）**全部有封号与合规风险**，务必专用小号 + 隔离部署。

---

## 1. 聊天前端（Web 端 / 产品级 UI）

### 1.1 Open WebUI
**Open WebUI** ｜ [open-webui/open-webui](https://github.com/open-webui/open-webui) ｜ ★155,699（API 核实）
- 定位：自托管多模型聊天前端 / 一站式 AI 平台（Ollama 与 OpenAI 兼容后端）。
- 许可：⚠️ **Open WebUI License**（= BSD-3-Clause + 品牌保护条款）。条款要点（LICENSE 原文）：v0.6.6（2025-04-19）起，任何部署/分发不得删除、遮挡、替换 "Open WebUI" 品牌（名称、Logo、界面标识），除非 ① 滚动 30 天内终端用户 ≤50 人，② 获得书面许可，③ 持有企业许可；否则构成重大违约。贡献需签 CLA；**≤v0.6.5 的代码仍为 BSD-3，可无限制 fork**。
- 技术栈：Python（FastAPI）+ Svelte；Docker 单镜像可跑。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：「开箱即用 Web 门面」性价比第一：用户/权限、多模型路由、RAG/文件、PWA、OpenAI 兼容 API 层，把后端换成你的 agent 即可先用起来；可抄其插件钩子（Functions）与模型配置体验。
- 集成坑：品牌条款（白标/商用需企业授权，产品级自研要提前决策）；版本迭代快、破坏性变更常有；企业功能闭源；对「agent 工具审批流/长任务」展示能力弱。

### 1.2 LibreChat
**LibreChat** ｜ [LibreChat-AI/LibreChat](https://github.com/LibreChat-AI/LibreChat)（原 danny-avila/LibreChat，已迁移组织） ｜ ★45,693（页面核实）
- 定位：ChatGPT 式多供应商聊天平台（Agents、MCP、多用户、预设/分享）。
- 许可：MIT。
- 技术栈：TypeScript（Node + React）+ MongoDB。
- 活跃度：高（2026-10-06）。
- 组件/可抄：多供应商配置中心、Agents + MCP 集成、按用户/按模型限流、对话分享；比 Open WebUI 更"多用户 SaaS 化"。
- 集成坑：组件较重（Mongo，可选 Redis）；Agents 深度编排不如专用框架；组织迁移需更新链接。

### 1.3 LobeChat（现 lobehub/lobehub）
**LobeChat / LobeHub** ｜ [lobehub/lobehub](https://github.com/lobehub/lobehub)（原 lobehub/lobe-chat，仓库已合并更名） ｜ ★83,237（页面核实）
- 定位：现代设计聊天 UI，现定位升级为「Agent 运营平台」（页面标题与描述已改为 LobeHub "Chief Agent Operator"）。
- 许可：⚠️ **LobeHub Community License**（"based on Apache License 2.0 with additional conditions"，附加条款未逐条核实，采用前读全文）。
- 技术栈：Next.js / TypeScript。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：UI/主题/多端体验、插件与市场设计、模型供应商配置体系。
- 集成坑：不是纯 Apache-2.0（有附加条款）；仓库合并/品牌调整进行中；开源版与官方云服务存在功能落差。

### 1.4 Chainlit
**Chainlit** ｜ [Chainlit/chainlit](https://github.com/Chainlit/chainlit) ｜ ★12,518（页面核实）
- 定位：Python 对话式 AI 应用框架（几分钟给 agent 套上对话 UI）。
- 许可：Apache-2.0。
- 技术栈：Python（装饰器式 API）。
- 活跃度：中（2026-08-26 后暂无提交）；⚠️ 治理风险：2025 年官方停止 Literal AI（服务 2025-10-31 关停）并**公开寻找 Chainlit 新维护者**，处于"社区接棒期"。
- 组件/可抄：`@cl.on_message` 极简模型、Step/元素 UI、与 Python 生态（LangChain 等）的即插即用。
- 集成坑：生产化薄弱（多租户/鉴权/横向扩展有限）；维护权交接未完成，长期支持不确定；仅适合原型与内部工具。

### 1.5 assistant-ui
**assistant-ui** ｜ [assistant-ui/assistant-ui](https://github.com/assistant-ui/assistant-ui) ｜ ★12,541（页面核实）
- 定位：React/TypeScript 聊天 UI 组件库（"AI 聊天界的 shadcn"）。
- 许可：MIT。
- 技术栈：TypeScript / React。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：流式消息渲染、线程列表、输入框/附件/工具调用状态展示等成套组件——自研 Web 前端时直接薅。
- 集成坑：纯前端库，需自建后端协议层（配合 Vercel AI SDK 或自研 SSE）；迭代快。

### 1.6 Vercel AI SDK
**Vercel AI SDK** ｜ [vercel/ai](https://github.com/vercel/ai) ｜ ★27,317（页面核实）
- 定位：TypeScript AI 应用工具包（模型抽象 + 流式 UI 协议）。
- 许可：Apache-2.0。
- 技术栈：TypeScript（core + React/Vue/Svelte 绑定 + 服务端）。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：**UI Message Stream 协议**（前后端流式契约，含工具调用中间态）是行业事实标准之一，建议自研系统直接对齐它；多 provider 抽象与类型安全工具定义也值得照搬。
- 集成坑：主战场 TS，Python 后端需自行实现等价协议；大版本升级协议有变更，锁版本。

### 1.7 CopilotKit
**CopilotKit** ｜ [CopilotKit/CopilotKit](https://github.com/CopilotKit/CopilotKit) ｜ ★38,013（页面核实）
- 定位：应用内 Agent/Copilot 前端栈（AG-UI 协议、Generative UI、前端共享状态）。
- 许可：MIT。
- 技术栈：TypeScript / React + 自托管 Runtime。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：**agent ↔ 前端的交互协议（AG-UI）**：状态同步、前端动作调用、组件级生成式 UI——做「产品级交互」时是最全面的参考。
- 集成坑：绑定 React 生态；runtime 需自托管；协议仍在快速演进，跟进成本高。

---

## 2. 终端侧（CLI/TUI，可直接复用或抄设计）

### 2.1 opencode
**opencode** ｜ [anomalyco/opencode](https://github.com/anomalyco/opencode)（原 sst/opencode，SST 团队已更名 Anomaly） ｜ ★213,518（页面核实）
- 定位：开源终端编码 Agent（TUI 客户端 + 本地 server 架构）。
- 许可：MIT。
- 技术栈：TypeScript + Go（TUI）。
- 活跃度：极活跃（2026-10-14 当日有提交）。
- 组件/可抄：**「TUI ↔ 本地 server」分层**（多客户端/多会话共享、会话持久化）、工具审批/权限 UI、provider 无关配置——终端交互层的头号参考，也可直接当现成 CLI 使用。
- 集成坑：组织更名史（sst→anomalyco、与已归档的 opencode-ai/opencode 易混淆）；产品节奏极快。附注：原版 [opencode-ai/opencode](https://github.com/opencode-ai/opencode) ★13,808，**已归档（2025-09）**，勿选用。

### 2.2 aider
**aider** ｜ [Aider-AI/aider](https://github.com/Aider-AI/aider) ｜ ★49,550（页面核实）
- 定位：终端 AI 结对编程（repo-map、diff 式编辑、git 自动提交）。
- 许可：Apache-2.0。
- 技术栈：Python。
- 活跃度：⚠️ 放缓（2026-05-22 后无提交，页面核实）。
- 组件/可抄：repo-map（代码库结构图）、edit formats、每次修改自动 commit 的纪律——经典设计仍值得抄。
- 集成坑：维护节奏放缓，作为参考而非核心依赖。

### 2.3 goose
**goose** ｜ [aaif-goose/goose](https://github.com/aaif-goose/goose)（原 block/goose） ｜ ★55,287（页面核实）
- 定位：local-first 通用 AI Agent（CLI + 桌面双端）。
- 许可：Apache-2.0。
- 技术栈：Rust。
- 活跃度：极活跃（2026-10-14 当日有提交）；治理：**2026-04 由 Block 捐赠给 Linux Foundation 旗下 Agentic AI Foundation（AAIF）**。
- 组件/可抄：extensions/MCP 生命周期管理、recipes（可复用任务配方）、本地优先架构与权限模型。
- 集成坑：治理迁移期路线待观察；Rust 栈与 Python 网关集成需 RPC/子进程方案。

### 2.4 Continue
**Continue** ｜ [continuedev/continue](https://github.com/continuedev/continue) ｜ ★36,225（页面核实）
- 定位：IDE + CLI 编码助手（配置驱动的模型/规则/上下文）。
- 许可：Apache-2.0。
- 技术栈：TypeScript。
- 活跃度：中（2026-07-21 后无提交，页面核实）。
- 组件/可抄：config.yaml 式统一配置（models / rules / context providers）、IDE 与 CLI 共享内核的双形态设计。
- 集成坑：重心仍在 IDE 插件；headless/CLI 场景成熟度不如 opencode；节奏放缓。

---

## 3. 消息通道桥（QQ / TG / Discord / Slack / WhatsApp / Signal / Matrix / 客服）

### 3.1 官方 Bot SDK

**python-telegram-bot** ｜ [python-telegram-bot/python-telegram-bot](https://github.com/python-telegram-bot/python-telegram-bot) ｜ ★29,516（页面核实）
- 定位：Telegram 官方 Bot API 的 Python 封装（事实标准）。
- 许可：LGPL-3.0（README/PyPI 元数据声明；⚠️ 仓库 LICENSE 文件为 GPLv3 全文，两处文本不一致，法务敏感场景留意）。
- 技术栈：Python（async）。
- 活跃度：高（2026-10-11）。
- 组件/可抄：handler 分组、ConversationHandler（FSM）、消息/媒体处理；直接用作 TG 通道适配器。
- 集成坑：Bot API 限制（读不到其他 bot 消息、callback 超时）；LGPL 对"修改库本身并分发"有传染，正常依赖使用无碍。

**aiogram**（补充） ｜ [aiogram/aiogram](https://github.com/aiogram/aiogram) ｜ ★5,892（页面抓取）
- 定位：另一主流 TG Bot 框架（路由/中间件/FSM 更 Pythonic）。
- 许可：MIT；技术栈：Python asyncio；活跃度：高（2026-10-11）。
- 组件/可抄：middleware 体系与依赖注入设计。
- 集成坑：生态小于 PTB，二选一即可。

**discord.py** ｜ [Rapptz/discord.py](https://github.com/Rapptz/discord.py) ｜ ★16,197（页面核实）
- 定位：Discord Bot 标准库。
- 许可：MIT；技术栈：Python；活跃度：中（2026-09-01）。
- 组件/可抄：cogs/extensions 插件模型、事件分发；直接用作 Discord 通道适配器。
- 集成坑：Message Content 等特权 intent 需申请；**不可用于个人账号自动化（违反 ToS）**；限流与断线恢复逻辑复杂。

**Slack Bolt**（bolt-python ★1,329 页面核实 / bolt-js ★约2,948 页面抓取） ｜ [slackapi/bolt-python](https://github.com/slackapi/bolt-python)、[slackapi/bolt-js](https://github.com/slackapi/bolt-js)
- 定位：Slack 官方 app 框架（Python/JS 双版本）。
- 许可：MIT；技术栈：Python / TypeScript；活跃度：高（2026-10-09）。
- 组件/可抄：Socket Mode（开发期免公网）、Block Kit、OAuth 安装流。
- 集成坑：需工作区管理员安装审批；企业分发审核；消息格式（Block Kit）与通用 Markdown 转换成本。

### 3.2 非官方协议通道（封号/合规风险，务必隔离部署）

**Baileys** ｜ [WhiskeySockets/Baileys](https://github.com/WhiskeySockets/Baileys) ｜ ★11,340（页面核实）
- 定位：WhatsApp Web 多设备协议的纯 WebSocket TS 实现（无需浏览器）。
- 许可：MIT；技术栈：TypeScript/Node；活跃度：中（2026-08-04）。
- 组件/可抄：协议级实现（无 Selenium/Puppeteer）、多设备配对（二维码）、auth state 持久化模式。
- 集成坑：**非官方渠道 → 封号风险**；协议随 WA 更新漂移；商用应走官方 Cloud API。

**wppconnect** ｜ [wppconnect-team/wppconnect](https://github.com/wppconnect-team/wppconnect) ｜ ★3,472（页面核实）
- 定位：Puppeteer 驱动 WhatsApp Web 的开源实现（Baileys 的浏览器方案替代）。
- 许可：⚠️ **LGPL-3.0**（不是 Apache，原文确认）；技术栈：TypeScript + Puppeteer；活跃度：高（2026-10-13）。
- 组件/可抄：浏览器路线的兜底方案；token 会话持久化。
- 集成坑：重（需跑 Chromium）；对 WA Web UI 变动敏感；封号风险同上。

**signal-cli** ｜ [AsamK/signal-cli](https://github.com/AsamK/signal-cli) ｜ ★4,983（页面核实）
- 定位：Signal 非官方命令行/库。
- 许可：GPL-3.0；技术栈：Java（GraalVM 原生镜像）；活跃度：高（2026-10-14 当日）。
- 组件/可抄：**JSON-RPC daemon 模式（socket/HTTP）** 天然适合做网关的下游进程——收到消息转发给你的网关、网关回发；`link` 设备配对流程也值得参考。
- 集成坑：GPL 传染（分发修改版注意）；需手机端扫码 link；官方非支持渠道，条款灰色。

**mautrix（家族）** ｜ [mautrix/whatsapp](https://github.com/mautrix/whatsapp)（另有 telegram/signal 等桥） ｜ ★1,905（页面核实）
- 定位：Matrix ↔ 各 IM 的 puppeting bridge（portal/puppet、double puppeting、E2EE）。
- 许可：AGPL-3.0；技术栈：Go；活跃度：高（2026-10-14 当日）。
- 组件/可抄：**「把各 IM 桥接进统一协议（Matrix）再让 bot 只对接一个协议」** 的架构范式——与你自研「统一网关」思路同构，是重要参照；对加密会话、多端同步的处理成熟。
- 集成坑：需要自建 Matrix homeserver（Synapse/Conduit）；AGPL；运维复杂度高；适合"以 Matrix 为内网总线"的重型方案。

### 3.3 QQ 专项（国内场景重点）

**NapCat** ｜ [NapNeko/NapCatQQ](https://github.com/NapNeko/NapCatQQ) ｜ ★10,960（页面核实）
- 定位：基于官方 QQNT 客户端的现代协议端（OneBot 11，HTTP/WS 正反向 + WebUI）。
- 许可：⚠️ **自定义 "Limited Redistribution License"（非开源许可）**——原文要点：未经作者明确许可禁止使用/复制/修改/分发；再分发须保留许可全文并注明来源；**禁止任何商用**；修改后的代码不得公开发布。产品化/商用必须先与作者沟通授权。
- 技术栈：TypeScript（QQNT 注入）；活跃度：高（2026-10-12）。
- 组件/可抄：当前 QQ 生态最完整的 OneBot 11 实现（接口覆盖全、无头部署成熟）；若你现系统已在用 OneBot 路线，保留可平滑迁移。
- 集成坑：**许可限制是最大坑**（商用禁止）；封号风险；QQNT 版本更新常破坏注入；社区不解答基础对接问题；建议专用小号 + 只绑内网 + 独立账号部署，协议端设计成可插拔层（见 §8）。

**NoneBot2** ｜ [nonebot/nonebot2](https://github.com/nonebot/nonebot2) ｜ ★7,743（页面核实）
- 定位：跨平台 Python 异步机器人框架（适配 OneBot v11/v12、TG、Discord、飞书等）。
- 许可：MIT；技术栈：Python asyncio；活跃度：高（2026-10-12）。
- 组件/可抄：国内最大的 QQ 插件生态；把 NapCat 当协议端、NoneBot 当事件路由层是成熟组合；其适配器（driver/adapter）抽象值得抄。
- 集成坑：OneBot 依赖第三方协议端（go-cqhttp 已死，见下）；与自研内核整合需要走事件桥（不要同时跑两套业务逻辑）。

**Lagrange.Core**（补充） ｜ [LagrangeDev/Lagrange.Core](https://github.com/LagrangeDev/Lagrange.Core) ｜ ★约2,991（页面抓取）
- 定位：纯 C# 实现的 NTQQ 协议（不依赖 QQNT 客户端）。
- 许可：⚠️ 仓库未发现标准 LICENSE 文件（页面核实），商用/再分发前需向作者确认。
- 技术栈：C#；活跃度：中（2026-09-07）。
- 组件/可抄：轻量部署路线（无需装 QQ 客户端）。
- 集成坑：许可不明确；协议实现需跟随官方变化；跨语言集成（.NET）。

**LLOneBot（现 LuckyLilliaBot）**（补充） ｜ [LLOneBot/LLOneBot](https://github.com/LLOneBot/LLOneBot) ｜ ★约3,665（页面抓取）
- 定位：QQNT 插件形态的协议端（支持 OneBot 11 / Satori / Milky）。
- 许可：GPL-2.0；技术栈：TypeScript；活跃度：高（2026-10-12）。
- 集成坑：GPL-2.0 传染性（修改分发需开源）；作为插件依赖桌面 QQNT 环境，无头场景弱于 NapCat。

**⚠️ go-cqhttp（反面案例，勿用）** ｜ [Mrs4s/go-cqhttp](https://github.com/Mrs4s/go-cqhttp) ｜ ★10,618
- 已停更（最后提交 2024-05；协议被 QQ 官方封禁，社区共识"已接近不可用"）。教训：**QQ 协议端生命周期不可预期，网关架构必须把"协议端"设计成可替换插槽**。

### 3.4 微信 / 综合

**wechaty** ｜ [wechaty/wechaty](https://github.com/wechaty/wechaty) ｜ ★23,366（API 核实）
- 定位：Conversational RPA SDK（"puppet" 协议可插拔，主打微信生态）。
- 许可：Apache-2.0（代码本体）＋ ⚠️ **依赖生态付费**：官方明确不售卖 Token，稳定通道由第三方 CPSP（Commercial Puppet Service Providers）提供 Token，属付费闭源服务。
- 技术栈：TypeScript；活跃度：⚠️ **核心仓库 2025-12-21 后无提交（页面核实），实质半停更**。
- 组件/可抄：puppet 抽象（协议层可插拔）+ Token 网关远程托管模式——架构思想有参考价值。
- 集成坑：微信个人号自动化有封号/诉讼风险；免费 puppet 基本不可用；核心停滞 → 不建议新产品依赖。

### 3.5 客服式统一收件箱

**Chatwoot** ｜ [chatwoot/chatwoot](https://github.com/chatwoot/chatwoot) ｜ ★37,793（页面核实）
- 定位：开源全渠道客服平台（网站/邮件/WA/TG 等统一收件箱 + 人工坐席）。
- 许可：MIT（除 `enterprise/` 目录专有，LICENSE 原文明确）；技术栈：Ruby on Rails + Vue；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**conversation/assignment/webhook/Agent Bot API 的数据模型**——做「agent 接管 + 人工兜底」交互形态的最佳借鉴。
- 集成坑：Rails 单体较重；定位是客服而非通用 agent；深度集成（把 agent 当 bot 坐席）需要二次开发。

### 3.6 额外发现：多通道 Agent 平台（最贴近目标形态）

**LangBot** ｜ [langbot-app/LangBot](https://github.com/langbot-app/LangBot)（原 RockChinQ/LangBot） ｜ ★18,164（API 核实）
- 定位：生产级多平台 Agentic IM Bot 平台（QQ/QQ 频道/微信/TG/Discord/Slack/飞书等统一接入 + Web 管理面板 + 插件）。
- 许可：Apache-2.0；技术栈：Python；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**"平台适配器 → 消息管道/插件 → LLM 内核"三层架构** 与你自研目标高度同构，是现成对照实现；其多平台适配器清单可作为通道优先级参考。
- 集成坑：作为整机方案直接采用则定制受限（取其架构、不照搬）；各平台适配质量参差；中文文档为主。

**AstrBot** ｜ [AstrBotDevs/AstrBot](https://github.com/AstrBotDevs/AstrBot) ｜ ★41,881（API 核实）
- 定位：多平台 LLM 聊天机器人框架 + 插件生态（QQ/微信/TG/Discord/飞书等；自带 WebUI 与 agent 能力）。
- 许可：⚠️ **AGPL-3.0**（修改后提供网络服务需开源对应修改）；技术栈：Python；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：适配器抽象、事件总线、插件市场与运营面板——国内生态里功能覆盖最全的参考实现之一。
- 集成坑：AGPL 传染性（自用无碍，产品化二次开发注意）；历史架构大改过，资料时效性参差。

---

## 4. 整机个人助理参考

### 4.1 Leon
**Leon** ｜ [leon-ai/leon](https://github.com/leon-ai/leon) ｜ ★17,576（页面核实）
- 定位：开源个人助理（技能/意图 + NLU 管线起家）。
- 许可：MIT；技术栈：TypeScript/Node；活跃度：高（2026-10-12），**当前处于 2.0 Developer Preview 重构**（转向工具/上下文/记忆/agentic 执行）。
- 组件/可抄：个人助理的"技能注册 + NLU 路由"经典结构；2.0 的 agentic 重构方向与你的目标一致，值得跟踪。
- 集成坑：2.0 未稳定；社区规模有限；作为"架构参考"而非依赖。

### 4.2 OpenVoiceOS（OVOS）
**OpenVoiceOS** ｜ [OpenVoiceOS/ovos-core](https://github.com/OpenVoiceOS/ovos-core) ｜ ★296（核心仓，页面核实；生态多仓库）
- 定位：FOSS 语音助理整机平台（Mycroft 遗产的社区延续）。
- 许可：Apache-2.0；技术栈：Python；活跃度：中（2026-10-08）。
- 组件/可抄：**消息总线（ovos-bus）+ 技能服务插件 + 唤醒词/STT/TTS 管线** 的整机架构，是"语音助理 = 家庭设备"路线的最佳开源对照。
- 集成坑：生态碎片化（几十个仓库）、部署重；中文资源需自建；整体热度低。

### 4.3 Willow
**Willow** ｜ [HeyWillow/willow](https://github.com/HeyWillow/willow)（原 toverainc/willow） ｜ ★3,126（页面核实；配套 [willow-inference-server](https://github.com/toverainc/willow-inference-server) ★511）
- 定位：低成本本地语音助理（ESP32 硬件 + 本地推理服务，HA 集成）。
- 许可：Apache-2.0；技术栈：ESP32 固件（C）+ Python/Rust 推理服务；活跃度：中（2026-08-04 / 2026-02-12）。
- 组件/可抄：**"廉价拾音终端 + 独立推理服务器"** 的拆分部署模式；消费级硬件交互设计。
- 集成坑：硬件向、社区热度下降；中文/自定义模型需改造；依赖 Home Assistant 生态。

---

## 5. 语音（实时语音 Agent）

### 5.1 pipecat
**pipecat** ｜ [pipecat-ai/pipecat](https://github.com/pipecat-ai/pipecat) ｜ ★16,473（页面核实）
- 定位：实时语音/多模态 agent 管线框架（"Open Source framework for voice agents"）。
- 许可：BSD-2-Clause；技术栈：Python；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**frame/pipeline 处理链抽象**（processor 依次串起 VAD/STT/LLM/TTS/传输）、打断（interruption）与回合检测、多家供应商与传输（WebSocket/电话）集成——语音接入的首选起点。
- 集成坑：实时链路调试门槛高；云端 STT/TTS 成本；生产监控/降级自建。

### 5.2 LiveKit Agents
**LiveKit Agents** ｜ [livekit/agents](https://github.com/livekit/agents) ｜ ★14,740（页面核实）
- 定位：基于 LiveKit/WebRTC 的实时语音 AI agent 框架。
- 许可：Apache-2.0；技术栈：Python（+Node SDK）；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：worker/job 调度模型、房间/参与者抽象、与 WebRTC 前端及电话（SIP）打通——产品级实时语音基础设施最完备。
- 集成坑：需部署 LiveKit 服务（自托管/云）；概念较多；模型组合自选（接 04 章节的模型方案）。

### 5.3 Vocode（⚠️ 停更）
**Vocode** ｜ [vocodedev/vocode-core](https://github.com/vocodedev/vocode-core) ｜ ★3,802（页面核实）
- 定位：voice-based LLM agent 框架（曾主打电话场景）。
- 许可：MIT；技术栈：Python；活跃度：⚠️ **停更（最后提交 2024-11-15）**。
- 处理：仅作"电话 + 语音 agent 抽象"的历史参考；新项目用 pipecat / LiveKit Agents 替代。

### 5.4 openai-realtime-agents
**openai-realtime-agents** ｜ [openai/openai-realtime-agents](https://github.com/openai/openai-realtime-agents) ｜ ★7,002（页面核实）
- 定位：OpenAI Realtime API 多 agent 交接官方样例。
- 许可：MIT；技术栈：TypeScript/Next.js；活跃度：低-中（最后提交 2026-01-07）。
- 组件/可抄：多 agent handoff、实时工具调用事件处理模式（演示性质）。
- 集成坑：样例代码，非生产框架；绑定 OpenAI Realtime。

### 5.5 Ultravox
**Ultravox** ｜ [fixie-ai/ultravox](https://github.com/fixie-ai/ultravox) ｜ ★4,578（页面核实）
- 定位：speech-native 多模态 LLM（语音直接进模型）。
- 许可：MIT（代码）；⚠️ **模型权重许可各版本不同，部署前逐模型核实**（未逐一核实）。
- 技术栈：Python（+GPU 推理）；活跃度：低（2025-12-12 后无提交）。
- 组件/可抄：语音直入 LLM 的建模/推理参考，可自托管（需 GPU）。
- 集成坑：更新放缓；权重许可不一；中文支持有限。

---

## 6. 调度与持久执行

### 6.1 Temporal
**Temporal** ｜ [temporalio/temporal](https://github.com/temporalio/temporal) ｜ ★23,707（页面核实）
- 定位：durable execution 引擎（工作流即代码，服务端持久化）。
- 许可：MIT；技术栈：Go（server）+ 多语言 SDK（Python/TS/Go/Java 等）；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**长任务/定时任务的最强底座**：workflow/activity 分离、自动重试、durable timer（长睡眠不占进程）、signal/query（外部审批注入）、cron workflow、版本化。把"agent 回合"建模为 workflow + activity 是教科书解法。
- 集成坑：组件多（server + Postgres/Cassandra + UI）、概念门槛高；workflow 确定性约束（副作用必须放 activity）；Python SDK 异步优先。

### 6.2 Windmill
**Windmill** ｜ [windmill-labs/windmill](https://github.com/windmill-labs/windmill) ｜ ★18,185（页面核实）
- 定位：开发者平台（脚本 → Flows → cron → Web UI 一体化）。
- 许可：⚠️ **Fair-code 组合**（LICENSE 原文）：backend/frontend 除 "enterprise" flag 代码外为 AGPLv3；SDK/OpenAPI 为 Apache-2.0；官方发行版（ghcr 镜像/GitHub Release）**含专有代码**：免费使用但有配额限制，禁止转售/托管服务/封装。
- 技术栈：Rust + TypeScript；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：脚本→流程→调度的 UI 化体验、worker 拉取队列模型、多语言 worker。
- 集成坑：许可边界（白标/商用/托管注意 AGPL 与专有条款）；定位偏数据运维，agent 集成自建。

### 6.3 Inngest
**Inngest** ｜ [inngest/inngest](https://github.com/inngest/inngest) ｜ ★5,942（页面核实）
- 定位：事件驱动 durable workflow / step functions（TS 生态最友好之一）。
- 许可：⚠️ **SSPL v1.0**（LICENSE 原文 "Server Side Public License"）+ 声明未来转 Apache-2.0。SSPL 非 OSI 开源；**若把其自托管版作为对外服务提供，SSPL 要求开源整个服务栈** —— 产品化慎用。
- 技术栈：Go/TypeScript；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：事件触发 + step 编排、fan-out、sleep/延迟步骤、本地 dev server 体验。
- 集成坑：SSPL 风险（自用/内部无碍）；Python SDK 弱于 TS；自托管运维。

### 6.4 Restate
**Restate** ｜ [restatedev/restate](https://github.com/restatedev/restate) ｜ ★4,559（页面核实）
- 定位：轻量 durable execution 平台（单二进制；journal 恢复；virtual object/工作流即代码）。
- 许可：⚠️ **BSL 1.1**（原文）：Additional Use Grant —— 允许自用（含生产部署自用），**禁止把 Restate 本体作为公共托管平台服务**（供第三方注册/调用其服务）对外售卖；Change License: Apache-2.0（未来生效）。
- 技术栈：Rust；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**virtual object（按用户隔离的持久状态机）+ workflow 代码化 + 单二进制部署** —— 与"每用户助理会话/长任务状态"高度契合，是自研系统调度层的重点备选（轻于 Temporal）。
- 集成坑：BSL 非开源（自用免费）；生态年轻、资料少；团队规模小，需评估长期支持。

### 6.5 DBOS
**DBOS** ｜ [dbos-inc/dbos-transact-py](https://github.com/dbos-inc/dbos-transact-py) ｜ ★1,629（页面核实）
- 定位：数据库支撑的 durable workflows（存储 = Postgres）。
- 许可：MIT；技术栈：Python/TypeScript；活跃度：高（2026-10-13）。
- 组件/可抄：**装饰器式 durable workflow、Postgres 即工作流状态存储**（零新增基础设施）——已有 Postgres 的极简派首选。
- 集成坑：年轻；性能/规模上限未经大规模验证；强依赖 Postgres。

### 6.6 APScheduler
**APScheduler** ｜ [agronholm/apscheduler](https://github.com/agronholm/apscheduler) ｜ ★7,655（页面核实）
- 定位：Python 进程内任务调度（cron/interval/date 触发器）。
- 许可：MIT；技术栈：Python；活跃度：中-高（2026-10-12）。
- 组件/可抄：trigger/jobstore/executor 三段模型；持久化 jobstore 后可重启恢复——个人系统 v1 的 cron 首选。
- 集成坑：进程内调度（多实例/分布式不适用）；3.x→4.x 演进期 API 变动；时区配置坑。

### 6.7 Celery
**Celery** ｜ [celery/celery](https://github.com/celery/celery) ｜ ★28,981（页面核实）
- 定位：分布式任务队列（broker/worker 模式）。
- 许可：BSD-3-Clause（仓库 LICENSE 为 BSD 文本）；技术栈：Python；活跃度：中-高（2026-10-14）。
- 组件/可抄：成熟的重试/路由/beat 调度；适合短副作用任务（发通知、抓取、批处理）。
- 集成坑：**at-least-once 语义**（需幂等）；长任务中断恢复弱；**不建议裸跑 agent 长任务**（无持久状态 → 重复执行/丢失）；需维护 broker。

---

## 7. 通知推送

### 7.1 ntfy
**ntfy** ｜ [binwiederhier/ntfy](https://github.com/binwiederhier/ntfy) ｜ ★34,819（API 核实）
- 定位：自托管推送通知服务（HTTP publish/subscribe，Android/iOS/Web 客户端）。
- 许可：Apache-2.0；技术栈：Go（server）；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**把「agent 需要你确认 / 任务完成」推到手机**的最简方案：curl 即可发推送，支持附件、Action 按钮（回连你的网关做审批）、访问令牌。
- 集成坑：iOS 自托管推送需经 ntfy.sh 中继（APNs 限制），纯离线自托管 iOS 受限；主题默认公开，必须用 token/ACL 保护。

### 7.2 Apprise
**Apprise** ｜ [caronc/apprise](https://github.com/caronc/apprise) ｜ ★17,587（页面核实）
- 定位：一个库/CLI 覆盖 100+ 通知服务（TG/Slack/邮件/Discord/Webhook……）。
- 许可：BSD-2-Clause（原文确认，非 MIT）；技术栈：Python；活跃度：极活跃（2026-10-14 当日）。
- 组件/可抄：**通知兜底标准件**——统一 URL 语法（`tgram://`、`mailto://`、`json://`…）做多路告警/降级链。
- 集成坑：各服务限流与格式差异需处理；凭据管理自建。

---

## 8. 『多通道接入 + 调度』推荐组合（交付重点）

### 8.1 需求拆解
- 多端：QQ / TG / Discord / CLI / Web（+可选 Slack / WhatsApp / Signal）
- 消息：去重、路由、可靠投递
- 调度：cron 定时 + 持久工作流（长任务跨重启/断线恢复）
- 语音：可选（锦上添花，不建议一期做）

### 8.2 推荐组合（总表）

| 层 | 首选 | 备选 / 替换 |
|---|---|---|
| **QQ** | NapCat（OneBot 11 WS，⚠️仅自用/需授权商用） | Lagrange.Core、LuckyLilliaBot（注意各自许可）；应用层可叠 NoneBot2 |
| **Telegram** | python-telegram-bot | aiogram |
| **Discord** | discord.py | 官方 interactions webhook（仅斜杠命令场景） |
| **Slack（可选）** | Slack Bolt（Python/JS） | — |
| **WhatsApp（可选）** | Baileys | wppconnect / 官方 Cloud API |
| **Signal（可选）** | signal-cli（daemon 模式） | mautrix（若走 Matrix 路线） |
| **CLI** | 自研 REPL（抄 opencode 的 TUI↔server 分层） | 直接复用 opencode |
| **Web** | Open WebUI（≤50 人自用；白标需授权） | LibreChat（MIT）或 assistant-ui + Vercel AI SDK 自研（产品级） |
| **调度（v1）** | APScheduler + 任务表（Postgres/SQLite） | Celery（仅短任务） |
| **调度（持久）** | Restate（轻）或 DBOS（已有 PG 极简） | Temporal（重但最稳）；Windmill（要 UI）；Inngest（TS 生态，⚠️SSPL） |
| **语音（可选）** | pipecat | LiveKit Agents（需 WebRTC/电话时） |
| **通知** | ntfy（手机推送）+ Apprise（多路兜底） | — |
| **整体参考实现** | LangBot / AstrBot（架构对照） | Leon（经典技能结构）、Chatwoot（人工兜底模型） |

### 8.3 考察点一：通道抽象与鉴权模式

**统一事件模型（网关内唯一事实）**
```
INBOUND  { channel, instance_id, chat{id,type,thread_id}, sender{id,name},
           msg{platform_msg_id, ts, text, attachments[], raw}, received_at }
OUTBOUND { channel, chat, reply_to, content(text|media), idempotency_key }
```
- **每通道一个 adapter**：只做协议翻译 + 连接管理（重连/心跳/限流/分片/格式转换），不含业务逻辑。NapCat/OneBot、PTB、discord.py、Bolt、signal-cli daemon 各自封装成 adapter，网关其余部分对通道无感知 → 协议端可插拔（吸取 go-cqhttp 死亡教训）。
- **鉴权隔离**：平台凭证（bot token / WS token / QR 会话）统一进 secrets（env/keyring），不进代码库；Webhook 入口必须验签（TG `secret_token`、Slack signing secret、Discord Ed25519 interactions）；QQ 的 OneBot WS 只绑 127.0.0.1/内网 + token，NapCat WebUI 严禁公网暴露。
- **用户 ACL**：owner 白名单 + 配对码（pairing）制绑定；`identity` 映射表把 (channel, platform_user) 归一为内部统一用户，跨端共享会话与记忆。
- **高风险通道**（QQ 注入、WA/微信非官方）默认只接小号、仅私聊/白名单群、限频。

### 8.4 考察点二：消息可靠性（去重 / 重试 / 有序）

- **去重（防重复触发 agent）**：入库 `seen_messages(platform, instance, platform_msg_id)` 唯一约束 + TTL（≥7 天）；在"入队前"执行；同时处理 edit/recall 事件（更新而非新触发）。各平台重投递源：TG 更新重试、Discord gateway resume、OneBot 重复事件。
- **幂等（副作用护栏）**：每次 agent 触发生成 `turn_id`（=去重键）；所有副作用（发消息、写状态、调工具）以 turn_id 幂等键执行，重试安全。
- **有序（防上下文交错）**：以 `channel+chat(+thread)` 为 session key，**每会话串行队列（并发 1）**，跨会话可并发；同一会话的多条消息排队进入 agent，避免历史交错。
- **Outbox 模式（防丢回复）**：回复先落 `outbox` 表 → 异步 sender 发送 → 成功回执落库；失败指数退避 + 抖动重试；超限进死信表并触发告警（ntfy）。启动时扫 outbox 补发。
- **平台细节**：TG 429 `retry_after` 实测遵守；Discord 限流桶按路由；QQ 消息分片（不同平台长度上限）；每 chat 独立限速器。
- **语义定档**：端到端为"**至少一次投递 + 幂等消费**"（"恰好一次"在分布式下不现实）；所有动作留审计日志（与 06 章节呼应）。

### 8.5 考察点三：调度器与 Agent 长任务融合

**模式 A（v1，轻量）**：APScheduler（cron）+ 任务表
`cron 触发 → 生成 run（idempotency_key = task_id + scheduled_slot）→ 串行执行器跑 agent 回合 → 结果写 outbox`
- 要点：run 落库（状态机 pending/running/done/failed）、重启时恢复"未完成"任务、同一 slot 幂等。

**模式 B（v2，持久工作流，推荐）**：把"agent 回合"建模为 workflow
- LLM/工具调用 = step/activity（独立重试、超时控制）
- 等用户确认 = signal（配合 ntfy Action 按钮 / 聊天回执）
- 定时/延期 = **durable timer**（不占进程，跨重启存活，替代"sleep 等到明天再问"）
- 长驻状态 = 每会话一个 workflow / Restate virtual object（按用户隔离的持久状态机）
- 选型：**Restate（单二进制、轻、virtual object 契合度最高）**；已有 Postgres 走 **DBOS**；规模上来或要强治理走 **Temporal**。
- 反模式：Celery 裸跑长 LLM 任务（无持久状态 + at-least-once → 重复执行/丢进度）；cron 直接群发不设幂等键。

**模式 C（可选）**：Windmill（脚本+UI+cron，运维型任务可视化）/ Inngest（TS 事件流，⚠️SSPL）。

**融合接口（一条线）**：
`Scheduler → workflow.start(session_key, task_type, payload, idem_key) → agent runtime（工具=activity）→ outbox → channel adapter`——调度层与消息层通过 outbox 表解耦，互不感知对方实现。

### 8.6 分阶段路线
- **v1（个人系统，1-2 周）**：网关（Python asyncio）+ QQ（OneBot WS 直连）+ TG 适配 + SQLite（dedup/outbox/任务表）+ APScheduler + CLI。
- **v2（多端+可靠）**：接入 Discord（+可选 Slack）；会话串行/ACL/身份归一；调度迁移 Restate 或 DBOS；ntfy 通知；Web 先用 Open WebUI 反向接自研后端（≤50 人自用合规）。
- **v3（产品化）**：Web 自研（assistant-ui + Vercel AI SDK，避开品牌条款）或 LibreChat；语音接入 pipecat；监控/审计/配额（配合 04/06 章节）。

### 8.7 替换关系速查
- NapCat 许可不可接受 → Lagrange.Core / LuckyLilliaBot（确认许可后）或暂缓 QQ 协议端
- Open WebUI 白标/商用 → LibreChat 或自研前端
- Temporal 太重 → Restate（首选轻量替代）/ DBOS
- 已有 Postgres → DBOS / Windmill
- TS 全栈团队 → Vercel AI SDK / CopilotKit / Inngest（注意 SSPL）
- 只需服务器端语音管线 → pipecat；要 WebRTC 通话/电话 → LiveKit Agents
- Matrix 总线路线 → mautrix 家族整体替换直连方案

---

## 附录 A：不推荐依赖清单
| 项目 | 原因 |
|---|---|
| go-cqhttp | 停更（2024-05），协议被封 |
| Vocode | 停更（2024-11 后无提交） |
| wechaty（核心） | 半停更（2025-12 后无提交）+ 付费第三方 Token 生态 + 微信合规风险 |
| opencode-ai/opencode | 已归档（用 anomalyco/opencode） |
| NapCat 用于商用/再分发 | 自定义许可禁止商用/限制分发（自用可） |
| aider / Ultravox / Continue / Chainlit | 可作参考，但上线依赖前需评估维护节奏与治理风险 |

## 附录 B：核实与未核实项（2026-10-14）
- **API 交叉核实（5/6 次额度）**：open-webui 155,699 · wechaty 23,366 · AstrBot 41,881 · LangBot 18,164 · ntfy 34,819。
- **页面抓取核实**：其余全部条目（见各条目标注）。
- **约值（页面抓取，未 API 交叉）**：Lagrange.Core ★约2,991、LuckyLilliaBot ★约3,665、aiogram ★约5,892、bolt-js ★约2,948。
- **未核实**：Ultravox 各模型权重许可（逐模型核对前勿商用）；LobeHub Community License 附加条款细则（采用前读全文）；Lagrange.Core 未见标准 LICENSE 文件。
- **方法备注**：星数为当日快照；活跃度对"最后提交时间"敏感，选型前建议再复查一次。

# 02 · 记忆系统与知识库 / RAG 集群（开源原材料调研）

> **范围**：长期记忆层、RAG/知识引擎、向量/图谱/检索存储。服务于「自研个人/产品级 AI Agent 系统」的选型与"抄作业"。
> **边界**：本文件不涉及 agent 框架/编排（01）、工具与沙箱（03）、模型/可观测（04）、交互/调度（05）、安全/基建（06）。
> **核实时间**：2026-10-14 UTC（10-15 澳东）。**数据口径**：star 为 GitHub 仓库页精确值（与 API 抽查一致），最后提交来自 `commits.atom`，发版来自 `releases.atom`；许可证读自仓库 LICENSE 原文；个别第三方信息已标注来源。详见附录 C。
> **图例**：🔒 = 许可证有限制性条款；📉 = 停更/归档；✅ = 已核实；🟡 = 未完全核实。

---

## 0. 结论速览（TL;DR）

- **记忆层首选（图 + 本地 + 低耦合）**：**Graphiti**（Apache-2.0，自带 MCP server，双时序知识图谱，Zep 的开源引擎）＋ **Neo4j CE**（GPL-3.0）或 **FalkorDB**（SSPL-1.0，注意条款）作图后端。
- **最值得"抄"上下文工程**：**Letta / letta-code**（可自编辑 memory blocks、git 化记忆仓库 MemFS、`/sleeptime` 空闲期整理）——但它是完整 harness，整机接入 = 高耦合，抄设计 > 用产品。
- **知识库**：轻量本地选 **LightRAG**（MIT，双级检索＋存储可插拔，全本地可跑）；文档解析、引用溯源、MCP 双向能力抄 **RAGFlow**（Apache-2.0，92k★，但基础设施重）。
- **存储三件套**：向量 **Qdrant / pgvector / LanceDB** 三选一；图 **Neo4j CE / FalkorDB**；全文/混合 **Meilisearch**（注意 EE 部分 BUSL）或 Postgres FTS。
- **明确排除/别踩**：Kuzu（📉已归档）、R2R（📉公司转型后停更）、memary / memobase / A-mem（停更或研究代码）、**Mem0 的 OSS 图记忆与本地 MCP 路径（2026 已被移除，勿按旧教程部署）**。
- **三个最大的长期坑**：① LLM 抽取是持续性成本（每条新信息都要过模型）；② 图库（Neo4j/FalkorDB）运维与许可；③ 「OSS 与云版功能剪刀差」——Mem0、Letta、Zep、Supermemory 都在把图记忆/托管能力往商业版迁移。

---

## 1. 记忆层（Memory）

### 1.1 Graphiti ⭐31.8k 【首选：图记忆引擎】
- **链接｜定位**：https://github.com/getzep/graphiti ｜ "Build Real-Time Knowledge Graphs for AI Agents"。Zep 背后的开源时序知识图谱引擎，专为 agent 记忆设计。
- **数据**：⭐31,754（10-14 核实）｜fork 3,267｜Apache-2.0｜Python｜最后提交 **2026-10-14（当日）**，最后发版 2026-09-08（持续高频）。
- **机制**：**写入**=把对话/文档作为 episode 增量摄入，LLM 抽取实体与关系边；**召回**=语义搜索＋BM25＋图遍历混合（含重排）；**更新**=新边令旧边 `invalid_at` 失效；**遗忘**=双时序失效（不物理删除）：每条边带 `valid_at / invalid_at`，可回答"当时是什么"。
- **可当组件/可抄**：官方仓库自带 **MCP server**（`mcp_server/` 目录）+ REST（需自建服务层）；抄：双时序"失效式遗忘"、episode 化增量摄入、混合检索配置（semantic + BM25 + graph）。
- **集成坑**：每个 episode 都要 LLM 抽取（用本地小模型可降本）；图后端运维；**Kuzu 后端已弃用（0.11.2 deprecated）**，官方支持 Neo4j 5.26 / FalkorDB 1.1.2 / Amazon Neptune（＋OpenSearch Serverless 作全文检索）；图库许可见 3.x 节。

### 1.2 Mem0 ⭐67.2k 【可选：抄"抽取-判定"管线；OSS 图记忆已砍】
- **链接｜定位**：https://github.com/mem0ai/mem0 ｜ "The Memory Layer for AI Agents"，事实抽取式记忆的标杆与流量最大的记忆项目。
- **数据**：⭐67,195（10-14 核实）｜fork 7,909｜Apache-2.0｜Python + TypeScript｜最后提交 **2026-10-14（当日）**，最后发版 2026-09-25。
- **机制**：**写入**=LLM 从消息中抽取事实，再与已有记忆比对做 ADD/UPDATE/DELETE/NOOP 决策；**召回**=向量检索＋元数据过滤；**遗忘**=判定为 DELETE 或不再召回。
- **⚠️ 关键变化（2026）**：① 2026-04「New Memory Algorithm」后，**图记忆（Neo4j/Memgraph/Kuzu/AGE/Neptune 驱动，约 4k 行代码）已从 OSS SDK 移除**——图记忆成为 Mem0 Platform（云）专属功能（官方迁移文档 oss-v2-to-v3 明示）；② 本地 MCP 栈 OpenMemory 据第三方梳理已在 2026-07 从 monorepo 删除、独立 `mem0-mcp` 仓库 2026-03 归档，`mem0ai/openmemory` 同名仓库已转为其它产品（98★）；③ 官方 MCP 入口现为**托管云服务**。
- **可当组件/可抄**：OSS 库（`pip install mem0ai`）+ 自托管 Server（monorepo `server/`，`make bootstrap` 起栈，默认开鉴权）；抄：抽取-判定的 prompt 设计、记忆排序/去重策略、LOCOMO 评测方法。
- **集成坑**：想本地 MCP 低耦合接入 → 官方路径已不提供（需自行封装 SDK）；图关系需自带图库（官方 Workaround：Mem0 + Neo4j 自行桥接）；云端功能与 OSS 剪刀差持续扩大。

### 1.3 Zep（名称澄清）⭐5.0k
- **链接**：https://github.com/getzep/zep
- **现状**：该仓库**已不是产品仓库**——README 原文："This repository is **not** Zep's product or service. It contains example code, framework integrations, and tools"（示例/集成集合，⭐4,959，10-14 仍在更新）。Zep 社区版服务器已退役；**开源侧看 Graphiti**，产品侧是 Zep Cloud（商业，自家"Context Graph Engine"专有图库，无需第三方图数据库）。
- **结论**：选型时不要对 `getzep/zep` 抱期待；开源即 Graphiti，托管即 Zep Cloud。

### 1.4 Cognee ⭐32.3k 【可选：pipeline 化记忆平台】
- **链接｜定位**：https://github.com/topoteretes/cognee ｜ "open-source AI memory platform for agents"，主打 ECL（extract→cognify→load）记忆管线 + 图/向量混合。
- **数据**：⭐32,293（10-14 核实）｜fork 3,365｜Apache-2.0｜Python｜最后提交 **2026-10-14（当日）**，发版 2026-10-13。
- **机制**：写入=管线化抽取与"认知化"（建图+建索引）；召回=图+向量检索；更新=重跑管线/追加数据集。
- **可当组件/可抄**：官方 **MCP server（cognee-mcp/）** ✅；集成多个框架；自述支持"小模型免费本地化"（用本地小模型跑记忆管线，看重成本者可抄这条路线）；抄：管线化记忆构建、ontology/数据集概念。
- **集成坑**：项目迭代快、API 变动频繁；体量与生态位与 Graphiti 有重叠，二选一即可。

### 1.5 Letta / letta-code ⭐25.1k（旧仓）/ 3.6k（新仓）【抄上下文工程，不整机接】
- **链接**：https://github.com/letta-ai/letta（MemGPT 正统仓库，现为历史/指引）｜活跃开发：https://github.com/letta-ai/letta-code
- **现状（重要）**：旧仓 README 明示"current source code lives in `letta-ai/letta-code`"，旧 V1 API server 已移入 `archive` 分支退役；旧仓最后提交 2026-09-10（docs 类）、最近发版 2026-05，事实上转入维护状态。
- **新形态**：letta-code（⭐3,612，Apache-2.0，最后提交 10-14，npm `@letta-ai/letta-code`）= "memory-first" agent harness：**memory blocks**（自我改写上下文/系统提示词学习）、**MemFS**（所有上下文含记忆块用 **git 版本化**，可同步 GitHub 仓库）、`/sleeptime`（空闲"做梦"整理）、跨会话/跨 agent 消息搜索、skills、subagents、channels（Telegram/Slack/Discord）、hooks、crons、BYO 模型。研究线：Sleep-time Compute（2025-04）、Context Constitution（2026-04）、Memory Models（2026-06）。
- **可当组件/可抄**：上下文工程最佳范本：① 自编辑记忆块 + token 预算；② 记忆的 git 化（可审计、可回滚、可迁移）；③ 空闲期整合（sleep-time）；④ "记忆不是插件，是 harness 职责"的设计立场（其官方 blog 观点）。
- **集成坑**：它是 harness/运行时，整机接入=替换你的主循环（高耦合）；无独立"记忆库"包可用；作为服务（App Server/SDK）接入需接受其体系。

### 1.6 MemOS ⭐11.9k 【可选：OS 式记忆调度】
- **链接｜定位**：https://github.com/MemTensor/MemOS ｜ "Self-evolving memory OS"，MemCube 记忆单元 + 调度（记忆编排/混合检索/跨任务技能复用；自述 token 节省 35%+）。
- **数据**：⭐11,863（10-14 核实）｜Apache-2.0｜Python｜最后提交 2026-09-22，发版 2026-09-23。
- **可当组件/可抄**：**官方 MCP 服务** ✅（`@memtensor/memos-api-mcp`，npm，支持托管/自部署两种）；本地 Server API（`src/memos/api/server_api.py`，默认 8001 端口）；抄：MemCube 抽象、记忆调度思想。
- **集成坑**：生态画布很大（插件/平台双线），版本迭代快；MCP 包默认连官方 API，纯本地要自行部署 Server API。

### 1.7 Supermemory ⭐31.2k 【可选：本地优先的"记忆+上下文引擎"】
- **链接｜定位**：https://github.com/supermemoryai/supermemory ｜ "Memory and context engine + app"，自述"extremely fast, scalable, and can be run fully locally"。
- **数据**：⭐31,228（10-14 核实）｜MIT｜TypeScript｜最后提交 **2026-10-14（当日）**，发版 2026-10-12（活跃度极高）。
- **可当组件/可抄**：MCP server + 各家编码 agent 插件（Claude Code/Codex/Cursor/OpenCode 等）✅；面向"给任何 assistant 加持久记忆"的产品化路径；抄：插件化分发、profile 与遗忘/管理 API 设计。
- **集成坑**：默认形态偏托管（第三方梳理指其云基于 CF Workers，自托管为可选路径 🟡细节需查文档）；MIT 友好。

### 1.8 Basic Memory ⭐4.2k 【轻量首选：Markdown 派】🔒
- **链接｜定位**：https://github.com/basicmachines-co/basic-memory ｜ 本地 Markdown 文件为"真源"＋SQLite 索引＋MCP 服务，人机双写知识图谱。
- **数据**：⭐4,190（10-14 核实）｜**AGPL-3.0 🔒（强 copyleft，商用/闭源分发需评估）**｜Python｜最后提交 **2026-10-14（当日）**。
- **可当组件/可抄**：**MCP 原生**（38 处 MCP 引用，注册于 MCP Registry）✅；抄："Markdown 文件=记忆真源、DB 只是索引"的架构（可迁移、可人工编辑、与 Obsidian 生态天然兼容）、实体-观测-关系组织。
- **集成坑**：AGPL；能力上限在"人工可读记忆"，非海量自动化抽取。

### 1.9 Redis Agent Memory Server ⭐0.3k 【可选：服务化记忆】
- **链接**：https://github.com/redis/agent-memory-server ｜ Redis 官方出品的"工作记忆（短期）+长期记忆"服务，REST 接口。
- **数据**：⭐322（10-14 核实）｜**Apache-2.0**（LICENSE 原文核实：Copyright 2025 Redis，Apache-2.0）｜Python｜最后提交 2026-09-15。
- **可当组件/可抄**：后台记忆服务形态（低耦合）；抄：把记忆做成独立微服务 + Redis 存储的工程法。🟡 MCP 支持未核实。
- **集成坑**：项目小、需要 Redis 依赖；生态影响力有限。

### 1.10 LangMem ⭐1.7k 【参考：抄 API 设计】
- **链接｜定位**：https://github.com/langchain-ai/langmem ｜ LangChain 官方记忆 SDK：语义/情节/程序性三类记忆 + 提示词优化（procedural）。
- **数据**：⭐1,703（10-14 核实）｜MIT｜Python｜最后提交 2026-10-02。
- **可当组件/可抄**：抄其"记忆类型学"（semantic/episodic/procedural）和后台记忆管理器设计——对自研系统的记忆分类很有参考价值。
- **集成坑**：与 LangGraph 的 Store/长期记忆 API 绑定较深，脱离 LangGraph 需自行移植；项目体量小（是 SDK 非平台）。

### 1.11 其他记忆候选（简评）
- **MemoryOS（BAI-LAB）** ⭐1.6k：https://github.com/BAI-LAB/MemoryOS ｜EMNLP 2025 Oral，短/中/长期三层记忆与热度更新，Apache-2.0，最后提交 2026-07-07（研究代码，参考算法）。
- **HippoRAG（OSU-NLP）** ⭐4.1k：https://github.com/OSU-NLP-Group/HippoRAG ｜NeurIPS'24 + **HippoRAG 2（ICML'25）**，"RAG to Memory"，个性化 PageRank 多跳召回，MIT，最后提交 2026-10-06（活跃研究项目，抄检索算法；见 §2.8）。
- **engram 系列**：名称有多个同名项目（含一个非常活跃的 Go 实现），见附录 B 专述。

---

## 2. 知识 / RAG 层

### 2.1 RAGFlow ⭐92.2k 【首选：重装全功能；抄解析与引用】
- **链接｜定位**：https://github.com/infiniflow/ragflow ｜ 深度文档理解 RAG 引擎，"RAG + Agent"一体化上下文层。
- **数据**：⭐**92,231**（10-14 核实）｜fork 10,986｜Apache-2.0｜**Python + Go（API/MCP 服务已由 Go 实现；GitHub 主语言标注为 Go）**｜最后提交 **2026-10-14（当日）**，发版通道活跃（含 nightly 通道，当日有更新）。
- **能力**：DeepDoc 解析（OCR/版面/表格）、模板化切块、GraphRAG、引用溯源、Agent 工作流与 MCP **双向**支持（既可当 MCP server 暴露检索工具，也可作为 MCP client 连接外部工具）✅。
- **可当组件/可抄**：私有知识库的现成完整产品；抄：文档解析管线、切块模板、引用锚定、"Go API server + MCP endpoint（streamable-HTTP `/mcp`）"的工程化方式。
- **集成坑**：基础设施重——默认栈 = Elasticsearch（或 Infinity）＋MySQL＋Redis＋MinIO，docker compose 全套（经验量级 4-8GB+ 内存，换 Infinity 降低）；UI/产品导向，二次开发成本高于库级方案。

### 2.2 LightRAG ⭐40.1k 【首选：轻量图 RAG；全本地可跑】
- **链接｜定位**：https://github.com/HKUDS/LightRAG ｜（EMNLP 2025）"Simple and Fast Retrieval-Augmented Generation"，轻量图 RAG 的代表。
- **数据**：⭐40,136（10-14 核实）｜fork 5,697｜MIT｜Python｜最后提交 **2026-10-14（当日）**，发版 2026-09-02。
- **能力**：local/global 双级检索、增量插入、**存储可插拔**（图：NetworkX/Neo4j 等；向量：多后端/文件 KV）、官方 Server（WebUI 管理台 `/webui` + 只读移动端 `/workspace`）、Ollama 本地模型支持。
- **可当组件/可抄**：**整架构都可抄**——"实体/关系抽取 → 图 + 向量双写 → 双级检索"是最适合自研系统内嵌的图 RAG 范式；零外部依赖模式（文件存储）适合单机。
- **集成坑**：**未见官方内置 MCP server**（仓库中无 mcp 目录，README 未提；社区有 npm/PyPI 第三方适配器）；图质量依赖抽取用 LLM 的能力；官方 REST API 可自行接主循环。

### 2.3 Microsoft GraphRAG ⭐36.3k 【可选：方法论源头】
- **链接**：https://github.com/microsoft/graphrag ｜ MIT｜Python｜⭐36,338，最后提交 2026-10-08。
- **能力**：社区检测 + 分层摘要（global search）、local search；索引期成本高（大量 LLM 调用），后续 LazyGraphRAG 大幅降本。
- **可当组件/可抄**：抄"社区摘要层级"设计（回答全局性问题）；生产内嵌成本高，一般借鉴思路而非直接用。
- **集成坑**：索引贵、pipeline（parquet 等）工程复杂度高、本地模型上跑得慢。

### 2.4 LlamaIndex ⭐52.5k 【框架-可选】
- **链接**：https://github.com/run-llama/llama_index ｜ MIT｜Python/TS｜⭐52,500，最后提交 10-14（当日）。
- **现状**：自我定位已转向 "document processing platform for AI"（LlamaCloud 商业服务）。
- **可当组件/可抄**：摄取管线（Ingestion Pipeline）、属性图索引、记忆/聊天存储抽象——抄接口设计与管线思想；不一定要用框架。
- **集成坑**：框架税、历史 API 变动多；与自研主循环是"二选一"级的关系（若只是要 RAG 零件，LightRAG/RAGFlow 更直接）。

### 2.5 Haystack ⭐26.7k 【框架-可选】
- **链接**：https://github.com/deepset-ai/haystack ｜ Apache-2.0｜Python｜⭐26,741，最后提交 10-14（当日）。
- **定位**：deepset 的生产级"context-engineered"管线框架（组件化 DAG）。
- **可当组件/可抄**：组件契约、评测体系；比 LlamaIndex 更偏"检索系统工厂"。
- **集成坑**：agent 侧能力薄（本集群无关）；生态增长趋缓。

### 2.6 txtai ⭐13.0k 【可选：嵌入式全家桶】
- **链接**：https://github.com/neuml/txtai ｜ Apache-2.0｜Python｜⭐13,019，最后提交 10-14（当日）。
- **定位**：all-in-one 嵌入检索框架（embeddings DB + LLM 编排 + workflows）。
- **适合**：想用纯 Python 快速搭本地语义检索、又不想引入独立服务；抄其"索引+管线一体"的 API 简洁性。
- **坑**：单机路线，非分布式；自带生态与主流割裂。

### 2.7 Khoj ⭐37.7k 【可选：自托管个人 AI 应用】🔒
- **链接**：https://github.com/khoj-ai/khoj ｜ **AGPL-3.0 🔒**｜Python(Django)+TS｜⭐37,686，最后提交 2026-08-02（近 2.5 个月无提交 ⚠️）。
- **定位**：可自托管的"第二大脑"应用（语义检索个人笔记/文档/网页、自动研究、定时任务）。
- **可当组件/可抄**：个人数据连接器（Obsidian/Notion/PDF 等）与"搜索+对话"产品形态；**应用而非库**，抄能力不如抄连接器矩阵。
- **坑**：AGPL；近期放缓。

### 2.8 HippoRAG 2 ⭐4.1k 【参考：检索算法】
- **链接**：https://github.com/OSU-NLP-Group/HippoRAG ｜ MIT｜Python｜⭐4,062，最后提交 2026-10-06。
- **定位**：类海马体长时记忆框架（NeurIPS'24 HippoRAG → ICML'25 HippoRAG 2），**个性化 PageRank（PPR）** 做多跳检索；官方称离线索引成本显著低于 GraphRAG/LightRAG。
- **可抄**：PPR 召回算法、"RAG→显式记忆"的评估维度（关联性/情节/事实）。
- **坑**：研究代码质量，生产化需重写。

### 2.9 R2R ⭐8.0k 【📉 排除：停更】
- **链接**：https://github.com/SciPhi-AI/R2R ｜ MIT｜Python｜⭐8,019，**最后提交 2025-11-07（已停更约 11 个月）**。
- **背景**：原公司 SciPhi 已转型（YC 资料显示其沿革指向 Event Horizon Labs），云服务关闭，仓库仅存代码。
- **参考价值**：REST 化 RAG 引擎的 API 设计（collections/documents/hybrid search）；**新项目勿采用**。

### 2.10 nano-graphrag ⭐4.0k 【参考：最小实现】
- **链接**：https://github.com/gusye1234/nano-graphrag ｜ MIT｜Python｜⭐4,001，最后提交 2026-01-27（半停更）。
- **价值**：约千行级的最简 GraphRAG 实现，**想把图 RAG 内嵌进自研系统时，直接以它为底改写是最低成本路线**。
- **坑**：半停更、功能面窄。

---

## 3. 向量 / 图谱 / 检索存储

### 3.1 Qdrant ⭐35.1k 【首选向量库（独立部署）】
- **链接**：https://github.com/qdrant/qdrant ｜ Apache-2.0｜**Rust**｜⭐35,076，最后提交 2026-10-05（活跃）。
- **要点**：单二进制/docker 即可；payload 过滤、量化（scalar/binary）、稀疏向量混合检索；REST + gRPC；云版商业。
- **坑**：索引/量化参数需调；过滤字段设计影响性能。

### 3.2 pgvector ⭐23.4k 【首选向量（Postgres 派）】
- **链接**：https://github.com/pgvector/pgvector ｜ **PostgreSQL License**（LICENSE 原文核实，宽松）｜C｜⭐23,362，最后提交 2026-10-01（活跃）。
- **要点**：HNSW/IVFFlat；向量与业务数据同库同事务（一致性是最大优势）；配 Postgres 全文检索可做混合检索。
- **坑**：规模上限（百万~千万级经验值，视参数/内存）；HNSW 构建内存/时间；不适合独立超大规模向量服务。

### 3.3 LanceDB ⭐11.7k 【首选嵌入式向量库】
- **链接**：https://github.com/lancedb/lancedb ｜ Apache-2.0｜**Rust**（Python/TS/Rust SDK）｜⭐11,676，最后提交 10-14（当日）。
- **要点**："SQLite 之于向量"：嵌入式、Lance 列存、版本化/时间旅行、多模态数据友好、零运维。
- **坑**：生态较新，各语言绑定能力有差异；超大规模仍建议独立服务。

### 3.4 Milvus ⭐46.4k 【可选：规模化】
- **链接**：https://github.com/milvus-io/milvus ｜ Apache-2.0｜Go/C++｜⭐46,385，最后提交 10-14（当日）。
- **要点**：分布式向量库标杆；单机可用 standalone docker；有 milvus-lite（嵌入式子集）。
- **坑**：集群组件重（etcd/MinIO/消息队列），资源占用高；个人系统一般用不到。

### 3.5 Weaviate ⭐16.9k 【可选】🔒
- **链接**：https://github.com/weaviate/weaviate ｜ **许可为混合模式**：LICENSE 原文"Source code in this repository is variously licensed under the BSD-3-Clause License, or the Weaviate License"——**部分文件受 Weaviate License 限制 🔒**｜Go｜⭐16,883，最后提交 10-13。
- **要点**：模块系统、混合检索、多租户；企业向。
- **坑**：许可需逐项确认（非纯 BSD）。

### 3.6 Chroma ⭐29.5k 【可选：入门/原型】
- **链接**：https://github.com/chroma-core/chroma ｜ Apache-2.0｜Python/Rust（1.0 大版本核心转向 Rust）｜⭐29,501，最后提交 10-13。
- **要点**：嵌入式优先、上手最快；适合原型与轻量场景。
- **坑**：经历 1.0 重写，历史 API 变动大（升级/迁移注意）；大规模性能口碑一般。

### 3.7 Meilisearch ⭐59.6k 【可选：全文/混合检索】🔒
- **链接**：https://github.com/meilisearch/meilisearch ｜ **`SPDX: MIT AND BUSL-1.1`**——主体 MIT，**Enterprise Edition 部分为 BUSL-1.1 🔒（LICENSE 原文核实）**｜Rust｜⭐59,568，最后提交 10-14（当日）。
- **要点**：typo 容忍全文检索起家，近版本主推 AI/混合检索；极佳 DX。
- **坑**：EE 文件许可注意；向量能力较新，别当通用向量库用。

### 3.8 Typesense ⭐26.9k 【警示：GPL】🔒
- **链接**：https://github.com/typesense/typesense ｜ **GPL-3.0 🔒（衍生产品/分发需开源，商业闭源嵌入需评估）**｜C++｜⭐26,872，最后提交 10-13。
- **要点**：快、typo 容忍、易用，支持向量/混合检索（较新版本加入）。
- **坑**：GPL；内存占用偏高。

### 3.9 Kuzu ⭐4.0k 【📉 排除：已归档】
- **链接**：https://github.com/kuzudb/kuzu ｜ MIT｜C++｜⭐4,022｜**已归档（archived），最后提交 2025-10-10**。
- **README 原文**："Kuzu is working on something new! We are archiving the KuzuDB project here…"（0.11.3 为最后整合版；旧 release 仍可用）。
- **结论**：嵌入式图库的空白很可惜——**新项目不要选**；Graphiti 也已弃用其后端。替代：Neo4j CE / FalkorDB。（注：对自研系统而言"嵌入式 Cypher 图库"生态目前没有同量级替代品，值得关注其团队新项目。）

### 3.10 FalkorDB ⭐9.9k 【图库-可选（注意 SSPL）】🔒
- **链接**：https://github.com/FalkorDB/FalkorDB ｜ **SSPL-1.0（Server Side Public License）🔒**——非 OSI 认证；"将本软件作为服务提供给第三方"受限，自用/内部部署一般可行（合规需法务确认）｜C/Rust｜⭐9,909，最后提交 10-14（当日）。
- **要点**：基于 GraphBLAS 的高性能图库，Redis 兼容协议，Graphiti 支持的后端之一；定位知识图谱/LMM 场景。
- **坑**：SSPL。

### 3.11 Neo4j（社区版）⭐17.3k 【图库-可选】🔒
- **链接**：https://github.com/neo4j/neo4j ｜ **GPL-3.0（Community Edition）🔒**；企业版商业授权｜Java｜⭐17,318，最后提交 2026-09-14。
- **要点**：图数据库事实标准，Cypher、生态最全；Graphiti 的首选后端（5.26+）。
- **坑**：GPL 边界（作为独立服务自用一般无碍，嵌入分发需评估）；内存开销（经验量级 1-2GB+）；社区版与企业版功能差异。

### 3.12 全文/其他（简评）
- **OpenSearch** ⭐13.9k：Apache-2.0，ES 7.10 分叉，AWS 生态；最后提交 10-14。（https://github.com/opensearch-project/OpenSearch）
- **Elasticsearch** ⭐78.3k：**混合许可 🔒**（LICENSE.txt 原文核实：AGPLv3 / SSPL v1 / Elastic License 2.0 三重 + 部分 Apache-2.0 兼容）｜Java｜最后提交 10-14。RAGFlow 默认后端之一；许可复杂（商用注意）。
- **Infinity** ⭐4.7k：Apache-2.0，infiniflow 自家 AI-native 数据库（dense/sparse/tensor + 全文），RAGFlow 配套引擎；最后提交 10-13。（https://github.com/infiniflow/infinity）

---

## 4. 重点横评（五轴）

### 4.1 写入 / 召回机制对比（编·取·更新·遗忘）

| 系统 | 写入（编） | 召回（取） | 更新 | 遗忘 |
|---|---|---|---|---|
| **Graphiti** | episode 增量摄入 → LLM 抽实体/边 | 语义+BM25+图遍历混合重排 | 新边令旧边失效（双时序） | **失效而非删除**（可时间回溯） |
| **Mem0 (OSS)** | LLM 抽取事实 + ADD/UPDATE/DELETE/NOOP 判定 | 向量 + 元数据过滤 | 同上（判定驱动） | DELETE 判定（图记忆已移出 OSS） |
| **Letta Code** | agent 自我改写 memory blocks / MemFS（git 化） | 常驻记忆块 + 消息搜索 + recall 子代理 | 自编辑 | 改写/压缩（"做梦"整合） |
| **Cognee** | ECL 管线（抽取→认知化→载入） | 图+向量 | 重跑管线 | 数据集级删除 |
| **MemOS** | MemCube 创建 + 调度 | 混合检索 | MemCube 更新 | 调度策略（弱） |
| **Basic Memory** | 人/机写 Markdown 文件 | SQLite FTS + 语义 + 双向链接 | 直接改文件 | 删文件 |
| **HippoRAG 2** | 离线建 KG/索引（成本低） | **个性化 PageRank 多跳** | 重建索引 | 无显式遗忘 |
| **LangMem** | 工具/后台管理器写入 | Store 搜索 | manage 工具 | 删除工具 |
| **engram (Go)** | 会话摘要/观测写入 SQLite | FTS5 全文（+可选向量） | 更新观测 | 手工/主题淘汰 |

> 读法：**"遗忘"能力全行业默认最弱**。目前只有 Graphiti 把"更新/遗忘"做成第一等公民（双时序失效），这是自研系统最值得抄的机制。

### 4.2 图记忆 vs 向量记忆

- **向量记忆**（Mem0/Chroma/pgvector 派）：写入便宜（一次嵌入）、召回快；弱点：无关系、无多跳、无时序、"相似≠相关"。
- **图记忆**（Graphiti/LightRAG/HippoRAG 派）：有关系与多跳、可解释（边即证据）、可时序化管理；代价：**每次写入需 LLM 抽取**（持续性成本）、图库运维、抽取错误会污染。
- **行业信号（重要）**：Mem0 2026 把图记忆**从 OSS 移除收进商业云**——说明"图记忆"在商业上被视为高价值环节；开源侧接棒者是 **Graphiti**（Apache-2.0）与 **LightRAG**（MIT，图+向量一体且可全本地）。
- **自研建议**：**混合架构**——图存实体/关系/时序（Graphiti 或 LightRAG 范式），向量存模糊语义检索（Qdrant/pgvector/LanceDB），召回端做融合（RRF/重排）。不要二选一。

### 4.3 上下文工程（context engineering）能力对比

| 能力 | 最佳范本 | 说明 |
|---|---|---|
| 常驻记忆块 + token 预算 | **Letta** | 可自编辑 blocks、系统提示词学习 |
| 记忆的版本化/可审计 | **Letta MemFS（git 化）** | 记忆=文件树+git，可回滚可迁移 |
| 空闲期整合（sleep-time） | **Letta**（`/sleeptime`、dreaming） | 不在推理期烧 token 的整理 |
| 引用溯源/防幻觉 | **RAGFlow** | 答案锚定原文切片 |
| 检索结果预算控制 | LightRAG（双级）、Graphiti（重排） | 控制注入上下文规模 |
| 记忆类型学 | **LangMem**（semantic/episodic/procedural） | 分类写入不同存储 |
| 提示词自我优化 | LangMem（procedural） | 程序性记忆 |
| 全局问题（summary 型） | GraphRAG（社区摘要） | 成本换质量 |

> 自研系统"上下文工程"最小完备集：记忆块（预算制）＋按需召回（工具面）＋失效式遗忘（双时序）＋引用溯源（知识库答案）+ 定期整合任务。

### 4.4 与 Agno / Hermes 类系统的集成难度

| 组件 | 对外形态 | 接入方式 | 耦合度 |
|---|---|---|---|
| **Graphiti** | 库 + **官方 MCP server** | MCP 工具面 / 自建 REST | **低** ✅ |
| **Cognee** | 库 + **MCP（cognee-mcp）** | MCP / pip | 低 |
| **Basic Memory** | **MCP server（原生）** | MCP | 低 |
| **Supermemory** | **MCP server + 插件** | MCP | 低 |
| **MemOS** | **官方 MCP（npm）+ REST** | MCP / REST | 低 |
| **RAGFlow** | 产品 + **MCP server/client** | MCP / REST | 中（要有基建） |
| **LightRAG** | 库 + REST（无官方 MCP） | 自建 MCP/REST 包装 | 中低 |
| **Mem0 (OSS)** | 库 + 自托管 Server（**本地 MCP 已移除**） | SDK/Server API | 中 |
| **Letta Code** | 完整 harness + SDK + App Server | 换主循环（或抄设计） | **高** |
| **Redis AMS** | REST 服务 | REST | 中低 |
| **Qdrant/pgvector/LanceDB** | 存储 | 客户端库 | **最低** |
| **LlamaIndex/Haystack** | 框架 | 框架内开发 | 高（框架税） |

> 低耦合首选路径：**一切经 MCP**（search / remember / forget 三个工具面），主循环只依赖接口不依赖实现，组件可替换。

### 4.5 长期运行成本（经验量级，未实测，以实测为准）

- **LLM 抽取（最大变量）**：Mem0 ≈ 每条消息 1-2 次小模型调用；Graphiti ≈ 每 episode 1-2 次；Cognee/RAGFlow GraphRAG 更重。**用本地 7-8B 小模型可把常态成本压到"电费级"**（Cognee 官方也在打"small models for free"）。
- **嵌入**：一次性为主，本地嵌入模型（bge/nomic 等）免 API 费。
- **常驻内存（粗略量级）**：LanceDB/pgvector（随 PG）≈ 低 → Qdrant ≈ 数百 MB → Neo4j/FalkorDB ≈ 1-2GB → Milvus standalone ≈ 4GB+ → RAGFlow 全套 ≈ 4-8GB+（ES 是大头）。
- **Token 注入成本**：常驻记忆块（Letta 式）每轮都付费；按需召回（MCP 工具式）更省——**自研建议"少量常驻 + 大量按需"**。
- **云版对照**：Zep Cloud / Mem0 Platform / Supermemory / Letta Cloud 均为商业定价（与各自 OSS 功能剪差在扩大）。

---

## 5. 推荐组合（长期记忆 + 知识库）

> 需求：跨会话长期记忆、按需召回、关系/图谱、可本地部署、与 agent 主循环低耦合。

### 方案 A（主推：本地、图优先、低耦合）
```
主循环（自研 agent）
   │  MCP（search / remember / forget）
   ├── Graphiti（Apache-2.0，记忆图：时序+失效式遗忘）
   │      └─ 图后端：Neo4j CE（GPL）或 FalkorDB（SSPL）—— 法务选型二选一
   ├── LightRAG（MIT，知识库：双级检索，存储起步用文件/NetworkX，规模上来换 Neo4j+Qdrant）
   └── 向量：Qdrant（独立）｜或 pgvector（已有 PG 时首选）｜或 LanceDB（嵌入式零运维）
全文：Postgres FTS（若用 PG）或 Meilisearch（MIT 部分）
嵌入/抽取：本地模型（bge-m3 类 + 7-8B 小模型），常态零 API 成本
```
- **抄作业清单**：Letta（记忆块+git 化+sleep-time）、Mem0（抽取-判定 prompt）、Graphiti（双时序失效）、RAGFlow（解析+引用）、nano-graphrag（最小图 RAG）。

### 方案 B（极简单机：文件优先）
- 记忆/知识：**Basic Memory**（Markdown+SQLite+MCP；🔒AGPL 注意）或 **engram（Go 单二进制）**＋ **LanceDB**＋ 文件全文检索。
- 适合：个人使用、代码/笔记场景、不愿运维任何服务；缺点：自动化抽取弱。

### 方案 C（重装全功能：要运维）
- **RAGFlow** 全套（文档解析/引用/Agent）＋ **Graphiti**（记忆图）＋ Qdrant/pgvector；适合把"知识库产品"本身当交付物时。

### 避免清单
- 📉 Kuzu（归档）、R2R（停更）、memary（2024-10 后停更）、memobase（2026-01 后停更）、A-Mem 官方仓库（2025-12 后停更，仅算法参考）。
- 勿按旧教程部署：Mem0 OSS 图记忆（已移除）、Mem0 本地 MCP/OpenMemory（已移除/已转型）。
- 许可红线自检：AGPL（Khoj、Basic Memory）、GPL（Typesense、Neo4j CE）、SSPL（FalkorDB）、BUSL（Meilisearch EE）、Weaviate 混合。
- **成本红线自检**：凡"每次写入都要 LLM"的组件（Graphiti/Mem0/Cognee），先规划小模型或批处理。

---

## 6. 附录

### 附录 A · 停更 / 归档 / 观察名单（2024 年后不再活跃）

| 项目 | 最后提交 | 状态 | 备注 |
|---|---|---|---|
| kingjulio8238/Memary ⭐2.7k | 2024-10-18 | 停更 | KG 记忆层，MIT，勿用 |
| SciPhi-AI/R2R ⭐8.0k | 2025-11-07 | 停更 | 公司转型；API 设计可参考 |
| agiresearch/A-mem ⭐1.2k（官方实现 A-mem-sys ⭐404） | 2025-12-12 / 2025-11-06 | 停更 | NeurIPS'25 论文；"链接演化"算法可参考 |
| memodb-io/memobase ⭐2.9k | 2026-01-11 | 半停更 | 用户画像记忆，参考 |
| gusye1234/nano-graphrag ⭐4.0k | 2026-01-27 | 半停更 | 最小图 RAG，仍是最佳抄写底稿 |
| kuzudb/kuzu ⭐4.0k | 2025-10-10 | **归档** | 勿新用；Graphiti 亦弃用 |
| OSU-NLP-Group/HippoRAG | 2026-10-06 | 活跃 | 研究项目，算法参考 |

### 附录 B · 「engram」名称澄清（任务点名项）
"engram"**不是单一知名项目**，同名者至少 4 个 + 1 篇论文：
| 项目 | ⭐ | 形态 | 活跃 |
|---|---|---|---|
| Gentleman-Programming/engram | 7,199 | Go 单二进制；SQLite+FTS5；MCP/HTTP/CLI/TUI；面向编码 agent | 2026-10-14 ✅ |
| tstockham96/engram | 47 | TS；SQLite+sqlite-vec；MCP；宣称 LOCOMO 84.5（HN 展示过） | 2026-09-02 |
| techtheist/engram | 32 | Rust；可检视图记忆（VS Code/JetBrains 插件） | 2026-10-14 |
| edg-l/engram-mcp | 17 | Rust；git 分支感知会话交接；本地 ONNX 嵌入 | 2026-09-23 |
| arXiv:2511.12960 "ENGRAM" | — | 论文：轻量记忆编排（LoCoMo 上 SOTA 宣称） | 2025-11 |
**结论**：若任务指"记忆系统 engram"，最接近的是 **Gentleman-Programming/engram（MIT，⭐7.2k，架构可抄：单文件 SQLite 记忆 + FTS5 + MCP）**；其余为小项目/论文，不建议作为依赖。

### 附录 C · 核实方法与口径
- star 数：GitHub 仓库页内嵌 JSON（`stargazerCount`）精确值，2026-10-14；其中 6 个项目另用 `api.github.com` 抽查（用量：本代理 6 次；共享配额 54→30，含他代理消耗），页面值与 API 值一致。
- 最后提交：`commits.atom`（默认分支）；发版：`releases.atom`；归档状态：仓库页 `isArchived`。
- 许可证：一律读仓库 LICENSE 原文（Meilisearch、Weaviate、Elasticsearch、FalkorDB、pgvector、Kuzu、redis/agent-memory-server 均逐字核实）。
- 第三方信息（已标注）：Mem0 OpenMemory 移除时间线（mnemoverse 整理）、Letta 研究与产品时间线（letta.com 官网）。
- 🟡 未完全核实项：Redis AMS 的 MCP 支持；Mem0 自托管 Server 是否暴露 MCP；Supermemory 自托管形态细节；Elasticsearch/OpenSearch 未做深度集成测试。
- 本文件为只读调研，未安装任何组件。

---

*文件：`/home/ubuntu/projects/agent-stack/sections/02-memory-rag.md` ｜ 集群：记忆与知识/RAG ｜ 核实日：2026-10-14/15*

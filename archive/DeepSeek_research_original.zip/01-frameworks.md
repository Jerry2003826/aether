# 01 · Agent 内核与编排框架（自研 Agent 系统选型 · 集群一）

> 调研日期：2026-10-14（UTC）｜仅覆盖"内核与编排"，记忆/RAG、工具沙箱、模型路由、通道调度、安全基建分别见 02–06 章节。
>
> **数据口径（先读）**
> - star/许可证/活跃度以 **shields.io 徽章（数据源=GitHub，2026-10-14 当天读取）** 核实，star 一律记"约"。
> - **GitHub API 精确核实 6 个仓库**（全机共享限流内恰好用满 6 次，另做 1 次免费 rate_limit 探测）：`openclaw/openclaw`、`langgenius/dify`、`agent0ai/agent-zero`、`mastra-ai/mastra`、`bytedance/deer-flow`、`microsoft/agent-framework`（表内标 ★）。
> - 许可证凡徽章无法识别者，均**直接读取仓库 LICENSE 原文**复核：Dify、Mastra、Agent-Zero、AutoGen。
> - 参考素材 4 篇全部抓取（Langfuse / Splunk / ayautomate / Reddit）。**Reddit 帖 r/LangChain/1rnc2u9 经 www、old.reddit、Wayback 三路均不可访问（反爬阻断），仅列链接、不计入结论权重。**
> - 所有条目均为 2024 年后仍存活项目；无法核实处显式标注"未核实/第三方口径"。

---

## 0. 总览速查表

| # | 项目 | star（约） | 许可证 | 语言 | 活跃度（最近提交 / 约月提交） | 一句话定位 |
|---|------|-----------|--------|------|------------------------------|-----------|
| 1 | **OpenClaw** ★ | 392k | MIT | TS（+Swift/Rust 组件） | 今天 / ~1.7 万 | 个人常驻 AI 操作员（网关+技能+本地优先） |
| 2 | LangGraph | 43k | MIT | Python（+JS） | 今天 / ~98 | 图/状态机编排内核（生产最广） |
| 3 | LangChain DeepAgents | 30k | MIT | Python | 今天 / ~443 | 官方"深度代理"harness（子代理+文件系统） |
| 4 | OpenHands | 91k | MIT | Python+TS | 今天 / ~345 | 软件工程自治 agent 平台 |
| 5 | Microsoft Agent Framework ★ | 14k | MIT | Python/.NET/Go | 今天 / ~467 | AutoGen+SK 合并继任者（企业级） |
| 6 | AutoGen（旧代） | 61k | ⚠ CC-BY-4.0（原文核实，异常） | Python/.NET | 2026-04 / 0 | 已交棒 MAF，维护模式 |
| 7 | CrewAI | 60k | MIT | Python | 今天 / ~112 | 角色化多代理协作 |
| 8 | OpenAI Agents SDK | 30k | MIT | Python（+JS） | 今天 / ~238 | 轻量 agent 原语（handoff/guardrail） |
| 9 | Claude Agent SDK | 8.3k（Py 仓） | MIT | Python/TS | 今天 / ~71 | Claude Code 内核 SDK 化 |
| 10 | Google ADK | 22k | Apache-2.0 | Python（+Java） | 今天 / ~563 | Google 官方 agent 开发套件 |
| 11 | Pydantic AI | 21k | MIT | Python | 今天 / ~920 | 类型安全 agent 框架 |
| 12 | AWS Strands | 8.8k | Apache-2.0 | Python（+TS） | 今天 / ~285 | 模型驱动轻量 SDK |
| 13 | Mastra ★ | 29k | Apache-2.0 + `ee/` 受限目录 | TypeScript | 今天 / ~1.8k | TS 全栈 agent 框架 |
| 14 | Agno | 43k | Apache-2.0 | Python | 今天 / ~134 | 高性能多代理运行时 + AgentOS |
| 15 | smolagents | 30k | Apache-2.0 | Python | 本月 / ~5（低速） | HF 极简 code-agent |
| 16 | LlamaIndex Workflows | 53k（仓库） | MIT | Python | 今天 / ~31 | 事件驱动 workflow 引擎 |
| 17 | MetaGPT | 71k | MIT | Python | 2026-01 / 0（停滞） | 软件公司 SOP 多角色框架 |
| 18 | CAMEL | 18k | Apache-2.0 | Python | 上周 / ~4 | 多代理角色扮演研究鼻祖 |
| 19 | Agent-Zero ★ | 19k | MIT（原文核实） | Python | 昨天 / ~125 | "给 agent 一台 Linux 电脑" |
| 20 | Eliza（elizaOS） | 20k | MIT | TypeScript | 今天 / ~9.7k | 多渠道社交/加密生态 agent |
| 21 | DeerFlow ★ | 84k | MIT | Python | 今天 / ~859 | ByteDance 长时程 super-agent harness |
| 22 | Dify ★ | 158k | ⚠ Dify 开源许可（修改版 Apache 2.0） | TS+Python | 今天 / ~851 | 低代码 LLM 应用/agent 平台 |
| 23 | Langflow | 156k | MIT | Python+TS | 今天 / ~343 | 可视化 flow 构建器（编译到 LangChain） |

> ⚠ 本集群**未发现 AGPL/SSPL/纯非商业许可**；需显式注意的受限许可只有两个：**Dify**（修改版 Apache 2.0，含多租户 SaaS 限制与品牌条款）与 **Mastra**（核心 Apache-2.0，但 `ee/` 目录为单独的受限许可）。

---

## 1. 【重点专项】OpenClaw 核查报告

### 1.1 结论（先行）

**OpenClaw 真实存在，且是 2026 年最主流的"个人常驻 AI Agent"系统之一**，但严格说它是**应用/平台底座**而非可嵌入的编排库：

- **仓库**：https://github.com/openclaw/openclaw ｜**star 约 392k**（API 精确值 392,024，2026-10-14）、82.4k forks、**107,954 commits**、今天仍在推送、非归档。
- **许可证**：**MIT**（仓库与 API 双重核实）｜**技术栈**：TypeScript（Wikipedia 另标 Swift；仓库含 `crates/` Rust 目录——按"约"解读）。
- **诞生线**：仓库创建于 **2025-11-24**；经 Wikipedia 核实的改名链：**Warelay（2025-11-24）→ CLAWDIS（12-03）→ Clawdbot（2026-01-02）→ Moltbot（01-27）→ OpenClaw（01-30）**；稳定版 2.0（v2026.8.1）发布于 2026-08-30。
- **治理**：由 **OpenClaw Foundation（美国 501(c)(3) 非营利，openclaw.org）** 托管，官方声明"无企业版、无付费版、全 MIT"；捐赠方含 OpenAI、Amazon、Red Hat、密歇根大学等；创始人 Peter Steinberger 现就职 OpenAI，官网明确"OpenClaw 不是 OpenAI 产品"。
- **一句话定位**（官方）："The AI that really does things. Any OS. Any Platform. The lobster way. 🦞"——发消息即用的**跨平台常驻个人 Agent**。

**"17% 采用率"传闻：证实，且找到原始出处**（见 1.3）。

### 1.2 核查过程（证据链，可复核）

1. 关键词检索 → 命中官方仓库、官网 openclaw.ai、文档 docs.openclaw.ai 及多篇第三方评测；
2. 抓取 GitHub 仓库页：392k stars、"The lobster way"、MIT、© OpenClaw Foundation；
3. **GitHub API（1 次额度）**：392,024 stars｜TypeScript｜created 2025-11-24｜pushed 2026-10-14｜fork 82,427｜未归档；
4. 抓取 Wikipedia 条目：改名史、发布线、"截至 2026-03 约 247,000 stars / 47,700 forks（引 Wired）"；
5. 抓取 arXiv 论文 **2603.27517《A Security Analysis of the OpenClaw AI Agent Framework》**（Texas A&M，2026-04）："2026 年 1 月以 OpenClaw 之名重启后数周内超过 20 万 star"；
6. 抓取 Stack Overflow 官方博客（2026-05-27）：**17% 使用 / 32% 想用**（详见 1.3）；
7. 生态面：NVIDIA **NemoClaw**（GTC 2026-03-16 主题演讲发布，黄仁勋原话"每家公司都需要一个 OpenClaw 战略"）、微软 **Scout**（Build 2026-06-02，基于 OpenClaw 的 M365 常驻助手）、腾讯 OpenClaw 产品套件（03-10）、阿里云/Moonshot/小米（第三方统计口径，未独立复验）；
8. 风险面：上述 arXiv 安全分析（WebSocket 各层信任决策分散）、MoltMatch 事故（Wikipedia 条目）、安全厂商事故盘点、ClawHub 技能市场 6.8% 验证率（第三方统计）。

### 1.3 "17% 采用率"传闻：证实 + 精确出处

出处为 **Stack Overflow 官方博客 2026-05-27（pulse survey，2026-04 下旬，n≈1,100 开发者/职场人）**，原文：

> "For **agent frameworks**, LangChain (22%) and LangGraph (14%) are the top tool choices among well-settled tools… Newcomers that show high usage and high interest are **OpenClaw (17% have used, 32% want to use)**, OpenAI Agents SDK (14% have used, 19% want to use) and Terminal Use (15%)…"

同时该调查显示：AI agent 使用率一年内从 31% → 59%，但**"多代理编排"仍属少数派**（日常多代理用户最常用 Claude Code 70%）。

**口径提醒**：这是"使用过的工具"自报题，不是市场份额；且 OpenClaw 与库类框架不在同一维度（SFAI Labs 明确指出其"是独立应用而非可安装库"，因而未进其框架采用指数）。

### 1.4 能力面与架构（docs.openclaw.ai，2026-10-14 读取）

- **Gateway 多通道**：Discord、Google Chat、iMessage、Matrix、Microsoft Teams、Signal、Slack、Telegram、WhatsApp、Zalo 等 + WebChat + 移动节点；"一个 Gateway 同时服务所有通道插件"。
- **架构口号**（官方文档原文）：**"trusted gateway, untrusted execution, deterministic policy"**——受信网关 / 不受信执行 / 确定性策略三层分离。
- **能力面**：Agents（sessions、context、memory、**multi-agent routing**）、Tools / skills / cron / webhooks、**ClawHub 插件市场**（第三方统计：约 5.2 万技能、1.2 万发布者、仅 6.8% 经官方验证）、Control UI 浏览器控制台。
- **数据面**：本地优先——"Your memories. Your skills. Your models. Your machines."；默认不回传数据（仅每日版本检查）。
- **规模**（第三方统计，谨慎引用）：3.2M 月活、3800 万月网站访问（2026-04 口径）。

### 1.5 与 Hermes Agent / OpenHands 的关系

- **与 Hermes Agent**：第三方对比文章（innfactory、openclawvps、Flowtivity、Medium）将两者并列为 2026 两大自托管个人 Agent；共识差异为"OpenClaw 赢在生态规模（技能/通道/企业层），Hermes 赢在自学习与运行成本"；有第三方转述的社区用法是"OpenClaw 做多通道路由层 + Hermes 做执行层"。**本次核查范围内未发现两者代码同源的证据**——属同赛道竞品/潜在互补。对自研系统而言，OpenClaw 是"产品形态对标"的首要对象。
- **与 OpenHands**：**不同赛道，无代码关系**。OpenHands 是面向软件工程的编码 agent 平台（SDK/CLI/GUI/云），OpenClaw 是常驻个人操作员；社区存在组合玩法（把 OpenHands 作为 OpenClaw 可调用的编码执行器）。

### 1.6 能拿它当什么组件 / 能抄什么

1. **三层架构直接抄**：受信网关（通道接入+路由）/ 不受信执行（沙箱内跑工具）/ 确定性策略（权限+审批）——映射到自研的"通道层 / 执行沙箱 / 权限引擎"三件套；
2. **技能生态机制**：skill 打包规范 + ClawHub 式市场（发布/策展/信任分级），自研"能力市场"的最佳对标；
3. **产品化细节**：`openclaw onboard` 引导流、设备配对（pairing）、Control UI、消息通道即 UI 的交互范式；
4. **本地优先数据面**：记忆/技能/模型全在用户侧，作为"个人数据主权"卖点的实现参考（记忆细节归 02 集群）。

### 1.7 集成注意 / 坑

1. **安全是最大雷区**：官方自己承认执行层"untrusted"；已有专门的 arXiv 安全分析、真实事故与供应链事件，技能市场验证率极低（6.8%）——任何参考都要求先有权限/沙箱/审批设计（详见 06 集群）；
2. **体量劝退 fork**：107,954 commits、约 1.7 万 commits/月（徽章口径）、82.4k forks——巨型高速仓库，建议"抄架构不 fork"；
3. **外部政策依赖**：Anthropic 曾专门调整 Claude 订阅内运行 OpenClaw 等第三方 agent 的政策（2026）；企业层（NemoClaw、Scout）均为第三方衍生产品，法务需单独评估。

---

## 2. 图 / 状态机 / 工作流内核组

### 2.1 LangGraph
- **链接**：https://github.com/langchain-ai/langgraph ｜**star**：约 43k（shields 徽章）｜**许可证**：MIT
- **定位**：低层"图 + 共享状态 + superstep"编排运行时，本集群**生产成熟度标杆**（Splunk 2026 评测列为一号位）。
- **技术栈**：Python（另有 JS 版，未单独核实）｜**活跃度**：最近提交=今天；约 98 commits/月
- **当组件/可抄**：① Checkpointer/thread 持久化模型（Postgres/Redis/SQLite）——**断点续跑**直接落库；② `interrupt()` 暂停-恢复机制做 **HITL 审批**；③ time-travel 回放调试。（第三方口径：2026-04 的 v0.4 强化了 state persistence 与 HITL checkpoint）
- **坑**：① 深绑 LangChain 生态（langchain-core 依赖、LangSmith 商业导流）；② 抽象偏底层，消息/状态建模全手写，曲线陡；③ state channel/reducer 心智负担大。

### 2.2 Microsoft Agent Framework（MAF）
- **链接**：https://github.com/microsoft/agent-framework ★｜**star**：约 14k（API 精确 14,129）｜**许可证**：MIT
- **定位**：**AutoGen + Semantic Kernel 的官方合并继任者**（2025-10 发布，2026 已生产级），企业级多代理编排。前代 AutoGen 自 late-2025 进入**维护模式**（见 2.6，官方迁移指南已出）。
- **技术栈**：Python/.NET/Go（Splunk 口径：.NET 版本略领先）｜**活跃度**：最近提交=今天；约 467 commits/月
- **当组件/可抄**：① Workflows 模型：**executors + typed edges + supersteps**（消息传递型工作流，与 LangGraph 的图范式互为镜像，值得对比后择一）；② 事件驱动 actor 内核（继承自 AutoGen）+ 企业治理/telemetry；③ 双语言 SDK 的 API 设计（同一抽象跨 .NET/Python 保持一致）。
- **坑**：① Python 侧成熟度落后 .NET；② Azure/Foundry 世界观（非 Azure 环境收益打折）；③ 公开时间短（2025-10），生态/文档仍在补齐。

### 2.3 Google ADK（Agent Development Kit）
- **链接**：https://github.com/google/adk-python ｜**star**：约 22k｜**许可证**：Apache-2.0
- **定位**：Google 官方 agent 开发套件（含内置评测），A2A（agent-to-agent）互操作协议的主要推动者。2026-02-27 发布 ADK Tools & Integrations 生态（第三方口径）。
- **技术栈**：Python（另有 Java 版，未单独核实）｜**活跃度**：最近提交=今天；约 563 commits/月
- **当组件/可抄**：① v2 的 `google.adk.Context` 统一工具上下文与会话状态隔离（第三方口径）；② 内置 eval 框架（agent 评测思路）；③ **A2A 协议**的互操作设计——自研系统若要对外互联，这是最现成的协议参考。
- **坑**：① GCP/Vertex 亲和（本地模型支持一般）；② 演进极快（2.0 大改，API 稳定性需跟版本）；③ 文档质量参差。

### 2.4 Pydantic AI
- **链接**：https://github.com/pydantic/pydantic-ai ｜**star**：约 21k｜**许可证**：MIT
- **定位**：**类型安全**的 Python agent 框架（"给 GenAI 的 FastAPI 时刻"），2026 年增速最快的框架之一。
- **技术栈**：Python｜**活跃度**：最近提交=今天；**约 920 commits/月（本集群最高之一）**
- **当组件/可抄**：① Pydantic 模型驱动的 tool schema/结构化输出/**依赖注入**——工具调用内核的最干净实现之一；② 自带 `pydantic-graph` 状态机；③ **durable execution 适配层**（对接 Temporal/DBOS 等持久执行引擎，具体清单以官方文档为准）——断点续跑的"外包"路线。
- **坑**：① 相对年轻（2024 起步），生产案例积累少于 LangGraph；② 生态插件少于 LangChain 系；③ 默认推荐自家 Logfire 可观测（选型时被捆绑一层）。

### 2.5 LlamaIndex Workflows
- **链接**：https://github.com/run-llama/llama_index ｜**star**：约 53k（仓库级）｜**许可证**：MIT
- **定位**：**事件驱动** workflow 引擎（steps + events），与 LlamaIndex 检索/索引栈一体，RAG 型 agent 的顺路之选。
- **技术栈**：Python｜**活跃度**：最近提交=今天；仓库级约 31 commits/月（workflow 模块随 core 发版）
- **当组件/可抄**：① "step 之间用事件解耦"——与 LangGraph 图范式不同的另一条**事件流**路线，对照后择一；② 工作流 streaming 事件模型；③ 与检索/数据生态的原生衔接。
- **坑**：① workflows 嵌在巨型 monorepo 里，版本耦合需盯 release；② 生态重心在 RAG/数据而非通用编排；③ 概念层级多（workflow/agent/query engine 易混）。

### 2.6 Microsoft AutoGen（前代，仅作警示条目）
- **链接**：https://github.com/microsoft/autogen ｜**star**：约 61k｜**许可证**：**⚠ LICENSE 原文为 CC-BY-4.0（"Attribution 4.0 International"，与常见代码许可不同，异常需注意；代码子目录或另有条款，未逐一核实）**
- **活跃度**：最近提交 2026-04；近月 0 commits——**官方维护模式**（Langfuse 口径：late-2025 起仅修 bug/安全补丁，社区托管，微软推荐迁移 MAF）
- **结论**：新项目**不要**以 AutoGen 起步；仅作为多代理辩论/群聊（GroupChat）模式的**设计素材**阅读。

---

## 3. 代码优先的轻量 Agent SDK / Harness

### 3.1 OpenAI Agents SDK
- **链接**：https://github.com/openai/openai-agents-python ｜**star**：约 30k｜**许可证**：MIT
- **定位**：极简 agent 原语：**Agents / Handoffs / Guardrails / Sessions / Tracing**，Swarm 的生产化继承者。
- **技术栈**：Python（另有 JS/TS 版，未单独核实）｜**活跃度**：最近提交=今天；约 238 commits/月
- **当组件/可抄**：① **handoff（交接棒）**——多代理协作的最简建模，比图/黑板轻得多；② guardrails 输入输出校验管线（安全旁路设计）；③ 内置 tracing spans 的埋点模型（自建可观测时的对照，观测另见 04 集群）。
- **坑**：① tracing 默认上报 OpenAI 平台，自建须替换 processor；② 抽象少 → 复杂控制流（循环/并行/长任务）要自搭；③ 双语言版本行为存在差异。

### 3.2 Claude Agent SDK
- **链接**：https://github.com/anthropics/claude-agent-sdk-python ｜**star**：约 8.3k（Python 仓）｜**许可证**：MIT
- **定位**：**Claude Code 内核的 SDK 化**：subagents、hooks、权限系统、MCP、context compaction、技能加载。
- **技术栈**：Python（TS 版本以 Claude Code/主仓形态提供，未单独核实）｜**活跃度**：最近提交=今天；约 71 commits/月
- **当组件/可抄**：① **分层权限模型（allow/ask/deny + 沙箱策略）**——HITL 审批的工业级样板，本集群最有价值的"可抄件"之一；② hooks 生命周期注入点（工具前后、会话事件）；③ subagent 隔离上下文 + compaction 策略（长任务上下文管理的现成答案）。
- **坑**：① 与 Claude 模型绑定较深（换模型体验非对称）；② 订阅/AUP 合规敏感（参见 OpenClaw 在 Claude 订阅上的政策风波）；③ Python 版较新，部分能力 TS/CLI 先行。

### 3.3 AWS Strands Agents
- **链接**：https://github.com/strands-agents/sdk-python ｜**star**：约 8.8k｜**许可证**：Apache-2.0
- **定位**：AWS 出品的"**模型驱动**"轻量 agent SDK（让模型自主决定 loop 与工具调用）。
- **技术栈**：Python（另有 TS 版，未单独核实）｜**活跃度**：最近提交=今天；约 285 commits/月
- **当组件/可抄**：① 极简 agent loop 内核（教学/自研内核的干净参考实现）；② 多代理两种拓扑（swarm / graph）的取舍示例；③ 与 Bedrock 的一体化接入方式。
- **坑**：① AWS 亲和；② star/社区规模在本组偏小；③ Python/TS 双实现的特性对齐需自查。

### 3.4 Mastra
- **链接**：https://github.com/mastra-ai/mastra ★｜**star**：约 29k（API 精确 28,824）｜**许可证**：**Apache-2.0（核心）+ `ee/` 目录单独受限许可（源码可见；README 口径：开发/测试可自由使用，生产使用受限——以 `ee/LICENSE` 为准）**
- **定位**：TypeScript 阵营的全栈 agent 框架（workflows + agents + RAG + evals），Gatsby 团队出品。
- **技术栈**：TypeScript（monorepo）｜**活跃度**：最近提交=今天；**约 1.8k commits/月（本集群最高）**
- **当组件/可抄**：① TS 世界观下的 workflow 引擎（step/分支/挂起）设计与 DX；② `mastra dev` 本地 playground 的产品体验；③ 与 Next.js/React 的集成模式。
- **坑**：① **`ee/` 目录为受限许可——生产集成前必须读 `ee/LICENSE`**；② Mastra Cloud 商业线（自托管 vs 云功能差需对照）；③ TS 单栈，跨语言控制面要另设计。

### 3.5 smolagents
- **链接**：https://github.com/huggingface/smolagents ｜**star**：约 30k｜**许可证**：Apache-2.0
- **定位**：HF 出品**极简 code-agent** 框架——LLM 直接写 Python 代码作为动作空间（而非 JSON 工具调用）。
- **技术栈**：Python｜**活跃度**：最近提交=本月内，但**约 5 commits/月——维护节奏明显放缓（选型需注意）**
- **当组件/可抄**：① **CodeAgent 范式**（代码即动作 + 沙箱执行 E2B/Docker）——自研工具内核的另一种范式对照；② 千行级内核的高可读性实现。
- **坑**：① 低活跃；② 代码执行必须自建沙箱（安全归 03/06 集群）；③ 功能面窄，定位教学/轻量。

### 3.6 LangChain DeepAgents
- **链接**：https://github.com/langchain-ai/deepagents ｜**star**：约 30k｜**许可证**：MIT
- **定位**：LangChain 官方"batteries-included"**深度代理 harness**（planning + 子代理 + 文件系统 + 上下文管理），Claude Code 式长任务代理的开源平替路线。
- **技术栈**：Python（构建于 LangGraph 之上）｜**活跃度**：最近提交=今天；约 443 commits/月
- **当组件/可抄**：① 内置 `task` 工具生成**隔离上下文的临时子代理**（长任务/并行任务模式）；② **可插拔文件系统后端**（本地/沙箱/远程）——agent 的"工作目录"抽象；③ 上下文压缩/总结策略。
- **坑**：① 全套 LangChain 栈依赖；② 较新、API 变动快；③ 面向"深度/多步"场景，通用内核仍需 LangGraph。

---

## 4. 多代理协作 / 角色编排

### 4.1 CrewAI
- **链接**：https://github.com/crewAIInc/crewAI ｜**star**：约 60k｜**许可证**：MIT（企业版为商业产品线）
- **定位**：**角色化多代理**协作框架（Crews=自治协作 / Flows=确定性工作流），多代理原型上手最快之一。
- **技术栈**：Python｜**活跃度**：最近提交=今天；约 112 commits/月
- **当组件/可抄**：① role/goal/backstory 的**prompt 编排模板**（人设即配置）；② "自治 Crews + 确定性 Flows"双模式的产品设计；③ 任务委派/层级流程（manager agent）模式。
- **坑**：① 早期自治循环不可控，生产要切 Flows 补确定性；② 持久化/HITL 较弱需自补（2026 有改进但非强项）；③ 企业版商业线分界需读清。

### 4.2 Agno
- **链接**：https://github.com/agno-agi/agno ｜**star**：约 43k｜**许可证**：Apache-2.0
- **定位**：高性能轻量多代理运行时 + **AgentOS 控制面**（sessions/memory/knowledge 一套 API，可自托管 UI）。
- **技术栈**：Python｜**活跃度**：最近提交=今天；约 134 commits/月
- **当组件/可抄**：① Agent/Team 极简抽象与低开销实例化（以性能为核心卖点，属厂商口径，需自测）；② 控制面（AgentOS）思路——"运行时 + 管理面"的分层；③ 多模态 agent 原语。
- **坑**：① 迭代激进、历史上有 breaking change（v1→v2 大改）；② 营销声量大，生产案例需自行验证；③ 库 + 云平台混合模式。

### 4.3 MetaGPT
- **链接**：https://github.com/FoundationAgents/MetaGPT ｜**star**：约 71k｜**许可证**：MIT
- **定位**：**"软件公司 SOP"**多角色框架（PM/架构/开发/测试顺序协作），学术明星项目。
- **活跃度**：最近提交 2026-01；近月 0 commits——**基本停滞（慎作依赖）**。
- **可抄**：SOP 化的多角色 prompt 流水线、结构化产物（PRD/设计/代码）交接设计。
- **坑**：已不适合作为活跃依赖；代码可作教学素材。

### 4.4 CAMEL
- **链接**：https://github.com/camel-ai/camel ｜**star**：约 18k｜**许可证**：Apache-2.0
- **定位**：最早的多代理**角色扮演/协作研究框架**（2023 起），大规模 agent society 数据生成。
- **活跃度**：最近提交=上周；约 4 commits/月（低强度维护）。
- **可抄**：role-playing 协议、agent 社会模拟、工具/记忆抽象的研究实现。
- **坑**：研究导向，生产设施少；节奏放缓。

### 4.5 Eliza（elizaOS / 原 ai16z）
- **链接**：https://github.com/elizaOS/eliza ｜**star**：约 20k｜**许可证**：MIT
- **定位**：多渠道社交/加密生态 agent 框架（character 人设文件 + 插件体系 + 海量 connector）。
- **技术栈**：TypeScript｜**活跃度**：最近提交=今天；**约 9.7k commits/月（极高，=高速迭代风险）**
- **可抄**：① **character 文件=人设即配置**的产品化思路；② 多渠道 connector 矩阵的工程组织；③ 社区代币化运营（如果做社区产品）。
- **坑**：① 加密语境重（治理/资金波动）；② 框架层频繁重构（breaking 风险高）；③ 与本集群其他框架定位差异大，选型勿混。

---

## 5. 自治常驻 Agent 运行时与平台

### 5.1 OpenHands
- **链接**：https://github.com/OpenHands/OpenHands ｜**star**：约 91k｜**许可证**：MIT
- **定位**：**软件工程自治 agent 平台**（SDK/CLI/本地 GUI/云），"事件流 + 沙箱运行时"架构的代表（原 All-Hands-AI，组织已改名 OpenHands）。
- **技术栈**：Python + TypeScript｜**活跃度**：最近提交=今天；约 345 commits/月
- **当组件/可抄**：① **Event Stream 架构**——一切交互皆事件，可审计/可回放（自研事件流内核的最好样板）；② **agent server（REST/WS）与沙箱 runtime 分离**：执行在容器里、控制面在外；③ HITL/确认模式与权限设计。
- **坑**：① 定位是编码 agent，通用任务需改造；② 组件多（前端/后端/runtime），集成面大；③ 版本迭代快（经历过大重构）。

### 5.2 Agent-Zero
- **链接**：https://github.com/agent0ai/agent-zero ★｜**star**：约 19k（API 精确 19,474）｜**许可证**：**MIT（LICENSE 原文核实，Copyright 2025 Agent Zero, s.r.o）**
- **定位**："**给 agent 一台完整 Linux 电脑**"的自治框架（内置 Web UI、Docker 运行时、多 agent 上下级协作）。
- **技术栈**：Python｜**活跃度**：最近提交=昨天；约 125 commits/月
- **当组件/可抄**：① **agent 层级制**（上级 agent 派生下级，上下文隔离）；② 容器化执行环境 + Web 控制台的开箱组合；③ prompts 可编辑（prompts 目录即行为配置）。
- **坑**：① 设计上全权限，安全边界必须自建；② 小团队/公司维护（19k star 量级）；③ Python 单栈。

### 5.3 DeerFlow
- **链接**：https://github.com/bytedance/deer-flow ★｜**star**：约 84k（API 精确 83,868）｜**许可证**：MIT
- **定位**：ByteDance 开源的**长时程 super-agent harness**（深度研究 → 报告/代码/多媒体交付），2026-02-27 开源 2.0。
- **技术栈**：Python（基于 LangGraph，第三方口径）｜**活跃度**：最近提交=今天；约 859 commits/月
- **当组件/可抄**：① 长时程任务的"计划-执行-反思"编排（研究型 agent 的完整范例）；② **StreamEvents 协议 + headless CLI**（`deerflow --json`，可嵌入自家 UI 的流式事件口）；③ 工具矩阵（搜索/爬虫/代码执行）编排。
- **坑**：① 重度 LangGraph 依赖（换内核成本高）；② 定位偏"深度研究/报告"垂直场景；③ 大厂项目治理（roadmap 受组织影响）。

### 5.4 Dify
- **链接**：https://github.com/langgenius/dify ★｜**star**：约 158k（API 精确 158,486）｜**许可证**：**⚠ "Dify 开源许可"= 修改版 Apache 2.0 + 限制条款**（LICENSE 原文核实；要点：未经授权**不得用于多租户 SaaS**、不得移除/修改品牌标识——细节以 LICENSE 为准）
- **定位**：可视化 LLM 应用/agent 平台（低代码 workflow + RAG + 插件市场 + API 后端）。
- **技术栈**：Python 后端 + TypeScript 前端（GitHub 主语言标 TS）｜**活跃度**：最近提交=今天；约 851 commits/月
- **当组件/可抄**：① **workflow DSL / 编排 UX**（画布 → 可版本化配置）；② 插件市场与"应用即 API"的后端设计；③ 运营/观测后台（日志、标注）的产品形态。
- **坑**：① **许可证限制是硬约束**（拿其做多租户 SaaS 需商业授权）；② 平台属性强，作为"内核"嵌入困难；③ 社区版 vs 云版功能差。

### 5.5 Langflow
- **链接**：https://github.com/langflow-ai/langflow ｜**star**：约 156k｜**许可证**：MIT
- **定位**：可视化拖拽 flow 构建器（编译为 LangChain Python 代码），DataStax 维护。
- **技术栈**：Python + TypeScript｜**活跃度**：最近提交=今天；约 343 commits/月
- **当组件/可抄**：① "可视化编排 → 导出代码"的 UX（比纯 DSL 更亲民）；② 组件库的组织方式。
- **坑**：① 与 LangChain 版本强耦合；② 产品重心在低代码 IDE，自研内核用不上其运行时；③ 云商业化（DataStax）。

---

## 6. 本集群首选 + 备选

### 6.1 首选（唯一骨架级推荐）：**LangGraph**
核心理由（对应考察五维）：**工具调用内核**（任何模型/工具可接）｜**状态机/事件流**（图+superstep，最成熟）｜**HITL 审批**（`interrupt()` 原生）｜**断点续跑**（checkpointer 工业级）｜**多代理**（子图/supervisor 模式齐备）；MIT 无限制、43k star、高活跃。生产成熟度在本集群无出其右。

### 6.2 备选（按场景，与首选组合使用）

| 备选 | 适用场景 |
|------|---------|
| **Pydantic AI** | 想要"类型安全 + 依赖注入"的执行层，或把持久化外包给 Temporal/DBOS 的 durable execution 路线（920 commits/月，增速之王） |
| **OpenAI Agents SDK** | 最快落地、需要 handoffs/guardrails 原语与开箱 tracing；可作 LangGraph 内的"单 agent 执行体" |
| **Claude Agent SDK** | 以 Claude 为主的栈；其**权限/HITL hooks 模型**建议即使不选也照抄 |
| **Microsoft Agent Framework** | .NET/企业/Azure 场景；executors+typed-edges 工作流与 LangGraph 二选一 |
| **OpenHands** | 需要"编码 agent"能力直接嵌入（事件流 + 沙箱 runtime 平台） |
| **Mastra** | 全 TS 栈产品（注意 `ee/` 许可） |
| **DeerFlow** | 起点就是"长时程研究/报告"类 agent（省一轮自研编排） |

**明确不建议作内核**：CrewAI（适合多代理原型，不做底层）、MetaGPT（停滞）、smolagents（低速维护）、AutoGen（维护模式）、Dify/Langflow（平台而非内核；Dify 另有许可证硬约束）、Eliza/CAMEL（定位/维护差异）、Agno（可作快原型，breaking 风险自评）。

### 6.3 "抄作业"映射（自研模块 ← 借鉴对象）

| 自研模块 | 借鉴 |
|---------|------|
| 状态机/持久化/断点续跑 | LangGraph checkpointer + interrupt |
| 事件流与审计回放 | OpenHands Event Stream；DeerFlow StreamEvents |
| HITL 审批与权限 | Claude Agent SDK 权限模型 + hooks；MS AF 企业治理 |
| 工具内核 | Pydantic AI（类型安全）/ smolagents（code-agent 范式对照） |
| 多代理协作 | DeepAgents 子代理隔离；OpenAI SDK handoffs；Agent-Zero 层级制 |
| 网关/通道/技能生态/产品形态 | **OpenClaw**（见第 1 节） |
| 长任务上下文管理 | Claude Agent SDK compaction；DeepAgents 文件系统抽象 |

### 6.4 数据可信度分级（防误用）

- **精确级**（GitHub API，6 次额度内）：OpenClaw、Dify、Agent-Zero、Mastra、DeerFlow、MAF 的 star/语言/时间戳；Dify/Mastra/Agent-Zero/AutoGen 的 LICENSE 原文。
- **实时级**（shields 徽章，数据源=GitHub，当天）：全部 23 条的 star/最近提交/月提交/许可证（star 记"约"）。
- **第三方口径**（未独立复验，引用时保留原标注）：NemoClaw/Scout 细节、ClawHub 技能数、OpenClaw MAU、ADK 生态发布、"v0.4"等版本细节。
- **不可用**：Reddit 帖 r/LangChain/1rnc2u9（反爬阻断，三路重试失败）。

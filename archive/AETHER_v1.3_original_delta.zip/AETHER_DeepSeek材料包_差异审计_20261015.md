# AETHER × DeepSeek 材料包：差异审计与架构裁决

审查日期：2026-10-15（澳大利亚墨尔本）

## 审查边界

本报告检查用户上传的 `AI-Agent系统-开源原材料-完整材料包.zip`，并与此前 AETHER V1.2 的 `config/ecosystem_candidates.yaml` 和架构规格进行交叉比较。DeepSeek ZIP 有 9 个文件：1 份组合总报告、总纲、6 个模块文件与 1 份原始研究快报。主体组合总报告中出现约 214 个不同 GitHub owner/repository 链接；AETHER V1.2 候选 YAML 含 80 个。按 URL 小写正规化交叉比较，AETHER 有 44 个仓库不在 DeepSeek 主报告的 GitHub URL 清单中。这是**链接覆盖差集**，不证明作者完全没有在正文提到某项技术，也不是对全部代码做了安装验证。

数据分三级：① 原文件明确记载的内容；② 已重新查看官方仓库/官方文档的事实；③ 工程设计判断或实验建议。所有候选能力必须在固定 Git revision、许可证、宿主平台、性能与安全测试通过后才能进入生产。

## A. DeepSeek 已补齐而 AETHER 应吸收的优点

| 领域 | DeepSeek 的价值 | 对 AETHER 的裁决 |
|---|---|---|
| 跨端/消息通道 | OpenClaw 的 Gateway、Telegram/Discord、QQ 等通道及去重、outbox | 增加 ChannelAdapter 契约。优先官方 Bot SDK；非官方 QQ/微信协议只可显式启用、隔离并承担账号风险。 |
| 真正隔离的代码执行 | microsandbox、E2B、bubblewrap、nsjail、Firecracker、gVisor | 保留 OpenHands 作为编码 Agent，另设 SandboxBackend；Docker workspace 不是所有敌意代码的充分安全边界。microsandbox/E2B 必须先跑宿主兼容和攻击面测试。 |
| MCP 生态治理 | 官方 Registry/Inspector、MCP Gateway、密钥代理、权限细分 | AETHER 可信 Tool Gateway 仍为授权源；MCP 是工具接入协议，而不是权限权威。接入 Docker MCP Gateway / IBM ContextForge 时作为候选，不做第二授权源。 |
| 技能供给与渐进加载 | agentskills 规范、社区技能库、lazy loading | 对 Skill 增加签名、来源、依赖锁、沙箱预检查与版本约束，未经可信审计的社区技能不自动安装。 |
| 独立安全与身份组件 | SOPS/age、Infisical、OPA、Better Auth/Keycloak | 初期 SOPS+age 与已有权限引擎；多租户时评估 OPA 和 OIDC。不要一口气装四套身份/密钥产品。 |
| 评测工具链 | promptfoo、Inspect AI、DeepEval/RAGAS、SWE-bench、WebArena | 保留 pydantic-evals 和 promptfoo；Inspect AI 可担任较重的离线基准执行器。不要用同一 LLM judge 替代真实测试。 |
| 用户体验 | assistant-ui、Vercel AI SDK、Open WebUI、CopilotKit、LiveKit/Pipecat | AETHER 自有 Next.js 控制台可参考 AG-UI 事件协议，语音后置。Open WebUI 的品牌/许可不是无条件可白标。 |
| 运营成本 | LiteLLM/semantic-router、Langfuse/OTel、OpenMeter 等 | LiteLLM 仅负责模型调用适配；可信成本账本归 AETHER，不依赖供应商返回的估算值作为唯一来源。 |

## B. DeepSeek 缺少的项目与机制（按影响程度）

| ID | 优先级 | 缺漏 | 官方仓库/实现切入点 | 进入条件 |
|---|---|---|---|---|
| GAP-01 | P0 | 结构化代码智能：独立调用图、影响范围分析 | https://github.com/colbymchenry/codegraph；https://github.com/ast-grep/ast-grep；https://github.com/oraios/serena（应用许可须单独审查） | 隔离仓库快照；跨租户不可见；图索引随 commit 更新；独立运行 lint/test。 |
| GAP-02 | P0 | Hindsight 记忆技术未被纳入 Graphiti 对照 | https://github.com/vectorize-io/hindsight；https://github.com/getzep/graphiti | 来源可追溯、时态冲突、正确忘记、租户隔离、隐私成本、P95 召回率对照。 |
| GAP-03 | P0 | 专门针对 Agent 运行环境的提示词注入基准 | https://github.com/ethz-spylab/agentdojo | 至少覆盖网页、仓库注释、MCP 元数据、第三方 Skill；测越权行动率与正常任务成功率。 |
| GAP-04 | P0 | 自动优化与 Skill 进化不是完整闭环 | https://github.com/stanfordnlp/dspy（GEPA/MIPROv2）；https://github.com/Human-Agent-Society/reef；https://github.com/microsoft/agent-lightning | 只能在离线候选环境训练/优化；隐藏测试集隔离，改善指标和失败样本归档；失败候选不能部署。 |
| GAP-05 | P0 | 完整供应链的自动 SBOM/漏洞/签名措施 | https://github.com/anchore/syft；https://github.com/google/osv-scanner；https://github.com/sigstore/cosign | 每个真实运行时依赖与镜像都可追溯版本、构建来源、漏洞处置和签名。 |
| GAP-06 | P0 | 状态权威与外部副作用幂等恢复不够具体 | https://github.com/temporalio/sdk-python；AETHER operation ledger | 模拟工具成功但响应丢失后重启，无重复付款/发消息/删除，能够对账和人工处理未知结果。 |
| GAP-07 | P1 | Agent-UI 和跨 Agent 标准没有形成可执行适配器 | https://github.com/ag-ui-protocol/ag-ui；https://github.com/a2aproject/a2a-python；https://github.com/modelcontextprotocol/ext-apps | AG-UI 试验 streaming、approval、reconnect；A2A 只在需要外部自治 Agent 时启用；MCP Apps 延后。 |
| GAP-08 | P1 | 自主搜索的完整召回/重排/评测系统设计不足 | https://github.com/xhluca/bm25s；https://github.com/FlagOpen/FlagEmbedding；https://github.com/pgvector/pgvector | BM25+embedding+RRF+reranker 独立评测；来源版本引用、删除传播、中文检索 nDCG@10。 |
| GAP-09 | P1 | Agent 目标合同 + 独立验证机制 | AETHER `GoalContract` + `Verifier`（自研，不装另一框架） | 用户验收与完成证明区分；代码须真实测试；未验证状态不能写 DONE。 |
| GAP-10 | P1 | 可信轨迹、溯源与事件持久化 | AETHER Event/Evidence/Operation Ledger（自研） | 每个决策、调用、模型/代码/数据版本可关联；敏感数据脱敏；追溯自哪段源码产生结果。 |
| GAP-11 | P2 | 跨应用主动通知、多端信息一致性 | python-telegram-bot 等官方通道 SDK + Temporal schedules | outbox + delivery receipts + dedup + approval token binding；勿让两个 scheduler 都成为任务权威。 |
| GAP-12 | P2 | 多模态/实时 GUI 操作与语音的专项评测 | https://github.com/trycua/cua；https://github.com/livekit/agents | 仅当产品确需跨桌面和语音时启动；先建立操作安全、隐私和延迟基线。 |

## C. 需纠正或降低信任等级的选型断言

1. **AutoGen 许可误判**：DeepSeek 描述 `microsoft/autogen` 的 LICENSE 为 `CC-BY-4.0`，并将其说成代码许可异常。官方 README 明确说明：文档/内容 CC-BY-4.0，**代码由 `LICENSE-CODE` 使用 MIT**。正确操作是按文件和子目录核对，不可仅根据根 LICENSE 推断整个源码的许可。
   - https://github.com/microsoft/autogen
2. **不能因为 LangGraph 很流行就推翻 Temporal**。LangGraph 的 checkpointer 能恢复图状态，也要求有副作用的 task 幂等；Temporal 的 Workflow/Activity 与恢复语义又是一套。AETHER V1.2 已选择 Temporal 作为唯一持久执行权威，不能再让 LangGraph + APScheduler + Restate/DBOS 同时拥有任务重试权。
   - https://github.com/langchain-ai/langgraph
   - https://github.com/temporalio/sdk-python
3. **“自托管 microVM”仍需平台探针**。不能因为库声称兼容 macOS/Windows/Linux，就假定三类宿主提供相同隔离强度。microsandbox 文档已指出部分 macOS/旧内核文件系统防护路径弱于新 Linux；敌意任务先采用真正隔离、无宿主凭据的后端。
   - https://github.com/superradcompany/microsandbox
4. **记忆与 RAG 不是同一个权威存储**。Graphiti/Hindsight/LightRAG 可作为派生索引或实验引擎；原始证据、用户更正、删除事件和权限仍在 AETHER 自有数据库与对象存储。
5. **许可证归纳不能过度简化**。AGPL 可以用于商业场景，但必须满足适用的网络提供/修改发布义务；GPL 是否触及主程序取决于分发与组合方式；source-available 不一定等同 OSI 开源。要审具体 release、依赖和部署方式，不应把“AGPL=不可商用”“GPL=所有网络服务感染”写成通用规则。
6. **Star 数与 Stack Overflow 采用率不是质量与可靠性指标**。DeepSeek 关于 OpenClaw 17% 曾使用的调查数据，官方 Stack Overflow 2026-05-27 博客确实有相应口径，但这是调查对象自报“使用过”，不是市场份额，也不能证明性能优于 Hermes。
   - https://stackoverflow.blog/2026/05/27/agents-on-a-leash-agentic-ai-remains-mostly-monitored-at-work/
7. **测 AI 防护不能只用分类器自身的离线得分**。2026 年 10 月关于 Agent 工具输出注入检测的研究提示跨基准迁移很差，需在真实任务轨迹、低误报率条件下评估。
   - https://arxiv.org/abs/2610.03448
8. **“已查过 214 个仓库”≠“214 个全部已验证”**。文件本身混合了 API/页面、镜像、未核实条目和参考清单。不可因 URL 存在就自动安装，更不可将“作者自测”当成 AETHER 实测。

## D. 最终推荐装配方案：明确唯一权威

| 层 | V1.3 决定 | 不这么做的原因 |
|---|---|---|
| 唯一任务状态权威 | **Temporal** + 自有 Goal/Task/Operation/Evidence Ledger | 避免 LangGraph/DBOS/Restate/APScheduler 共管恢复而重复副作用。 |
| 轻量 Agent 循环 | **AETHER 自有 typed agent loop** | 不把 DeepAgents/CrewAI/MAF 当第二个 supervisor。 |
| 编码 | **OpenHands SDK** 执行任务、**CodeGraph** 只读代码理解、ast-grep 可选改写 | 编码 Agent 和检索 Agent 不应拥有并行的任务发布权。 |
| 安全执行 | 受控 Docker 开发模式；敌意代码采用 **可替换 sandbox backend**，优先验证 microsandbox/E2B | Docker 开发空间 ≠ 已经过红队的 microVM 生产边界。 |
| 检索 | 自有采集→BM25S+pgvector+FlagEmbedding→RRF→reranker；LightRAG 仅研究 | 自主搜索不能由第三方图 RAG 产品取代全部索引与评测。 |
| 记忆 | 原始证据权威 = AETHER；Hindsight/Graphiti 竞争派生 MemoryEngine | 保证删除、纠错、租户隔离不会取决于一个外部引擎的自我说法。 |
| 工具 | AETHER 可信权限与凭证代理，MCP 仅接入层；OPA 可选策略执行 | MCP tool descriptions 是数据，不是授权。 |
| 前端 | Next.js 控制台，AG-UI 先做兼容 POC；MCP Apps 以后再引 | 控制台必须可展示真实任务、证据、审批和回滚。 |
| 多 Agent 外联 | A2A 作为可选远程 Agent adapter，内部子任务仍由 Temporal 管理 | 不把不受信远程 Agent 直接纳入内部工作流可信边界。 |
| 评测 | pydantic-evals/Inspect/Promptfoo + AgentDojo + 隐藏 holdout | 同一模型打分不能证明 agent 改善。 |
| 自我改进 | Skill Lab + 离线 DSPy/GEPA 对照，人工签发推广 | 自己生成的策略必须靠独立 grader 评判。 |
| 供应链 | 锁 SHA、SBOM (Syft)、漏洞 (OSV)、签名 (Cosign) | 不能仅人工检查 LICENSE 而忽视代码来源和已知漏洞。 |
| 通道 | 优先官方 Telegram/Discord；非官方 QQ/微信隔离且 opt-in | 降低封号与凭据泄漏风险。 |
| 语音/桌面 | 后续功能门控实验：LiveKit、Pipecat、Cua | 缺基线时不应因功能炫酷增加危险攻击面。 |

## E. 避免过度工程：第一批开发顺序

**立即执行**：账本与恢复关卡、安全沙箱平台探针、SBOM/依赖门禁、CodeGraph 代码快照与独立测试、AgentDojo 工具输出注入评测。

**小规模对照后决定**：Hindsight vs Graphiti、DSPy/GEPA 技能候选优化、AG-UI 控制台流式协议、官方 A2A SDK 对外互联、assistant-ui 组件。

**暂时只留接口**：大规模 Neo4j/FalkorDB 双图库、三种消息渠道同时上线、E2B 和 microsandbox 双运行、完整 Open WebUI 整机、Voice 全栈、多模型 finetuning、技能商店/商业化计费。

实验上线都应使用冻结 revision、合成/许可许可的数据、成功率/成本/安全三指标，失败必须保留 `not_run` 或 `blocked`，不得生成假的“通过”。

## F. 参考来源

- DeepSeek 上传的六章研究与综合报告（材料来源，不是外部真实性证明）
- AETHER V1.2 的 `docs/14_ecosystem_audit.md`、`config/ecosystem_candidates.yaml`、`tasks/backlog.yaml`
- 官方仓库/文档：A2A、AG-UI、MCP Apps、Hindsight、DSPy、AgentDojo、Syft、OSV-Scanner、Cosign、Temporal、LangGraph、AutoGen、microsandbox
- Stack Overflow 2026-05-27 官方博客与 arXiv:2610.03448

**说明**：本报告是选型审计/建议，不是完成集成的运行验收。它不能穷尽 GitHub 全部项目，且较新版本需在 Codex 实施时重新锁定和核验。

# Codex: AETHER V1.3 查漏增量实施指令

你当前在正在开发的 AETHER 项目中。请先读取项目现有 `AGENTS.md`、`MASTER_SPEC.md`、`STATUS.json`、`tasks/backlog.yaml`，以及随附的 `AETHER_DeepSeek材料包_差异审计_20261015.md` 与 `aether_v13_delta.yaml`。

目标：**增量合并** V1.3 审查结论；保留已有任务、源码、数据库迁移、测试与 Git 历史。先检查哪些功能已经实现，避免重写和重复依赖。需要提交代码和证据，而不只是报告。

约束：

1. **Temporal 是唯一负责持久任务状态、重试和恢复的调度权威**；不要按 DeepSeek 总纲把 LangGraph+APScheduler+Restate/DBOS 叠到现有架构中。允许 LangGraph 仅作离线研究/局部无副作用规划实验，前提是不得自行持久化外部任务。
2. **OpenHands SDK 仍是第一编码执行器**；CodeGraph/ast-grep 是 RepoIntelligence 能力，不替代独立 verifier。sandbox backend 独立于 OpenHands；先测宿主兼容，再决定微虚拟化后端。
3. Hindsight 与 Graphiti 只能作为受限、派生的候选记忆引擎；原始证据和权限始终属于 AETHER。没有完成同条件实验前，不宣布胜者。
4. AG-UI、A2A、MCP Apps 先分别写独立适配器协议和测试；仅 AG-UI streaming/approval POC 建议进入第一轮功能实验；A2A 外联、MCP Apps 按需后置。
5. 优先做 AgentDojo 类实际工具链注入测试和供应链门禁（Syft/OSV/Cosign）；检测器不能单独替代权限检查。所有网络外发要显式记录。
6. DSPy/GEPA 只在离线实验生成候选 prompt/skill；不得接触封存的 holdout 或自行部署发布。必须有统计上可信的对照和回滚。
7. 所有依赖根据具体 git SHA、license 与传递依赖审核；AutoGen 的代码是 MIT，文档是 CC-BY-4.0，不得沿用 DeepSeek 错误总结。
8. 任务按照 `aether_v13_delta.yaml` 的先后依赖逐项实现；每项的 `acceptance` 是交付门槛。新增默认 flag=false；已完成的工作需复用，不得重置进度。
9. 若环境不支持、无法访问外部模型或跑不起微虚拟化，清晰记录 `blocked`/`not_run`；不得谎称测试通过。不得自行 push、购买云资源或进行生产破坏性操作。

开始操作：建立安全的增量分支；按项目既有任务格式导入 delta ticket，但不要覆盖原有 `backlog.yaml`；先实施 **供应链/许可证核验和风险清单**，再实现一条端到端可复现的额外评测路径，最后才开启昂贵的长期记忆/优化实验。每项结束更新 STATUS 和 HANDOFF。
